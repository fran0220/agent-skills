# Archetype Recipe: Point & Click Adventure (point-click)

## 1. Archetype Identity
**ID:** point-click
**Name (EN):** Point & Click Adventure
**Name (CN):** 点击冒险类

**Definition:**
The Point & Click Adventure archetype is a narrative-driven genre where player interaction is primarily mediated through a cursor or direct touch, focusing on exploration, puzzle-solving, and character interaction rather than reflex-based action. Players navigate environments, collect items, converse with NPCs, and combine objects to progress through a carefully authored story. The pacing is typically deliberate, allowing players to absorb the atmosphere and narrative details at their own speed.

**Benchmark Games:**
*   *The Secret of Monkey Island* (1990)
*   *Grim Fandango* (1998)
*   *Machinarium* (2009)
*   *Disco Elysium* (2019)
*   *Return to Monkey Island* (2022)

## 2. Elemental Tetrad Analysis

**Mechanics:**
The core loops revolve around observation, collection, and logical deduction. Players scan environments for interactive hotspots, gather items into an inventory, and use these items on other objects or characters to solve puzzles. Dialogue trees are a primary mechanism for uncovering lore, gaining clues, and advancing the plot. The absence of fail states (like death) in many modern iterations shifts the focus entirely to progression through problem-solving.

**Aesthetics:**
Visually, these games often employ highly detailed, pre-rendered, or hand-drawn 2D backgrounds, though 3D environments are also common. The audio design relies heavily on atmospheric soundscapes, evocative musical scores, and extensive voice acting to bring characters to life. The overall aesthetic goal is to create a rich, immersive world that feels like a living illustration or a playable novel.

**Story:**
Narrative is the driving force of the Point & Click archetype. The structure is usually linear or branching, with a strong emphasis on character development, world-building, and thematic depth. Puzzles are integrated into the narrative, acting as roadblocks that make sense within the context of the story rather than arbitrary challenges.

**Technology:**
Technical requirements are generally low compared to action-heavy genres. The engine needs robust systems for state management (tracking inventory, dialogue choices, and puzzle states), pathfinding for character movement, and a flexible dialogue tree editor. High-quality asset streaming for audio and high-resolution 2D art is often more critical than complex physics or real-time rendering.

## 3. Atom Recipe Table

| Atom ID | Atom Name | Role in Archetype | Weight | Typical Config |
| :--- | :--- | :--- | :--- | :--- |
| `logic_deduction` | Logic Deduction | Core puzzle-solving mechanism requiring players to connect clues. | Core | `difficulty: moderate`, `hint_system: optional` |
| `branching_dialogue` | Branching Dialogue | Primary method for narrative delivery and NPC interaction. | Core | `node_limit: high`, `voice_acted: true` |
| `spatial_portal` | Spatial Portal | Moving between distinct scenes or rooms. | Important | `transition_time: fast` |
| `skill_check` | Skill Check | Used in RPG-hybrid variants (like Disco Elysium) to gate progress or alter outcomes based on character stats. | Optional | `rng_variance: low` |
| `multiple_endings` | Multiple Endings | Providing narrative payoff based on player choices throughout the game. | Important | `ending_count: 3-5` |
| `collection_log` | Collection Log | Tracking found documents, lore entries, or key items. | Important | `auto_update: true` |
| `evidence_contradiction` | Evidence Contradiction | Used in investigative variants to challenge NPC statements. | Optional | `penalty_on_fail: false` |
| `escape_room` | Escape Room | Self-contained puzzle sequences within a single location. | Optional | `time_limit: none` |

## 4. Atom Coupling Matrix

1.  **`logic_deduction` + `branching_dialogue`**
    *   **Dynamic:** Players must use information gleaned from dialogue to solve logical puzzles, or vice versa.
    *   **Aesthetic:** Creates a sense of intellectual satisfaction and deepens immersion in the narrative world.
2.  **`collection_log` + `logic_deduction`**
    *   **Dynamic:** Players review collected documents and items to find hidden connections or codes.
    *   **Aesthetic:** Fosters a feeling of investigation and discovery, rewarding meticulous exploration.
3.  **`branching_dialogue` + `multiple_endings`**
    *   **Dynamic:** Choices made in conversations accumulate to determine the final outcome of the story.
    *   **Aesthetic:** Enhances replayability and gives players a sense of agency and consequence.
4.  **`skill_check` + `branching_dialogue`**
    *   **Dynamic:** Dialogue options are gated or their success is determined by character attributes.
    *   **Aesthetic:** Adds RPG elements, making the protagonist feel unique and personalizing the narrative journey.
5.  **`spatial_portal` + `escape_room`**
    *   **Dynamic:** Players are locked in a specific set of rooms and must solve interconnected puzzles to unlock the portal to the next area.
    *   **Aesthetic:** Creates focused, intense bursts of puzzle-solving within the broader exploration.

## 5. MDA Chain

*   **Mechanics:** Point-and-click interface, inventory management, dialogue trees, state-based puzzle logic.
*   **Dynamics:** Scavenging for items, exhausting dialogue options, trial-and-error item combinations, logical deduction based on environmental clues.
*   **Aesthetics:** Narrative immersion, intellectual challenge (Submission), discovery, and the satisfaction of unraveling a mystery.

## 6. Variant Spectrum

1.  **Classic LucasArts Style:** Focuses heavily on inventory puzzles and humorous dialogue. (Atoms added: `physics_puzzle` (rarely), Atoms removed: `skill_check`, `multiple_endings` (often linear)).
2.  **Narrative RPG Hybrid:** Blends point-and-click exploration with deep RPG mechanics. (Atoms added: `skill_check`, `xp_level`, `class_job`. Atoms removed: traditional inventory puzzles).
3.  **Investigative Thriller:** Focuses on solving crimes or mysteries. (Atoms added: `evidence_contradiction`, `vision_cone` (for stealth segments). Atoms removed: whimsical elements).
4.  **Hidden Object Hybrid:** Simplifies puzzles in favor of finding items in cluttered scenes. (Atoms added: `time_limit` (sometimes). Atoms removed: complex `logic_deduction`).

## 7. Anti-Patterns

1.  **Moon Logic Puzzles:** Puzzles whose solutions are so obscure or illogical that players must resort to random trial-and-error or a walkthrough.
2.  **Pixel Hunting:** Requiring players to find a tiny, barely visible interactive hotspot to progress, leading to frustration rather than challenge.
3.  **Dead Ends:** Allowing players to progress to a point where the game becomes unwinnable because they missed an item earlier, without any warning.

## 8. Cross-Cutting Systems

*   **Monetization:** Typically premium (pay-once), though episodic releases were historically common.
*   **Social:** Generally single-player, but community discussion and walkthrough sharing are significant meta-social elements.
*   **Progression:** Narrative milestones and achievement systems (`achievement_system`) are the primary forms of meta-progression.
