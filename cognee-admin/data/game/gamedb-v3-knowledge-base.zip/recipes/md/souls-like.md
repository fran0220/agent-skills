# Archetype Recipe: Souls-like (魂类游戏)

## 1. Archetype Identity
- **ID**: souls-like
- **Name (EN)**: Souls-like
- **Name (CN)**: 魂类游戏
- **Definition**: 魂类游戏是一种以高难度、碎片化叙事、体力限制的战斗系统以及死亡惩罚（如掉落经验/货币）为核心特征的动作角色扮演游戏。玩家需要在不断试错中学习敌人的攻击模式，通过精准的闪避、格挡和攻击来取得胜利。地图设计通常采用高度互通的立体结构，并以检查点（如篝火）作为探索的基石。
- **Benchmark Games**:
  - *Dark Souls* (2011)
  - *Sekiro: Shadows Die Twice* (2019)
  - *Elden Ring* (2022)

## 2. Elemental Tetrad Analysis
- **Mechanics**: 核心循环围绕着“探索-战斗-死亡-复活-重新挑战”展开。战斗系统高度依赖体力管理（stamina_combat）和无敌帧（iframes）。死亡惩罚机制要求玩家在风险与收益之间做出权衡。
- **Aesthetics**: 视觉和听觉风格通常呈现出黑暗、破败、史诗感和压抑感。环境叙事占据主导地位，通过场景细节、物品描述和NPC的只言片语来构建世界观。
- **Story**: 叙事结构通常是碎片化和非线性的。玩家扮演一个微不足道的角色，在一个已经衰败或正在走向毁灭的世界中探索，逐渐拼凑出过去的真相。
- **Technology**: 需要精确的碰撞检测和动画帧控制，以确保战斗的公平性和打击感。复杂的AI行为树用于控制敌人的攻击模式和反应。

## 3. Atom Recipe Table

| atom_id | atom_name | role_in_archetype | weight | typical_config |
| :--- | :--- | :--- | :--- | :--- |
| stamina_combat | 体力战斗 | 限制玩家的攻击、闪避和格挡频率，强调策略性 | core | stamina_regen_rate: slow, action_cost: high |
| iframes | 无敌帧 | 提供通过精准操作规避伤害的手段 | core | dodge_iframes: 10-15 frames |
| dodge_roll | 翻滚闪避 | 最基础的规避伤害和调整位置的动作 | core | weight_load_impact: true |
| parry_riposte | 弹反处决 | 高风险高回报的防御反击机制 | important | parry_window: tight |
| checkpoint | 检查点 | 玩家复活、升级和重置世界状态的枢纽 | core | reset_enemies: true, heal_player: true |
| currency_dual | 双重货币 | 经验值与购买货币合二为一，增加死亡风险 | core | drop_on_death: true, recoverable: true |
| interconnected_map | 互通地图 | 鼓励探索，通过捷径连接不同区域，提升地图复用率 | core | shortcut_unlocks: frequent |
| ability_cooldown | 技能冷却 | 限制强力技能或法术的滥用 | optional | uses_per_checkpoint: limited |
| melee_combo | 近战连击 | 基础的攻击输出方式，需要根据敌人破绽选择连击长度 | important | animation_cancel: limited |
| xp_level | 经验升级 | 玩家提升属性的主要途径，需要消耗特定资源 | core | cost_scaling: exponential |

## 4. Atom Coupling Matrix
1. **stamina_combat + dodge_roll**:
   - **Interaction**: 翻滚闪避需要消耗体力，体力耗尽时无法闪避。
   - **Emergent Dynamic**: 玩家必须在攻击和保留体力用于闪避之间做出权衡，避免贪刀。
   - **Aesthetic**: 营造出紧张、步步为营的战斗体验。
2. **currency_dual + checkpoint**:
   - **Interaction**: 玩家在检查点休息会重置世界（复活敌人），但也是消耗货币（经验）升级的唯一地点。死亡会掉落货币，需要在下次复活后跑图捡回。
   - **Emergent Dynamic**: 玩家在携带大量货币时会面临巨大的心理压力，需要决定是继续探索寻找下一个检查点，还是原路返回消耗货币。
   - **Aesthetic**: 强化了风险与回报的刺激感，以及成功生还的释然感。
3. **iframes + parry_riposte**:
   - **Interaction**: 玩家可以选择利用无敌帧躲避攻击，或者冒着受伤的风险尝试弹反。
   - **Emergent Dynamic**: 鼓励玩家观察和学习敌人的攻击模式，熟练后可以从被动躲避转为主动压制。
   - **Aesthetic**: 带来极高的成就感和掌控感。
4. **interconnected_map + checkpoint**:
   - **Interaction**: 检查点数量稀少，但地图通过各种单向门、电梯等捷径相互连接。
   - **Emergent Dynamic**: 玩家在长时间探索后发现捷径并连通回已知检查点，形成“柳暗花明又一村”的体验。
   - **Aesthetic**: 极大地增强了探索的乐趣和对世界结构的认知。
5. **stamina_combat + melee_combo**:
   - **Interaction**: 每次攻击都会消耗体力，且攻击动作往往难以取消。
   - **Emergent Dynamic**: 玩家不能无脑按键连击，必须计算体力并预判敌人的硬直时间。
   - **Aesthetic**: 战斗显得沉重、真实且充满策略性。

## 5. MDA Chain
- **Mechanics**: 体力限制、死亡掉落、检查点重置、精准的碰撞与无敌帧、碎片化文本。
- **Dynamics**: 玩家在探索中不断试错，学习地图布局和敌人配置；在战斗中观察敌人动作，管理自身资源（体力、恢复道具）；在死亡后评估风险，决定行动路线。
- **Aesthetics**: 
  - **Challenge (挑战)**: 克服高难度带来的巨大成就感。
  - **Discovery (发现)**: 探索未知区域、解开世界观谜团的乐趣。
  - **Submission (臣服)**: 沉浸在一个充满压迫感和史诗感的黑暗奇幻世界中。

## 6. Variant Spectrum
1. **Sekiro-like (Action-focused)**:
   - **Atoms Added**: posture_meter (架势条), grapple_hook (抓钩), stealth_takedown (潜行暗杀).
   - **Atoms Removed**: stamina_combat (体力限制), xp_level (传统经验升级).
2. **2D Souls-vania**:
   - **Atoms Added**: double_jump (二段跳), air_dash (空中冲刺), ability_gating (能力锁).
   - **Atoms Removed**: 3D spatial awareness.
3. **Sci-fi Souls (e.g., The Surge)**:
   - **Atoms Added**: directional_parry (定向格挡), limb_targeting (部位破坏).
   - **Atoms Removed**: traditional magic systems.

## 7. Anti-Patterns
1. **Artificial Difficulty (堆怪/数值碾压)**: 仅仅通过增加敌人数量或不合理的伤害数值来提高难度，而不是通过设计复杂的攻击模式，这会破坏玩家“死得心服口服”的体验。
2. **Unfair Checkpoint Placement (恶意检查点)**: 检查点距离Boss房间过远，导致玩家每次挑战Boss前都需要进行漫长且无意义的跑图（Run-back），消耗玩家耐心。
3. **Clunky Controls (操作手感僵硬)**: 动画锁定时间过长或输入延迟，导致玩家无法准确执行战术意图，破坏了基于精准操作的战斗核心。

## 8. Cross-Cutting Systems
- **Asynchronous Multiplayer (异步多人)**: 玩家可以在地上留下建言（提示或欺骗），或者看到其他玩家死亡的幻影。
- **Invasion/Co-op (入侵/合作)**: 允许玩家进入他人的世界进行PVP战斗或协助击败Boss。
- **Fashion Souls (外观系统)**: 玩家在满足基本防御属性的前提下，热衷于搭配各种装备以追求独特的外观（outfit_scoring）。
