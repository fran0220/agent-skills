# Archetype Recipe: Arcade Racing

## 1. Archetype Identity

**ID:** `arcade-racing`
**Names:** Arcade Racing (English) / 街机竞速类 (Chinese)

Arcade Racing is a high-octane, accessible subgenre of racing games that prioritizes exhilarating speed, spectacular action, and immediate fun over realistic physics and simulation. These games often feature exaggerated drifting mechanics, generous catch-up systems (rubber-banding), and sometimes vehicular combat or item usage. The focus is on mastering track layouts, chaining boosts, and experiencing the sheer thrill of velocity in visually striking environments.

**Benchmark Games:**

| Game Name | Year | Platform |
| :--- | :--- | :--- |
| Mario Kart 8 Deluxe | 2017 | Nintendo Switch |
| Forza Horizon 5 | 2021 | PC, Xbox |
| Burnout Paradise | 2008 | PC, PS3, Xbox 360 |
| Need for Speed: Underground 2 | 2004 | PC, PS2, Xbox |

## 2. Elemental Tetrad Analysis

**Mechanics:** The core loop revolves around accelerating, steering, and braking, but heavily emphasizes drifting to build boost meter. Players navigate tracks or open worlds, collecting items or hitting checkpoints to extend time or gain advantages. Rubber-banding AI ensures races remain competitive until the finish line.

**Aesthetics:** Visually, these games often employ motion blur, vibrant colors, and dynamic camera angles to convey a profound sense of speed. Audio features roaring engines, screeching tires, and high-energy soundtracks (electronic, rock, or pop) that match the fast-paced gameplay.

**Story:** Narrative is usually minimal or serves merely as a backdrop, such as an underground racing festival or a grand prix tournament. The focus is on the player's progression from a rookie to a champion, unlocking new vehicles and customization options along the way.

**Technology:** Requires robust physics engines tuned for "fun" rather than realism, allowing for impossible jumps and forgiving collisions. Networking technology is crucial for seamless multiplayer experiences, handling fast-moving objects with minimal latency.

## 3. Atom Recipe Table

| Atom ID | Atom Name | Role in Archetype | Weight | Typical Config |
| :--- | :--- | :--- | :--- | :--- |
| `drift_boost` | Drift Boost | Core mechanic for cornering and gaining speed advantages. | Core | `boost_duration: variable`, `drift_angle_threshold: low` |
| `sprint_stamina` | Sprint/Nitrous | Provides temporary bursts of extreme speed. | Important | `stamina_type: nitrous`, `regen_rate: high` |
| `checkpoint` | Checkpoint | Structures races and extends time in classic arcade modes. | Core | `time_extension: true` |
| `projectile` | Projectile | Adds combat elements and unpredictability (e.g., shells, missiles). | Optional | `homing: true`, `damage_type: spin_out` |
| `rubber_banding` | Rubber-banding | Keeps races tight by boosting trailing players or slowing leaders. | Core | `catch_up_speed_multiplier: 1.2` |
| `combo_counter` | Combo Counter | Rewards chaining drifts, near-misses, or jumps. | Important | `combo_type: drift_chain`, `reward: score_multiplier` |
| `ghost_replay` | Ghost Replay | Allows players to race against their own or others' best times. | Important | `opacity: 0.5`, `collision: false` |

## 4. Atom Coupling Matrix

**Drift Boost and Combo Counter:** Chaining multiple drifts or maintaining a long drift increases the combo multiplier. This interaction creates an emergent dynamic where players engage in risk-reward cornering, pushing the limits of their vehicle's grip to maximize their score or boost reserves. The resulting aesthetic is a profound sensation of mastery and flow.

**Projectile and Rubber-banding:** Trailing players are more likely to receive powerful, homing projectiles to attack the leaders. This interaction leads to constant position shuffling, creating chaotic and unpredictable finishes where no lead is ever truly safe. It fosters an aesthetic of fellowship through shared frustration and triumph, as well as challenge.

**Sprint Stamina and Drift Boost:** Successfully executing drifts fills the nitrous or stamina meter. This interaction produces a continuous high-speed flow state where players must drift to boost, and boost to reach the next drift opportunity faster. The aesthetic outcome is a sensation of relentless speed.

**Checkpoint and Sprint Stamina:** Reaching checkpoints not only extends the timer but may also refill a portion of the nitrous meter. This interaction encourages the strategic use of boosting to ensure the vehicle reaches the next checkpoint just in time, creating tense, down-to-the-wire moments. It heavily contributes to the aesthetic of challenge and suspense.

**Ghost Replay and Drift Boost:** Players can study the ghost's racing lines and drift initiation points. This interaction allows for the iterative optimization of racing lines, as players visually compare their performance against the ideal path. The aesthetic is one of discovery and self-improvement.

## 5. MDA Chain

**Mechanics:** The foundational mechanics include drifting, boosting via nitrous, item collection, rubber-banding AI, and checkpoint timers. These elements form the basic verbs available to the player.

**Dynamics:** From these mechanics emerge dynamics such as position jockeying, risk-reward cornering (drifting close to walls for more boost), resource management (knowing when to use nitrous or items), and continuous momentum building.

**Aesthetics:** The ultimate emotional responses evoked are sensation (the visceral thrill of high speed and responsive controls), challenge (mastering complex track layouts and optimizing racing lines), and fellowship (the chaotic, competitive joy of multiplayer races, especially in kart racers).

## 6. Variant Spectrum

| Variant Name | Atoms Added | Atoms Removed | Description |
| :--- | :--- | :--- | :--- |
| Kart Racer | `projectile`, `random_item_box`, `character_stats` | `realistic_physics`, `open_world` | Focuses on chaotic multiplayer fun with items and exaggerated character designs. |
| Open World Arcade | `interconnected_map`, `collection_log`, `fast_travel` | `strict_laps`, `linear_progression` | Players explore a massive map, finding hidden collectibles and entering events seamlessly. |
| Combat Racing | `hitscan`, `health_bar`, `vehicle_destruction` | `rubber_banding`, `strict_racing_lines` | Winning is achieved either by crossing the finish line first or by destroying all opponents. |

## 7. Anti-Patterns

**Unfair Rubber-banding:** When the AI catch-up mechanic is too aggressive, making player skill feel irrelevant. If a player drives perfectly but is still overtaken by an AI that suddenly gains impossible speed, it causes immense frustration and breaks the illusion of fairness.

**Clunky Drifting:** In an arcade racer, drifting must feel intuitive and satisfying. If the drift initiation is inconsistent or the vehicle loses too much speed during a drift, the core loop breaks down, leading to a sluggish and unrewarding experience.

**Overpowered Catch-up Items:** Items like the "Blue Shell" in Mario Kart are iconic, but if they appear too frequently or cannot be countered in any way, they punish the leading player excessively and discourage skillful play, turning races into pure games of chance.

## 8. Cross-Cutting Systems

Many modern arcade racers use free-to-play economy models (`economy_f2p`) with premium currencies for cosmetic vehicle upgrades. Social multiplayer systems (`social_multiplayer`) such as guilds or clans allow players to pool scores and compete on global leaderboards. Regular content updates are often tied to a season rank (`season_rank`) and battle pass (`battle_pass`), featuring new cars, tracks, and cosmetics. Finally, a massive garage of unlockable vehicles acts as a collection log (`collection_log`), encouraging long-term engagement and completionist behavior.
