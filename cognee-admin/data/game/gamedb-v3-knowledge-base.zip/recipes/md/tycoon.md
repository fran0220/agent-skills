# Archetype Recipe: Tycoon (大亨经营类)

## 1. Archetype Identity
- **ID**: tycoon
- **Name (EN)**: Tycoon
- **Name (CN)**: 大亨经营类
- **Definition**: The Tycoon archetype centers around the construction, management, and economic optimization of a business, facility, or settlement. Players act as an omniscient manager, making strategic decisions regarding resource allocation, infrastructure layout, and operational efficiency to maximize profit, growth, or satisfaction metrics. The core gameplay loop involves investing resources to generate more resources, creating a satisfying sense of progression and mastery over complex, interacting systems.
- **Benchmark Games**:
  - *RollerCoaster Tycoon* (1999)
  - *Two Point Hospital* (2018)
  - *Planet Coaster* (2016)
  - *Cities: Skylines* (2015)

## 2. Elemental Tetrad Analysis
- **Mechanics**: The core loops revolve around resource generation, expenditure, and optimization. Players place structures (nodes) that interact with each other and the environment. Systems include economic simulation (supply/demand, income/expenses), agent behavior (guests, employees, citizens), and spatial management (layout efficiency, zoning). Progression is driven by unlocking new technologies, structures, or scenarios.
- **Aesthetics**: Visuals often emphasize a "god game" perspective, typically isometric or top-down 3D, allowing players to oversee their creation. The style can range from realistic simulations to stylized, cartoonish environments (e.g., *Two Point Hospital*). Audio features ambient sounds of the bustling environment, satisfying UI feedback for construction and income, and dynamic music that scales with the size or success of the enterprise.
- **Story**: Narrative is usually emergent, driven by the player's successes, failures, and the unique situations that arise from the simulation. Formal storytelling is often limited to scenario briefings, campaign objectives, or humorous flavor text describing items and events. The true story is the history of the player's creation.
- **Technology**: Requires robust simulation engines capable of handling hundreds or thousands of independent agents (pathfinding, decision-making, needs fulfillment) simultaneously. Efficient rendering of complex, dense environments and dynamic UI systems for data visualization (heatmaps, graphs, ledgers) are critical.

## 3. Atom Recipe Table

| Atom ID | Atom Name | Role in Archetype | Weight | Typical Config |
| :--- | :--- | :--- | :--- | :--- |
| resource_gathering | Resource Gathering | The foundation of the economy; acquiring the means to build and expand. | Core | `{"auto_gather": true, "rate_multiplier": 1.0}` |
| currency_dual | Dual Currency | Separating basic economic flow (money) from premium or specialized resources (e.g., reputation, research points). | Important | `{"primary": "money", "secondary": "reputation"}` |
| tech_tree | Tech Tree | Providing long-term goals and unlocking new structures/efficiencies. | Core | `{"node_cost_scaling": "exponential"}` |
| node_map | Node Map | The spatial representation of the player's enterprise; where structures are placed. | Core | `{"grid_based": true, "cell_size": 1}` |
| zoning_system | Zoning System | Designating areas for specific purposes (e.g., residential, commercial, staff-only). | Important | `{"zone_types": ["public", "staff", "utility"]}` |
| colonist_ai | Colonist AI | The agents (guests, staff) that interact with the player's creation, driving needs and generating income. | Core | `{"needs": ["hunger", "energy", "fun"], "pathfinding": "a_star"}` |
| belt_conveyor | Belt Conveyor | (In specific variants) Automating the physical movement of resources between nodes. | Optional | `{"speed": 1.0, "capacity": 1}` |
| achievement_system | Achievement System | Providing meta-goals and rewarding specific playstyles or milestones. | Optional | `{"visible_progress": true}` |
| daily_weekly_reset | Daily/Weekly Reset | (In live-service variants) Structuring recurring engagement and income. | Optional | `{"reset_time": "00:00 UTC"}` |
| random_affix | Random Affix | Applying modifiers to scenarios, guests, or events to increase variety and challenge. | Important | `{"event_frequency": "medium"}` |

## 4. Atom Coupling Matrix

1. **`node_map` + `colonist_ai`**:
   - **Interaction**: Agents navigate the spatial layout created by the player to fulfill their needs.
   - **Emergent Dynamic**: Traffic jams, inefficient pathing, and localized areas of high/low satisfaction based on structure placement.
   - **Aesthetic**: The visual satisfaction of a well-oiled machine vs. the chaos of poor planning; the "ant farm" effect.

2. **`resource_gathering` + `tech_tree`**:
   - **Interaction**: Accumulated resources are spent to unlock nodes on the tech tree, which in turn provide better resource gathering methods.
   - **Emergent Dynamic**: The core progression loop; players must balance spending on immediate expansion vs. long-term technological investment.
   - **Aesthetic**: A sense of continuous growth, technological advancement, and increasing complexity.

3. **`zoning_system` + `colonist_ai`**:
   - **Interaction**: Zones dictate where specific agents can go and what activities they can perform.
   - **Emergent Dynamic**: Segregation of staff and guests, optimization of workflows, and managing the "attractiveness" or "efficiency" of different areas.
   - **Aesthetic**: Order and control; the satisfaction of creating specialized, functional districts.

4. **`currency_dual` + `random_affix`**:
   - **Interaction**: Random events or modifiers affect the generation or expenditure of different currencies (e.g., a health inspection costs money but boosts reputation if passed).
   - **Emergent Dynamic**: Risk management and crisis response; players must maintain reserves of both currencies to handle unexpected situations.
   - **Aesthetic**: Tension and relief; the challenge of adapting to a dynamic economic environment.

5. **`belt_conveyor` + `node_map`**:
   - **Interaction**: Conveyors physically connect nodes on the map, automating resource transport.
   - **Emergent Dynamic**: Complex logistical networks, bottleneck identification, and spatial optimization of production lines.
   - **Aesthetic**: The mesmerizing visual flow of resources; the satisfaction of perfect automation and efficiency.

## 5. MDA Chain
- **Mechanics**: Placing structures on a grid (`node_map`), managing income and expenses (`resource_gathering`, `currency_dual`), researching upgrades (`tech_tree`), and observing agent behavior (`colonist_ai`).
- **Dynamics**: Balancing budgets, optimizing spatial layouts to reduce travel time, responding to fluctuating demand or random events, and scaling operations from a small startup to a massive enterprise.
- **Aesthetics**:
  - *Expression*: Designing a unique layout and aesthetic for the enterprise.
  - *Challenge*: Overcoming economic hurdles and optimizing complex systems.
  - *Discovery*: Unlocking new technologies and understanding the deep simulation mechanics.
  - *Submission*: The relaxing, almost hypnotic experience of watching the simulation run smoothly (the "ant farm" appeal).

## 6. Variant Spectrum
1. **Theme Park/Resort Tycoon**: Focuses heavily on guest satisfaction, aesthetics, and ride/attraction design. (Adds: `room_decoration`, `physics_puzzle` for coaster design; Removes: `belt_conveyor`).
2. **Factory/Automation Tycoon**: Focuses on logistical efficiency, production chains, and resource processing. (Adds: `belt_conveyor`, `physics_puzzle` for routing; Removes: `colonist_ai` needs management).
3. **City Builder**: Focuses on macro-level zoning, infrastructure (roads, power, water), and managing a large population's macro-needs. (Adds: `zoning_system` emphasis, `procedural_gen` for terrain; Removes: micro-management of individual `colonist_ai`).
4. **Survival/Colony Sim**: Blends tycoon mechanics with harsh environmental challenges and survival elements. (Adds: `permadeath` (for colonists), `biome_system`, `day_night_cycle`; Removes: purely aesthetic `room_decoration`).

## 7. Anti-Patterns
1. **The Waiting Game**: When the primary challenge is simply waiting for resources to accumulate without any meaningful decisions to make in the interim. This breaks the engagement loop.
2. **Opaque Simulation**: When the rules governing agent behavior or economic shifts are hidden or illogical, preventing players from making informed decisions or understanding why their strategies fail.
3. **Runaway Snowball**: When early success guarantees infinite wealth, removing all challenge and tension from the mid-to-late game. The economy must have sinks and scaling costs to maintain engagement.

## 8. Cross-Cutting Systems
- **Economy/Monetization**: In F2P variants, premium currencies (`currency_dual`) are often used to speed up construction timers or purchase exclusive cosmetic items.
- **Social/Multiplayer**: Leaderboards for wealth or efficiency, visiting friends' parks/cities, or asynchronous trading of resources.
- **Progression**: Meta-progression across different scenarios or cities, unlocking permanent bonuses or new starting conditions.
