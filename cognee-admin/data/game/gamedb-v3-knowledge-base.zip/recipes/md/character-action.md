# Archetype Recipe: Character Action (角色动作类)

## 1. Archetype Identity

**ID:** `character-action`
**Names:** Character Action, 角色动作类, Spectacle Fighter, Stylish Action

**Definition:**
The Character Action archetype is a subgenre of action games that emphasizes high-speed, complex, and stylish melee combat against multiple enemies and massive bosses. Unlike traditional beat-'em-ups or action RPGs, Character Action games prioritize player expression through an extensive repertoire of moves, demanding precise execution, timing, and situational awareness. The core loop revolves around mastering a deep combat system to achieve high scores or "style" rankings, encouraging players to not just defeat enemies, but to do so with flair, variety, and uninterrupted offensive flow.

**Benchmark Games:**
*   *Devil May Cry 5* (2019) - PC, PS4, Xbox One
*   *Bayonetta 3* (2022) - Nintendo Switch
*   *Ninja Gaiden Black* (2005) - Xbox
*   *Metal Gear Rising: Revengeance* (2013) - PC, PS3, Xbox 360
*   *Astral Chain* (2019) - Nintendo Switch

---

## 2. Elemental Tetrad Analysis

Based on Jesse Schell's framework, the Character Action archetype can be broken down into four fundamental elements:

### Mechanics
The core loops and systems are heavily focused on combat mechanics. Players are given a vast array of offensive and defensive tools, including light and heavy attacks, launchers, aerial combos, dodges, and parries. The defining mechanic is often the **Style Meter**, which grades the player's performance in real-time based on combo variety, damage avoidance, and continuous aggression. Resource management (like Devil Trigger or magic gauges) allows for powerful, temporary transformations or special attacks. The progression system usually involves purchasing new moves or upgrading existing ones using currency earned from combat performance.

### Aesthetics
The visual and audio style patterns are designed to be bombastic, over-the-top, and highly kinetic. "Spectacle" is a key word here. Animations are exaggerated and fluid, with distinct hit-stops and visual effects to emphasize impact. The camera work is dynamic, often pulling back to show the scale of boss fights or zooming in for stylish finishing moves. The soundtrack is typically high-energy—often heavy metal, electronic, or hard rock—that dynamically shifts in intensity based on the player's current style rank, further reinforcing the feeling of being an unstoppable force.

### Story
The narrative structure patterns usually follow a highly capable, often cocky or stoic protagonist facing overwhelming odds, typically involving supernatural or sci-fi threats (demons, angels, cyborgs). The story serves primarily as a vehicle to move the player from one spectacular set-piece battle to the next. Cutscenes are heavily choreographed and action-packed, often mirroring the over-the-top nature of the gameplay itself. The tone can range from campy and self-aware to dark and melodramatic, but the focus remains on the protagonist's sheer power and skill.

### Technology
Typical technical requirements demand a rock-solid, high framerate (traditionally 60 FPS) to ensure responsive inputs and precise timing windows for dodges and parries. The engine must handle complex animation blending, hit detection, and collision physics seamlessly. Furthermore, the game needs robust AI systems that can coordinate multiple enemies attacking simultaneously without overwhelming the player unfairly, often utilizing off-screen attack indicators or token-based attack systems.

---

## 3. Atom Recipe Table

The following table lists the required gameplay atoms that construct the Character Action archetype.

| Atom ID | Atom Name | Role in Archetype | Weight | Typical Config |
| :--- | :--- | :--- | :--- | :--- |
| `melee_combo` | Melee Combo | The foundation of offense; allows for branching attack strings and player expression. | Core | `cancelable: true`, `branching: true`, `input_buffer: medium` |
| `style_meter` | Style Meter | The primary intrinsic motivator; grades combat performance and encourages variety. | Core | `decay_rate: fast`, `variety_bonus: high`, `taunt_boost: true` |
| `dodge_roll` | Dodge Roll | The primary defensive tool; provides mobility and invincibility frames. | Core | `iframes: 10-15 frames`, `recovery_cancel: true` |
| `iframes` | Invincibility Frames | Crucial for surviving dense enemy attacks; rewards precise timing. | Core | `perfect_dodge_bonus: true`, `visual_cue: subtle` |
| `combo_counter` | Combo Counter | Tracks consecutive hits; feeds into the style meter and end-of-level scoring. | Core | `visual_prominence: high`, `reset_on_hit: true` |
| `air_dash` | Air Dash | Enhances aerial mobility; used for closing gaps or extending air combos. | Important | `charges: 1-2`, `reset_on_enemy_step: true` |
| `double_jump` | Double Jump | Provides vertical mobility and another layer of evasion. | Important | `enemy_step: true` (jumping off enemies resets jump) |
| `parry_riposte` | Parry & Riposte | High-risk, high-reward defensive option; often staggers enemies or reflects projectiles. | Important | `timing_window: strict (3-5 frames)`, `style_boost: massive` |
| `skill_tree` | Skill Tree | The primary progression system; unlocks new moves to expand the player's arsenal. | Important | `currency: performance_based_orbs` |
| `boss_fight` | Boss Fight | The ultimate test of the player's mastery over the combat mechanics. | Core | `phases: 2-4`, `telegraphed_attacks: clear` |
| `lock_on` | Lock-On System | Helps focus attacks on specific targets in chaotic encounters. | Important | `soft_lock: true`, `hard_lock_toggle: true` |
| `weapon_switching` | Weapon Switching | Allows changing weapons mid-combo to extend strings and increase style. | Core | `delay: 0 frames (instant)` |

---

## 4. Atom Coupling Matrix

The emergent gameplay in Character Action games arises from the intricate interactions between these core atoms. Here are the 5 most important couplings:

1.  **`melee_combo` + `style_meter`**
    *   **Interaction:** Executing varied and complex melee combos increases the style meter, while repeating the same simple combo causes the meter to stagnate or decay.
    *   **Emergent Dynamic:** Players are pushed out of their comfort zones. Instead of finding one optimal, safe attack and spamming it, they must constantly rotate their moveset, adapting to the situation to maintain a high rank.
    *   **Aesthetic:** Creates a feeling of "Expression" and "Challenge," as players strive to look as cool as possible while fighting efficiently.

2.  **`dodge_roll` (with `iframes`) + `melee_combo`**
    *   **Interaction:** Dodging an attack at the last possible moment (utilizing iframes) often allows the player to instantly transition back into a melee combo, sometimes with a specific counter-attack move.
    *   **Emergent Dynamic:** Defense becomes an offensive tool. Players learn to stay in the pocket, dodging through attacks rather than running away, maintaining continuous pressure on the enemy.
    *   **Aesthetic:** Fosters a sense of "Flow" and "Mastery," where the player dances through danger untouched.

3.  **`double_jump` (Enemy Step) + `melee_combo`**
    *   **Interaction:** Jumping off an enemy's head (Enemy Step) resets the player's aerial mobility (double jump, air dash) and attack animations.
    *   **Emergent Dynamic:** Allows for "jump canceling," enabling skilled players to stay airborne indefinitely, juggling enemies and bypassing the normal recovery frames of heavy attacks.
    *   **Aesthetic:** Delivers the ultimate "Spectacle" and "Fantasy" of defying gravity and dominating opponents in the air.

4.  **`weapon_switching` + `combo_counter`**
    *   **Interaction:** Instantly switching weapons mid-animation allows the player to string together attacks from different weapons into a single, massive combo.
    *   **Emergent Dynamic:** Exponentially increases the complexity and potential length of combos. Players must memorize the properties of multiple weapons and how they link together.
    *   **Aesthetic:** Enhances "Expression" and "Variety," making high-level play look incredibly diverse and personalized.

5.  **`parry_riposte` + `style_meter`**
    *   **Interaction:** Successfully parrying an attack with a strict timing window grants a massive, immediate boost to the style meter and often leaves the enemy vulnerable.
    *   **Emergent Dynamic:** Incentivizes high-risk behavior. Players will actively seek out parry opportunities rather than just dodging, trading safety for a higher score and faster kill times.
    *   **Aesthetic:** Creates moments of intense "Tension" followed by immense "Release" and satisfaction.

---

## 5. MDA Chain

The Mechanics, Dynamics, and Aesthetics (MDA) framework illustrates how the foundational rules of the Character Action archetype create the final player experience.

*   **Mechanics (The Rules):**
    *   A vast, unlockable moveset with branching inputs (pauses, directional inputs).
    *   A Style Meter that grades variety, damage avoidance, and aggression.
    *   Precise defensive tools (dodges, parries) with specific invincibility frames.
    *   Mechanics that allow for animation canceling (e.g., jump canceling, weapon switching).
    *   Enemies with distinct attack patterns and telegraphs.

*   **Dynamics (The Play):**
    *   **Continuous Offensive Pressure:** The game discourages passive play; the player must constantly attack to maintain their style rank.
    *   **Risk-Reward Decision Making:** Choosing whether to attempt a strict parry for a huge style boost or a safer dodge roll.
    *   **Execution and Memorization:** Learning complex button combinations and the specific timing required to link them together seamlessly.
    *   **Spatial Awareness and Crowd Control:** Managing multiple enemies, prioritizing targets, and using positioning to avoid off-screen attacks.

*   **Aesthetics (The Experience):**
    *   **Expression:** The combat system is deep enough that two players can defeat the same encounter in completely different, personalized ways.
    *   **Challenge:** The satisfaction of mastering difficult, demanding mechanics and achieving the highest possible rank (e.g., an "S" or "SSS" rank).
    *   **Fantasy:** The power fantasy of controlling an overwhelmingly skilled, stylish protagonist who effortlessly dispatches hordes of enemies.
    *   **Flow:** Entering a "zone" where inputs become second nature, and the player reacts instinctively to the chaos on screen.

---

## 6. Variant Spectrum

The Character Action archetype can be modified by adding or removing specific atoms to create distinct sub-genres:

1.  **Souls-lite Action (e.g., *Sekiro: Shadows Die Twice*, *Stellar Blade*)**
    *   **Atoms Added:** `stamina_combat` (or posture meter), `permadeath_lite` (punishing checkpoints), `interconnected_map`.
    *   **Atoms Removed:** `style_meter`, `infinite_juggling`, `complex_branching_combos`.
    *   **Shift:** Moves the focus from expressive, prolonged combos to deliberate, high-stakes strikes and rhythmic parrying.

2.  **Musou / Warriors (e.g., *Dynasty Warriors*, *Hyrule Warriors*)**
    *   **Atoms Added:** `crowd_combat` (hundreds of weak enemies), `territory_control`, `kill_counter`.
    *   **Atoms Removed:** `strict_iframes`, `complex_enemy_ai`, `strict_timing_windows`.
    *   **Shift:** Focuses on the macro-level power fantasy of destroying entire armies rather than the micro-level mastery of 1v1 or 1v3 combat.

3.  **Action RPG (e.g., *NieR: Automata*, *Genshin Impact*)**
    *   **Atoms Added:** `loot_rarity`, `xp_level`, `random_affix`, `elemental_reaction`.
    *   **Atoms Removed:** `style_meter` (usually), `strict_animation_canceling`.
    *   **Shift:** Player power is determined more by stats, gear, and team composition than pure mechanical execution and combo memorization.

4.  **2D Character Action (e.g., *Guacamelee!*, *Odin Sphere*)**
    *   **Atoms Added:** `platforming_challenges`, `metroidvania_gating`.
    *   **Atoms Removed:** `3d_camera_control`, `z-axis_dodging`.
    *   **Shift:** Translates the complex combos and juggling into a 2D plane, often blending it with exploration elements.

---

## 7. Anti-Patterns

When designing a Character Action game, these are the three most common design failures to avoid:

1.  **The "Spongy" Enemy Problem:**
    *   **Failure:** Giving enemies too much health without giving them interesting behaviors or hit reactions (staggering).
    *   **Result:** Combat becomes a tedious chore. If an enemy doesn't react to being hit, the player's attacks feel weightless, destroying the power fantasy and making long combos feel pointless rather than stylish.

2.  **Off-Screen Untelegraphed Attacks:**
    *   **Failure:** Allowing enemies outside the player's field of view to initiate fast, untelegraphed attacks.
    *   **Result:** Feels incredibly unfair. In a game that demands perfection for high scores, taking damage from an source the player couldn't possibly see or react to leads to immense frustration. (Solution: Implement an "attack token" system where off-screen enemies are restricted from attacking, or provide clear audio/visual warnings).

3.  **Overly Restrictive Stamina Meters:**
    *   **Failure:** Implementing a harsh stamina system that limits basic attacks and dodges in a game meant to be about continuous, stylish offense.
    *   **Result:** Breaks the flow of combat. Character Action games are about *what* you do and *how* you do it, not *whether* you have the energy to do it. Stamina systems belong in deliberate, tactical action games (like Souls-likes), not spectacle fighters.

---

## 8. Cross-Cutting Systems

While traditionally single-player, premium experiences, modern iterations or live-service adaptations of the Character Action archetype often layer these systems on top:

*   **`gacha_banner` & `character_collection`:** (e.g., *Zenless Zone Zero*, *Honkai Impact 3rd*) Players roll for new characters, each with their own unique Character Action moveset, encouraging team building and weapon switching between distinct characters rather than just weapons.
*   **`economy_f2p` & `daily_weekly_reset`:** Implementing energy systems for running specific combat domains to grind for upgrade materials or artifacts (`random_affix`).
*   **`battle_pass`:** Rewarding players with cosmetics, currency, or upgrade materials for completing specific combat challenges or playing regularly.
*   **`leaderboards` & `asynchronous_multiplayer`:** Allowing players to compare their high scores, clear times, and style rankings on specific stages or boss fights against friends or globally.
*   **`roguelite_mode` (Run-Based):** A separate mode where players draft random buffs, new moves, or modifiers (`card_draft`, `random_affix`) as they progress through a series of increasingly difficult combat rooms.
