# Auto-Battler Archetype Recipe

## 1. Archetype Identity
- **ID**: auto-battler
- **Names**: Auto-Battler (自动战棋类)
- **Definition**: A strategic multiplayer game genre where players draft units from a shared pool, build synergies, and place them on a grid. Combat resolves automatically without direct player input during the battle phase. Success relies on economy management, probability calculation, and adapting to random shop offerings.
- **Benchmark Games**:
  - Teamfight Tactics (2019)
  - Dota Underlords (2019)
  - Auto Chess (2019)
  - Hearthstone Battlegrounds (2019)

## 2. Elemental Tetrad Analysis
- **Mechanics**: Core loops involve a preparation phase (buying units, managing economy, placing units on a board) and a combat phase (automated battles against other players or PvE waves). Systems include shared unit pools, interest-based economy, and unit combining (e.g., 3 copies make a 2-star unit).
- **Aesthetics**: Visuals often feature a chessboard-like grid with distinct, recognizable character models. Audio cues emphasize the satisfaction of combining units, winning rounds, and triggering powerful abilities.
- **Story**: Narrative is usually minimal, serving as a thematic wrapper for the units and synergies (e.g., factions, races, classes).
- **Technology**: Requires robust server-side logic to handle simultaneous automated battles, shared pool tracking, and matchmaking for 8-player lobbies.

## 3. Atom Recipe Table

| Atom ID | Atom Name | Role in Archetype | Weight | Typical Config |
|---------|-----------|-------------------|--------|----------------|
| card_draft | Card Draft | Core mechanic for acquiring units from a shared shop | Core | `pool_shared: true` |
| wave_system | Wave System | Structures the game into distinct preparation and combat rounds | Core | `pvp_rounds: true` |
| tower_placement | Tower Placement | Positioning units on the grid before combat | Core | `grid_based: true, auto_combat: true` |
| elemental_reaction | Elemental Reaction | Trait synergies when combining specific unit types | Core | `trait_synergy: true` |
| xp_level | XP Level | Determines max units on board and shop tier probabilities | Important | `unit_star_level: true` |
| currency_dual | Dual Currency | Managing gold for buying units vs leveling up | Important | `gold_interest: true` |
| random_affix | Random Affix | Item drops and augment choices | Important | `augment_system: true` |
| pvp_arena | PvP Arena | 8-player free-for-all matchmaking | Core | `lobby_size: 8` |

## 4. Atom Coupling Matrix
1. **card_draft + elemental_reaction**: Drafting specific units builds trait synergies. This creates the emergent dynamic of strategic pivoting based on shop RNG, leading to an aesthetic of discovery and expression.
2. **currency_dual + xp_level**: Spending gold to level up the player vs rolling for units. This creates the dynamic of economy management and power spikes, leading to an aesthetic of challenge and strategy.
3. **tower_placement + wave_system**: Positioning units before each automated combat wave. This creates the dynamic of scouting and counter-positioning, leading to an aesthetic of anticipation and tactical depth.
4. **card_draft + pvp_arena**: Drafting from a shared pool in a multiplayer lobby. This creates the dynamic of contesting units and scouting opponents' boards, leading to an aesthetic of competition and fellowship.
5. **random_affix + elemental_reaction**: Equipping items or choosing augments that enhance specific traits. This creates the dynamic of adapting builds to random drops, leading to an aesthetic of novelty and mastery.

## 5. MDA Chain
- **Mechanics**: Shared unit pool drafting, grid-based auto combat, economy interest system, trait synergies, unit combining.
- **Dynamics**: Risk vs reward in economy (saving for interest vs rolling to survive), adapting to RNG (shop offerings, item drops), scouting opponents to contest or avoid contested builds, transitioning team compositions mid-game.
- **Aesthetics**: Discovery (finding new synergies), Challenge (mastering economy and positioning), Fellowship (competing in an 8-player lobby), Expression (building unique team compositions).

## 6. Variant Spectrum
- **Single-player Auto-Battler**: Adds `meta_progression` and `permadeath`, removes `pvp_arena` and `shared_pool`. Focuses on PvE roguelike progression (e.g., Super Auto Pets campaign mode).
- **Action Auto-Battler**: Adds `action_points` and `dodge_roll`, removes `grid_based`. Players control a main character while drafted units fight automatically (e.g., Mechabellum with active abilities).
- **Deckbuilding Auto-Battler**: Adds `deck_thinning` and `relic_artifact`. Combines auto-battler combat with Slay the Spire-style map progression.

## 7. Anti-Patterns
1. **Over-reliance on RNG**: If shop offerings and item drops dictate the winner too heavily, players feel a lack of agency.
2. **Snowballing Economy**: If early wins provide too much economic advantage without catch-up mechanics (like loss streaks), the game becomes decided too early.
3. **Unclear Combat Clarity**: If visual effects during the auto-combat phase are too chaotic, players cannot understand why they won or lost, hindering learning.

## 8. Cross-Cutting Systems
- **Economy/Monetization**: `economy_f2p` (cosmetics, arenas, little legends).
- **Social**: `social_multiplayer` (party queuing).
- **Progression**: `season_rank` (ladder climbing), `battle_pass` (seasonal rewards).
