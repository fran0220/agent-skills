# Archetype Recipe: Wave Survival (波次生存类)

## 1. Archetype Identity
**ID:** `wave-survival`
**English Name:** Wave Survival
**Chinese Name:** 波次生存类

**Definition:**
Wave Survival is a subgenre of action roguelites characterized by surviving increasingly difficult hordes of enemies over a set period or number of waves. The core gameplay loop revolves around maneuvering a character to avoid damage while automatically or manually attacking enemies, collecting dropped resources (like XP gems), and selecting randomized upgrades upon leveling up to create synergistic builds capable of handling the escalating threat.

**Benchmark Games:**
- *Vampire Survivors* (2021)
- *Brotato* (2022)
- *20 Minutes Till Dawn* (2022)
- *Magic Survival* (2019)

## 2. Elemental Tetrad Analysis

**Mechanics:**
The core loop consists of movement, automatic or simple attacks, enemy destruction, XP collection, and randomized leveling up. Systems include wave-based enemy spawning with exponential scaling, a vast pool of weapons and passive items, and meta-progression that carries over between runs.

**Aesthetics:**
Visually, these games often feature high-contrast, readable sprites to manage screen clutter when hundreds of entities are present. Audio is characterized by satisfying, repetitive feedback loops (e.g., the sound of collecting XP gems or leveling up) that induce a trance-like flow state.

**Story:**
Narrative is typically minimal or non-existent, serving only as a loose framing device for the action. The focus is entirely on the mechanical progression and the emergent "story" of the player's build during a specific run.

**Technology:**
The primary technical requirement is the ability to handle massive numbers of independent entities (enemies, projectiles, XP gems) on screen simultaneously without performance degradation. This often necessitates optimized collision detection, object pooling, and efficient rendering techniques.

## 3. Atom Recipe Table

| Atom ID | Atom Name | Role in Archetype | Weight | Typical Config |
| :--- | :--- | :--- | :--- | :--- |
| `wave_system` | Wave System | Dictates the pacing and escalation of enemy threats. | Core | `duration: 15-30m, scaling: exponential` |
| `xp_level` | XP & Leveling | Drives the in-run progression and upgrade frequency. | Core | `drop_on_kill: true, collection_radius: variable` |
| `random_affix` | Random Affixes/Upgrades | Provides build variety and roguelite replayability. | Core | `pool_size: large, rarity_weights: standard` |
| `run_based` | Run-Based Structure | Frames the gameplay session and resets progress. | Core | `session_length: fixed` |
| `permadeath` | Permadeath | Enforces the stakes of the run. | Core | `reset_inventory: true` |
| `meta_progression` | Meta Progression | Provides long-term goals and permanent power increases. | Important | `currency: gold, upgrades: stat_boosts` |
| `projectile` | Projectiles | The primary method of interacting with enemies. | Important | `pierce: high, bounce: optional` |
| `ability_cooldown` | Ability Cooldowns | Regulates the frequency of attacks. | Important | `reduction_stat: haste` |
| `achievement_system` | Achievement System | Guides player goals and unlocks new content. | Important | `unlocks_items: true` |
| `dodge_roll` | Dodge Roll | Provides active defensive options in some variants. | Optional | `iframes: short` |

## 4. Atom Coupling Matrix

1. **`wave_system` + `xp_level`**
   - **Interaction:** Enemies spawned by the wave system drop XP upon death, which must be collected to level up.
   - **Emergent Dynamic:** Creates a risk/reward dynamic where players must wade into dangerous enemy swarms to collect the resources needed to survive future waves.
   - **Aesthetic:** Tension and release, driving the player into a flow state.

2. **`random_affix` + `projectile`**
   - **Interaction:** Randomized upgrades modify the behavior, count, and damage of projectiles.
   - **Emergent Dynamic:** Allows players to discover broken synergies and screen-clearing combinations without complex inputs.
   - **Aesthetic:** Power fantasy and discovery.

3. **`permadeath` + `meta_progression`**
   - **Interaction:** Dying ends the run but awards currency that can be spent on permanent upgrades.
   - **Emergent Dynamic:** Softens the blow of failure and ensures that even unsuccessful runs contribute to long-term success.
   - **Aesthetic:** Submission (grinding) and a compelling "one more run" loop.

4. **`run_based` + `achievement_system`**
   - **Interaction:** Completing specific tasks during a run unlocks new items or characters for future runs.
   - **Emergent Dynamic:** Encourages players to experiment with different playstyles and builds rather than sticking to a single optimal strategy.
   - **Aesthetic:** Challenge and completionism.

5. **`xp_level` + `ability_cooldown`**
   - **Interaction:** Leveling up allows players to reduce ability cooldowns, increasing attack frequency.
   - **Emergent Dynamic:** Transforms the pacing from slow, deliberate attacks early in the run to a chaotic, continuous barrage of abilities in the late game.
   - **Aesthetic:** Escalating spectacle and power fantasy.

## 5. MDA Chain

**Mechanics:**
- Movement (WASD/Joystick)
- Auto-firing weapons with specific targeting rules
- Enemy spawning in escalating waves
- XP gem drops on enemy death
- Randomized upgrade selection on level up
- Gold collection for meta-progression

**Dynamics:**
- **Kiting and Herding:** Manipulating enemy pathing to group them up for efficient area-of-effect damage.
- **Risk-Reward Gathering:** Deciding when it is safe to push into a horde to collect a massive pile of XP gems.
- **Build Optimization:** Selecting upgrades that synergize with existing weapons to maximize damage output.
- **Power Curve Management:** Staying ahead of the enemy scaling curve to avoid being overwhelmed.

**Aesthetics:**
- **Challenge:** Overcoming seemingly impossible odds through smart build choices and movement.
- **Fantasy:** Becoming an unstoppable force of destruction.
- **Discovery:** Finding new, overpowered combinations of items.
- **Submission:** Entering a zen-like flow state where movement and decision-making become instinctual.

## 6. Variant Spectrum

1. **Bullet Heaven (e.g., Vampire Survivors)**
   - **Added:** `auto_attack`, `screen_clear`
   - **Removed:** `manual_aim`, `dodge_roll`
   - **Focus:** Pure build optimization and movement, minimizing mechanical execution.

2. **Arena Shooter Survival (e.g., Brotato, 20 Minutes Till Dawn)**
   - **Added:** `manual_aim`, `dodge_roll`, `reload_mechanic`
   - **Removed:** `auto_attack` (often optional)
   - **Focus:** Higher mechanical skill ceiling, requiring precise aiming and dodging alongside build crafting.

3. **Tower Defense Survival (e.g., Slime Legion)**
   - **Added:** `tower_placement`, `grid_movement`, `resource_gathering`
   - **Removed:** `free_movement`
   - **Focus:** Strategic placement and resource management over real-time action.

## 7. Anti-Patterns

1. **The Snowball of Boredom:** If the player's power curve vastly outpaces the enemy scaling too early, the game loses all tension and becomes a passive waiting game.
2. **Unreadable Screen Clutter:** Failing to prioritize visual hierarchy, resulting in the player losing track of their character or dangerous projectiles amidst their own attacks.
3. **Meaningless Choices:** Offering upgrade options that lack synergy or are mathematically inferior, reducing the leveling process to a solved equation rather than an interesting decision.

## 8. Cross-Cutting Systems

- **Economy/Monetization:** In mobile variants, `gacha_banner` systems are often used to unlock new characters or starting weapons. `battle_pass` systems provide a structured reward track for daily play.
- **Social:** `leaderboards` for longest survival time or highest score. `daily_weekly_reset` challenges with specific modifiers to encourage community discussion and competition.
