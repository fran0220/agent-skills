# Archetype Recipe: Cooking Game (烹饪类)

## 1. Archetype Identity
**ID:** `cooking-game`
**Names:** Cooking Game / 烹饪类

The Cooking Game archetype is a time-management and simulation genre where players prepare, cook, and serve food to customers within strict time limits. It heavily emphasizes task prioritization, spatial awareness, and rhythm. Players must navigate a kitchen environment, process raw ingredients through various stations (chopping, boiling, frying), and assemble them into complex recipes while managing a continuous influx of orders. The genre often scales in difficulty by introducing more complex recipes, hazardous kitchen layouts, and demanding customer patience mechanics.

**Benchmark Games:**
- *Cooking Mama* (2006) - Nintendo DS
- *Cook, Serve, Delicious!* (2012) - PC, Mobile
- *Overcooked* (2016) - PC, Consoles

## 2. Elemental Tetrad Analysis
**Mechanics:**
The core loops revolve around receiving an order, breaking it down into constituent tasks, executing those tasks at specific stations, and delivering the final product. Systems include order queuing, ingredient processing timers, score multipliers for consecutive successful deliveries, and penalty systems for burnt food or failed orders.

**Aesthetics:**
Visually, these games often employ bright, appetizing color palettes and clear, readable UI to help players quickly parse complex information. Audio plays a crucial role, with distinct sound cues for completed tasks, burning food, and ticking clocks to heighten tension. The overall aesthetic pattern is one of escalating chaos masked by a cheerful presentation.

**Story:**
Narrative structures are typically lightweight, serving primarily as a framing device for the gameplay. Common tropes include saving a failing family restaurant, competing in a culinary tournament, or traveling the world to learn new cuisines. The story rarely interferes with the core loop, instead providing context for unlocking new levels or recipes.

**Technology:**
Technical requirements focus heavily on robust state management for numerous interacting objects (ingredients, tools, stations). Precise collision detection and responsive input handling are critical, especially in fast-paced or co-op variants. Pathfinding and AI may be required for customer behaviors or automated kitchen elements.

## 3. Atom Recipe Table

| Atom ID | Atom Name | Role in Archetype | Weight | Typical Config |
| :--- | :--- | :--- | :--- | :--- |
| `crafting_recipe` | Crafting Recipe | Defines the sequence of actions required to complete an order. | Core | `complexity: high`, `time_limit: strict` |
| `resource_gathering` | Resource Gathering | Retrieving raw ingredients from dispensers or storage. | Core | `source: kitchen_stations` |
| `timing_window` | Timing Window | Managing the duration food spends cooking to avoid burning. | Core | `penalty: burnt_food` |
| `combo_counter` | Combo Counter | Rewarding players for consecutive successful, timely deliveries. | Important | `reward: score_multiplier` |
| `role_assignment` | Role Assignment | Dividing tasks among players or automated systems. | Important | `dynamic: true` |
| `belt_conveyor` | Belt Conveyor | Moving ingredients or obstacles through the kitchen space. | Optional | `speed: variable` |
| `sprint_stamina` | Sprint/Stamina | Allowing quick bursts of movement to reach stations faster. | Optional | `dash_cooldown: short` |

## 4. Atom Coupling Matrix

1. **`crafting_recipe` + `timing_window`**
   - **Interaction:** Recipes require specific timing for each step (e.g., boiling pasta for exactly 10 seconds).
   - **Emergent Dynamic:** Time management pressure and risk/reward decisions (leaving a station unattended to start another task).
   - **Aesthetic:** Tension and the satisfaction of perfect execution.

2. **`role_assignment` + `resource_gathering`**
   - **Interaction:** Players must divide tasks to gather ingredients efficiently from different parts of the kitchen.
   - **Emergent Dynamic:** Communication breakdowns and chaotic cooperation as players bump into each other or forget their assigned roles.
   - **Aesthetic:** Fellowship (in co-op) and comedic frustration.

3. **`combo_counter` + `timing_window`**
   - **Interaction:** Perfect timing on deliveries builds a combo multiplier, while missed windows reset it.
   - **Emergent Dynamic:** Flow state mastery and high-score chasing, pushing players to optimize their routines.
   - **Aesthetic:** Challenge and expression through skillful play.

4. **`belt_conveyor` + `crafting_recipe`**
   - **Interaction:** Ingredients or partially completed recipes arrive on moving belts, requiring players to grab them before they disappear.
   - **Emergent Dynamic:** Spatial awareness challenges and dynamic prioritization as the environment constantly shifts.
   - **Aesthetic:** Unpredictability and frantic adaptation.

5. **`sprint_stamina` + `role_assignment`**
   - **Interaction:** Dashing allows quick role switching but risks bumping into other players or dropping items.
   - **Emergent Dynamic:** Physical comedy and frantic movement as players try to cover for each other's mistakes.
   - **Aesthetic:** Slapstick humor and high-energy action.

## 5. MDA Chain
**Mechanics:**
- Ingredient processing (chopping, cooking, assembling).
- Time-limited order fulfillment.
- Station management and spatial navigation.
- Score calculation based on speed and accuracy.

**Dynamics:**
- Task prioritization under strict time constraints.
- Bottleneck identification (e.g., waiting for the only frying pan).
- Panic management when multiple orders are about to expire.
- Team coordination and communication (in multiplayer variants).

**Aesthetics:**
- **Challenge:** Overcoming increasingly complex and demanding levels.
- **Fellowship:** Working together (or yelling at each other) in co-op modes.
- **Expression:** Optimizing kitchen layouts or developing personal strategies for efficiency.

## 6. Variant Spectrum
1. **Co-op Party Cooking** (e.g., *Overcooked*)
   - **Atoms Added:** `role_assignment`, `sprint_stamina`, `physics_puzzle`
   - **Atoms Removed:** `combo_counter`
   - Focuses on chaotic multiplayer interaction and environmental hazards.

2. **Hardcore Restaurant Sim** (e.g., *Cook, Serve, Delicious!*)
   - **Atoms Added:** `combo_counter`, `adaptive_difficulty`, `menu_management`
   - **Atoms Removed:** `role_assignment`, `sprint_stamina`
   - Focuses on intense single-player rhythm, memorization, and high-score chasing.

3. **Puzzle Cooking** (e.g., *Automachef*)
   - **Atoms Added:** `belt_conveyor`, `logic_deduction`, `programming_nodes`
   - **Atoms Removed:** `sprint_stamina`, `timing_window` (real-time)
   - Focuses on designing automated kitchens to solve spatial and logical puzzles.

## 7. Anti-Patterns
1. **Unreadable UI in Chaos:** Failing to provide clear visual or audio cues when food is burning or orders are expiring, leading to unfair failures rather than skill-based mistakes.
2. **Overly Punishing Snowball Effects:** Designing systems where one small mistake (e.g., dropping a plate) makes it mathematically impossible to recover and pass the level, causing frustration.
3. **Meaningless Complexity:** Adding too many ingredients or steps to a recipe without increasing the strategic depth, resulting in tedious memorization rather than engaging time management.

## 8. Cross-Cutting Systems
- **`economy_f2p`:** Energy systems limiting play sessions, premium currency for cosmetic kitchen upgrades or temporary boosts.
- **`social_multiplayer`:** Leaderboards for high scores, asynchronous ghost data, or live co-op matchmaking.
- **`meta_progression`:** Unlocking new chefs, permanent kitchen upgrades, or new restaurant themes between levels.
- **`collection_log`:** Tracking discovered recipes, earned stars, or special achievements.
