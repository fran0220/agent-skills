# Rhythm Action (音乐动作类)

## 1. Archetype Identity
- **ID**: rhythm-action
- **Names**: Rhythm Action, 音乐动作类
- **Definition**: A genre where gameplay actions are tightly synchronized with musical beats or rhythms. Players must perform specific inputs (tapping, slashing, dodging) in time with the music to succeed, often evaluated on timing accuracy and sequence completion. The core loop revolves around achieving a flow state where physical execution matches auditory cues perfectly.
- **Benchmark Games**:
  - *osu!* (2007)
  - *Beat Saber* (2018)
  - *Muse Dash* (2018)
  - *Project Sekai: Colorful Stage! feat. Hatsune Miku* (2020)
  - *Hi-Fi RUSH* (2023)

## 2. Elemental Tetrad Analysis
- **Mechanics**: The core loop involves reading incoming notes or environmental cues, executing inputs at the precise moment they align with a target zone, and receiving immediate feedback on timing accuracy (e.g., Perfect, Great, Miss). Success builds a combo multiplier and score, while failure depletes a health or stamina bar.
- **Aesthetics**: Highly stylized visual feedback that pulses or reacts to the music. Audio is paramount, with clear, distinct beats and sound effects that complement the track when inputs are correct, or discordant sounds when missed. The visual UI is often clean to allow focus on the note highway.
- **Story**: Often minimal or abstracted, serving as a backdrop for the music. In some variants (like idol games or rhythm-action hybrids), the narrative focuses on musical journeys, band dynamics, or saving the world through the power of music.
- **Technology**: Requires extremely low input latency and precise audio-visual synchronization. Often involves custom audio engines, precise hit detection algorithms, and robust calibration tools for different hardware setups to ensure fairness.

## 3. Atom Recipe Table

| Atom ID | Atom Name | Role in Archetype | Weight | Typical Config |
|---------|-----------|-------------------|--------|----------------|
| `note_highway` | Note Highway | Core visual representation of incoming inputs | Core | `speed_multiplier: variable`, `lanes: 4-6` |
| `timing_window` | Timing Window | Defines the strictness of input evaluation | Core | `perfect_ms: 30`, `good_ms: 80` |
| `combo_counter` | Combo Counter | Rewards sustained accuracy with score multipliers | Core | `drop_on_miss: true`, `max_multiplier: 8x` |
| `one_tap` | One Tap | The fundamental input mechanism for hitting notes | Core | `input_type: tap/hold/swipe` |
| `style_meter` | Style Meter | Visual representation of current performance level | Important | `decay_rate: fast` |
| `adaptive_difficulty` | Adaptive Difficulty | Adjusts note density or health drain based on performance | Optional | `dynamic_scaling: true` |
| `gacha_banner` | Gacha Banner | Monetization and character acquisition in mobile variants | Optional | `pity_count: 100` |
| `skill_tree` | Skill Tree | Meta-progression for character abilities or score boosts | Optional | `unlock_currency: coins` |

## 4. Atom Coupling Matrix
1. **`note_highway` + `timing_window`**: The fundamental interaction. The highway dictates *what* and *when* to hit, while the timing window dictates *how accurately* it was hit. 
   - *Emergent dynamic*: Flow state and rhythm synchronization. 
   - *Aesthetic*: Challenge and Submission.
2. **`combo_counter` + `style_meter`**: Maintaining a high combo directly feeds into the style meter, creating a positive feedback loop of visual and auditory rewards. 
   - *Emergent dynamic*: High-stakes performance pressure. 
   - *Aesthetic*: Expression and Sensation.
3. **`timing_window` + `one_tap`**: The physical execution of the rhythm. The strictness of the window demands precise physical tapping. 
   - *Emergent dynamic*: Muscle memory development. 
   - *Aesthetic*: Challenge.
4. **`gacha_banner` + `combo_counter`**: In mobile variants, characters acquired via gacha provide skills that forgive missed notes or boost combo scores. 
   - *Emergent dynamic*: Pay-to-progress or grind-to-progress meta. 
   - *Aesthetic*: Fantasy and Fellowship (if social).
5. **`note_highway` + `adaptive_difficulty`**: The speed and density of the highway change dynamically based on the player's current combo or health. 
   - *Emergent dynamic*: Tension modulation. 
   - *Aesthetic*: Challenge and Narrative (dramatic peaks).

## 5. MDA Chain
- **Mechanics**: Notes spawn on a highway synced to an audio track. Players input commands within specific timing windows. Combos multiply scores. Health depletes on misses.
- **Dynamics**: Players enter a "flow state," anticipating patterns rather than reacting to individual notes. The pressure increases as the combo builds, leading to "combo anxiety." Players memorize complex patterns through repeated attempts.
- **Aesthetics**: Sensation (audio-visual spectacle), Challenge (mastering difficult tracks), Submission (losing oneself in the rhythm), Expression (customizing profiles or playstyles).

## 6. Variant Spectrum
1. **Pure Rhythm (osu!, Beatmania)**: Focuses entirely on mechanical execution. 
   - *Atoms added*: `ghost_replay`. 
   - *Atoms removed*: `gacha_banner`, `skill_tree`.
2. **Rhythm Action Hybrid (Hi-Fi RUSH, Crypt of the NecroDancer)**: Combines rhythm mechanics with traditional action/combat. 
   - *Atoms added*: `melee_combo`, `dodge_roll`, `iframes`. 
   - *Atoms removed*: `note_highway` (often replaced by environmental cues).
3. **Idol/Gacha Rhythm (Project Sekai, BanG Dream!)**: Combines rhythm gameplay with character collection and narrative. 
   - *Atoms added*: `gacha_banner`, `affinity_meter`, `branching_dialogue`. 
   - *Atoms removed*: `adaptive_difficulty` (usually fixed difficulties).
4. **VR Rhythm (Beat Saber, Synth Riders)**: Translates rhythm into full-body spatial movement. 
   - *Atoms added*: `spatial_portal` (spatial awareness), `physics_puzzle` (slashing angles). 
   - *Atoms removed*: `one_tap`.

## 7. Anti-Patterns
1. **Desync Issues**: Audio and visual cues not perfectly aligned, or high input latency, making the game feel unfair and frustrating.
2. **Unreadable Charts**: Note patterns that are visually confusing or physically impossible to execute, breaking the flow state and relying on memorization rather than rhythm reading.
3. **Overbearing Meta-Progression**: When score is determined more by character stats (gacha) than player skill, alienating core rhythm game fans.

## 8. Cross-Cutting Systems
- **Economy/Monetization**: F2P with Gacha (character cards, outfits), Song Packs (DLC), Battle Pass (cosmetics and resources).
- **Social**: Leaderboards (global and friend), Co-op Live shows (multiplayer score pooling), Guilds/Clans.
- **Progression**: Player level, Character affinity, Song clear achievements.
