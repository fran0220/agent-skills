# Archetype Recipe: Decoration (装饰类)

## 1. Archetype Identity
**ID:** decoration
**Name (EN):** Decoration
**Name (CN):** 装饰类

**Definition:**
The Decoration archetype centers around the creative expression of the player through the arrangement, customization, and aesthetic enhancement of virtual spaces. Unlike competitive or purely narrative-driven games, this archetype emphasizes intrinsic motivation, allowing players to shape their environment according to personal taste. The core gameplay loop typically involves gathering resources, unlocking new decorative items, and meticulously placing them to create a unique, personalized space. This genre thrives on the satisfaction of visual progression and the emotional attachment players form with their customized environments.

**Benchmark Games:**
*   *Animal Crossing: New Horizons* (2020)
*   *The Sims 4* (2014)
*   *Stardew Valley* (2016)
*   *House Flipper* (2018)
*   *Unpacking* (2021)

## 2. Elemental Tetrad Analysis

**Mechanics:**
The foundational mechanics of the Decoration archetype revolve around spatial manipulation and inventory management. Players engage in core loops of resource acquisition (either through currency generation, gathering, or completing tasks) which are then expended to acquire decorative assets. The placement system is paramount, often utilizing grid-based or free-form placement mechanics, allowing for rotation, scaling, and layering of objects. Progression is typically tied to expanding the available space or unlocking higher-tier, more intricate items.

**Aesthetics:**
Visually, these games often employ a welcoming, relaxing, and highly customizable art style. The audio design complements this with soothing, ambient soundtracks and satisfying sound effects for object placement and interaction. The overall aesthetic goal is to create a "cozy" atmosphere that encourages prolonged, low-stress engagement. The visual feedback of transforming a barren space into a detailed, personalized area is the primary aesthetic reward.

**Story:**
Narrative in Decoration games is often emergent and player-driven. While there may be a loose overarching premise (e.g., moving to a new town, inheriting a farm), the true story is the history of the space the player creates. The arrangement of items can imply character traits, past events, or personal preferences, allowing players to engage in environmental storytelling within their own customized domains.

**Technology:**
Technologically, these games require robust spatial partitioning and object management systems to handle potentially thousands of individual items within a scene without performance degradation. Advanced save systems are necessary to accurately record the precise position, rotation, and state of every placed object. Furthermore, intuitive user interfaces for browsing large catalogs of items and precise manipulation controls are critical technical requirements.

## 3. Atom Recipe Table

| Atom ID | Atom Name | Role in Archetype | Weight | Typical Config |
| :--- | :--- | :--- | :--- | :--- |
| room_decoration | Room Decoration | The core mechanic of placing and arranging items in a space. | Core | `grid_snap: true`, `free_rotation: false` |
| resource_gathering | Resource Gathering | The primary method for acquiring materials needed to craft or purchase decorations. | Important | `yield_variance: low`, `respawn_rate: daily` |
| crafting_recipe | Crafting Recipe | Allows players to convert raw resources into specific decorative items. | Important | `complexity: medium`, `time_to_craft: instant` |
| currency_dual | Dual Currency | Often uses a standard currency for basic items and a premium/rare currency for exclusive decorations. | Optional | `premium_currency_source: achievements` |
| collection_log | Collection Log | Tracks acquired items, encouraging completionism and providing a sense of progression. | Important | `display_missing: true`, `reward_tiers: true` |
| spatial_portal | Spatial Portal | Used to transition between different customizable areas (e.g., rooms in a house). | Optional | `transition_time: fast` |
| achievement_system | Achievement System | Rewards players for reaching specific milestones in their decoration efforts. | Optional | `reward_type: exclusive_items` |
| daily_weekly_reset | Daily/Weekly Reset | Refreshes available items in shops or provides new gathering opportunities. | Important | `shop_rotation: daily` |
| outfit_scoring | Outfit Scoring | Sometimes adapted to score the aesthetic value or theme of a decorated room. | Optional | `theme_matching: true` |
| physics_puzzle | Physics Puzzle | Occasionally used in games like *Unpacking* where item placement must adhere to physical constraints. | Optional | `collision_detection: strict` |

## 4. Atom Coupling Matrix

1.  **`room_decoration` + `collection_log`**
    *   **Dynamic:** Players are motivated to acquire new items not just for immediate use, but to fill out their catalog, driving long-term engagement.
    *   **Aesthetic:** Creates a sense of completion and satisfaction, appealing to the collector archetype.
2.  **`resource_gathering` + `crafting_recipe`**
    *   **Dynamic:** Establishes a clear loop of effort and reward. Players must actively engage with the world to create the specific items they desire.
    *   **Aesthetic:** Fosters a feeling of accomplishment and self-sufficiency, making the final decorated space feel earned.
3.  **`room_decoration` + `outfit_scoring` (Room Scoring)**
    *   **Dynamic:** Introduces a gamified element to the subjective act of decoration, providing external validation or constraints based on themes.
    *   **Aesthetic:** Adds a layer of challenge and puzzle-solving to the creative process, appealing to players who enjoy optimizing within constraints.
4.  **`daily_weekly_reset` + `currency_dual`**
    *   **Dynamic:** Creates a habit-forming loop where players log in regularly to check new stock and manage their resources to afford rotating items.
    *   **Aesthetic:** Induces a mild sense of FOMO (Fear Of Missing Out) balanced with the anticipation of discovering new, desirable items.
5.  **`room_decoration` + `physics_puzzle`**
    *   **Dynamic:** Transforms simple placement into a spatial reasoning challenge, requiring players to fit items logically within a confined space.
    *   **Aesthetic:** Generates a highly tactile and satisfying experience when items "click" into their logical or physically appropriate places.

## 5. MDA Chain

**Mechanics:**
The core mechanics involve the `room_decoration` system, supported by `resource_gathering` and `crafting_recipe`. Players interact with a grid or free-space environment, selecting items from an inventory and manipulating their position and orientation. The `collection_log` tracks progress, while `daily_weekly_reset` mechanics govern the availability of new assets.

**Dynamics:**
These mechanics create a dynamic of continuous, low-pressure optimization and expansion. Players establish personal goals (e.g., "build a rustic kitchen") and engage in the necessary loops to achieve them. The interaction between gathering and crafting creates a rhythm of work and reward. The spatial constraints of the environment force players to make creative decisions about layout and prioritization.

**Aesthetics:**
The resulting aesthetics are primarily Expression and Submission (as a pastime). Players express their identity through their design choices, finding a state of flow and relaxation in the meticulous arrangement of objects. The completion of a well-designed space provides a strong sense of pride and ownership, while the ongoing pursuit of new items offers a comforting, predictable routine.

## 6. Variant Spectrum

1.  **The Sandbox Builder:** (e.g., *Minecraft* Creative Mode)
    *   **Atoms Added:** `procedural_gen`, `voxel_manipulation` (hypothetical)
    *   **Atoms Removed:** `currency_dual`, `resource_gathering` (often bypassed)
    *   **Focus:** Pure, unrestricted creative freedom with minimal friction.
2.  **The Life Sim Decorator:** (e.g., *The Sims*)
    *   **Atoms Added:** `colonist_ai`, `affinity_meter`, `skill_tree`
    *   **Atoms Removed:** `physics_puzzle`
    *   **Focus:** Decoration serves the functional and emotional needs of simulated inhabitants.
3.  **The Cozy Organizer:** (e.g., *Unpacking*)
    *   **Atoms Added:** `physics_puzzle`, `narrative_discovery` (hypothetical)
    *   **Atoms Removed:** `resource_gathering`, `crafting_recipe`, `currency_dual`
    *   **Focus:** The tactile satisfaction of finding the "right" place for items, often with implicit storytelling.
4.  **The Farming/Town Sim:** (e.g., *Animal Crossing*)
    *   **Atoms Added:** `day_night_cycle`, `fishing_minigame`, `social_multiplayer`
    *   **Atoms Removed:** `physics_puzzle`
    *   **Focus:** Decoration is integrated into a broader simulation of community and daily life.

## 7. Anti-Patterns

1.  **Overly Restrictive Placement:** Implementing a grid system that is too coarse or collision boxes that are too large, preventing players from achieving the precise layouts they envision. This leads to frustration and breaks the creative flow.
2.  **Excessive Grind for Basic Items:** Locking fundamental decorative elements behind tedious or excessively long gathering loops. While rare items should require effort, basic building blocks must be accessible to allow early creative expression.
3.  **Lack of Meaningful Interaction:** Creating beautiful spaces where none of the objects can be interacted with. If a player builds a chair, they (or their avatars) should be able to sit in it; otherwise, the space feels like a static diorama rather than a living environment.

## 8. Cross-Cutting Systems

*   **Economy/Monetization:** Often utilizes a `currency_dual` system, where basic items are bought with easily earned in-game currency, while premium, highly desirable, or licensed items are purchased with premium currency (microtransactions). Battle passes or seasonal events are also common for distributing exclusive thematic sets.
*   **Social/Multiplayer:** Asynchronous multiplayer is prevalent, allowing players to visit and tour each other's decorated spaces (e.g., Dream Addresses in *Animal Crossing*). This fosters community sharing, inspiration, and sometimes competitive voting or scoring of designs.
*   **Progression:** Meta-progression often involves expanding the physical size of the customizable area (e.g., upgrading a house, unlocking new rooms or islands), which in turn drives the need for more resources and decorations.
