# Archetype Recipe: Hades-like (Roguelite动作类)

## 1. Archetype Identity
- **ID**: hades-like
- **Name (EN)**: Hades-like
- **Name (CN)**: Roguelite动作类
- **Definition**: An action-oriented roguelite subgenre characterized by fast-paced, isometric or side-scrolling combat, persistent meta-progression, and highly synergistic build-crafting during individual runs. It emphasizes narrative integration with repeated deaths and fluid, responsive controls.
- **Benchmark Games**:
  - *Hades* (2020)
  - *Dead Cells* (2018)
  - *Curse of the Dead Gods* (2021)

## 2. Elemental Tetrad Analysis
- **Mechanics**: Core loops involve entering a run, clearing rooms of enemies using fast-paced combat, choosing between branching paths or rewards, and dying to return to a hub area where permanent upgrades are purchased. Systems heavily rely on random affixes, synergistic boons/relics, and resource management.
- **Aesthetics**: Often features stylized, highly readable visual effects to ensure clarity during chaotic combat. Audio provides punchy feedback for hits and dodges, accompanied by dynamic, adrenaline-pumping soundtracks.
- **Story**: Narrative is typically integrated into the roguelite loop, where death is canonically explained (e.g., returning to the underworld). Characters react to the player's repeated attempts, unlocking new dialogue and lore progressively.
- **Technology**: Requires highly responsive input handling, robust procedural generation for room layouts and reward distribution, and complex state management for stacking buffs and modifiers.

## 3. Atom Recipe Table

| Atom ID | Atom Name | Role in Archetype | Weight | Typical Config |
|---------|-----------|-------------------|--------|----------------|
| dodge_roll | Dodge Roll | Primary defensive maneuver and repositioning tool. | Core | `iframes: true, cooldown: 0.5s` |
| melee_combo | Melee Combo | Core offensive action, providing rhythm and flow to combat. | Core | `cancelable: true` |
| run_based | Run-based | Defines the overarching structure of gameplay sessions. | Core | `duration: 30-45m` |
| meta_progression | Meta Progression | Provides long-term goals and permanent power increases. | Core | `currency_type: persistent` |
| random_affix | Random Affix | Drives build variety and run uniqueness through boons/upgrades. | Core | `stackable: true` |
| room_reward | Room Reward | Incentivizes clearing encounters and guides pathing choices. | Important | `preview_visible: true` |
| branching_dialogue | Branching Dialogue | Delivers narrative progressively across multiple runs. | Important | `condition: run_count` |
| ability_cooldown | Ability Cooldown | Paces the use of powerful secondary skills or spells. | Important | `reduction_mods: true` |
| permadeath | Permadeath | Resets run-specific progress upon failure, enforcing the loop. | Core | `keep_meta_currency: true` |
| procedural_gen | Procedural Gen | Ensures varied room layouts and enemy compositions per run. | Important | `chunk_based: true` |

## 4. Atom Coupling Matrix

1. **dodge_roll + iframes**
   - **Interaction**: Dodging grants temporary invulnerability.
   - **Emergent Dynamic**: Players aggressively dodge *through* attacks rather than just away from them, enabling high-risk, high-reward positioning.
   - **Aesthetic**: Feeling of mastery, fluidity, and "dancing" through danger.

2. **random_affix + melee_combo**
   - **Interaction**: Modifiers alter the properties of basic attacks (e.g., adding chain lightning or applying doom).
   - **Emergent Dynamic**: Players adapt their combat rhythm based on the specific upgrades acquired during the run.
   - **Aesthetic**: Discovery, power fantasy, and the joy of "breaking" the game with synergistic builds.

3. **run_based + meta_progression**
   - **Interaction**: Failing a run yields persistent currency used to buy permanent upgrades.
   - **Emergent Dynamic**: Death transforms from a frustrating failure state into a rewarding opportunity for growth and narrative progression.
   - **Aesthetic**: Persistence, gradual empowerment, and reduced punishment anxiety.

4. **room_reward + procedural_gen**
   - **Interaction**: Players choose their next procedurally generated room based on the previewed reward.
   - **Emergent Dynamic**: Strategic pathing and risk assessment (e.g., taking a harder room for a better upgrade).
   - **Aesthetic**: Agency, anticipation, and strategic planning amidst chaos.

5. **permadeath + branching_dialogue**
   - **Interaction**: Dying triggers new conversations with hub NPCs based on how or where the player died.
   - **Emergent Dynamic**: Players look forward to returning to the hub to experience new story beats, integrating failure into the narrative.
   - **Aesthetic**: Immersion, emotional attachment to characters, and narrative continuity.

## 5. MDA Chain
- **Mechanics**: Fast-paced action combat (dodge, attack), randomized power-ups (boons/relics), procedural room progression, and persistent hub upgrades.
- **Dynamics**: Players constantly evaluate risk vs. reward, adapt their playstyle to the RNG of upgrades, and experience a cycle of intense action followed by calm hub management.
- **Aesthetics**: Challenge (overcoming difficult encounters), Discovery (finding new synergies), Narrative (unfolding story through repeated attempts), and Submission (entering the "zone" during flow-state combat).

## 6. Variant Spectrum
- **Pure Action Roguelite**: Focuses entirely on combat mechanics and reflexes, minimizing narrative elements (e.g., *Curse of the Dead Gods*). Atoms removed: `branching_dialogue`, `affinity_meter`.
- **Platformer Roguelite**: Integrates heavy platforming and verticality into the combat loop (e.g., *Dead Cells*). Atoms added: `double_jump`, `wall_slide_jump`.
- **Bullet Hell Roguelite**: Emphasizes dodging dense projectile patterns over melee combat (e.g., *Enter the Gungeon*). Atoms added: `projectile`, `hitscan`.

## 7. Anti-Patterns
1. **Meaningless Meta-Progression**: Upgrades that only provide flat stat boosts without altering gameplay, leading to a grindy feeling rather than genuine progression.
2. **Cluttered Visuals**: Overlapping spell effects and enemy attacks that obscure telegraphs, resulting in unfair damage and player frustration.
3. **Snowballing RNG**: Runs that are entirely decided by the first few random drops, making the rest of the run either trivially easy or impossibly hard regardless of player skill.

## 8. Cross-Cutting Systems
- **Economy**: Dual currency systems (run-specific gold vs. persistent darkness/cells).
- **Social**: Asynchronous leaderboards for daily runs or speedrun times.
- **Monetization**: Typically premium (buy-to-play), occasionally featuring cosmetic DLCs or expansions.
