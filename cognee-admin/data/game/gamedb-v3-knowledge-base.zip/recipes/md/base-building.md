# Archetype Recipe: Base Building

## 1. Archetype Identity
**ID:** base-building
**Name (EN):** Base Building
**Name (CN):** 基地建设类

**Definition:**
The Base Building archetype centers around the construction, management, and optimization of a central hub or sprawling network of structures. Players gather resources, process them through various production chains, and expand their infrastructure to meet increasingly complex demands. The core gameplay loop involves a continuous cycle of expansion, efficiency optimization, and defense against environmental or hostile threats, creating a deeply satisfying sense of progression and mastery over the game world.

**Benchmark Games:**
- *Factorio* (2016)
- *Satisfactory* (2019)
- *RimWorld* (2018)
- *Dyson Sphere Program* (2021)

## 2. Elemental Tetrad Analysis

### Mechanics
The core mechanics revolve around resource extraction, logistics, and production. Players must establish supply chains, manage power grids, and balance input/output ratios to ensure smooth operation. Automation is a key progression milestone, shifting the player's focus from manual labor to high-level system design and troubleshooting.

### Aesthetics
Visually, these games often emphasize scale and complexity, transitioning from a pristine natural environment to a sprawling, industrialized landscape. The audio design typically features rhythmic, mechanical sounds that reinforce the feeling of a well-oiled machine, providing auditory feedback on the health and efficiency of the factory.

### Story
Narratives in base-building games are often emergent, driven by the player's decisions and the challenges they face. While there may be an overarching goal (e.g., escaping a planet, building a megastructure), the true story is the history of the base itself—the initial struggles, the logistical bottlenecks overcome, and the eventual triumph of automation.

### Technology
Technologically, these games require robust simulation engines capable of tracking thousands of individual entities, resources, and calculations simultaneously without compromising performance. Efficient pathfinding, fluid dynamics (for pipes), and complex state management are essential technical pillars.

## 3. Atom Recipe Table

| Atom ID | Atom Name | Role in Archetype | Weight | Typical Config |
| :--- | :--- | :--- | :--- | :--- |
| resource_gathering | Resource Gathering | Foundation of all construction and production. | Core | yield_rate: variable, depletion: optional |
| crafting_recipe | Crafting Recipe | Defines the transformation of raw materials into usable items. | Core | complexity: high, multi_step: true |
| belt_conveyor | Belt Conveyor | Primary method of automated logistics and item transport. | Core | throughput: tiered, routing: complex |
| tech_tree | Tech Tree | Gates progression and unlocks new structures/recipes. | Core | unlock_cost: exponential, branches: multiple |
| tower_placement | Tower Placement | Used for defensive structures or specialized production nodes. | Important | grid_snap: true, footprint: variable |
| energy_stamina_gate | Energy/Power Grid | Limits expansion and requires dedicated infrastructure to maintain. | Important | capacity: scalable, consumption: continuous |
| procedural_gen | Procedural Generation | Ensures replayability by randomizing resource distribution and terrain. | Important | seed_based: true, biome_diversity: high |
| colonist_ai | Colonist AI | Manages autonomous agents in colony-sim variants. | Optional | needs_system: complex, task_prioritization: true |
| day_night_cycle | Day/Night Cycle | Affects solar power generation and enemy behavior. | Optional | duration: adjustable, impact: moderate |

## 4. Atom Coupling Matrix

1. **resource_gathering + belt_conveyor**
   - **Dynamic:** Automated Extraction. Players transition from manual mining to setting up automated drills that feed directly into transport networks.
   - **Aesthetic:** The satisfaction of seeing a continuous flow of resources, representing the first step towards total automation.

2. **crafting_recipe + belt_conveyor**
   - **Dynamic:** Assembly Lines. Items are moved between different crafting stations automatically, creating complex production chains.
   - **Aesthetic:** The visual spectacle of a bustling factory floor, where raw materials are systematically transformed into advanced products.

3. **tech_tree + resource_gathering**
   - **Dynamic:** Resource Gating. Advanced technologies require new, rarer resources, forcing the player to expand their base and explore new areas.
   - **Aesthetic:** A sense of discovery and the constant drive to push the boundaries of the established infrastructure.

4. **energy_stamina_gate + tower_placement**
   - **Dynamic:** Power Management. Placing new structures increases power draw, requiring the player to constantly upgrade their energy grid to prevent blackouts.
   - **Aesthetic:** The tension of balancing expansion with sustainability, and the relief of successfully stabilizing a strained power network.

5. **colonist_ai + crafting_recipe**
   - **Dynamic:** Labor Management. In colony sims, crafting is performed by AI agents with specific skills and needs, adding a layer of human resource management.
   - **Aesthetic:** The emergent drama of managing a living community, where efficiency is balanced against the well-being of the workforce.

## 5. MDA Chain

**Mechanics:**
Players interact with the world by placing structures on a grid, connecting them with logistical networks (belts, pipes), and configuring recipes. The game simulates the flow of resources and energy in real-time, applying rules for throughput, capacity, and conversion rates.

**Dynamics:**
These mechanics create dynamics of optimization and bottleneck identification. Players constantly analyze their systems to find inefficiencies—a lack of iron ore, a clogged conveyor belt, or insufficient power—and redesign their layouts to solve these problems. The base grows organically, often leading to "spaghetti" layouts that must eventually be refactored.

**Aesthetics:**
The resulting aesthetics are characterized by *Expression* (designing unique, personalized factory layouts), *Challenge* (solving complex logistical puzzles), and *Submission* (entering a flow state while tweaking and expanding the system). The ultimate aesthetic goal is the profound satisfaction of watching a massive, complex machine operate flawlessly without manual intervention.

## 6. Variant Spectrum

1. **Factory Automation (e.g., Factorio)**
   - **Added:** belt_conveyor, fluid_dynamics, logic_circuits
   - **Removed:** colonist_ai, morality_system
   - **Focus:** Pure logistical optimization and massive scale.

2. **Colony Simulation (e.g., RimWorld)**
   - **Added:** colonist_ai, morality_system, mental_breaks
   - **Removed:** belt_conveyor (usually), complex_fluid_dynamics
   - **Focus:** Managing the needs and behaviors of individual agents alongside base expansion.

3. **Survival Base Building (e.g., Subnautica)**
   - **Added:** oxygen_meter, hunger_thirst, exploration_gating
   - **Removed:** massive_scale_automation, complex_supply_chains
   - **Focus:** Building safe havens in hostile environments to facilitate further exploration.

## 7. Anti-Patterns

1. **The Waiting Game:** Designing progression that requires players to simply wait for long periods for resources to accumulate or research to finish, without providing meaningful tasks to perform in the meantime.
2. **Opaque Bottlenecks:** Failing to provide adequate UI/UX tools for players to diagnose why a production line has stopped working, leading to frustration rather than problem-solving.
3. **Punishing Refactoring:** Making it too costly or tedious to tear down and rebuild parts of the base. Since refactoring is a core part of the optimization loop, it should be frictionless.

## 8. Cross-Cutting Systems

- **Economy/Monetization:** Typically premium (buy-to-play). F2P variants often introduce artificial time gates (energy systems) that can be bypassed with microtransactions, which generally conflicts with the core appeal of the genre.
- **Social/Multiplayer:** Co-op multiplayer is highly synergistic, allowing players to divide tasks (e.g., one manages power, another manages oil processing). Competitive multiplayer is rare but can involve racing to a tech milestone or sabotaging rival bases.
- **Modding Support:** Essential for longevity. The community often creates mods that add new production chains, quality-of-life features, or entirely new mechanics, significantly extending the game's lifespan.
