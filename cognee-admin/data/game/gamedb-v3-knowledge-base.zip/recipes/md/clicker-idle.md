# Archetype Recipe: Clicker / Idle (clicker-idle)

## 1. Archetype Identity

**ID:** clicker-idle
**Names:** Clicker / Idle (点击/放置类)

The Clicker/Idle archetype, also known as incremental games, is defined by its core loop of performing simple actions (like clicking or tapping) to generate resources, which are then spent to automate and accelerate the generation of those same resources. This creates an exponential growth curve where numbers scale to astronomical heights. The genre is characterized by a transition from active, manual play to passive, automated play, often incorporating a "prestige" system that resets progress in exchange for permanent multipliers, ensuring long-term engagement and replayability.

**Benchmark Games:**
*   *Cookie Clicker* (2013) - Web/PC
*   *Adventure Capitalist* (2014) - Mobile/PC
*   *Clicker Heroes* (2014) - Web/Mobile/PC
*   *Realm Grinder* (2015) - Web/Mobile/PC

## 2. Elemental Tetrad Analysis

**Mechanics:**
The core mechanics revolve around resource generation and expenditure. Players start by manually generating a primary resource (e.g., clicking a giant cookie). This resource is used to purchase upgrades or buildings that automatically generate the resource over time. As the cost of upgrades increases exponentially, so does the production rate. A secondary layer of mechanics involves the "prestige" system, where players sacrifice their current progress to gain a special currency that provides permanent, global bonuses to future runs, creating a nested loop of growth and reset.

**Aesthetics:**
The visual and audio aesthetics are typically designed to provide immediate, satisfying feedback. Numbers popping up on screen, satisfying click sounds, and visual representations of growing wealth or power are common. The aesthetic experience is often one of "Submission" (game as pastime) and "Discovery" (unveiling new upgrades or mechanics as numbers grow). The visual style can range from simple UI-driven interfaces to more elaborate thematic representations (e.g., baking cookies, running a capitalist empire, or battling monsters).

**Story:**
Narrative in clicker/idle games is usually minimal or satirical. It often serves as a thin wrapper for the mechanics, providing a humorous or absurd context for the exponential growth. For example, *Cookie Clicker* starts with baking cookies and escalates to altering the fabric of reality to produce more cookies. The story is often conveyed through flavor text on upgrades or achievements rather than a structured plot.

**Technology:**
Technically, these games require robust systems for handling extremely large numbers (often exceeding standard integer limits, requiring custom BigInt implementations or floating-point math). They also need reliable offline progression calculation, ensuring players are rewarded for time spent away from the game. The UI must be highly responsive and capable of displaying rapidly changing values without performance degradation.

## 3. Atom Recipe Table

| Atom ID | Atom Name | Role in Archetype | Weight | Typical Config |
| :--- | :--- | :--- | :--- | :--- |
| `one_tap` | One Tap | The initial manual interaction to generate resources. | Core | `input_type: click/tap` |
| `currency_dual` | Dual Currency | Soft currency for immediate upgrades, hard/prestige currency for permanent meta-progression. | Core | `primary: soft, secondary: hard` |
| `prestige_reset` | Prestige Reset | The mechanism to reset progress for permanent multipliers, extending the game's lifespan. | Core | `multiplier_scaling: exponential` |
| `meta_progression` | Meta Progression | Permanent upgrades purchased with prestige currency that persist across resets. | Important | `offline_progress: true` |
| `resource_gathering` | Resource Gathering | The automated generation of resources over time. | Core | `automation: true` |
| `achievement_system` | Achievement System | Provides milestones and often small bonuses to encourage continued play. | Important | `milestone_rewards: true` |
| `daily_weekly_reset` | Daily/Weekly Reset | Encourages regular check-ins with time-gated rewards or events. | Optional | `reward_type: premium_currency` |
| `skill_tree` | Skill Tree | Offers branching paths for meta-progression, allowing for different playstyles or builds. | Optional | `respec_cost: low` |

## 4. Atom Coupling Matrix

1.  **`one_tap` + `resource_gathering`**
    *   **Interaction:** Manual clicks generate the initial resources required to purchase the first automated gatherers.
    *   **Emergent Dynamic:** The transition from active, high-attention play to passive, low-attention play.
    *   **Aesthetic:** A sense of relief and accomplishment as the burden of manual labor is lifted.

2.  **`resource_gathering` + `currency_dual`**
    *   **Interaction:** Automated gathering produces the primary soft currency, which is continuously reinvested to increase the gathering rate.
    *   **Emergent Dynamic:** An exponential growth loop where production and costs race against each other.
    *   **Aesthetic:** The satisfaction of watching numbers go up and optimizing efficiency.

3.  **`currency_dual` + `prestige_reset`**
    *   **Interaction:** The total amount of soft currency accumulated (or a related metric) determines the amount of prestige currency awarded upon reset.
    *   **Emergent Dynamic:** The strategic decision of *when* to reset to maximize prestige currency gain versus time spent.
    *   **Aesthetic:** Anticipation and the thrill of a fresh start with newfound power.

4.  **`prestige_reset` + `meta_progression`**
    *   **Interaction:** Prestige currency is spent on permanent upgrades that persist across all future resets.
    *   **Emergent Dynamic:** A sense of permanent, overarching growth that contextualizes the repetitive core loop.
    *   **Aesthetic:** Long-term investment and the realization of a grander scale of power.

5.  **`meta_progression` + `resource_gathering`**
    *   **Interaction:** Permanent upgrades multiply the base gathering rate or unlock new, more efficient gathering methods.
    *   **Emergent Dynamic:** Subsequent runs progress much faster through the early stages, allowing players to reach new heights more quickly.
    *   **Aesthetic:** A feeling of mastery and overwhelming power as early-game hurdles are trivialized.

## 5. MDA Chain

**Mechanics:**
*   Clicking/Tapping to generate resources.
*   Purchasing automated resource generators.
*   Purchasing upgrades that multiply production.
*   Resetting progress (Prestige) to earn a meta-currency.
*   Spending meta-currency on permanent, global upgrades.
*   Calculating offline progress based on time away.

**Dynamics:**
*   **Exponential Growth:** The core driver of the game, where numbers scale rapidly.
*   **Active vs. Passive Play:** The shifting balance between needing to interact with the game and letting it run in the background.
*   **Optimization and Efficiency:** Players constantly calculate the best return on investment for their resources.
*   **Resetting for Power:** The cyclical nature of building up and tearing down to build up faster next time.

**Aesthetics:**
*   **Submission:** The game serves as a low-stress pastime that can be engaged with lightly.
*   **Discovery:** Unlocking new tiers of upgrades, buildings, or narrative flavor text.
*   **Expression:** In games with skill trees or complex meta-progression, choosing a specific "build" or strategy.
*   **Sensation:** The satisfying visual and audio feedback of rapid resource generation and large numbers.

## 6. Variant Spectrum

1.  **Merge Idle:**
    *   **Atoms Added:** `swap_match3`, `physics_puzzle` (often simplified to dragging and dropping identical items).
    *   **Atoms Removed:** `one_tap` (often replaced by the merge action).
    *   **Description:** Instead of clicking, players merge identical items to create higher-tier items that generate more resources.

2.  **RPG Idle:**
    *   **Atoms Added:** `xp_level`, `skill_tree`, `loot_rarity`, `class_job`.
    *   **Atoms Removed:** None (often builds upon the core clicker mechanics).
    *   **Description:** Incorporates RPG elements like heroes, equipment, and combat, where the "resource" is often damage dealt to enemies.

3.  **Simulation Idle:**
    *   **Atoms Added:** `node_map`, `tech_tree`, `resource_gathering` (complex, multi-resource chains).
    *   **Atoms Removed:** `prestige_reset` (sometimes less prominent or replaced by moving to new areas).
    *   **Description:** Focuses on building and managing a complex system or economy, often with multiple interconnected resources.

## 7. Anti-Patterns

1.  **The "Wall" of Progression:** Designing the exponential curves such that progress grinds to an absolute halt for days or weeks without a prestige reset or premium currency spend. This leads to player churn.
2.  **Meaningless Prestige:** If the permanent upgrades gained from a prestige reset do not significantly alter the speed or feel of the next run, the reset feels like a punishment rather than a reward.
3.  **Overly Complex Early Game:** Bombarding the player with too many currencies, upgrades, or systems before they have grasped the core loop of click -> automate -> upgrade.

## 8. Cross-Cutting Systems

*   **Economy (F2P):** Heavily reliant on free-to-play models.
*   **Monetization (Ads):** Rewarded video ads are extremely common, offering temporary production multipliers or instant resource injections.
*   **Monetization (IAP):** In-app purchases for premium currency, which can be used for permanent multipliers, time skips, or exclusive cosmetics.
*   **Social (Leaderboards):** Often asynchronous, comparing total prestige or highest stage reached.
*   **Events:** Limited-time events with unique mechanics or separate progression tracks to earn exclusive rewards for the main game.
