# Archetype Recipe: Survival Horror (生存恐怖类)

## 1. Archetype Identity
- **ID:** survival-horror
- **Name (EN):** Survival Horror
- **Name (CN):** 生存恐怖类
- **Definition:** A subgenre of action-adventure games that focuses on survival of the character as the game tries to frighten players with either horror graphics or scary ambience. Combat is usually deemphasized or made difficult through limited resources, clunky controls, or powerful enemies.
- **Benchmark Games:**
  - *Resident Evil* (1996)
  - *Silent Hill* (1999)
  - *Amnesia: The Dark Descent* (2010)
  - *Outlast* (2013)

## 2. Elemental Tetrad Analysis
- **Mechanics:** Core loops revolve around exploration, puzzle-solving, resource management (ammo, health), and evasion or strategic combat against overwhelming threats.
- **Aesthetics:** Dark, claustrophobic environments, limited visibility (fog, darkness), unsettling audio design, grotesque or uncanny enemy designs.
- **Story:** Often involves isolation, uncovering a mystery, psychological trauma, or escaping a hostile environment. Narrative is frequently delivered through environmental storytelling and found documents.
- **Technology:** Dynamic lighting and shadows, spatial audio, advanced AI for stalking enemies, inventory management systems.

## 3. Atom Recipe Table

| Atom ID | Atom Name | Role in Archetype | Weight | Typical Config |
|---------|-----------|-------------------|--------|----------------|
| resource_gathering | Resource Gathering | Scavenging for limited ammo and health items | core | scarcity_multiplier: 0.2 |
| inventory_tetris | Inventory Management | Forcing difficult choices on what to carry | core | slots: limited |
| stealth_takedown | Stealth Mechanics | Evading enemies to conserve resources | important | detection_speed: fast |
| physics_puzzle | Puzzle Solving | Pacing breakers and gating progress | important | complexity: medium |
| combat_melee | Melee Combat | Desperate last resort when out of ammo | optional | stamina_cost: high |
| save_room | Safe Zones | Providing temporary relief from tension | core | limited_saves: true |
| vision_cone | Enemy Vision | Avoiding detection by patrolling threats | important | fov: 90 |
| interconnected_map | Interconnected Map | Metroidvania-style exploration and backtracking | core | unlock_keys: true |

## 4. Atom Coupling Matrix
1. **resource_gathering + inventory_tetris:** 
   - *Dynamic:* Players must constantly evaluate the worth of items vs space.
   - *Aesthetic:* Anxiety and strategic planning.
2. **stealth_takedown + vision_cone:**
   - *Dynamic:* Players observe enemy patterns to slip by unnoticed.
   - *Aesthetic:* Tension and suspense.
3. **save_room + interconnected_map:**
   - *Dynamic:* Players push further into danger, knowing they must return to safety.
   - *Aesthetic:* Relief mixed with dread of the unknown.
4. **combat_melee + resource_gathering:**
   - *Dynamic:* Deciding whether to use precious ammo or risk health in melee.
   - *Aesthetic:* Desperation and risk-reward calculation.
5. **physics_puzzle + interconnected_map:**
   - *Dynamic:* Solving puzzles unlocks new areas or shortcuts.
   - *Aesthetic:* Satisfaction of progression and mastery of the environment.

## 5. MDA Chain
- **Mechanics:** Limited inventory, scarce resources, powerful enemies, environmental puzzles, limited save points.
- **Dynamics:** Careful exploration, resource hoarding, flight-over-fight decision making, route planning.
- **Aesthetics:** Fear, tension, vulnerability, relief (upon finding a safe room), immersion.

## 6. Variant Spectrum
- **Action Horror:** (e.g., *Resident Evil 4*)
  - *Added:* action_points, combo_counter
  - *Removed:* limited_saves, extreme_scarcity
- **Psychological Horror:** (e.g., *Silent Hill 2*)
  - *Added:* branching_dialogue, morality_system
  - *Removed:* heavy_combat
- **Stealth Horror:** (e.g., *Amnesia*)
  - *Added:* hiding_mechanics, sanity_meter
  - *Removed:* combat_melee, projectile_weapons

## 7. Anti-Patterns
1. **Overabundance of Resources:** Removes the tension and turns the game into a standard shooter.
2. **Predictable Jump Scares:** Desensitizes the player and replaces genuine dread with cheap startles.
3. **Frustrating Controls:** While clunky controls can add vulnerability, overly unresponsive controls lead to player anger rather than fear.

## 8. Cross-Cutting Systems
- **Economy:** Typically none, or very limited in-game currency for upgrades.
- **Social:** Usually single-player, though asynchronous multiplayer (e.g., leaving messages) can be used.
- **Progression:** Unlockable difficulties, New Game Plus, speedrun rewards.
