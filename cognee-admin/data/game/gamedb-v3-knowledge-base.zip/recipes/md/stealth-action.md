# Archetype Recipe: Stealth Action

## 1. Archetype Identity

The **stealth-action** archetype, known in English as Stealth Action and in Chinese as 潜行动作类, is a gameplay archetype that emphasizes avoiding detection by enemies while navigating hostile environments to achieve objectives. It blends the tension of remaining unseen with the mechanical depth of action games, allowing players to use shadows, cover, disguises, and silent takedowns to outsmart AI opponents. When stealth fails, players must often rely on limited combat capabilities or escape mechanics to survive.

Benchmark games that define this archetype include *Hitman* (2016), *Metal Gear Solid V: The Phantom Pain* (2015), *Splinter Cell: Chaos Theory* (2005), and *Dishonored* (2012).

## 2. Elemental Tetrad Analysis

**Mechanics:** The core loop revolves around observation, planning, and execution. Players analyze enemy patrol routes and environmental layouts, formulate a strategy using available tools such as distractions and cover, and execute it. Failure shifts the game state from stealth to combat or evasion, requiring quick adaptation.

**Aesthetics:** Visually, these games often employ high-contrast lighting to clearly delineate safe shadows from dangerous illuminated areas. Audio design is critical, with clear cues for enemy footsteps, player noise, and alert states. The overall mood is tense and atmospheric.

**Story:** Narratives frequently involve espionage, assassination, or infiltration. Protagonists are typically highly trained operatives, thieves, or assassins operating behind enemy lines. Themes of conspiracy, betrayal, and moral ambiguity are common.

**Technology:** This archetype requires robust AI systems capable of complex pathfinding, sensory perception including sight and sound, and state management such as unaware, suspicious, searching, and combat. Dynamic lighting and sound propagation engines are also essential for communicating stealth mechanics to the player.

## 3. Atom Recipe Table

| atom_id | atom_name | role_in_archetype | weight | typical_config |
| :--- | :--- | :--- | :--- | :--- |
| `stealth_takedown` | Stealth Takedown | Primary method of eliminating enemies silently without raising alarms. | core | `noise_level: low`, `animation_duration: medium` |
| `vision_cone` | Vision Cone | Defines the visual perception area of AI enemies, dictating where the player can safely move. | core | `range: long`, `fov: 90` |
| `cover_system` | Cover System | Allows players to hide behind environmental objects to break line of sight. | core | `snap_distance: short`, `peeking: true` |
| `crouch_movement` | Crouch Movement | Reduces player profile and noise generation at the cost of movement speed. | core | `speed_multiplier: 0.5`, `noise_multiplier: 0.1` |
| `distraction_item` | Distraction Item | Tools used to manipulate enemy AI, drawing them away from their patrol paths. | important | `radius: medium`, `duration: short` |
| `alert_state` | Alert State | Manages the AI's awareness level, escalating from calm to active searching or combat. | core | `levels: ["unaware", "suspicious", "searching", "combat"]` |
| `melee_combo` | Melee Combo | Fallback combat option when stealth is broken, often risky against multiple foes. | optional | `damage: high`, `stamina_cost: medium` |
| `projectile` | Projectile | Ranged weapons, typically suppressed, used for taking out lights or distant enemies. | important | `suppressed: true`, `dropoff: realistic` |
| `climb_system` | Climb System | Enables vertical traversal to bypass ground-level security and find alternative routes. | important | `stamina_drain: low`, `ledge_grab: true` |
| `interconnected_map` | Interconnected Map | Provides multiple pathways and approaches to a single objective, rewarding exploration. | important | `verticality: high`, `multiple_routes: true` |

## 4. Atom Coupling Matrix

**Vision Cone and Cover System:** Cover physically blocks the AI's vision cones, allowing the player to remain undetected even when in close proximity to an enemy. This interaction creates a cat-and-mouse positioning dynamic, where players must constantly adjust their position relative to the enemy's gaze. The resulting aesthetic is one of tension and relief as patrols pass by inches away.

**Distraction Item and Alert State:** Throwing a distraction item forces an enemy's alert state to shift from unaware to suspicious, causing them to investigate the noise. This allows players to manipulate AI behavior to create openings in otherwise impenetrable defenses, fostering a feeling of mastery and intellectual superiority over the AI.

**Stealth Takedown and Alert State:** Successfully executing a stealth takedown removes an enemy from the map without triggering a higher alert state for the remaining guards. This introduces a risk versus reward elimination dynamic, where players must decide whether to risk a takedown or simply sneak past. The aesthetic is the satisfaction of a clean, surgical strike.

**Crouch Movement and Vision Cone:** Crouching reduces the player's physical profile, making them harder to detect within the outer, less sensitive edges of an enemy's vision cone. This leads to tension-filled traversal across open spaces, timing movements with enemy head turns, and emphasizes suspense and vulnerability.

**Climb System and Interconnected Map:** The climb system allows players to exploit the verticality of an interconnected map, bypassing heavily guarded ground routes. This encourages creative problem solving and route planning, turning the environment into a puzzle. The aesthetic is discovery and the thrill of finding a secret path.

## 5. MDA Chain

**Mechanics:** The game provides mechanics for perception through vision cones and auditory radii, concealment via cover, crouching, and shadows, manipulation using distractions, and elimination with stealth takedowns. AI operates on a state machine governed by alert levels.

**Dynamics:** These mechanics create a dynamic where players spend significant time observing and planning. They must predict AI behavior and execute precise movements. When a plan fails, the dynamic shifts rapidly from methodical stealth to chaotic evasion or desperate combat, forcing improvisation.

**Aesthetics:** The resulting aesthetics are heavily focused on suspense, which is the fear of discovery, mastery, representing the satisfaction of perfectly executing a complex plan, and expression, which is the freedom to choose between a ghost-like non-lethal approach or a lethal predator style.

## 6. Variant Spectrum

**Social Stealth:** This variant focuses on hiding in plain sight rather than in shadows. It adds atoms like `disguise_system` and `crowd_blending`, while removing or deemphasizing `cover_system` and `crouch_movement`.

**Immersive Sim Stealth:** These are highly systemic environments where stealth is just one of many viable approaches, heavily reliant on physics and elemental interactions. It adds `physics_puzzle`, `elemental_reaction`, and `multiple_endings`, while removing `linear_level_design`.

**Action Stealth:** This is a more forgiving stealth variant where being discovered leads to fluid, empowering combat rather than immediate failure or extreme disadvantage. It adds `melee_combo`, `dodge_roll`, and `bullet_time`, while removing `instant_fail_stealth`.

## 7. Anti-Patterns

**Inconsistent AI Perception:** When enemies can spot the player through solid walls or fail to notice them standing in broad daylight, it shatters the illusion and frustrates the player, as they cannot reliably plan their actions.

**Instant-Fail Stealth Sections:** Forcing a game over the moment the player is spotted removes the dynamic of improvisation and escape, turning the game into a tedious trial-and-error exercise.

**Lack of Feedback:** Failing to clearly communicate the player's visibility, noise level, or the enemy's alert state makes stealth feel arbitrary and unfair.

## 8. Cross-Cutting Systems

**Achievement System:** This system is often used to reward specific playstyles, such as completing a level without being spotted for a Ghost achievement, or without killing anyone for a Pacifist achievement.

**Loadout Customization:** Allowing players to choose their gadgets and weapons before a mission tailors their approach to their preferred style.

**Mission Rating System:** Grading the player's performance based on time, detections, and casualties encourages replayability and mastery.
