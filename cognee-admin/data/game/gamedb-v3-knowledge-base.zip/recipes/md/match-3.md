# Archetype Recipe: Match-3 (三消类)

## 1. Archetype Identity
- **ID:** match-3
- **Name (EN):** Match-3
- **Name (CN):** 三消类
- **Definition:** A puzzle game subgenre where the core mechanic involves manipulating tiles on a grid to create lines or groups of three or more identical tiles, causing them to disappear and new tiles to fall into place.
- **Benchmark Games:**
  - *Bejeweled* (2001)
  - *Candy Crush Saga* (2012)
  - *Puzzle & Dragons* (2012)
  - *Homescapes* (2017)

## 2. Elemental Tetrad Analysis
- **Mechanics:** Core loops revolve around swapping or dragging tiles to match 3 or more. Systems include cascade chains, special tile creation (match 4/5), level objectives (clear jelly, collect items), and move/time limits.
- **Aesthetics:** Bright, colorful, and highly polished visual feedback. Satisfying audio cues for matches, cascades, and level completion. Often features a lighthearted or thematic wrapper (candy, gems, home renovation).
- **Story:** Usually minimal or serves as a wrapper for progression (e.g., traveling through a candy kingdom, renovating a house). Narrative is delivered in bite-sized chunks between levels.
- **Technology:** 2D grid-based logic, robust physics/animation systems for falling tiles, procedural generation for initial board states, and backend systems for live-ops, economy, and social features.

## 3. Atom Recipe Table

| Atom ID | Atom Name | Role in Archetype | Weight | Typical Config |
|---------|-----------|-------------------|--------|----------------|
| `swap_match3` | Swap & Match 3 | The fundamental interaction of swapping adjacent tiles to form matches. | Core | `grid_size: 8x8, match_requirement: 3` |
| `cascade_chain` | Cascade Chain | Gravity-fed falling tiles creating subsequent matches automatically. | Core | `chain_multiplier: 1.5, gravity_speed: fast` |
| `one_tap` | One Tap / Drag | The primary input method, optimized for touchscreen devices. | Core | `input_type: swipe_or_tap` |
| `combo_counter` | Combo Counter | Tracks and rewards consecutive matches or cascades. | Important | `display_threshold: 3` |
| `energy_stamina_gate` | Energy/Stamina Gate | Limits play sessions by requiring energy to attempt levels. | Important | `max_energy: 5, recharge_rate: 30m` |
| `daily_weekly_reset` | Daily/Weekly Reset | Encourages daily login through rewards and rotating events. | Important | `reset_time: 00:00 UTC` |
| `gacha_banner` | Gacha Banner | Used in RPG variants (like Puzzle & Dragons) to acquire characters. | Optional | `pity_threshold: 50` |
| `meta_progression` | Meta Progression | Upgrading a base, character, or story outside the core puzzle. | Optional | `currency_type: stars` |

## 4. Atom Coupling Matrix
1. **`swap_match3` + `cascade_chain`**
   - *Interaction:* Swapping tiles creates a match, clearing space for new tiles to fall, which may create new matches.
   - *Emergent Dynamic:* Unpredictable chain reactions that clear large portions of the board.
   - *Aesthetic:* Sensation of luck, spectacle, and overwhelming positive feedback.
2. **`swap_match3` + `combo_counter`**
   - *Interaction:* Each successive match in a single move increments the combo counter.
   - *Emergent Dynamic:* Players actively look for moves that will trigger multiple matches.
   - *Aesthetic:* Mastery and achievement.
3. **`energy_stamina_gate` + `daily_weekly_reset`**
   - *Interaction:* Energy limits play, while daily resets provide free energy or items.
   - *Emergent Dynamic:* Habituation and session pacing.
   - *Aesthetic:* Anticipation and routine.
4. **`swap_match3` + `meta_progression`**
   - *Interaction:* Completing puzzle levels awards currency used to progress the meta-game (e.g., decorating a room).
   - *Emergent Dynamic:* The puzzle becomes a means to an end, driving long-term engagement.
   - *Aesthetic:* Expression and completion.
5. **`cascade_chain` + `gacha_banner`** (RPG Variant)
   - *Interaction:* Larger cascade chains deal more damage or activate character skills acquired via gacha.
   - *Emergent Dynamic:* Players optimize team composition to maximize the impact of cascades.
   - *Aesthetic:* Strategic depth and power fantasy.

## 5. MDA Chain
- **Mechanics:** Grid manipulation, tile matching, gravity/falling logic, move limits, special tile combinations.
- **Dynamics:** Board evaluation, pattern recognition, risk/reward calculation (using a special tile now vs. saving it), chain reaction anticipation.
- **Aesthetics:** 
  - *Sensation:* Audiovisual spectacle of cascades and explosions.
  - *Challenge:* Solving spatial puzzles within constraints.
  - *Pastime:* Relaxing, low-stakes engagement.
  - *Submission:* Entering a flow state during long play sessions.

## 6. Variant Spectrum
1. **Classic Arcade Match-3:** (e.g., *Bejeweled*) Focuses on high scores, time limits, and endless play. Removes `energy_stamina_gate`, adds `adaptive_difficulty`.
2. **Saga/Level-Based Match-3:** (e.g., *Candy Crush Saga*) Focuses on map progression, varied level objectives, and monetization. Adds `energy_stamina_gate`, `social_map`.
3. **Puzzle RPG:** (e.g., *Puzzle & Dragons*) Combines matching with enemy combat and team building. Adds `gacha_banner`, `elemental_reaction`, `xp_level`.
4. **Decor/Narrative Match-3:** (e.g., *Homescapes*) Uses puzzle levels to gate narrative and customization. Adds `room_decoration`, `branching_dialogue`.

## 7. Anti-Patterns
1. **Over-Reliance on RNG:** Levels that are impossible to beat without a lucky initial board state or lucky cascades, leading to frustration.
2. **Pay-to-Win Walls:** Sudden, extreme difficulty spikes designed solely to force the purchase of premium boosters.
3. **Visual Clutter:** Too many special tiles, animations, or board mechanics that make it difficult to read the grid and plan moves.

## 8. Cross-Cutting Systems
- **Economy/Monetization:** Free-to-play with in-app purchases for premium currency, boosters, extra moves, and energy refills.
- **Social:** Leaderboards, sending/receiving lives with friends, guild/clan systems in RPG variants.
- **Live-Ops:** Frequent content updates (new levels), seasonal events, battle passes, and limited-time challenges.
