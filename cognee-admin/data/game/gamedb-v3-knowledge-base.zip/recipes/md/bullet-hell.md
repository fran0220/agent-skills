# Archetype Recipe: Bullet Hell (弹幕类)

## 1. Archetype Identity
- **ID:** `bullet-hell`
- **Names:** Bullet Hell / 弹幕类
- **Definition:** A subgenre of shoot 'em up games characterized by an overwhelming number of enemy projectiles on screen, often forming complex geometric patterns. Players must navigate a character with a very small hitbox through these dense patterns while simultaneously dealing damage to enemies.
- **Benchmark Games:**
  - *Touhou Project* (1996)
  - *Ikaruga* (2001)
  - *Enter the Gungeon* (2016)
  - *DoDonPachi* (1997)

## 2. Elemental Tetrad Analysis
- **Mechanics:** The core loop involves dodging dense projectile patterns using precise movement, managing screen-clearing resources (bombs), and maintaining a continuous stream of fire against enemies. The player's hitbox is typically much smaller than their character sprite.
- **Aesthetics:** Visually spectacular, often featuring bright, colorful, and mesmerizing geometric patterns of bullets that fill the screen. The audio is usually fast-paced and energetic to match the high-tension gameplay.
- **Story:** Often minimal or abstracted, serving primarily as a backdrop for the action. In some series like Touhou, the narrative is conveyed through pre-boss dialogue and rich character lore.
- **Technology:** Requires highly optimized 2D collision detection systems capable of handling thousands of active projectiles simultaneously without frame drops.

## 3. Atom Recipe Table

| atom_id | atom_name | role_in_archetype | weight | typical_config |
| :--- | :--- | :--- | :--- | :--- |
| projectile | Projectile | The primary hazard and visual spectacle of the genre. | core | density: extreme, pattern: geometric |
| iframes | Invincibility Frames | Provides brief moments of safety, often tied to a dodge or bomb. | core | duration: short, trigger: dodge_roll/bomb |
| dodge_roll | Dodge Roll | Allows players to quickly reposition or pass through bullet walls. | important | distance: medium |
| hitscan | Hitscan | Used sparingly to force immediate player movement. | optional | frequency: low |
| ability_cooldown | Ability Cooldown | Manages the use of screen-clearing bombs or special attacks. | important | type: screen_clear_bomb |
| combo_counter | Combo Counter | Rewards aggressive play and grazing bullets. | important | decay: fast |
| permadeath | Permadeath | Creates high stakes, often mitigated by a set number of lives. | important | lives: 3 |

## 4. Atom Coupling Matrix
1. **projectile + iframes:** Player uses iframes to pass through dense projectile walls that are otherwise impassable. This creates a dynamic of high-risk, high-reward positioning and an aesthetic of thrilling narrow escapes.
2. **projectile + combo_counter:** Grazing (flying extremely close to) projectiles increases the combo counter. This encourages playing dangerously close to bullets, creating a dynamic of risk management and an aesthetic of mastery.
3. **dodge_roll + ability_cooldown:** Successful dodges reduce the cooldown of the player's bomb ability. This creates an aggressive defensive playstyle, rewarding players for actively engaging with threats rather than purely avoiding them.
4. **permadeath + combo_counter:** Maintaining a high combo grants extra lives or extends the run. This creates a skill-based survival extension dynamic, rewarding consistent high-level play.
5. **projectile + hitscan:** Enemies mix slow, dense projectiles with fast hitscan attacks to restrict movement and force immediate reactions. This creates complex spatial awareness requirements and an aesthetic of overwhelming challenge.

## 5. MDA Chain
- **Mechanics:** Dense projectile patterns, precise hitbox (often smaller than sprite), screen-clearing bombs, grazing mechanics.
- **Dynamics:** Pattern memorization and recognition, micro-dodging and macro-routing, resource management (bombs/lives) under extreme pressure.
- **Aesthetics:** Challenge (overcoming seemingly impossible odds), Sensation (the visual spectacle of bullet patterns), Submission (entering a flow state to process the visual information).

## 6. Variant Spectrum
- **Roguelite Bullet Hell:** Adds `run_based`, `random_affix`, and `relic_artifact`. Removes strict arcade `permadeath`. Focuses on build variety and procedural generation (e.g., *Enter the Gungeon*).
- **Rhythm Bullet Hell:** Adds `timing_window` and `note_highway`. Removes free movement. Actions must be synchronized with the music (e.g., *Just Shapes & Beats*).
- **Puzzle Bullet Hell:** Adds `logic_deduction` and `spatial_portal`. Removes `combo_counter`. Focuses on finding the specific solution to a bullet pattern rather than pure reaction.

## 7. Anti-Patterns
1. **Unreadable Patterns:** Projectiles that blend into the background or overlap in ways that make their trajectories impossible to predict, leading to unfair deaths.
2. **Misleading Hitboxes:** A player hitbox that is larger than it appears, or enemy projectiles with hitboxes larger than their sprites, causing frustration.
3. **Resource Starvation:** Providing too few bombs or lives in sections with unavoidable damage, forcing players into unwinnable situations.

## 8. Cross-Cutting Systems
- **Leaderboard System:** Essential for arcade-style bullet hells to drive replayability and competition.
- **Replay Sharing:** Allows players to study high-level play and share their achievements.
- **Achievement System:** Provides meta-goals beyond simply clearing the game, such as 1CC (1 Credit Clear) or pacifist runs.
