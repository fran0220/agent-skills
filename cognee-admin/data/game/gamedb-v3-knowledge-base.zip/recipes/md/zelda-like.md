# Archetype Recipe: Zelda-like

## 1. Archetype Identity
**ID:** `zelda-like`
**English Name:** Zelda-like
**Chinese Name:** 塞尔达类

**Definition:**
The Zelda-like archetype represents a genre of action-adventure games characterized by a strong emphasis on exploration, puzzle-solving, and systemic interactions within a cohesive, often open or semi-open world. These games empower players with a versatile toolkit of abilities and items that serve dual purposes in both combat and environmental traversal. The core philosophy revolves around player-driven discovery, where the world itself acts as a massive puzzle box, and progression is often gated by the acquisition of new tools or the mastery of systemic mechanics rather than arbitrary numerical stats.

**Benchmark Games:**
- *The Legend of Zelda: Breath of the Wild* (2017)
- *The Legend of Zelda: Tears of the Kingdom* (2023)
- *Okami* (2006)
- *Immortals Fenyx Rising* (2020)

## 2. Elemental Tetrad Analysis

### Mechanics
The core loop involves exploring the environment, identifying obstacles or points of interest, and utilizing a combination of traversal abilities (climbing, gliding) and physics-based tools to overcome them. Combat is often stamina-driven and heavily relies on environmental awareness, encouraging players to use physics and elemental reactions to gain an advantage. Progression is tied to discovering shrines, dungeons, or hidden areas that reward the player with health/stamina upgrades or new abilities.

### Aesthetics
Visually, Zelda-like games often employ stylized, cel-shaded, or vibrant art directions that prioritize readability and clear visual language over hyper-realism. This ensures that interactive elements, climbable surfaces, and points of interest stand out against the environment. The audio design heavily features ambient nature sounds punctuated by minimalist, dynamic musical cues that swell during combat or significant discoveries, reinforcing a sense of wonder and isolation.

### Story
The narrative structure typically follows a "Hero's Journey" framework, often involving a chosen protagonist awakening to save a kingdom from an ancient, cyclical evil. The storytelling is largely environmental and non-linear, allowing players to piece together the lore and history of the world through scattered ruins, NPC interactions, and optional memory fragments, supporting the open-ended nature of the gameplay.

### Technology
Technologically, these games require robust physics engines capable of handling complex interactions between multiple objects, elements (fire, wind, electricity), and the player. Seamless open-world streaming is crucial to maintain immersion without loading screens. Additionally, advanced AI systems are needed for systemic enemy behaviors that react dynamically to the player's actions and environmental changes.

## 3. Atom Recipe Table

| atom_id | atom_name | role_in_archetype | weight | typical_config |
| :--- | :--- | :--- | :--- | :--- |
| `climb_system` | Climb System | Enables vertical exploration and bypasses traditional pathing. | core | `stamina_cost: high`, `surface_restriction: none` |
| `glide_float` | Glide / Float | Facilitates rapid, safe descent and horizontal traversal from high vantage points. | core | `stamina_drain: medium`, `height_loss: low` |
| `stamina_combat` | Stamina Combat | Limits continuous actions, forcing tactical pacing in fights and traversal. | important | `regen_rate: fast` |
| `physics_puzzle` | Physics Puzzle | Forms the basis of environmental problem-solving and emergent combat tactics. | core | `interaction_types: [push, pull, lift, stasis]` |
| `resource_gathering` | Resource Gathering | Drives exploration and fuels the crafting/cooking systems for buffs. | important | `respawn_timer: blood_moon` |
| `crafting_recipe` | Crafting Recipe | Encourages experimentation with gathered materials to create survival items. | important | `discovery_method: experimentation` |
| `interconnected_map` | Interconnected Map | Provides a cohesive world where visual landmarks guide player navigation. | core | `verticality: high`, `landmarks: visible_from_afar` |
| `ability_gating` | Ability Gating | Restricts access to certain areas until specific tools or knowledge are acquired. | core | `soft_gating: true`, `hard_gating: false` |
| `day_night_cycle` | Day/Night Cycle | Alters enemy spawns, NPC behaviors, and environmental conditions dynamically. | important | `enemy_spawns: dynamic`, `npc_schedules: active` |
| `biome_system` | Biome System | Introduces environmental hazards (heat, cold) that require specific preparation. | core | `temperature_effects: true`, `weather_hazards: true` |

## 4. Atom Coupling Matrix

1. **`climb_system` + `stamina_combat`**
   - **Interaction:** Stamina is a shared resource pool for both vertical traversal and combat actions.
   - **Emergent Dynamic:** Players must carefully manage their stamina gauge when engaging enemies on uneven terrain or immediately after a long climb, leading to tense moments of vulnerability.
   - **Aesthetic:** Tension and strategic resource management.

2. **`physics_puzzle` + `ability_gating`**
   - **Interaction:** Physics-manipulation abilities act as the "keys" to environmental puzzles and traversal obstacles.
   - **Emergent Dynamic:** Players creatively combine physics tools (like stasis and kinetic energy) to bypass intended puzzle solutions or launch themselves to unintended areas.
   - **Aesthetic:** Expression and intellectual satisfaction.

3. **`day_night_cycle` + `biome_system`**
   - **Interaction:** The time of day directly impacts the temperature and weather conditions of specific biomes.
   - **Emergent Dynamic:** Players must prepare specific clothing, food, or fire sources for nighttime in cold biomes or daytime in hot biomes, turning the environment itself into an antagonist.
   - **Aesthetic:** Survival and immersion.

4. **`resource_gathering` + `crafting_recipe`**
   - **Interaction:** Gathered resources from the open world are combined experimentally without explicit recipes.
   - **Emergent Dynamic:** Players are intrinsically motivated to explore every nook and cranny to gather diverse ingredients, testing combinations to discover powerful buffs or healing items.
   - **Aesthetic:** Discovery and experimentation.

5. **`glide_float` + `interconnected_map`**
   - **Interaction:** Gliding allows for rapid, line-of-sight traversal across the map from elevated positions.
   - **Emergent Dynamic:** Players actively seek out high vantage points (towers, mountains) to scout the landscape, identify points of interest, and glide directly to them, creating a satisfying loop of climb-scout-glide.
   - **Aesthetic:** Freedom and visual majesty.

## 5. MDA Chain

**Mechanics:**
- Stamina-gated universal climbing and gliding mechanics.
- A robust, systemic physics engine governing object interactions, gravity, and momentum.
- Elemental chemistry systems (e.g., fire creates updrafts, water conducts electricity).
- Open-ended, physics-based puzzle design.

**Dynamics:**
- **Emergent Gameplay:** Players combine basic mechanics in unforeseen ways to solve puzzles or defeat enemies (e.g., dropping metal weapons in a thunderstorm to attract lightning to enemies).
- **Player-Driven Goal Setting:** The lack of strict linear progression encourages players to set their own micro-goals based on visual landmarks.
- **Creative Problem Solving:** Puzzles have multiple valid solutions depending on the player's current toolkit and ingenuity.

**Aesthetics:**
- **Discovery:** The joy of uncovering hidden secrets, mechanics, and interactions in a vast world.
- **Expression:** The freedom to tackle challenges and traverse the world in a highly personalized manner.
- **Fantasy:** Immersing oneself in a vibrant, living world as a capable adventurer.
- **Challenge:** Overcoming environmental hazards and formidable foes through preparation and wit.

## 6. Variant Spectrum

1. **Classic Zelda-like (Pre-BotW)**
   - **Atoms Added:** `dungeon_crawling`, `item_based_progression` (strict lock-and-key design).
   - **Atoms Removed:** `climb_system`, `glide_float`, `stamina_combat`.
   - **Description:** Focuses on linear progression through distinct, themed dungeons using specific items found within them.

2. **Survival Zelda-like**
   - **Atoms Added:** `hunger_thirst`, `base_building`, `permadeath`.
   - **Atoms Removed:** `ability_gating` (often replaced by resource gating).
   - **Description:** Emphasizes the harshness of the environment, requiring constant resource management and shelter construction to survive.

3. **Action-RPG Zelda-like**
   - **Atoms Added:** `xp_level`, `skill_tree`, `loot_rarity`.
   - **Atoms Removed:** `physics_puzzle`.
   - **Description:** Shifts the focus from environmental puzzle-solving to combat mastery, character builds, and grinding for better gear.

## 7. Anti-Patterns

1. **Over-Reliance on UI Markers:** Cluttering the map with objective markers and question marks undermines the core aesthetic of discovery and player-driven exploration, turning the game into a checklist rather than an adventure.
2. **Rigid Puzzle Solutions:** Designing puzzles that only accept one specific, developer-intended solution frustrates players and negates the value of a systemic physics engine, breaking the illusion of freedom.
3. **Meaningless Durability:** Implementing weapon durability without providing a constant, satisfying stream of replacements or alternative combat options leads to hoarding behavior and combat avoidance.

## 8. Cross-Cutting Systems

While traditionally single-player, premium experiences, modern adaptations or live-service variants of the Zelda-like archetype often layer the following systems:
- **`economy_f2p`:** Free-to-play monetization models.
- **`gacha_banner`:** Character or weapon acquisition through randomized pulls (e.g., *Genshin Impact*).
- **`battle_pass`:** Seasonal progression tracks rewarding cosmetics and resources.
- **`social_multiplayer`:** Co-op exploration or asynchronous multiplayer elements (e.g., leaving messages or sharing resources).
