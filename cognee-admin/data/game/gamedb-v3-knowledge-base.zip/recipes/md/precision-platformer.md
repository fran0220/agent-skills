# Archetype Recipe: Precision Platformer

## 1. Archetype Identity
- **ID**: precision-platformer
- **Name (EN)**: Precision Platformer
- **Name (CN)**: 精确平台跳跃
- **Definition**: A subgenre of platform games characterized by demanding, tight controls, high difficulty, and frequent deaths with rapid respawns. These games focus on executing precise sequences of jumps, dashes, and other movement mechanics to navigate hazardous environments.
- **Benchmark Games**:
  - *Super Meat Boy* (2010)
  - *Celeste* (2018)
  - *The End Is Nigh* (2017)
  - *N++* (2015)

## 2. Elemental Tetrad Analysis
- **Mechanics**: The core loop revolves around trial-and-error platforming. Players must navigate from point A to point B through rooms filled with instant-death hazards (spikes, saws). Systems emphasize momentum, precise timing, and chaining movement abilities.
- **Aesthetics**: Often features minimalist or highly readable pixel art to ensure hazards and safe zones are instantly recognizable. Audio relies on upbeat, driving soundtracks to maintain player flow and motivation despite repeated failures.
- **Story**: Narratives are usually secondary but often thematic to the struggle of the gameplay. For example, overcoming personal demons or climbing a literal and metaphorical mountain.
- **Technology**: Requires extremely responsive input handling, high frame rates, and deterministic physics to ensure that player deaths always feel fair and avoidable.

## 3. Atom Recipe Table

| Atom ID | Atom Name | Role in Archetype | Weight | Typical Config |
|---------|-----------|-------------------|--------|----------------|
| variable_jump | Variable Jump | Allows fine control over jump height based on button hold duration. | Core | `min_height: 1.0, max_height: 4.0` |
| coyote_time | Coyote Time | Forgives late jump inputs when running off ledges, reducing frustration. | Core | `duration_frames: 4-6` |
| jump_buffer | Jump Buffer | Queues jump inputs slightly before landing to ensure smooth chaining. | Core | `buffer_frames: 4-6` |
| wall_slide_jump | Wall Slide & Jump | Enables vertical traversal and complex routing between vertical surfaces. | Core | `slide_friction: high, jump_angle: 45deg` |
| air_dash | Air Dash | Provides horizontal or omnidirectional bursts of speed for crossing gaps. | Important | `cooldown: reset_on_ground, distance: fixed` |
| checkpoint | Checkpoint | Frequent, often room-by-room respawn points to minimize lost progress. | Core | `respawn_time: <0.5s` |
| timing_window | Timing Window | Demands precise execution of mechanics within tight frames. | Core | `tolerance: strict` |
| interconnected_map | Interconnected Map | Often structures the world into distinct, themed zones with escalating difficulty. | Optional | `structure: linear_rooms_with_secrets` |

## 4. Atom Coupling Matrix

1. **variable_jump + coyote_time**:
   - **Interaction**: Players can run off a ledge and still execute a perfectly tailored jump.
   - **Emergent Dynamic**: Creates a feeling of fluid, uninterrupted momentum even when making split-second decisions.
   - **Aesthetic**: Sensation of flow and mastery over the character's weight.

2. **air_dash + wall_slide_jump**:
   - **Interaction**: Dashing into a wall to immediately transition into a wall jump.
   - **Emergent Dynamic**: Allows for rapid changes in direction and scaling complex vertical shafts.
   - **Aesthetic**: High-speed, acrobatic traversal that looks and feels spectacular.

3. **checkpoint + timing_window**:
   - **Interaction**: Extremely tight execution requirements paired with instant respawns.
   - **Emergent Dynamic**: Encourages rapid iteration and trial-and-error without the penalty of long runbacks.
   - **Aesthetic**: "One more try" addiction and a trance-like state of focused repetition.

4. **jump_buffer + variable_jump**:
   - **Interaction**: Inputting a jump before landing and holding it for maximum height.
   - **Emergent Dynamic**: Ensures that frame-perfect sequential jumps are reliably executable by human players.
   - **Aesthetic**: Smooth, rhythmic bouncing across hazards.

5. **air_dash + interconnected_map**:
   - **Interaction**: Using dashes to reach hidden areas or bypass intended routes.
   - **Emergent Dynamic**: Speedrunning and sequence breaking become core community activities.
   - **Aesthetic**: Discovery and expressive freedom within a rigid mechanical framework.

## 5. MDA Chain
- **Mechanics**: Tight movement controls (variable jump, dash, wall jump), instant death hazards, rapid respawns, room-based checkpoints.
- **Dynamics**: Players engage in a loop of observe, attempt, fail, adjust, and succeed. They learn the spatial layout and rhythm of each room, building muscle memory.
- **Aesthetics**: Challenge (overcoming immense difficulty), Submission (entering a flow state through repetition), and Discovery (finding optimal routes or secrets).

## 6. Variant Spectrum
- **Metroidvania Hybrid**: Adds `ability_gating` and `interconnected_map` (e.g., *Hollow Knight* Path of Pain). Removes strict linearity.
- **Combat Platformer**: Adds `melee_combo` and `iframes` (e.g., *Katana ZERO*). Shifts focus from pure traversal to enemy management.
- **Puzzle Platformer**: Adds `physics_puzzle` and `logic_deduction` (e.g., *Braid*). Reduces execution speed requirements in favor of spatial reasoning.

## 7. Anti-Patterns
1. **Inconsistent Physics**: Variable jump heights or unpredictable momentum that makes deaths feel unfair rather than the player's fault.
2. **Long Respawn Times**: Breaking the flow state by forcing players to wait or watch long animations after a failure.
3. **Visual Clutter**: Backgrounds or foreground elements that obscure hazards, making it difficult to read the safe path at a glance.

## 8. Cross-Cutting Systems
- **Speedrunning Integration**: Built-in timers, ghost replays, and leaderboards.
- **Accessibility Options**: Game speed toggles, infinite stamina, or invincibility modes to broaden the audience.
- **User-Generated Content**: Level editors and custom campaign sharing (e.g., *Super Mario Maker*).
