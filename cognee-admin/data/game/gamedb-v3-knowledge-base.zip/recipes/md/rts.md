# Archetype Recipe: Real-Time Strategy (RTS)

## 1. Archetype Identity
- **ID**: rts
- **Name (EN)**: Real-Time Strategy
- **Name (CN)**: 即时战略
- **Definition**: Real-Time Strategy (RTS) is a subgenre of strategy video games where the game does not progress incrementally in turns. Instead, all players play simultaneously, in "real-time". Players typically gather resources, build bases, research technologies, and produce units to defeat their opponents in military combat. The core gameplay loop revolves around macro-management (economy and production) and micro-management (unit control and positioning).
- **Benchmark Games**:
  - *StarCraft* (1998)
  - *Age of Empires II: The Age of Kings* (1999)
  - *Warcraft III: Reign of Chaos* (2002)
  - *Command & Conquer: Red Alert 2* (2000)
  - *Company of Heroes* (2006)

## 2. Elemental Tetrad Analysis
- **Mechanics**: The core loops involve resource gathering, base building, technology research, and unit production. Systems include fog of war, unit pathfinding, combat resolution (damage types, armor types), and economy management. The primary interaction is issuing commands to units and structures in real-time.
- **Aesthetics**: Visually, RTS games often employ an isometric or top-down perspective to provide a comprehensive view of the battlefield. Audio plays a crucial role with distinct unit responses, combat sounds, and alert notifications (e.g., "Base under attack"). The aesthetic experience is one of command, tension, and strategic mastery.
- **Story**: Narrative structures often involve multiple factions with distinct ideologies and campaigns. The story is typically conveyed through pre-mission briefings, in-game dialogue, and cutscenes, focusing on large-scale conflicts, political intrigue, and the fate of nations or species.
- **Technology**: Typical technical requirements include robust pathfinding algorithms (e.g., A*), efficient handling of hundreds of simultaneous units, deterministic lockstep networking for multiplayer synchronization, and a responsive user interface for rapid command input.

## 3. Atom Recipe Table

| Atom ID | Atom Name | Role in Archetype | Weight | Typical Config |
| :--- | :--- | :--- | :--- | :--- |
| resource_gathering | Resource Gathering | Core economic engine; drives production and expansion. | Core | `resource_types: 2-4`, `depletion_rate: medium` |
| tech_tree | Tech Tree | Unlocks advanced units and structures; dictates strategic progression. | Core | `branching: high`, `research_time: variable` |
| fog_of_war | Fog of War | Creates uncertainty; necessitates scouting and intelligence gathering. | Core | `vision_range: unit_dependent`, `reveal_terrain: true` |
| unit_production | Unit Production | Generates military force; requires balancing economy and military. | Core | `queue_size: 5`, `rally_point: enabled` |
| base_building | Base Building | Establishes infrastructure, defense, and map control. | Core | `placement_grid: true`, `construction_time: variable` |
| combat_resolution | Combat Resolution | Determines outcomes of engagements based on stats and positioning. | Core | `damage_types: multiple`, `armor_types: multiple` |
| pathfinding | Pathfinding | Ensures units navigate terrain and obstacles efficiently. | Core | `algorithm: A*`, `collision_avoidance: high` |
| control_groups | Control Groups | Allows rapid selection and management of specific unit formations. | Important | `max_groups: 10`, `hotkeys: 1-0` |
| minimap | Minimap | Provides a macro-level overview of the battlefield and unit positions. | Important | `ping_system: enabled`, `click_to_move: true` |
| hero_units | Hero Units | Powerful individual units with unique abilities; adds micro depth. | Optional | `respawn: true/false`, `leveling: optional` |
| terrain_elevation | Terrain Elevation | Influences combat (e.g., high ground advantage) and movement. | Optional | `miss_chance_low_ground: 25%`, `vision_block: true` |

## 4. Atom Coupling Matrix
1. **resource_gathering + unit_production**:
   - **Interaction**: Gathering resources directly funds the production of units.
   - **Emergent Dynamic**: The "macro cycle" where players must constantly balance spending resources on economy (more gatherers) vs. military (more fighters).
   - **Aesthetic**: Tension between greed (economic boom) and safety (military defense).
2. **fog_of_war + minimap**:
   - **Interaction**: The minimap displays known information, but fog of war obscures enemy movements.
   - **Emergent Dynamic**: Scouting becomes essential. Players must actively seek information while denying it to the opponent.
   - **Aesthetic**: Paranoia and the thrill of discovery or successful deception.
3. **tech_tree + base_building**:
   - **Interaction**: Specific buildings unlock specific branches of the tech tree.
   - **Emergent Dynamic**: "Tech switching" where players hide building construction to surprise opponents with unexpected unit types.
   - **Aesthetic**: Strategic depth and the satisfaction of outsmarting the opponent.
4. **control_groups + combat_resolution**:
   - **Interaction**: Players use control groups to execute precise micro-management during combat.
   - **Emergent Dynamic**: "Kiting," "focus firing," and "flanking" maneuvers that allow a smaller force to defeat a larger one through superior control.
   - **Aesthetic**: Mastery of execution and the adrenaline rush of intense micro battles.
5. **terrain_elevation + fog_of_war**:
   - **Interaction**: High ground often grants vision over low ground, while low ground cannot see up.
   - **Emergent Dynamic**: Choke point control and positional advantage become critical objectives on the map.
   - **Aesthetic**: Tactical positioning and the satisfaction of holding a defensible location.

## 5. MDA Chain
- **Mechanics**: Resource gathering, base building, unit production, tech tree progression, fog of war, real-time command issuance.
- **Dynamics**: Economic expansion vs. military aggression (rush vs. boom), scouting and counter-scouting, tech transitions, micro-management in combat, map control and resource denial.
- **Aesthetics**:
  - *Challenge*: Overcoming complex strategic and tactical problems under time pressure.
  - *Expression*: Developing unique playstyles (e.g., aggressive rusher, defensive turtle, unpredictable trickster).
  - *Submission*: Entering a flow state of high Actions Per Minute (APM) and multitasking.
  - *Competition*: The intense rivalry and psychological warfare against human opponents.

## 6. Variant Spectrum
1. **Grand Strategy RTS**: Adds deep diplomacy, complex trade, and massive scale (e.g., *Stellaris*, *Sins of a Solar Empire*). Atoms added: `diplomacy_system`, `trade_routes`. Atoms removed: `micro_heavy_combat`.
2. **Tactical RTS (RTT)**: Removes base building and resource gathering, focusing entirely on unit combat and positioning (e.g., *World in Conflict*, *Myth*). Atoms removed: `base_building`, `resource_gathering`. Atoms added: `reinforcement_points`, `cover_system`.
3. **Hero-Centric RTS**: Blends RTS with RPG elements, focusing heavily on powerful hero units and their abilities (e.g., *Warcraft III*, *SpellForce*). Atoms added: `hero_units`, `xp_level`, `inventory_system`.
4. **Survival RTS**: Focuses on defending a base against endless waves of AI enemies rather than defeating a peer opponent (e.g., *They Are Billions*). Atoms added: `wave_system`, `pause_command`. Atoms removed: `multiplayer_pvp`.

## 7. Anti-Patterns
1. **Snowballing**: When a small early advantage inevitably leads to an insurmountable lead, making the rest of the game a foregone conclusion. This reduces comeback potential and player engagement.
2. **APM Tax**: Designing mechanics that require high physical dexterity (Actions Per Minute) just to maintain basic efficiency, rather than rewarding strategic decision-making. This alienates players with lower mechanical skill.
3. **Deathballing**: When the optimal strategy is simply to group all units into one massive, un-microable army and attack-move across the map, negating the need for tactical positioning or multi-pronged attacks.

## 8. Cross-Cutting Systems
- **Economy/Monetization**: Traditionally premium (buy-to-play) with expansion packs. Modern iterations may include cosmetic microtransactions (skins, announcers, UI themes) or a Free-to-Play model with a rotating roster of factions/commanders (e.g., *StarCraft II* Co-op).
- **Social/Multiplayer**: Robust matchmaking systems (Elo/MMR), ranked ladders, automated tournaments, clan/guild support, spectator modes, and replay sharing are essential for the competitive ecosystem.
- **Progression**: Meta-progression is often limited to cosmetic unlocks or player profile levels to maintain competitive integrity. Co-op or PvE modes may feature deep progression systems (e.g., commander leveling).
