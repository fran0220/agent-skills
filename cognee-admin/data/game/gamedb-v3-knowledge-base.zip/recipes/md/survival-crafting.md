# Archetype Recipe: Survival Crafting

## 1. Archetype Identity
**ID:** survival-crafting
**Names:** Survival Crafting (English) / 生存制造类 (Chinese)
**Definition:** The Survival Crafting archetype is a genre of video games where the player starts with minimal resources in a hostile environment and must gather materials, craft tools, build shelters, and manage survival meters (such as hunger, thirst, and health) to endure and progress. The core loop revolves around exploration, resource acquisition, technological advancement, and environmental mastery.
**Benchmark Games:**
- Minecraft (2011)
- Terraria (2011)
- Valheim (2021)
- Rust (2013)
- Subnautica (2018)

## 2. Elemental Tetrad Analysis
- **Mechanics:** The core loops consist of resource gathering, crafting, building, and survival management. Players explore the world to find materials, which are then used to craft better tools and structures. These advancements allow players to gather more advanced resources and survive against increasingly difficult environmental hazards or enemies.
- **Aesthetics:** Visual and audio styles often emphasize the contrast between the harsh, untamed wilderness and the safety of player-built sanctuaries. Sound design plays a crucial role in signaling danger (e.g., approaching enemies or weather changes) and rewarding progress (e.g., the satisfying sound of chopping wood or completing a structure).
- **Story:** Narrative structures are typically emergent, driven by the player's actions and experiences rather than a linear script. Environmental storytelling is common, with lore scattered throughout the world for players to discover. The primary narrative is the player's journey from vulnerability to mastery.
- **Technology:** Typical technical requirements include robust procedural generation systems to create expansive, unique worlds, complex inventory and crafting databases, and dynamic environmental systems (e.g., day/night cycles, weather). Voxel-based or highly modifiable terrain engines are also common to support extensive building mechanics.

## 3. Atom Recipe Table

| Atom ID | Atom Name | Role in Archetype | Weight | Typical Config |
| :--- | :--- | :--- | :--- | :--- |
| resource_gathering | Resource Gathering | Core loop of acquiring materials for crafting and building. | Core | yield_variance: high, tool_tier_gating: true |
| crafting_recipe | Crafting Recipe | System for combining resources into tools, weapons, and structures. | Core | unlock_method: discovery/tech_tree |
| energy_stamina_gate | Energy/Stamina Gate | Limits player actions and forces strategic resource management (e.g., hunger, thirst). | Core | depletion_rate: moderate, recovery_items: food/water |
| procedural_gen | Procedural Generation | Creates unique, expansive worlds for exploration and replayability. | Core | seed_based: true, biome_diversity: high |
| day_night_cycle | Day/Night Cycle | Dictates pacing, with nights typically being more dangerous and requiring shelter. | Core | night_duration: 30%, night_threat_multiplier: 2.0 |
| biome_system | Biome System | Provides varied environments with unique resources and hazards. | Important | biome_count: 5+, transition_smoothness: high |
| melee_combo | Melee Combo | Basic combat system for defending against wildlife and enemies. | Important | stamina_cost: low, knockback: moderate |
| projectile | Projectile | Ranged combat options (e.g., bows, firearms) for hunting and defense. | Important | ammo_craftable: true, gravity_drop: true |
| tech_tree | Tech Tree | Structures progression by unlocking new crafting recipes and abilities. | Important | tier_count: 4+, resource_cost_scaling: exponential |
| stealth_takedown | Stealth Takedown | Allows players to bypass or ambush enemies, conserving resources. | Optional | detection_radius: dynamic, noise_multiplier: terrain_based |
| physics_puzzle | Physics Puzzle | Adds variety to exploration and resource acquisition (e.g., moving boulders). | Optional | complexity: low, reward: rare_resources |
| collection_log | Collection Log | Encourages exploration and completionism by tracking discovered items and creatures. | Optional | reward_tiers: cosmetic/minor_buffs |

## 4. Atom Coupling Matrix

1. **resource_gathering + crafting_recipe**
   - **Dynamic:** The fundamental progression loop. Gathering resources unlocks new crafting recipes, which in turn provide better tools for more efficient gathering.
   - **Aesthetic:** A sense of continuous growth and empowerment as the player transforms raw materials into complex items.

2. **energy_stamina_gate + day_night_cycle**
   - **Dynamic:** Forces players to plan their activities. Daytime is for gathering and exploration, while nighttime requires shelter and consumes stored resources (food/warmth).
   - **Aesthetic:** Tension and relief. The anxiety of being caught outside at night contrasts with the comfort of returning to a well-stocked base.

3. **procedural_gen + biome_system**
   - **Dynamic:** Encourages long-distance exploration. Players must venture into new, procedurally generated biomes to find specific resources required for progression.
   - **Aesthetic:** Wonder and discovery. Each new biome presents unique visual themes, challenges, and rewards.

4. **tech_tree + resource_gathering**
   - **Dynamic:** Creates long-term goals. Players must gather specific, often rare, resources to unlock higher tiers of the tech tree, driving exploration into more dangerous areas.
   - **Aesthetic:** Anticipation and satisfaction. The build-up to unlocking a major technological advancement is rewarded with significant gameplay improvements.

5. **melee_combo/projectile + biome_system**
   - **Dynamic:** Combat difficulty scales with exploration. Different biomes introduce new enemy types that require varied combat strategies and better equipment.
   - **Aesthetic:** Mastery and adaptation. Players must learn enemy patterns and prepare appropriate weapons before entering new biomes.

## 5. MDA Chain
- **Mechanics:** Resource gathering, crafting, building, survival meters (hunger/thirst), procedural world generation, day/night cycles.
- **Dynamics:** Players establish a safe base, venture out to gather resources, manage their survival needs, and gradually upgrade their equipment and shelter to explore more dangerous areas. The interplay between limited inventory space and the desire to hoard resources creates constant decision-making.
- **Aesthetics:** 
  - *Challenge:* Overcoming the harsh environment and hostile creatures.
  - *Discovery:* Exploring unknown, procedurally generated lands.
  - *Expression:* Designing and building unique bases and structures.
  - *Submission:* Engaging in the repetitive but satisfying loop of gathering and crafting.

## 6. Variant Spectrum
1. **Hardcore Survival:** Emphasizes realistic survival mechanics (e.g., temperature, disease, complex nutrition). Adds atoms like `permadeath` and `adaptive_difficulty`. Removes forgiving atoms like `checkpoint`. Example: *The Long Dark*.
2. **Creative Sandbox:** Focuses heavily on building and expression, often with a mode that disables survival threats. Adds atoms like `room_decoration` and `one_tap` (for instant building). Removes `energy_stamina_gate`. Example: *Minecraft (Creative Mode)*.
3. **Narrative Survival:** Integrates a strong, linear or branching story into the survival loop. Adds atoms like `branching_dialogue` and `multiple_endings`. Example: *Subnautica*.
4. **Automation Survival:** Shifts focus from manual gathering to building complex, automated systems. Adds atoms like `belt_conveyor` and `logic_deduction`. Example: *Factorio*.
5. **Multiplayer PvP Survival:** Focuses on player conflict and base raiding. Adds atoms like `pvp_arena` and `guild_clan`. Example: *Rust*.

## 7. Anti-Patterns
1. **Tedious Grind:** Requiring excessive amounts of basic resources for minor upgrades, turning the core loop into a chore rather than a rewarding experience.
2. **Punishing Death Mechanics:** Losing all progress and inventory upon death without a reasonable way to recover them, leading to extreme frustration and rage-quitting.
3. **Empty Worlds:** Procedural generation that creates vast but featureless landscapes with little to discover, making exploration boring and unrewarding.

## 8. Cross-Cutting Systems
- **Economy/Monetization:** Often features cosmetic microtransactions (e.g., character skins, base decorations) or server hosting fees for multiplayer variants.
- **Social Systems:** Cooperative multiplayer is highly prevalent, allowing players to share bases and divide labor. Competitive variants feature clan systems, territory control, and base raiding mechanics.
- **Modding Support:** Extensive modding communities are typical, allowing players to add new items, mechanics, or entirely new game modes, significantly extending the game's lifespan.
