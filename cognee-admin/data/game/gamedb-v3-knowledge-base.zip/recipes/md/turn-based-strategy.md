# Archetype Recipe: Turn-Based Strategy (turn-based-strategy)

## 1. Archetype Identity
**ID:** turn-based-strategy
**Names:** Turn-Based Strategy (回合制策略)
**Definition:** Turn-Based Strategy (TBS) is a genre of strategy games where players take turns to make decisions, move units, and execute actions. Unlike real-time strategy games, the flow of time is segmented into discrete turns, allowing players to carefully plan their moves, analyze the battlefield, and optimize their action economy without the pressure of real-time execution.
**Benchmark Games:**
- XCOM: Enemy Unknown (2012)
- Fire Emblem: Three Houses (2019)
- Into the Breach (2018)

## 2. Elemental Tetrad Analysis
- **Mechanics:** The core loops revolve around grid-based movement, action point management, and probabilistic combat resolution. Players must position units advantageously, utilize cover, and manage resources to defeat enemies or achieve objectives.
- **Aesthetics:** The visual and audio style often emphasizes clarity and readability. Grids, movement ranges, and line-of-sight indicators are prominent. Audio cues reinforce the impact of actions, such as the satisfying sound of a critical hit or the tense music during enemy turns.
- **Story:** Narrative structures often involve a commander leading a squad or army against overwhelming odds. The story is frequently character-driven, with individual units having distinct personalities, backgrounds, and relationships that evolve over the course of the campaign.
- **Technology:** Typical technical requirements include robust pathfinding algorithms, line-of-sight calculations, and complex AI systems capable of evaluating multiple potential moves and making strategic decisions based on the current game state.

## 3. Atom Recipe Table

| Atom ID | Atom Name | Role in Archetype | Weight | Typical Config |
| :--- | :--- | :--- | :--- | :--- |
| action_points | Action Points | Dictates how many actions a unit can perform per turn. | Core | base_ap: 2 |
| cover_system | Cover System | Provides defensive bonuses based on positioning. | Core | half_cover_bonus: 20, full_cover_bonus: 40 |
| vision_cone | Vision Cone | Determines what units can see, enabling fog of war and stealth. | Important | fog_of_war: true |
| hitscan | Hitscan | Resolves attacks instantly based on probability and stats. | Important | rng_based_accuracy: true |
| permadeath | Permadeath | Adds high stakes by permanently removing fallen units. | Optional | revive_window: 0 |
| class_job | Class/Job | Defines unit roles, abilities, and stat growth. | Core | promotion_levels: 2 |
| skill_tree | Skill Tree | Allows customization and progression of unit abilities. | Important | mutually_exclusive_branches: true |
| node_map | Node Map | Structures the campaign progression between tactical battles. | Optional | branching_paths: true |

## 4. Atom Coupling Matrix

1. **action_points + cover_system:** Players must spend AP to move into cover before attacking. This creates a dynamic of risk vs. reward positioning, where moving to a better offensive position might leave a unit exposed defensively.
2. **vision_cone + hitscan:** Line of sight is required to calculate hit probability. This encourages flanking and ambushing, as players try to maneuver around enemy cover to secure clear shots.
3. **class_job + skill_tree:** Classes define the available skill trees for unit progression. This leads to squad composition synergy, where players must build a balanced team with complementary abilities.
4. **permadeath + cover_system:** The high stakes of death make cover utilization mandatory. This produces a tense and cautious pacing, as players carefully advance their units to minimize risk.
5. **action_points + skill_tree:** Advanced skills may cost more AP or grant free actions. This allows for action economy manipulation, rewarding players who optimize their skill usage to maximize their turn efficiency.

## 5. MDA Chain
- **Mechanics:** Grid-based movement, turn-based action economy, RNG-based combat resolution, unit progression, and cover systems.
- **Dynamics:** Tactical positioning, resource management, risk assessment, squad building, and adapting to unexpected outcomes (e.g., missing a 95% shot).
- **Aesthetics:** Challenge (overcoming difficult tactical puzzles), Fellowship (building attachment to squad members), and Expression (developing unique strategies and squad compositions).

## 6. Variant Spectrum
- **Tactical RPG:** Adds `branching_dialogue` and `affinity_meter` to emphasize character relationships and story. Removes `permadeath` to ensure narrative continuity.
- **Roguelike Tactics:** Adds `procedural_gen`, `run_based`, and `random_affix` to create highly replayable, randomized campaigns. Removes `branching_dialogue` to focus purely on gameplay.
- **Grand Strategy Tactics:** Adds `tech_tree` and `resource_gathering` to introduce a macro-level strategic layer. Removes `cover_system` to simplify tactical battles in favor of larger-scale conflicts.

## 7. Anti-Patterns
1. **RNG Frustration:** Over-reliance on extreme RNG without mitigation mechanics (e.g., missing multiple 90%+ shots in a row) can lead to player frustration and a feeling of lost agency.
2. **Snowball Effect:** If early mistakes are punished too harshly (e.g., losing key units to permadeath), the game can become unwinnable, forcing players to restart the entire campaign.
3. **Analysis Paralysis:** Providing too many options or overly complex mechanics without clear feedback can overwhelm players, slowing down the pace of the game to a crawl.

## 8. Cross-Cutting Systems
- **Meta Progression:** Unlocking new classes, items, or starting bonuses across multiple playthroughs.
- **Achievement System:** Rewarding players for completing specific challenges or reaching milestones.
- **Daily/Weekly Reset:** Offering rotating challenges or missions to encourage regular engagement in live-service variants.
