# Archetype Recipe: Logic Puzzle

## 1. Archetype Identity
**ID:** `logic-puzzle`
**Name (EN):** Logic Puzzle
**Name (CN):** 逻辑解谜类

**Definition:**
The Logic Puzzle archetype is a genre of games that challenges the player's deductive reasoning, spatial awareness, and problem-solving skills. Unlike action games that rely on reflexes, logic puzzles require players to understand a set of rules and apply them to manipulate the game state toward a specific goal. The core loop revolves around observation, hypothesis generation, testing, and the eventual "Eureka" moment of epiphany when the solution clicks into place.

**Benchmark Games:**
- *Portal* (2007)
- *The Talos Principle* (2014)
- *The Witness* (2016)
- *Baba Is You* (2019)

## 2. Elemental Tetrad Analysis

**Mechanics:**
The core systems of a logic puzzle game are built on strict, deterministic rules. Players interact with the environment using a limited set of verbs (e.g., move, push, connect, swap). The game presents a starting state and a goal state, and the player must find a sequence of valid actions to bridge the gap. Progression is typically gated by knowledge and understanding rather than character stats or reflexes.

**Aesthetics:**
Visually, logic puzzles often employ clean, readable art styles to ensure that gameplay elements are easily distinguishable from background decoration. Audio design focuses on atmospheric, non-intrusive background music that aids concentration, punctuated by satisfying sound effects that provide clear feedback for correct actions or completed puzzles.

**Story:**
Narrative in logic puzzles is frequently minimalist or environmental. The story often serves as a framing device for why the puzzles exist (e.g., a testing facility, an ancient ruin, a philosophical simulation). Narrative progression is usually tied to puzzle completion, rewarding the player with lore fragments or philosophical musings.

**Technology:**
Technical requirements prioritize robust state management, undo/redo systems, and deterministic physics or logic engines. The game must flawlessly track the state of all interactive elements to prevent soft-locks and ensure that solutions are consistently reproducible.

## 3. Atom Recipe Table

| Atom ID | Atom Name | Role in Archetype | Weight | Typical Config |
| :--- | :--- | :--- | :--- | :--- |
| `logic_deduction` | Logic Deduction | Forms the core cognitive challenge of understanding and applying rules. | Core | `complexity: high`, `feedback: immediate` |
| `physics_puzzle` | Physics Puzzle | Provides spatial and physical constraints for logical reasoning. | Important | `determinism: strict`, `gravity: standard` |
| `sokoban_push` | Sokoban Push | Offers a classic grid-based spatial manipulation mechanic. | Optional | `grid_based: true`, `undo_enabled: true` |
| `spatial_portal` | Spatial Portal | Introduces non-Euclidean geometry to challenge spatial reasoning. | Optional | `seamless: true`, `momentum_conservation: true` |
| `evidence_contradiction` | Evidence Contradiction | Used in narrative-heavy logic puzzles to find logical flaws. | Optional | `text_heavy: true`, `cross_referencing: required` |

## 4. Atom Coupling Matrix

1. **`logic_deduction` + `physics_puzzle`**
   - **Interaction:** Physical rules (like gravity or momentum) act as logical constraints that must be factored into the deduction process.
   - **Emergent Dynamic:** Spatial reasoning and trajectory planning.
   - **Aesthetic:** The satisfaction of seeing a complex physical chain reaction execute perfectly based on logical setup.

2. **`logic_deduction` + `sokoban_push`**
   - **Interaction:** The order of movement strictly determines the logical validity of the state; pushing an object blocks or opens future logical pathways.
   - **Emergent Dynamic:** Sequence planning and forward-thinking (calculating moves ahead).
   - **Aesthetic:** Intellectual rigor and the "aha" moment of finding the correct sequence.

3. **`physics_puzzle` + `spatial_portal`**
   - **Interaction:** Momentum and physical properties are conserved or altered when passing through portals, creating complex physical logic.
   - **Emergent Dynamic:** Trajectory manipulation and non-linear spatial navigation.
   - **Aesthetic:** Mind-bending realization of spatial relationships.

4. **`logic_deduction` + `evidence_contradiction`**
   - **Interaction:** Visual or textual clues contradict stated rules, requiring the player to deduce the hidden truth.
   - **Emergent Dynamic:** Paradox resolution and critical analysis.
   - **Aesthetic:** The thrill of investigation and uncovering hidden layers of meaning.

5. **`sokoban_push` + `spatial_portal`**
   - **Interaction:** Pushing objects through portals alters their position in non-Euclidean space, complicating traditional grid logic.
   - **Emergent Dynamic:** Topology mapping and multi-dimensional spatial reasoning.
   - **Aesthetic:** Disorientation followed by profound spatial comprehension.

## 5. MDA Chain

**Mechanics:**
- Rule discovery and learning through environmental observation.
- State manipulation via discrete, deterministic actions.
- Constraint satisfaction (finding a state that meets all required conditions).

**Dynamics:**
- Hypothesis testing: Players formulate a theory about how a mechanic works and test it.
- Iterative refinement: Failing a puzzle, analyzing the failure, and adjusting the approach.
- Mental modeling: Building a complex internal representation of the game's ruleset.

**Aesthetics:**
- Epiphany: The sudden, exhilarating "Eureka" moment when a solution is realized.
- Intellectual challenge: The satisfaction of overcoming a difficult cognitive hurdle.
- Curiosity: The drive to understand new mechanics and see what lies beyond the next puzzle.

## 6. Variant Spectrum

1. **Programming Puzzle**
   - **Added Atoms:** `belt_conveyor`, `logic_gates`
   - **Removed Atoms:** `physics_puzzle`
   - **Description:** Focuses on automation, algorithmic thinking, and optimizing processes (e.g., *Zachtronics* games).

2. **Detective Deduction**
   - **Added Atoms:** `evidence_contradiction`, `branching_dialogue`
   - **Removed Atoms:** `sokoban_push`
   - **Description:** Shifts the focus from spatial logic to narrative logic, requiring players to piece together clues and find contradictions (e.g., *Return of the Obra Dinn*).

3. **Physics Sandbox Puzzle**
   - **Added Atoms:** `physics_puzzle`, `fluid_dynamics`
   - **Removed Atoms:** `grid_movement`
   - **Description:** Relies heavily on emergent physics interactions rather than strict grid-based logic, allowing for multiple creative solutions (e.g., *Besiege*).

## 7. Anti-Patterns

1. **Moon Logic:** Puzzles whose solutions rely on leaps of logic, obscure cultural references, or arbitrary combinations that cannot be reasonably deduced from the game's established rules.
2. **Execution Over Deduction:** Requiring precise timing or reflex-based execution to solve a puzzle, which frustrates players who have figured out the logical solution but struggle with the physical input.
3. **Lack of Feedback:** Failing to provide clear visual or auditory feedback when a player makes a mistake or a correct move, leaving them unable to understand why their hypothesis failed.

## 8. Cross-Cutting Systems

- **Hint System:** A carefully designed system to provide progressive nudges without giving away the solution entirely, preventing player churn due to frustration.
- **Achievement System:** Used to reward out-of-the-box thinking, finding alternative solutions, or completing puzzles under specific constraints (e.g., minimum moves).
- **Level Editor / Workshop:** Allowing the community to create and share their own puzzles, significantly extending the game's lifespan and exploring the mechanics to their absolute limits.
