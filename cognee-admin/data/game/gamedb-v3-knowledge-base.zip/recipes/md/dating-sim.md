# Archetype Recipe: Dating Sim (dating-sim)

## 1. Archetype Identity
**ID:** dating-sim
**Name (EN):** Dating Sim
**Name (CN):** 恋爱模拟类
**Definition:** A dating simulation game focuses on romantic interactions, relationship building, and narrative choices. Players navigate social encounters, manage time or resources, and make decisions that influence the protagonist's relationships with various characters, ultimately leading to different romantic outcomes or endings.
**Benchmark Games:**
- *Tokimeki Memorial* (1994)
- *Persona 5* (2016)
- *Doki Doki Literature Club!* (2017)
- *Dream Daddy: A Dad Dating Simulator* (2017)

## 2. Elemental Tetrad Analysis
**Mechanics:** The core loops revolve around time management, stat building, and dialogue choices. Players allocate limited time to activities that boost personal statistics, which in turn unlock specific dialogue options or events with romantic interests. The affinity meter is the primary progression tracker.
**Aesthetics:** Visually, these games often employ anime or stylized 2D art, featuring expressive character sprites and detailed background illustrations. The audio design relies heavily on voice acting to convey emotion, accompanied by atmospheric and mood-setting background music.
**Story:** The narrative structure is inherently branching, driven by player choices. It typically follows a calendar or event-based progression, culminating in multiple endings based on the accumulated affinity with specific characters.
**Technology:** Technical requirements are generally low, focusing on robust dialogue trees, state management for variables (stats, affinity), and efficient 2D asset rendering. Advanced implementations may include Live2D or 3D models for character expressiveness.

## 3. Atom Recipe Table

| atom_id | atom_name | role_in_archetype | weight | typical_config |
| :--- | :--- | :--- | :--- | :--- |
| branching_dialogue | Branching Dialogue | Core interaction method for building relationships | core | `{"node_complexity": "high", "choice_timer": false}` |
| affinity_meter | Affinity Meter | Tracks relationship progress with each character | core | `{"visibility": "visible", "decay_rate": 0}` |
| multiple_endings | Multiple Endings | Provides narrative payoff based on player choices | core | `{"ending_types": ["good", "bad", "true", "character_specific"]}` |
| resource_gathering | Resource Gathering | (Time/Stats) Managing daily activities to improve protagonist | important | `{"resource_types": ["charm", "intelligence", "courage"]}` |
| day_night_cycle | Day/Night Cycle | Structures the gameplay loop and time management | important | `{"time_slots_per_day": 3}` |
| skill_check | Skill Check | Gates specific dialogue options behind stat thresholds | important | `{"visibility": "hidden_until_met"}` |
| butterfly_effect | Butterfly Effect | Early choices significantly impact late-game events | optional | `{"impact_delay": "long"}` |
| room_decoration | Room Decoration | Personalizing space to attract specific characters | optional | `{"stat_bonus": true}` |

## 4. Atom Coupling Matrix
1. **branching_dialogue + affinity_meter**
   - **Dynamic:** Dialogue choices directly manipulate the affinity meter.
   - **Aesthetic:** Creates a sense of emotional investment and consequence in conversations.
2. **resource_gathering + skill_check**
   - **Dynamic:** Players must grind stats (resources) to pass skill checks in dialogue.
   - **Aesthetic:** Adds a layer of strategy and self-improvement to the romantic pursuit.
3. **day_night_cycle + affinity_meter**
   - **Dynamic:** Limited time slots force players to prioritize which character's affinity to raise.
   - **Aesthetic:** Induces a feeling of urgency and the weight of opportunity cost.
4. **affinity_meter + multiple_endings**
   - **Dynamic:** The final state of affinity meters determines which ending is unlocked.
   - **Aesthetic:** Provides closure and validates the player's long-term relationship building.
5. **skill_check + branching_dialogue**
   - **Dynamic:** High stats unlock new, often more favorable, dialogue branches.
   - **Aesthetic:** Rewards preparation and makes the protagonist feel capable and attractive.

## 5. MDA Chain
**Mechanics:** Time management (allocating daily slots), stat grinding (studying, working), dialogue selection (choosing responses), and affinity tracking (gaining/losing points with characters).
**Dynamics:** Players optimize their schedule to maximize stats while ensuring they spend enough time with their chosen romantic interest. They carefully read dialogue to predict which response will yield the most affinity points, sometimes reloading saves if a choice goes poorly.
**Aesthetics:** The experience evokes feelings of romance, companionship, and narrative discovery. Players feel a sense of achievement when successfully wooing a character and curiosity about alternative paths and endings.

## 6. Variant Spectrum
- **Stat-Heavy Sim:** Focuses heavily on time management and stat building (e.g., *Tokimeki Memorial*). Added atoms: `energy_stamina_gate`, `random_affix` (for events).
- **Visual Novel Hybrid:** Minimizes gameplay mechanics in favor of pure narrative and branching dialogue (e.g., *Clannad*). Removed atoms: `resource_gathering`, `day_night_cycle`.
- **RPG Hybrid:** Integrates dating mechanics into a broader RPG framework (e.g., *Persona 5*). Added atoms: `xp_level`, `melee_combo`, `turn_based_combat`.
- **Meta-Horror:** Subverts the genre expectations with psychological horror elements (e.g., *Doki Doki Literature Club!*). Added atoms: `glitch_aesthetic`, `fourth_wall_break`.

## 7. Anti-Patterns
1. **Obvious Choices:** Making the "correct" dialogue option too obvious, removing the challenge of understanding the character's personality.
2. **Tedious Grinding:** Requiring excessive stat grinding that interrupts the narrative flow and makes the game feel like a chore.
3. **Lack of Consequence:** Choices that seem important but ultimately funnel back into the same narrative path without affecting affinity or endings.

## 8. Cross-Cutting Systems
- **Monetization:** Often premium (pay-to-play), but mobile variants frequently use `gacha_banner` for unlocking characters or outfits, and `energy_stamina_gate` to limit daily reading/playing time.
- **Social:** Typically single-player, but may include asynchronous features like sharing unlocked CGs or comparing ending completion rates.
- **Economy:** In-game currency is often used to buy gifts for characters to boost affinity, requiring a basic `currency_dual` system (e.g., money earned from part-time jobs).
