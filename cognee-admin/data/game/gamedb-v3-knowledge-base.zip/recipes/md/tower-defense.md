# Archetype Recipe: Tower Defense

## 1. Archetype Identity
**ID:** tower-defense
**Name (EN):** Tower Defense
**Name (CN):** 塔防类

**Definition:**
Tower Defense is a subgenre of strategy video games where the goal is to defend a player's territories or possessions by obstructing the enemy attackers or by stopping enemies from reaching the exits, usually achieved by placing defensive structures on or along their path of attack. This typically means building a variety of different structures that serve to automatically block, impede, attack or destroy enemies.

**Benchmark Games:**
- *Bloons TD 6* (2018)
- *Kingdom Rush* (2011)
- *Plants vs. Zombies* (2009)
- *Defense Grid: The Awakening* (2008)

## 2. Elemental Tetrad Analysis
**Mechanics:**
The core loop revolves around resource management, spatial planning, and real-time tactical adjustments. Players earn currency by defeating enemies, which is then reinvested into building new towers or upgrading existing ones. The system relies heavily on wave-based enemy spawning, pathing algorithms, and diverse tower types (e.g., single-target, area-of-effect, slowing).

**Aesthetics:**
Visual and audio patterns often emphasize clarity and feedback. Enemies and towers are distinctively designed to be easily recognizable at a glance. Audio cues play a crucial role in signaling wave starts, enemy breaches, or the completion of tower upgrades. The overall aesthetic can range from cartoonish and lighthearted to gritty and realistic, but readability remains paramount.

**Story:**
Narrative structures in Tower Defense games are typically straightforward, serving primarily as a backdrop for the gameplay. The story often involves a defending faction protecting a homeland, base, or specific objective from an invading force. Progression through levels is usually tied to a linear or branching campaign map, with narrative exposition delivered between stages.

**Technology:**
Technical requirements focus on handling large numbers of entities (enemies and projectiles) simultaneously without performance degradation. Efficient pathfinding algorithms (like A*) are essential for enemy movement, especially in games where players can alter the path by placing towers (mazing). Robust state management is needed to track enemy health, status effects, and tower targeting priorities.

## 3. Atom Recipe Table

| Atom ID | Atom Name | Role in Archetype | Weight | Typical Config |
| :--- | :--- | :--- | :--- | :--- |
| wave_system | Wave System | Dictates the pacing and progression of enemy attacks. | Core | `wave_count: 20-50`, `scaling_difficulty: true` |
| tower_placement | Tower Placement | The primary method of player interaction and defense building. | Core | `grid_based: true`, `blocking_path: optional` |
| currency_dual | Dual Currency | Manages in-match economy (gold for towers) and meta-economy (stars for upgrades). | Core | `in_match_currency: gold`, `meta_currency: stars` |
| ability_cooldown | Ability Cooldown | Governs the use of powerful, active player abilities or spells. | Important | `cooldown_time: 30s-120s` |
| elemental_reaction | Elemental Reaction | Adds depth to combat by encouraging specific tower combinations (e.g., water + electricity). | Optional | `damage_multiplier: 1.5x` |
| node_map | Node Map | Structures the campaign progression and level selection. | Important | `branching_paths: true` |
| skill_tree | Skill Tree | Provides meta-progression by allowing permanent upgrades to towers or abilities. | Important | `max_level: 50` |
| projectile | Projectile | Defines the behavior of attacks from towers to enemies. | Core | `homing: optional`, `splash_radius: variable` |

## 4. Atom Coupling Matrix

1. **wave_system + currency_dual**
   - **Interaction:** Defeating enemies in a wave grants in-match currency.
   - **Emergent Dynamic:** Players must balance spending currency immediately to survive the current wave versus saving for more expensive, powerful towers for future waves.
   - **Aesthetic:** Creates a sense of tension and strategic anticipation.

2. **tower_placement + wave_system**
   - **Interaction:** The placement of towers determines how effectively the incoming wave is handled.
   - **Emergent Dynamic:** In games allowing mazing, players actively shape the enemy path, creating choke points and maximizing tower exposure time.
   - **Aesthetic:** Fosters a feeling of intellectual satisfaction and spatial mastery.

3. **elemental_reaction + projectile**
   - **Interaction:** Projectiles carry elemental properties that interact upon hitting enemies.
   - **Emergent Dynamic:** Players are incentivized to build diverse tower setups to trigger synergistic effects (e.g., slowing an enemy with ice, then hitting them with a heavy physical projectile).
   - **Aesthetic:** Enhances visual spectacle and rewards complex planning.

4. **skill_tree + tower_placement**
   - **Interaction:** Meta-progression unlocks new tower types or enhances existing ones.
   - **Emergent Dynamic:** Players revisit earlier levels with new strategies or tackle higher difficulties, shifting the optimal placement strategies based on upgraded capabilities.
   - **Aesthetic:** Provides a satisfying sense of long-term growth and empowerment.

5. **ability_cooldown + wave_system**
   - **Interaction:** Active abilities are saved for critical moments during difficult waves.
   - **Emergent Dynamic:** Players must judge when a wave threatens to breach defenses and deploy abilities optimally, adding a layer of real-time action to the strategic planning.
   - **Aesthetic:** Injects moments of high adrenaline and clutch saves into the methodical gameplay.

## 5. MDA Chain
**Mechanics:**
The game provides a grid or predefined spots for `tower_placement`. Enemies spawn according to a `wave_system` and travel towards an objective. Towers automatically fire `projectile`s at enemies. Defeating enemies yields `currency_dual` (in-match), used to build or upgrade towers.

**Dynamics:**
Players engage in resource management, deciding when and where to invest their currency. They analyze enemy types and wave compositions to adapt their defenses, creating choke points or exploiting elemental weaknesses. The game fluctuates between periods of calm planning (between waves) and frantic observation/intervention (during waves).

**Aesthetics:**
The experience delivers **Challenge** through strategic puzzle-solving and resource optimization. It offers **Submission** as players enter a flow state watching their meticulously planned defenses operate automatically. There is also a strong element of **Expression** in how players choose to design their defensive layouts.

## 6. Variant Spectrum
1. **Mazing Tower Defense:** (e.g., *Desktop Tower Defense*)
   - **Atoms Added:** `physics_puzzle` (spatial manipulation)
   - **Atoms Removed:** Predefined paths. Players build towers anywhere to create the path enemies must take.
2. **Action Tower Defense:** (e.g., *Orcs Must Die!*)
   - **Atoms Added:** `melee_combo`, `dodge_roll` (player avatar combat)
   - **Atoms Removed:** Purely passive observation. The player actively fights alongside their towers.
3. **Reverse Tower Defense (Tower Offense):** (e.g., *Anomaly: Warzone Earth*)
   - **Atoms Added:** `squad_management`, `route_planning`
   - **Atoms Removed:** `tower_placement`. The player controls the creeps navigating through a gauntlet of enemy towers.
4. **Card-Based Tower Defense:** (e.g., *Random Dice*)
   - **Atoms Added:** `card_draft`, `random_affix`
   - **Atoms Removed:** Deterministic tower selection. Towers are drawn from a deck and often merged randomly.

## 7. Anti-Patterns
1. **The "One True Build" Problem:** When a specific tower combination is so mathematically superior that it trivializes all other strategies, reducing the game to rote memorization rather than dynamic problem-solving.
2. **Unreadable Visual Clutter:** In late-game stages, excessive projectiles, particle effects, and overlapping enemies can make it impossible for the player to understand what is happening or identify priority targets.
3. **Punishing Early Mistakes Too Late:** If a slight misplacement of a tower in wave 5 guarantees failure in wave 45, but the player only realizes it at wave 45, it creates immense frustration and disrespects the player's time.

## 8. Cross-Cutting Systems
- **Economy (F2P):** Often utilizes `gacha_banner` for unlocking new, powerful towers or heroes, and `energy_stamina_gate` to limit daily playtime.
- **Social/Multiplayer:** Can include `pvp_arena` where players send waves of enemies to each other's boards, or co-op modes where players share a map and resources.
- **Live Ops:** Regular `daily_weekly_reset` challenges and `season_rank` leaderboards to maintain long-term engagement.
