# Archetype Recipe: Metroidvania

## 1. Archetype Identity
**ID:** metroidvania
**Name (EN):** Metroidvania
**Name (CN):** 银河城类

**Definition:**
Metroidvania is a subgenre of action-adventure games characterized by a large, interconnected world map that the player can explore, though access to parts of the world is often limited by doors or other obstacles that can only be passed once the player has acquired special items, tools, weapons, abilities, or knowledge within the game. Acquiring such improvements can also aid the player in defeating more difficult enemies and locating shortcuts and secret areas, and often includes retracing one's steps across the map.

**Benchmark Games:**
- *Hollow Knight* (2017)
- *Metroid Dread* (2021)
- *Ori and the Will of the Wisps* (2020)
- *Castlevania: Symphony of the Night* (1997)
- *Super Metroid* (1994)

## 2. Elemental Tetrad Analysis
**Mechanics:**
The core loop revolves around exploration, combat, and platforming. Players navigate an interconnected map, encounter obstacles or unreachable areas, and must find specific abilities (e.g., double jump, wall climb) to progress. Combat often involves learning enemy patterns and utilizing acquired skills. The progression system is heavily tied to exploration and ability gating.

**Aesthetics:**
Visually, Metroidvanias often employ a 2D side-scrolling perspective, though 3D variants exist. The art style frequently emphasizes atmosphere, isolation, and mystery, encouraging players to delve deeper into unknown territories. Audio design plays a crucial role in setting the mood and providing feedback for combat and environmental interactions.

**Story:**
Narratives in Metroidvanias are typically conveyed through environmental storytelling, item descriptions, and sparse dialogue. The protagonist is often an isolated figure exploring a ruined or hostile world, uncovering its history and secrets as they progress. The story unfolds non-linearly, mirroring the player's exploration.

**Technology:**
Technical requirements include robust collision detection for precise platforming, efficient memory management for seamless loading of interconnected map rooms, and a flexible state management system to track acquired abilities, unlocked doors, and defeated bosses across the entire game world.

## 3. Atom Recipe Table

| atom_id | atom_name | role_in_archetype | weight | typical_config |
| :--- | :--- | :--- | :--- | :--- |
| interconnected_map | Interconnected Map | Provides the foundational world structure for exploration and backtracking. | core | `{"rooms": 100+, "seamless_transitions": true}` |
| ability_gating | Ability Gating | Restricts access to new areas until specific skills are acquired, driving progression. | core | `{"strict_locks": true, "sequence_breaking_allowed": false}` |
| node_map | Node Map | Allows players to track their location, discovered areas, and points of interest. | core | `{"auto_reveal": false, "manual_pins": true}` |
| double_jump | Double Jump | A classic traversal upgrade that expands vertical exploration capabilities. | important | `{"height_multiplier": 0.8, "coyote_time_compatible": true}` |
| air_dash | Air Dash | Enhances horizontal mobility and combat evasion, often unlocking new platforming routes. | important | `{"distance": 5.0, "iframes": 0.2}` |
| wall_slide_jump | Wall Slide & Jump | Enables vertical scaling of vertical shafts and complex platforming challenges. | important | `{"slide_friction": 0.5, "jump_angle": 45}` |
| melee_combo | Melee Combo | Forms the basis of close-quarters combat against standard enemies and bosses. | important | `{"combo_length": 3, "cancelable": true}` |
| dodge_roll | Dodge Roll | Provides a defensive maneuver with invincibility frames for surviving boss encounters. | important | `{"iframes": 0.3, "stamina_cost": 10}` |
| checkpoint | Checkpoint | Serves as save rooms, fast travel nodes, and respawn points upon death. | core | `{"heal_on_rest": true, "respawn_enemies": true}` |
| collection_log | Collection Log | Tracks found items, lore entries, and map completion percentage. | optional | `{"completion_rewards": true}` |

## 4. Atom Coupling Matrix

1. **`interconnected_map` + `ability_gating`**
   - **Interaction:** The map is designed with physical barriers that correspond to specific abilities.
   - **Emergent Dynamic:** Players experience the "aha!" moment when acquiring a new ability, immediately recalling previously inaccessible areas and backtracking to explore them.
   - **Aesthetic:** Discovery, anticipation, and satisfaction of overcoming environmental puzzles.

2. **`checkpoint` + `interconnected_map`**
   - **Interaction:** Checkpoints are strategically placed to create tension during exploration and relief upon discovery.
   - **Emergent Dynamic:** Players push their limits exploring unknown areas, weighing the risk of losing progress against the reward of finding the next safe room.
   - **Aesthetic:** Tension, relief, and a sense of hard-earned progress.

3. **`melee_combo` + `dodge_roll`**
   - **Interaction:** Combat requires balancing offensive strikes with timely evasions.
   - **Emergent Dynamic:** Players learn enemy attack patterns, finding safe windows to execute combos and using dodge rolls to avoid damage.
   - **Aesthetic:** Mastery, rhythm, and the thrill of overcoming challenging foes.

4. **`double_jump` + `air_dash`**
   - **Interaction:** Combining these traversal abilities allows for complex aerial maneuvers.
   - **Emergent Dynamic:** Players can bypass intended platforming routes (sequence breaking) or reach hidden collectibles requiring precise execution.
   - **Aesthetic:** Freedom of movement, expression, and the joy of sequence breaking.

5. **`ability_gating` + `node_map`**
   - **Interaction:** The map records areas the player has visited but couldn't fully explore due to missing abilities.
   - **Emergent Dynamic:** Players use the map as a mental checklist, planning their routes based on newly acquired skills.
   - **Aesthetic:** Strategic planning, spatial awareness, and the satisfaction of filling in the blanks.

## 5. MDA Chain

**Mechanics:**
- Interconnected world map with distinct biomes.
- Player character with a base set of movements and attacks.
- Upgrades and abilities hidden throughout the world.
- Environmental obstacles that require specific abilities to bypass.
- Enemies and bosses with distinct attack patterns.

**Dynamics:**
- **Exploration and Backtracking:** Players continuously explore new areas, hit roadblocks, and return later with new abilities to progress.
- **Combat Mastery:** Players learn to utilize their expanding moveset to defeat increasingly difficult enemies.
- **Resource Management:** Managing health, magic/energy, and currency while exploring far from checkpoints.
- **Mental Mapping:** Players develop a spatial understanding of the world, remembering locations of locked doors and secrets.

**Aesthetics:**
- **Discovery:** The thrill of finding hidden rooms, powerful upgrades, and uncovering the world's secrets.
- **Challenge:** Overcoming difficult platforming sections and demanding boss fights.
- **Empowerment:** The satisfying transition from a weak, limited character to a highly mobile and powerful force.
- **Atmosphere:** Immersion in a cohesive, often melancholic or mysterious world.

## 6. Variant Spectrum

1. **Soulsvania (e.g., *Hollow Knight*, *Salt and Sanctuary*)**
   - **Atoms Added:** `stamina_combat`, `permadeath` (currency loss on death), `dodge_roll` (heavy emphasis on iframes).
   - **Atoms Removed:** `linear_progression`.
   - **Focus:** High-difficulty combat, punishing death mechanics, and deep lore.

2. **Roguevania (e.g., *Dead Cells*)**
   - **Atoms Added:** `procedural_gen`, `run_based`, `random_affix`.
   - **Atoms Removed:** `interconnected_map` (persistent), `manual_saves`.
   - **Focus:** Replayability, randomized loot, and adapting to unpredictable level layouts while retaining permanent meta-progression.

3. **Puzzle-vania (e.g., *Animal Well*, *Toki Tori 2*)**
   - **Atoms Added:** `physics_puzzle`, `logic_deduction`, `spatial_portal`.
   - **Atoms Removed:** `melee_combo`, `boss_fights`.
   - **Focus:** Using abilities to solve complex environmental puzzles rather than combat.

4. **Classic Action-vania (e.g., *Castlevania: Symphony of the Night*)**
   - **Atoms Added:** `xp_level`, `random_loot`, `equipment_slots`.
   - **Atoms Removed:** `stamina_combat`.
   - **Focus:** RPG mechanics, grinding for levels and gear, and a wide variety of weapons.

## 7. Anti-Patterns

1. **Tedious Backtracking:** Forcing the player to traverse long, empty, or overly familiar stretches of the map without meaningful shortcuts, fast travel options, or new challenges, leading to boredom and frustration.
2. **Obscure Progression Blockers:** Hiding critical path items or abilities in illogical or easily missed locations without sufficient hints or environmental cues, causing players to wander aimlessly.
3. **Meaningless Upgrades:** Providing abilities that are only used to open specific doors (e.g., a "red key" disguised as a spell) but offer no utility in combat, traversal, or general gameplay, making the acquisition feel unrewarding.

## 8. Cross-Cutting Systems

- **Economy System:** Often features a dual currency system (`currency_dual`) where one currency is used for purchasing consumable items and minor upgrades, while another rarer currency is used for significant permanent enhancements.
- **Meta-Progression:** While the core game is usually a single continuous playthrough, some variants incorporate `new_game_plus` or `achievement_system` to encourage replayability and mastery.
- **Social Systems:** Typically single-player, but may include asynchronous elements like `ghost_replay` for speedrunning leaderboards or community-driven message systems (similar to Souls games).
