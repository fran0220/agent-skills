# Archetype Recipe: Sports Simulation (sports-sim)

## 1. Archetype Identity
**ID:** sports-sim
**Name (EN):** Sports Simulation
**Name (CN):** 体育模拟类
**Definition:** Sports Simulation games aim to recreate the experience of playing or managing real-world sports as authentically as possible. They emphasize realistic physics, accurate rules, real-world player statistics, and strategic depth, often featuring licensed teams and athletes to enhance immersion.
**Benchmark Games:**
- *EA SPORTS FC 24* (2023)
- *NBA 2K24* (2023)
- *MLB The Show 23* (2023)
- *Football Manager 2024* (2023)

## 2. Elemental Tetrad Analysis
**Mechanics:** The core loops revolve around executing precise inputs to control athletes during matches, managing team rosters, and making strategic decisions. Systems include physics-based ball/player movement, stamina management, and complex AI behaviors for teammates and opponents.
**Aesthetics:** Visuals strive for photorealism, featuring detailed player models, authentic stadiums, and broadcast-style presentation (e.g., commentary, replays, overlays). Audio includes realistic crowd noise, on-pitch communication, and professional commentary.
**Story:** Narrative is often emergent, driven by the player's journey through a season or career. Some games feature structured "Career Modes" with cinematic cutscenes detailing an athlete's rise to stardom.
**Technology:** Requires advanced physics engines for realistic collisions and ball trajectories, sophisticated AI for dynamic positioning, and motion capture technology for authentic player animations.

## 3. Atom Recipe Table

| Atom ID | Atom Name | Role in Archetype | Weight | Typical Config |
| :--- | :--- | :--- | :--- | :--- |
| `sprint_stamina` | Sprint & Stamina | Limits continuous high-speed movement, forcing tactical pacing. | Core | `depletion_rate: high, recovery_rate: slow` |
| `physics_puzzle` | Physics Simulation | Governs ball trajectories, collisions, and player momentum. | Core | `gravity: realistic, friction: dynamic` |
| `timing_window` | Timing Window | Determines success of shots, passes, and tackles based on input timing. | Core | `window_ms: 50-150` |
| `action_points` | Action Points / Stamina | Used in management modes for training or transfer negotiations. | Important | `daily_allowance: limited` |
| `gacha_banner` | Gacha / Pack Opening | Drives the acquisition of new players in modes like Ultimate Team. | Core | `drop_rate: tiered` |
| `season_rank` | Season Ranking | Provides long-term goals through league tables and competitive seasons. | Core | `reset_period: monthly/yearly` |
| `role_assignment` | Role Assignment | Assigning positions and tactical roles to individual players. | Core | `flexibility: strict` |
| `adaptive_difficulty` | Adaptive Difficulty | Adjusts AI competence based on player performance to maintain challenge. | Important | `scaling: dynamic` |
| `collection_log` | Collection Log | Tracking acquired players, kits, and stadium items. | Optional | `completion_reward: cosmetic` |
| `pvp_arena` | PvP Arena | Head-to-head online matches against other players. | Core | `matchmaking: skill-based` |

## 4. Atom Coupling Matrix
1. **`sprint_stamina` + `timing_window`:**
   - **Dynamic:** As stamina depletes, the timing window for successful actions (like shooting or tackling) shrinks.
   - **Aesthetic:** Creates a sense of fatigue and tension late in the game, emphasizing the need for substitutions and pacing.
2. **`physics_puzzle` + `timing_window`:**
   - **Dynamic:** The physical state of the ball (speed, spin) alters the required timing for a successful strike.
   - **Aesthetic:** Delivers a highly realistic and satisfying feeling when executing a perfect volley or curveball.
3. **`gacha_banner` + `pvp_arena`:**
   - **Dynamic:** Players acquired through gacha mechanics are used to compete in PvP arenas, driving the desire for better pulls.
   - **Aesthetic:** Fosters a competitive and sometimes frustrating environment where team strength heavily influences match outcomes.
4. **`role_assignment` + `adaptive_difficulty`:**
   - **Dynamic:** The AI adjusts its tactical approach based on the roles assigned by the player, exploiting weaknesses.
   - **Aesthetic:** Enhances the strategic depth, making the player feel like a real manager outsmarting an opponent.
5. **`season_rank` + `collection_log`:**
   - **Dynamic:** Achieving higher ranks rewards exclusive items for the collection log, which in turn may offer slight gameplay boosts or prestige.
   - **Aesthetic:** Provides a continuous sense of progression and achievement across multiple seasons.

## 5. MDA Chain
**Mechanics:** Players utilize `timing_window` and `sprint_stamina` to control athletes governed by a `physics_puzzle` engine. Off the pitch, they engage with `gacha_banner` and `role_assignment` to build their teams.
**Dynamics:** The interplay of physics and timing creates unpredictable, emergent moments during matches. The gacha system drives a continuous loop of playing matches to earn currency for better players, while stamina management dictates the flow of individual games.
**Aesthetics:** The experience evokes the thrill of real-world sports (Challenge, Fellowship in co-op, Competition in PvP). The broadcast presentation and realistic physics create deep Immersion, while team building satisfies the desire for Expression and Progression.

## 6. Variant Spectrum
- **Management Simulation (e.g., Football Manager):** Removes `timing_window` and direct control atoms; heavily emphasizes `role_assignment`, `action_points`, and `logic_deduction` for tactical planning.
- **Arcade Sports (e.g., Mario Strikers):** Reduces `physics_puzzle` realism; adds `elemental_reaction`, `ability_cooldown`, and `iframes` for exaggerated, fast-paced action.
- **Career RPG (e.g., NBA 2K MyCareer):** Adds `branching_dialogue`, `skill_tree`, and `outfit_scoring` to focus on a single athlete's narrative journey.
- **Street/Freestyle Sports (e.g., FIFA Street):** Emphasizes `style_meter` and `combo_counter`; reduces strict `role_assignment` and `season_rank` in favor of trick-based gameplay.

## 7. Anti-Patterns
1. **Scripting/Rubber-Banding:** Overusing `adaptive_difficulty` to artificially keep matches close, making players feel their inputs and team quality don't matter.
2. **Pay-to-Win Dominance:** Balancing `gacha_banner` so heavily that skill (`timing_window`) is entirely overshadowed by the statistical superiority of purchased players in `pvp_arena`.
3. **Animation Priority over Responsiveness:** Forcing long, realistic animations that ignore player inputs, leading to a sluggish and frustrating control experience.

## 8. Cross-Cutting Systems
- **Economy/Monetization:** Heavy reliance on microtransactions via `gacha_banner` (e.g., Ultimate Team packs), dual currencies (earnable vs. premium), and seasonal Battle Passes.
- **Social:** Guilds/Clans (Pro Clubs), online leaderboards, daily/weekly tournaments, and live-ops events tied to real-world sports happenings.
- **Live Operations:** Weekly roster updates reflecting real-world player forms, special event cards, and continuous content drops to maintain engagement throughout the real-world sports season.
