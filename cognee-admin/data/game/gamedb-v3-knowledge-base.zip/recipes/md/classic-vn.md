# Archetype Recipe: Classic Visual Novel (classic-vn)

## 1. Archetype Identity
**ID:** classic-vn
**Name (EN):** Classic Visual Novel
**Name (CN):** 经典视觉小说

**Definition:**
The Classic Visual Novel is a narrative-driven game archetype that relies heavily on text-based storytelling, accompanied by static or semi-animated character sprites, background art, and atmospheric music. The core gameplay revolves around reading the narrative and making occasional choices that branch the storyline, ultimately leading to multiple distinct endings. This archetype prioritizes emotional engagement, character development, and intricate plotting over mechanical complexity.

**Benchmark Games:**
- *Steins;Gate* (2009)
- *Clannad* (2004)
- *Fate/stay night* (2004)
- *Ever 17: The Out of Infinity* (2002)

## 2. Elemental Tetrad Analysis

**Mechanics:**
The core loops and systems are minimalistic, focusing primarily on advancing text and making decisions at critical junctures. The primary mechanics include branching dialogue, affinity meters (to track relationships with characters), and a save/load system that encourages exploring different narrative paths to unlock all endings.

**Aesthetics:**
Visuals typically consist of detailed 2D character sprites with varying expressions overlaid on evocative background art. The audio design is crucial, featuring fully voiced dialogue (often in Japanese) and a highly emotive soundtrack that underscores the mood of each scene. The overall aesthetic aims to immerse the player in the story's emotional landscape.

**Story:**
Narrative structure patterns are highly branching. A common structure involves a linear "common route" that introduces the world and characters, which then splinters into character-specific "routes" based on player choices. These routes culminate in multiple endings, ranging from "bad" to "true" endings, often requiring multiple playthroughs to uncover the complete overarching narrative.

**Technology:**
Technical requirements are generally low. The archetype relies on robust text-rendering engines, audio playback systems, and simple state-tracking for variables (like affection points or flags). Scripting languages tailored for visual novels (e.g., Ren'Py, Kirikiri) are standard, allowing for easy integration of text, images, and sound.

## 3. Atom Recipe Table

| Atom ID | Atom Name | Role in Archetype | Weight | Typical Config |
| :--- | :--- | :--- | :--- | :--- |
| branching_dialogue | Branching Dialogue | Drives the narrative forward and allows player agency in shaping the story's direction. | Core | `{"branch_complexity": "high", "visible_impact": false}` |
| multiple_endings | Multiple Endings | Provides replay value and rewards exploration of different narrative paths. | Core | `{"ending_types": ["bad", "normal", "good", "true"]}` |
| affinity_meter | Affinity Meter | Tracks the protagonist's relationship with key characters, determining route access. | Important | `{"hidden_values": true, "decay_rate": 0}` |
| butterfly_effect | Butterfly Effect | Ensures early choices have significant, sometimes unforeseen, consequences later in the story. | Important | `{"delay_impact": "long"}` |
| collection_log | Collection Log | Encourages completionists to unlock all CGs (Computer Graphics), music tracks, and endings. | Optional | `{"gallery_unlocks": true}` |

## 4. Atom Coupling Matrix

1. **branching_dialogue + multiple_endings**
   - **Dynamic:** Players navigate a complex web of choices to reach specific conclusions.
   - **Aesthetic:** Creates a sense of agency and curiosity, driving the desire to uncover all possible outcomes.

2. **branching_dialogue + affinity_meter**
   - **Dynamic:** Choices directly influence relationship scores, locking or unlocking specific character routes.
   - **Aesthetic:** Fosters emotional investment and attachment to specific characters.

3. **butterfly_effect + multiple_endings**
   - **Dynamic:** Seemingly minor decisions early on drastically alter the final outcome, often leading to unexpected "bad endings."
   - **Aesthetic:** Instills a sense of tension and weight to every decision, enhancing the narrative's impact.

4. **affinity_meter + collection_log**
   - **Dynamic:** Maximizing affinity with different characters unlocks exclusive artwork and scenes in the gallery.
   - **Aesthetic:** Provides a tangible reward for emotional investment, satisfying the completionist urge.

5. **branching_dialogue + butterfly_effect**
   - **Dynamic:** The narrative tree expands exponentially, requiring careful navigation and frequent use of save states.
   - **Aesthetic:** Enhances the feeling of a living, reactive world where the player's presence truly matters.

## 5. MDA Chain

**Mechanics:**
- Text advancement
- Choice selection (branching dialogue)
- Save/Load functionality
- Variable tracking (affinity, flags)

**Dynamics:**
- Route planning and optimization (using saves to explore different branches)
- Emotional bonding with characters through targeted choices
- Piecing together the overarching mystery or narrative by experiencing multiple perspectives

**Aesthetics:**
- **Narrative:** Experiencing a deep, unfolding story.
- **Discovery:** Uncovering hidden truths and secret endings.
- **Fellowship:** Forming emotional connections with virtual characters.

## 6. Variant Spectrum

1. **Kinetic Novel**
   - **Atoms Removed:** branching_dialogue, multiple_endings, affinity_meter
   - **Description:** A purely linear experience with no player choices, focusing entirely on delivering a single, cohesive narrative.

2. **Dating Sim Hybrid**
   - **Atoms Added:** resource_gathering, time_management, stat_building
   - **Description:** Incorporates simulation elements where players must manage time and stats to successfully romance characters.

3. **Mystery/Investigation VN**
   - **Atoms Added:** logic_deduction, evidence_contradiction, point_and_click
   - **Description:** Blends traditional VN storytelling with interactive investigation and puzzle-solving mechanics (e.g., *Ace Attorney*, *Danganronpa*).

## 7. Anti-Patterns

1. **Illusion of Choice:** Offering numerous choices that ultimately lead to the exact same outcome, frustrating players who seek agency.
2. **Obtuse Flagging:** Requiring highly specific, illogical sequences of choices to unlock a route, forcing players to rely on external guides.
3. **Pacing Issues:** Overly long, uneventful "common routes" that fail to hook the player before the story branches into more interesting territory.

## 8. Cross-Cutting Systems

- **Monetization:** Typically premium (pay-to-play) for the base game. Occasionally features DLC for side stories or fan discs.
- **Social:** Minimal in-game social features. Strong reliance on external community building (forums, fan art, wikis) for discussing theories and sharing guides.
