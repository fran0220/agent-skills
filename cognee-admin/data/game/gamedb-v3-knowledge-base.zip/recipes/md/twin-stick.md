# Archetype Recipe: Twin-Stick Shooter (twin-stick)

## 1. Archetype Identity

**ID:** twin-stick
**Name (EN):** Twin-Stick Shooter
**Name (CN):** 双摇杆射击

**Definition:**
The Twin-Stick Shooter is an action-oriented game archetype characterized by the independent control of character movement and aiming/firing direction. Traditionally utilizing two analog sticks (one for movement, one for aiming), this genre emphasizes spatial awareness, crowd control, and reflex-based evasion against overwhelming numbers of enemies or dense projectile patterns. The core loop revolves around surviving waves of enemies, dodging incoming attacks, and efficiently clearing the screen using a variety of weapons and abilities.

**Benchmark Games:**
- *Geometry Wars* (2003)
- *The Binding of Isaac* (2011)
- *Enter the Gungeon* (2016)
- *Vampire Survivors* (2021)

## 2. Elemental Tetrad Analysis

**Mechanics:**
The core mechanics center on independent movement and aiming, allowing players to retreat while firing or strafe around targets. Combat is typically projectile-based, requiring players to manage fire rates, spread, and reload times. The game loop often involves surviving escalating waves of enemies, with progression tied to either run-based roguelite mechanics (collecting random affixes and upgrades) or arcade-style score chasing. Evasion mechanics like the dodge roll with invincibility frames (iframes) are crucial for navigating dense enemy formations and bullet patterns.

**Aesthetics:**
Visually, Twin-Stick Shooters often employ a top-down or isometric perspective to provide a clear view of the battlefield, essential for spatial positioning. The audio-visual feedback is typically intense and chaotic, with bright particle effects, screen shake, and energetic soundtracks emphasizing the fast-paced action. The aesthetic experience is one of high tension, flow state, and the power fantasy of overcoming impossible odds.

**Story:**
Narrative in Twin-Stick Shooters is often minimal or secondary to gameplay, serving primarily as a framing device for the action. When present, stories tend to be environmental or delivered through item descriptions and brief cutscenes, focusing on themes of survival, exploration of hostile environments, or descending into madness/dungeons.

**Technology:**
Technically, these games require robust collision detection and physics systems to handle hundreds of simultaneous projectiles and enemies without performance degradation. Efficient pathfinding for enemy swarms and precise input handling for the dual-stick controls are critical. Procedural generation algorithms are frequently used for level design and loot distribution in roguelite variants.

## 3. Atom Recipe Table

| Atom ID | Atom Name | Role in Archetype | Weight | Typical Config |
| :--- | :--- | :--- | :--- | :--- |
| `projectile` | Projectile | Primary means of dealing damage; defines weapon feel. | Core | `fire_rate: high`, `spread: variable` |
| `wave_system` | Wave System | Structures the pacing and difficulty escalation. | Core | `scaling_difficulty: true` |
| `dodge_roll` | Dodge Roll | Essential evasion tool for navigating dense threats. | Important | `iframes: true` |
| `permadeath` | Permadeath | Adds stakes and tension to each run. | Important | N/A |
| `run_based` | Run-Based | Structures the game into distinct, repeatable attempts. | Important | N/A |
| `random_affix` | Random Affix | Provides build variety and synergistic potential. | Important | N/A |
| `hitscan` | Hitscan | Alternative weapon type for immediate damage delivery. | Optional | N/A |
| `meta_progression` | Meta Progression | Offers long-term goals and gradual difficulty reduction. | Optional | N/A |

## 4. Atom Coupling Matrix

1. **`projectile` + `dodge_roll`**
   - **Interaction:** Players must weave through dense enemy projectile patterns using the invincibility frames of their dodge roll.
   - **Emergent Dynamic:** High-tension spatial positioning and timing mastery, creating a rhythmic dance of evasion and counter-attack.
   - **Aesthetic:** Sensation of flow and mastery.

2. **`wave_system` + `random_affix`**
   - **Interaction:** As enemy waves escalate in difficulty, they may gain random affixes (e.g., explosive death, speed boost), forcing the player to adapt their build and tactics.
   - **Emergent Dynamic:** Continuous build adaptation and dynamic target prioritization based on immediate threats.
   - **Aesthetic:** Challenge and strategic depth.

3. **`run_based` + `meta_progression`**
   - **Interaction:** Resources gathered during failed runs contribute to permanent upgrades or unlocks for future attempts.
   - **Emergent Dynamic:** A satisfying grind loop where even failure yields progress, gradually reducing the difficulty curve.
   - **Aesthetic:** Submission (grinding) and long-term accomplishment.

4. **`projectile` + `random_affix`**
   - **Interaction:** Player projectiles can be modified with random affixes (e.g., bouncing, piercing, elemental damage) collected during a run.
   - **Emergent Dynamic:** Synergistic build crafting, where players seek combinations that exponentially increase their screen-clearing potential.
   - **Aesthetic:** Power fantasy and discovery.

5. **`dodge_roll` + `wave_system`**
   - **Interaction:** As wave density increases, the physical space available to the player shrinks, making precise dodge roll positioning critical for survival.
   - **Emergent Dynamic:** Intense crowd control and spatial awareness, managing the "kiting" of enemy swarms.
   - **Aesthetic:** High tension and adrenaline.

## 5. MDA Chain

**Mechanics:**
- Independent movement and aiming controls.
- High enemy density and projectile volume.
- Projectile-based combat with varying fire rates and spreads.
- Run-based progression with randomized upgrades and permadeath.

**Dynamics:**
- **Spatial Positioning:** Constantly evaluating safe zones and kiting enemy swarms.
- **Crowd Control:** Prioritizing targets and managing the physical space of the arena.
- **Build Optimization:** Synergizing random upgrades to maximize damage output and survivability.
- **Risk vs. Reward:** Deciding whether to push into dangerous areas for resources or play safely.

**Aesthetics:**
- **Challenge:** Overcoming escalating difficulty and complex bullet patterns.
- **Sensation:** The audio-visual feedback of destroying large numbers of enemies.
- **Fantasy:** The power fantasy of becoming an unstoppable force through synergistic builds.

## 6. Variant Spectrum

1. **Bullet Heaven / Survivor-like**
   - **Atoms Added:** `auto_fire`, `meta_progression`
   - **Atoms Removed:** `independent_aiming`
   - **Description:** Automates the firing mechanic, shifting the focus entirely to movement, positioning, and build optimization.

2. **Roguelite Twin-Stick**
   - **Atoms Added:** `room_based_generation`, `permadeath`
   - **Atoms Removed:** `infinite_waves`
   - **Description:** Structures the game into distinct rooms or dungeons, emphasizing exploration and resource management alongside combat.

3. **Arcade Score Chaser**
   - **Atoms Added:** `combo_counter`, `score_multiplier`
   - **Atoms Removed:** `meta_progression`
   - **Description:** Focuses purely on mechanical skill and high scores, often featuring infinite, escalating waves without permanent upgrades.

## 7. Anti-Patterns

1. **Visual Clutter:** Overwhelming the screen with particle effects and similar-colored projectiles, making it impossible for the player to distinguish threats from their own attacks.
2. **Unavoidable Damage:** Designing enemy patterns or arena layouts that guarantee damage regardless of player skill, breaking the contract of reflex-based evasion.
3. **Meaningless Upgrades:** Offering a pool of random affixes that lack synergy or fail to meaningfully alter the gameplay, leading to stagnant and repetitive runs.

## 8. Cross-Cutting Systems

- **Economy / Monetization:** Often utilizes a premium model for core games, while mobile variants may employ F2P economies with gacha mechanics for unlocking characters or weapons.
- **Social:** Leaderboards are common for arcade variants, fostering asynchronous competition. Co-op multiplayer (local or online) is frequently included to enhance the chaotic fun.
- **Progression:** Achievement systems and collection logs are heavily utilized to provide long-term goals and encourage diverse playstyles.
