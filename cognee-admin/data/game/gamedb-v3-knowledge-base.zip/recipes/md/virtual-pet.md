# Archetype Recipe: Virtual Pet (virtual-pet)

## 1. Archetype Identity
**ID:** `virtual-pet`
**Name (EN):** Virtual Pet
**Name (CN):** 虚拟宠物类

**Definition:**
The Virtual Pet archetype centers around the care, nurturing, and observation of a digital entity. Gameplay is typically low-intensity and asynchronous, focusing on routine maintenance tasks such as feeding, cleaning, and playing with the pet to maintain its well-being (affinity and energy levels). These games often run in real-time, requiring players to check in periodically rather than engaging in long, continuous play sessions. The core appeal lies in the emotional attachment formed with the digital companion and the gradual progression of its lifecycle or the player's collection.

**Benchmark Games:**
- *Tamagotchi* (1996) - Dedicated Hardware
- *Seaman* (1999) - Dreamcast
- *Pou* (2012) - Mobile
- *Neko Atsume* (2014) - Mobile

## 2. Elemental Tetrad Analysis

**Mechanics:**
The core loops revolve around resource management and time-gated interactions. Players expend resources (food, toys) to replenish the pet's decaying stats (hunger, happiness). The systems heavily rely on real-time clocks to dictate stat decay and the availability of new interactions or events. Progression is often tracked through a collection log or the pet's evolutionary stages.

**Aesthetics:**
Visuals are typically stylized, cute, and expressive to foster emotional connection. Audio features distinct, recognizable cues for the pet's needs (e.g., crying when hungry, cheering when happy). The overall tone is relaxing, non-threatening, and nurturing.

**Story:**
Narrative is usually emergent rather than scripted. The "story" is the personal history of the player's interactions with the pet—its growth, its quirks, and the environment the player builds for it. Some variants include light lore about the pet's species or world.

**Technology:**
Requires robust background processing or real-time clock synchronization to calculate stat decay while the game is closed. Push notifications are critical for alerting the player to the pet's needs. Cloud saving is often necessary to prevent the tragic loss of a long-nurtured pet.

## 3. Atom Recipe Table

| Atom ID | Atom Name | Role in Archetype | Weight | Typical Config |
| :--- | :--- | :--- | :--- | :--- |
| `affinity_meter` | Affinity Meter | Tracks the pet's happiness, health, and bond with the player. | Core | `decay_rate: constant`, `interaction_boost: high` |
| `energy_stamina_gate` | Energy/Stamina Gate | Limits the number of interactions per session, enforcing breaks. | Core | `regen_rate: slow`, `max_cap: low` |
| `daily_weekly_reset` | Daily/Weekly Reset | Encourages habitual check-ins by refreshing tasks or shop items. | Important | `cycle_length: 24h` |
| `collection_log` | Collection Log | Provides long-term goals by tracking discovered pets, items, or behaviors. | Important | `display_mode: gallery` |
| `currency_dual` | Dual Currency | Separates basic care resources from premium cosmetic items. | Important | `premium_ratio: high` |
| `room_decoration` | Room Decoration | Allows players to personalize the pet's environment, serving as a resource sink. | Optional | `grid_snap: true` |
| `resource_gathering` | Resource Gathering | Provides a secondary activity to acquire food or currency. | Optional | `passive_generation: true` |
| `fishing_minigame` | Fishing Minigame | A common, low-stress minigame to earn resources while interacting with the pet. | Optional | `difficulty: low` |

## 4. Atom Coupling Matrix

1. **`affinity_meter` + `energy_stamina_gate`**
   - **Interaction:** Pet actions (playing, feeding) consume the player's energy/stamina but increase the pet's affinity.
   - **Emergent Dynamic:** Dictates the pacing of interaction sessions, forcing players to optimize their limited actions to maximize the pet's well-being.
   - **Aesthetic:** Creates a sense of routine and careful management (Submission/Fellowship).

2. **`daily_weekly_reset` + `collection_log`**
   - **Interaction:** New items, rare pets, or specific behaviors only appear on certain days or after daily resets.
   - **Emergent Dynamic:** Drives habitual daily check-ins as players strive to complete their collections.
   - **Aesthetic:** Fosters anticipation and the joy of discovery (Discovery).

3. **`currency_dual` + `room_decoration`**
   - **Interaction:** Premium currency is required to purchase exclusive, high-tier room decorations.
   - **Emergent Dynamic:** Monetizes the player's desire for aesthetic expression and personalization of the pet's space.
   - **Aesthetic:** Enhances self-expression and status (Expression).

4. **`affinity_meter` + `collection_log`**
   - **Interaction:** Reaching high affinity thresholds unlocks new entries in the collection log, such as unique animations or diary entries.
   - **Emergent Dynamic:** Transforms short-term caretaking into long-term progression goals.
   - **Aesthetic:** Rewards dedication with deeper lore or visual treats (Discovery/Fellowship).

5. **`energy_stamina_gate` + `resource_gathering`**
   - **Interaction:** Gathering resources (like food) is gated by the same stamina pool used for interacting with the pet.
   - **Emergent Dynamic:** Forces a strategic choice between gathering supplies for the future or interacting with the pet now, controlling overall session length.
   - **Aesthetic:** Adds a layer of resource management to the nurturing experience (Challenge/Submission).

## 5. MDA Chain

**Mechanics:**
- Real-time stat decay (hunger, hygiene, happiness).
- Interaction cooldowns and stamina limits.
- Resource management (earning currency to buy food/toys).
- Collection systems (logging different pet evolutions or behaviors).

**Dynamics:**
- **Routine Maintenance:** Players develop a daily habit of checking in to perform necessary care tasks.
- **Delayed Gratification:** Waiting for real-time processes (like an egg hatching or a pet evolving) builds anticipation.
- **Session Pacing:** Short, frequent play sessions are encouraged over long binges due to stamina gates.
- **Aesthetic Customization:** Players invest time and resources into personalizing the pet's environment.

**Aesthetics:**
- **Submission:** The game acts as a relaxing pastime with a predictable structure.
- **Fellowship:** A strong emotional bond is formed with the digital companion.
- **Expression:** Customizing the pet's room or appearance allows for personal creativity.
- **Discovery:** Uncovering new pet evolutions, behaviors, or items in the collection log.

## 6. Variant Spectrum

1. **Idle Collector (e.g., Neko Atsume)**
   - **Atoms Added:** `passive_generation`, `gacha_banner`
   - **Atoms Removed:** `energy_stamina_gate`
   - **Description:** Shifts focus from active caretaking to passive observation and collection. Players leave out items and wait for pets to visit.

2. **Pet Simulator RPG (e.g., Pokémon Amie/Camp features)**
   - **Atoms Added:** `xp_level`, `skill_tree`, `turn_based_combat`
   - **Atoms Removed:** `room_decoration`
   - **Description:** Integrates pet care into a broader RPG framework, where affinity directly impacts combat performance or stat growth.

3. **Tamagotchi Classic**
   - **Atoms Added:** `permadeath`, `one_tap`
   - **Atoms Removed:** `currency_dual`, `room_decoration`
   - **Description:** The purest form of the archetype, focusing solely on survival and evolution with high stakes (death if neglected).

## 7. Anti-Patterns

1. **Over-Demanding Decay Rates:** If stats decay too quickly, the game shifts from a relaxing companion to a stressful chore, leading to player burnout and churn.
2. **Lack of Meaningful Progression:** Without a collection log, evolutions, or room decoration, the core loop of feeding/cleaning becomes monotonous, and players lose long-term motivation.
3. **Aggressive Monetization of Basic Needs:** Locking essential care items (like basic food or medicine) behind premium currency breaks the emotional bond and feels exploitative.

## 8. Cross-Cutting Systems

- **Economy (F2P):** Heavily relies on dual currencies, where basic care is free but cosmetics and time-skips are monetized.
- **Social/Multiplayer:** Often includes asynchronous social features, such as visiting friends' rooms, sending gifts, or breeding pets together.
- **Push Notifications:** Essential for retention, alerting players when the pet needs attention or when a real-time task is complete.
- **Monetization (Cosmetics):** The primary revenue driver, offering skins, outfits, and room decorations that do not affect core gameplay balance.
