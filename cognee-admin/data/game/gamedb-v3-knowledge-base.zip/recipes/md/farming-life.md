# Archetype Recipe: Farming Life Sim (farming-life)

## 1. Archetype Identity
**ID:** farming-life
**Names:** Farming Life Sim (English), 农场生活模拟 (Chinese)

The Farming Life Sim archetype is defined by a core loop of agricultural management intertwined with social simulation and community building. Players typically inherit or purchase a run-down farm and must restore it to prosperity through daily labor, resource management, and economic expansion. This genre emphasizes a relaxing, low-stakes atmosphere where progression is measured in seasons, relationships, and the gradual transformation of the environment. It blends the systemic depth of management games with the emotional resonance of life simulation, creating a deeply personal and rewarding experience.

**Benchmark Games:**
- *Harvest Moon* (1996)
- *Stardew Valley* (2016)
- *Animal Crossing: New Horizons* (2020)
- *Story of Seasons: Pioneers of Olive Town* (2021)

## 2. Elemental Tetrad Analysis

### Mechanics
The core loops revolve around a daily cycle of energy management and time allocation. Players must balance agricultural tasks (planting, watering, harvesting) with exploration, resource gathering (mining, fishing, foraging), and social interactions. The economy is driven by selling produce and crafted goods to upgrade tools, expand the farm, and unlock new areas. Progression is gated by seasons, which dictate crop availability and environmental events.

### Aesthetics
Visually, these games often employ a charming, stylized, or pixel-art aesthetic that evokes nostalgia and warmth. The audio design features relaxing, seasonal soundtracks that change with the weather and time of day, reinforcing the passage of time. The overall aesthetic is one of pastoral tranquility, encouraging players to unwind and immerse themselves in a peaceful virtual life.

### Story
Narrative structures typically follow a "return to nature" trope, where the protagonist leaves a stressful urban life to embrace rural simplicity. The overarching goal is often to revitalize a struggling town or farm, while personal stories unfold through interactions with NPCs. These character arcs are revealed gradually as the player builds affinity, culminating in deep friendships or romance.

### Technology
Technical requirements focus on robust simulation systems for crop growth, weather patterns, and NPC schedules. The game must handle complex state management for thousands of individual tiles (soil, crops, objects) and track numerous variables related to player progression, inventory, and relationships. Efficient save systems and time-tracking algorithms are crucial.

## 3. Atom Recipe Table

| Atom ID | Atom Name | Role in Archetype | Weight | Typical Config |
| :--- | :--- | :--- | :--- | :--- |
| energy_stamina_gate | Energy/Stamina Gate | Limits daily actions, forcing strategic time management. | Core | `max_stamina: 100`, `regen_rate: 0` (sleep required) |
| day_night_cycle | Day/Night Cycle | Dictates NPC schedules, store hours, and crop growth phases. | Core | `day_length: 15_mins`, `night_penalty: true` |
| resource_gathering | Resource Gathering | Core activity for acquiring materials (wood, stone, ore). | Core | `tool_tier_scaling: true` |
| crafting_recipe | Crafting Recipe | Allows players to process raw materials into higher-value goods. | Core | `unlock_method: skill_level` |
| affinity_meter | Affinity Meter | Tracks relationship progress with NPCs, unlocking dialogue and events. | Core | `decay_rate: low`, `gift_bonus: true` |
| season_rank | Season System | Changes environment, available crops, and triggers festivals. | Core | `season_length: 28_days` |
| fishing_minigame | Fishing Minigame | Provides an alternative income source and collection activity. | Important | `difficulty_scaling: fish_rarity` |
| branching_dialogue | Branching Dialogue | Enhances social interactions and allows for player expression. | Important | `impact_affinity: true` |
| room_decoration | Room Decoration | Allows personalization of the player's home and farm layout. | Important | `grid_based: true` |
| collection_log | Collection Log | Encourages long-term engagement through completing sets (museum, shipping). | Important | `reward_tiers: true` |
| skill_tree | Skill Progression | Rewards repeated actions with increased efficiency or new abilities. | Optional | `max_level: 10` |
| combat_melee | Melee Combat | Adds risk/reward to exploration areas like mines. | Optional | `complexity: low` |

## 4. Atom Coupling Matrix

1. **energy_stamina_gate + day_night_cycle**
   - **Interaction:** The player's available energy is constrained by the length of the day, and staying up too late incurs an energy penalty the next day.
   - **Emergent Dynamic:** Creates a compelling daily optimization puzzle where players must plan their routes and activities to maximize productivity before exhaustion or midnight.
   - **Aesthetic:** Produces a satisfying rhythm of labor and rest, reinforcing the feeling of a hard day's work.

2. **resource_gathering + crafting_recipe**
   - **Interaction:** Gathering basic resources unlocks the ability to craft machines (e.g., mayonnaise machines, kegs) that process raw materials.
   - **Emergent Dynamic:** Shifts the economic focus from selling raw crops to establishing automated production lines for artisanal goods.
   - **Aesthetic:** Fosters a sense of industrial progression and mastery over the farm's output.

3. **affinity_meter + branching_dialogue**
   - **Interaction:** Giving gifts and choosing the right dialogue options increases affinity, which in turn unlocks deeper, more personal dialogue branches.
   - **Emergent Dynamic:** Encourages players to learn NPC preferences and schedules, turning social interaction into a strategic but emotionally rewarding system.
   - **Aesthetic:** Creates a sense of belonging and community integration.

4. **season_rank + collection_log**
   - **Interaction:** Certain items required for the collection log are only available during specific seasons.
   - **Emergent Dynamic:** Forces players to plan their activities months in advance, ensuring they don't miss a seasonal window and have to wait an entire in-game year.
   - **Aesthetic:** Instills a deep appreciation for the passage of time and the cyclical nature of nature.

5. **fishing_minigame + energy_stamina_gate**
   - **Interaction:** Fishing consumes energy but can yield fish that restore energy when eaten.
   - **Emergent Dynamic:** Provides a risk/reward loop where players can gamble their remaining energy on catching high-value fish to extend their workday.
   - **Aesthetic:** Adds a layer of tension and excitement to an otherwise relaxing activity.

## 5. MDA Chain

**Mechanics:**
The foundation rests on the `day_night_cycle` and `energy_stamina_gate`, which limit player actions. These are coupled with `resource_gathering` (farming, mining) and an `affinity_meter` for social interactions. The economy is driven by a `crafting_recipe` system that increases the value of goods.

**Dynamics:**
These mechanics create a dynamic of constant prioritization. Players must decide whether to spend their limited energy watering crops, delving into the mines for ore, or socializing with townsfolk. The seasonal changes introduce long-term planning dynamics, as players must prepare for the next season's crops and events. The progression from manual labor to automated systems (sprinklers, artisan machines) creates a dynamic of increasing efficiency and wealth.

**Aesthetics:**
The resulting aesthetics are primarily **Submission** (game as pastime) and **Discovery** (game as uncharted territory). The repetitive, rhythmic nature of farm work provides a relaxing, meditative experience. The gradual uncovering of NPC backstories, new areas, and efficient farming layouts satisfies the desire for discovery. Ultimately, the archetype delivers a profound sense of **Expression** and **Fellowship** as players customize their farms and build a virtual life.

## 6. Variant Spectrum

1. **Combat-Heavy Farmer (e.g., *Rune Factory*)**
   - **Atoms Added:** `melee_combo`, `dodge_roll`, `elemental_reaction`, `boss_fights`
   - **Atoms Removed:** `room_decoration` (often simplified)
   - **Focus:** Blends action-RPG dungeon crawling with farming, where crops are often used to buff combat stats or tame monsters.

2. **Automation Tycoon (e.g., *Slime Rancher*, *Factorio* lite)**
   - **Atoms Added:** `belt_conveyor`, `logic_deduction`, `tech_tree`
   - **Atoms Removed:** `affinity_meter`, `branching_dialogue`
   - **Focus:** Shifts the emphasis entirely to optimizing production chains and maximizing output, minimizing social simulation.

3. **Cozy Life Sim (e.g., *Animal Crossing*)**
   - **Atoms Added:** `real_time_clock`, `outfit_scoring`, `multiplayer_visiting`
   - **Atoms Removed:** `energy_stamina_gate`, `combat_melee`
   - **Focus:** Removes pressure and failure states, focusing purely on decoration, collection, and low-stakes social interaction synced to real-world time.

## 7. Anti-Patterns

1. **The Grind Wall:** Making the transition from manual labor to automation too slow or resource-intensive. If players spend 80% of their in-game day just watering crops for too many seasons, the game becomes a chore rather than a relaxing experience.
2. **Lifeless NPCs:** Designing NPCs with limited dialogue pools that repeat the same lines daily. This shatters the illusion of a living community and makes the `affinity_meter` feel like a mechanical transaction rather than a relationship.
3. **Punishing Time Limits:** Implementing overly strict deadlines for quests or seasonal events without adequate warning. This introduces unnecessary stress into an archetype that relies on a relaxing, self-paced aesthetic.

## 8. Cross-Cutting Systems

- **Economy:** Typically a single-currency system (Gold/G) driven by a shipping bin mechanic, where goods are sold overnight.
- **Social:** Often features asynchronous multiplayer (visiting other farms) or full co-op, allowing players to share the workload and economy.
- **Monetization:** Traditionally premium (pay-once), though mobile variants may introduce `energy_stamina_gate` monetization (paying to refill energy) or cosmetic microtransactions for `room_decoration`.
