# Archetype Recipe: Social Deduction

## 1. Archetype Identity
**ID:** social-deduction
**Names:** Social Deduction (English) / 社交推理类 (Chinese)

**Definition:**
The Social Deduction archetype is a multiplayer game genre where players are secretly assigned roles, typically divided into an uninformed majority (the "innocents" or "crew") and an informed minority (the "traitors" or "impostors"). The core gameplay revolves around information asymmetry, deception, and deduction. The innocent team must identify and eliminate the traitors or complete a set of objectives to win, while the traitors must eliminate the innocents or sabotage their objectives without being discovered. The genre heavily relies on player interaction, communication, and psychological manipulation, making the social dynamics the primary driver of the gameplay experience.

**Benchmark Games:**
- *Werewolf* (1986)
- *The Resistance* (2009)
- *Town of Salem* (2014)
- *Secret Hitler* (2016)
- *Among Us* (2018)

## 2. Elemental Tetrad Analysis

**Mechanics:**
The core loops of Social Deduction games involve phases of action and discussion. During the action phase, players complete tasks, gather information, or use special abilities (e.g., killing, investigating, protecting). This is followed by a discussion phase where players share information, make accusations, and defend themselves. The system is driven by hidden roles, voting mechanisms, and elimination. The mechanics are designed to create situations where trust is necessary but dangerous, forcing players to constantly evaluate the motives of others based on their actions and statements.

**Aesthetics:**
The visual and audio style patterns in Social Deduction games often emphasize tension, paranoia, and isolation. The art style can range from minimalist and abstract (as seen in many tabletop adaptations) to cartoonish and expressive (like *Among Us*), which helps to lower the barrier to entry and contrast with the dark themes of murder and betrayal. Audio cues are crucial, often using heartbeat sounds, sudden stingers for eliminations, and limited visibility or muffled sounds to enhance the feeling of vulnerability and uncertainty.

**Story:**
Narrative structures in this archetype are typically emergent rather than scripted. The overarching premise usually involves a group of people trapped in an isolated environment (a spaceship, a remote village, a locked mansion) with a hidden threat among them. The actual "story" of each match is created by the players' interactions: the alliances formed, the betrayals executed, the clever bluffs, and the dramatic reveals. The narrative is a psychological thriller written in real-time by the participants.

**Technology:**
Typical technical requirements include robust multiplayer networking to handle real-time interactions and synchronization of game states. Voice or text chat integration is essential, often requiring proximity chat features or structured communication channels that open and close based on the game phase. The game must securely handle hidden information, ensuring that clients only receive the data they are supposed to know to prevent cheating. Cross-platform play is also highly desirable to ensure a large and active player base.

## 3. Atom Recipe Table

| Atom ID | Atom Name | Role in Archetype | Weight | Typical Config |
| :--- | :--- | :--- | :--- | :--- |
| role_assignment | Role Assignment | Assigns hidden identities and abilities to players at the start. | Core | `hidden: true, distribution: asymmetric` |
| discussion_vote | Discussion & Voting | The primary mechanism for the majority to eliminate suspected traitors. | Core | `timer: 120s, majority_required: true` |
| logic_deduction | Logic Deduction | Players must piece together clues and alibis to find the truth. | Core | `clue_types: [behavioral, mechanical]` |
| stealth_takedown | Stealth Takedown | Allows traitors to eliminate innocents without immediate detection. | Core | `cooldown: 30s, range: short, noise: low` |
| vision_cone | Vision Cone / Line of Sight | Limits information gathering, creating opportunities for stealth and deception. | Important | `angle: 90-120, blocked_by_walls: true` |
| resource_gathering | Task Completion | Gives innocents an alternative win condition and forces movement. | Important | `task_count: 4-6 per player, shared_progress: true` |
| ability_cooldown | Ability Cooldown | Paces the use of powerful actions like kills or investigations. | Important | `kill_cooldown: 15-45s, ability_cooldown: 20s` |
| evidence_contradiction | Evidence Contradiction | Players cross-reference statements to catch liars. | Important | `log_history: true, public_record: partial` |
| spatial_portal | Vents / Fast Travel | Allows traitors to move quickly and secretly across the map. | Optional | `access: traitors_only, visibility: entry_exit_only` |
| day_night_cycle | Phase Alternation | Structures the game into distinct periods of action and discussion. | Optional | `day_duration: variable, night_duration: fixed` |

## 4. Atom Coupling Matrix

1. **role_assignment + discussion_vote**
   - **Dynamic:** The fundamental conflict of the game. The uninformed majority uses voting to find the informed minority, who use discussion to misdirect the vote.
   - **Aesthetic:** Paranoia, persuasion, and the tension of mob justice.

2. **stealth_takedown + vision_cone**
   - **Dynamic:** Traitors must carefully position themselves to eliminate targets out of sight of others, while innocents try to maintain visual contact with trusted allies.
   - **Aesthetic:** Suspense, fear of the dark, and the thrill of the hunt.

3. **resource_gathering + logic_deduction**
   - **Dynamic:** Innocents must move around to complete tasks, which separates them and makes them vulnerable. The pattern of task completion (or faking it) becomes a key piece of evidence for deduction.
   - **Aesthetic:** Anxiety of vulnerability, satisfaction of piecing together a timeline.

4. **spatial_portal + evidence_contradiction**
   - **Dynamic:** Traitors use portals to create false alibis (e.g., "I was in the reactor"). Innocents must use map knowledge and timing to prove these alibis are impossible.
   - **Aesthetic:** The "aha!" moment of catching a lie, the smugness of a perfect crime.

5. **ability_cooldown + discussion_vote**
   - **Dynamic:** Traitors must time their kills around the cooldowns and the impending discussion phases. A kill right before a meeting is risky but can silence a witness.
   - **Aesthetic:** Pacing, urgency, and the strategic manipulation of time.

## 5. MDA Chain

**Mechanics:**
- Hidden role assignment (Innocent vs. Traitor).
- Limited vision and movement mechanics.
- Task completion systems for Innocents.
- Stealth kill and sabotage abilities for Traitors.
- Structured discussion and voting phases.

**Dynamics:**
- **Information Asymmetry:** Traitors know everything; Innocents know nothing.
- **Deception and Bluffing:** Traitors must act like Innocents, faking tasks and expressing false suspicion.
- **Deduction and Interrogation:** Innocents must analyze movement patterns, task progress, and vocal cues to identify inconsistencies.
- **Herd Mentality vs. Independent Thought:** Voting often cascades based on the loudest voice, requiring players to persuade the group or resist manipulation.

**Aesthetics:**
- **Fellowship:** The fragile bonds formed when two players decide to trust each other.
- **Submission:** The tension of being forced into a confined space with a potential killer.
- **Expression:** The performative aspect of defending oneself or accusing another in chat.
- **Challenge:** The intellectual puzzle of solving the murder or the strategic challenge of getting away with it.

## 6. Variant Spectrum

1. **The Pure Talker (e.g., *Town of Salem*)**
   - **Added:** `day_night_cycle`, `class_job` (many complex roles with specific abilities).
   - **Removed:** `vision_cone`, `stealth_takedown` (replaced by menu-based night actions), `resource_gathering`.
   - **Focus:** Pure logic, role claiming, and complex ability interactions.

2. **The Action-Deduction Hybrid (e.g., *Among Us*)**
   - **Added:** `vision_cone`, `stealth_takedown`, `resource_gathering`, `spatial_portal`.
   - **Removed:** `day_night_cycle` (replaced by real-time continuous play interrupted by meetings).
   - **Focus:** Spatial awareness, timing, and multitasking.

3. **The Survival Traitor (e.g., *Project Winter*)**
   - **Added:** `resource_gathering` (for survival, not just points), `crafting_recipe`, `combat_system` (health, weapons).
   - **Removed:** `discussion_vote` (elimination is often through combat or exposure, not just voting).
   - **Focus:** Resource management, physical survival, and brutal betrayals.

4. **The Audio-Visual Thriller (e.g., *Deceit*)**
   - **Added:** `fps_combat`, `item_looting`, `transformation_mechanic`.
   - **Removed:** `top_down_perspective`, structured `discussion_vote` (replaced by real-time voice chat and shooting).
   - **Focus:** Jump scares, fast-paced action, and sensory deprivation.

## 7. Anti-Patterns

1. **The "Quiet Town" Syndrome:** If the game lacks mechanics to force interaction or provide starting information, players may have nothing to discuss, leading to random voting or passive gameplay.
2. **Snowballing Advantage:** If a team gains too much information too quickly (e.g., through overpowered investigative roles), the game can end prematurely without giving the opposing team a chance to counterplay.
3. **The "Dead Player" Boredom:** In games with player elimination, players who die early often have nothing to do for the remainder of the match, leading to disengagement and frustration.

## 8. Cross-Cutting Systems

- **Social & Multiplayer:** Robust friends lists, party systems, and matchmaking are critical. Proximity voice chat is increasingly becoming a standard feature to enhance immersion.
- **Economy & Monetization:** Typically relies on a Free-to-Play (F2P) model with cosmetic microtransactions (skins, pets, kill animations, lobby decorations).
- **Progression & Meta:** Account leveling, battle passes, and achievement systems to reward long-term play without affecting the balanced, asymmetric gameplay of individual matches.
