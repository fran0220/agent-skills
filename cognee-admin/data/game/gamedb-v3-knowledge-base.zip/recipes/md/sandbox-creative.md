# Archetype Recipe: Sandbox Creative (沙盒创造类)

## 1. Archetype Identity
- **Archetype ID:** `sandbox-creative`
- **Name (EN):** Sandbox Creative
- **Name (CN):** 沙盒创造类
- **Definition:** A genre focused on providing players with a vast, open environment and a comprehensive set of tools to build, modify, and interact with the world. Unlike survival modes, creative sandboxes remove resource constraints and survival pressures, emphasizing pure player expression, architectural design, and emergent gameplay through physics and logic systems.
- **Benchmark Games:**
  - *Minecraft (Creative Mode)* (2011)
  - *Roblox* (2006)
  - *Garry's Mod* (2006)
  - *Terraria (Journey Mode)* (2011)

## 2. Elemental Tetrad Analysis
- **Mechanics:** Core loops revolve around placing and destroying blocks/objects, manipulating physics, and wiring logic gates. Systems are highly modular, allowing players to combine simple elements into complex machines or structures.
- **Aesthetics:** Visuals often lean towards voxel-based or stylized low-poly to ensure high performance with massive numbers of objects. Audio provides satisfying feedback for building and interacting. The overall aesthetic is one of infinite possibility and a "blank canvas."
- **Story:** Inherently player-driven. There is no predefined narrative; instead, the story emerges from the player's creations, role-playing scenarios, and social interactions within the world.
- **Technology:** Requires robust voxel engines or physics simulators capable of handling dynamic, fully destructible/constructible environments. Network architecture must support real-time synchronization of massive world changes for multiplayer.

## 3. Atom Recipe Table

| atom_id | atom_name | role_in_archetype | weight | typical_config |
| :--- | :--- | :--- | :--- | :--- |
| `procedural_gen` | Procedural Generation | Creates the infinite or massive canvas for players to build upon. | core | `{"seed_based": true, "infinite": true}` |
| `room_decoration` | Room/World Decoration | The primary verb: placing blocks, props, and structures to shape the world. | core | `{"grid_snap": true, "infinite_resources": true}` |
| `physics_puzzle` | Physics System | Allows creations to have dynamic behaviors (falling sand, ragdolls, vehicles). | important | `{"gravity_scale": 1.0, "collision_damage": false}` |
| `logic_deduction` | Logic/Wiring System | Enables the creation of automated machines, traps, and interactive elements (e.g., Redstone). | important | `{"tick_rate": 20, "turing_complete": true}` |
| `biome_system` | Biome System | Provides varied aesthetic backdrops and environmental conditions for builds. | important | `{"transition_smoothing": true}` |
| `day_night_cycle` | Day/Night Cycle | Adds dynamic lighting and atmosphere to player creations. | optional | `{"duration_minutes": 20, "player_controlled": true}` |
| `glide_float` | Flight/No-Clip | Essential for navigating and building large structures without traversal friction. | core | `{"speed_multiplier": 3.0, "collision": false}` |
| `social_multiplayer` | Social Interaction | Allows players to collaborate on builds or show off creations. | core | `{"max_players": 64, "permissions_system": true}` |

## 4. Atom Coupling Matrix
1. **`room_decoration` + `procedural_gen`**
   - *Dynamic:* Players modify the procedurally generated terrain, creating a stark contrast between natural algorithms and human design.
   - *Aesthetic:* Expression and Discovery.
2. **`logic_deduction` + `physics_puzzle`**
   - *Dynamic:* Players build complex, moving contraptions like elevators, vehicles, or automated doors.
   - *Aesthetic:* Intellectual Challenge and Submission (to the rules of the simulation).
3. **`room_decoration` + `social_multiplayer`**
   - *Dynamic:* Collaborative building projects where multiple players contribute to a single massive structure.
   - *Aesthetic:* Fellowship and Expression.
4. **`glide_float` + `room_decoration`**
   - *Dynamic:* Players can build from any angle and reach any height, removing the platforming challenge from the building process.
   - *Aesthetic:* Fantasy (god-like control over the environment).
5. **`biome_system` + `day_night_cycle`**
   - *Dynamic:* The visual mood of a player's build changes dramatically based on the time of day and the surrounding biome.
   - *Aesthetic:* Sensation and Atmosphere.

## 5. MDA Chain
- **Mechanics:** Infinite resources, free-flying camera/avatar, modular building blocks, logic gates, and physics entities.
- **Dynamics:** Players experiment with combinations of blocks, reverse-engineer others' creations, collaborate on mega-builds, and invent mini-games within the sandbox.
- **Aesthetics:** 
  - *Expression:* Leaving a permanent mark on the world.
  - *Fellowship:* Sharing and building together.
  - *Discovery:* Finding new ways systems interact (emergent gameplay).

## 6. Variant Spectrum
- **Physics Sandbox (e.g., Garry's Mod):** Removes `procedural_gen` and `biome_system`, adds advanced `physics_puzzle` and tool-guns. Focuses on manipulating props rather than voxel blocks.
- **Logic/Engineering Sandbox (e.g., Besiege, Scrap Mechanic):** Enhances `logic_deduction` and `physics_puzzle`, adds `vehicle_crafting`. Focuses on building functional machines to solve implicit goals.
- **Social Metaverse (e.g., Roblox, VRChat):** Enhances `social_multiplayer` and `avatar_customization`, adds `scripting_api`. Focuses on user-generated experiences and socializing rather than just building.

## 7. Anti-Patterns
1. **Over-Complicated UI:** Making the inventory or building tools too complex, which stifles the flow of creativity.
2. **Lack of Export/Sharing:** Failing to provide tools for players to save, share, or blueprint their creations, leading to a loss of motivation.
3. **Inconsistent Physics/Logic:** Unpredictable system behaviors that break complex machines, frustrating players who invest time in engineering.

## 8. Cross-Cutting Systems
- **Economy/Monetization:** Cosmetic microtransactions (skins, textures), marketplace for user-generated content (UGC), server hosting fees.
- **Social:** Friends lists, server browsers, permission management (griefing protection), reporting systems.
- **Progression:** Typically absent in pure creative modes, but may include "likes" or "visits" metrics for shared creations.
