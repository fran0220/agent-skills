# Archetype Recipe: Colony Sim

## 1. Archetype Identity
**Archetype ID:** `colony-sim`
**Name (EN):** Colony Sim
**Name (CN):** 殖民地模拟

**Definition:**
The Colony Sim is a complex management and simulation archetype where the player acts as an unseen overseer, guiding a group of autonomous or semi-autonomous agents (colonists) to survive, build, and thrive in a dynamic, often hostile environment. Unlike traditional city builders, Colony Sims focus heavily on the individual needs, skills, and psychological states of the agents, creating emergent narratives through the intersection of systemic mechanics, procedural generation, and random events.

**Benchmark Games:**
* *Dwarf Fortress* (2006)
* *RimWorld* (2013)
* *Oxygen Not Included* (2017)
* *Going Medieval* (2021)

## 2. Elemental Tetrad Analysis

**Mechanics:**
The core loops revolve around resource gathering, base building, and fulfilling the physiological and psychological needs of the colonists. Systems are highly interconnected; for example, temperature affects crop growth, which affects food supply, which impacts colonist mood. The game is driven by an AI storyteller or event director that introduces random events (raids, diseases, drop pods) to test the player's preparations and force adaptation.

**Aesthetics:**
Visually, Colony Sims often employ a top-down or isometric perspective with grid-based layouts to emphasize spatial management and clarity of information. The audio design typically features ambient environmental sounds that reflect the current biome and weather, punctuated by alert sounds for critical events. The overall aesthetic leans towards functional and informative, prioritizing readability of complex systems over graphical fidelity.

**Story:**
Narrative in Colony Sims is almost entirely emergent. Rather than a authored linear plot, the story is generated through the interactions of the game's systems. A colonist going berserk because they ate without a table and subsequently destroying a vital power generator during a raid is a unique, memorable story created by the mechanics rather than a writer.

**Technology:**
These games require robust pathfinding algorithms (like A*) capable of handling dynamic environments where walls and obstacles are constantly built or destroyed. They also demand complex AI state machines or utility AI for the colonists to evaluate their needs and prioritize tasks. Performance optimization is critical, as the simulation must track thousands of items, temperature gradients, and entity states simultaneously.

## 3. Atom Recipe Table

| atom_id | atom_name | role_in_archetype | weight | typical_config |
| :--- | :--- | :--- | :--- | :--- |
| `colonist_ai` | Colonist AI | Drives the autonomous behavior, needs, and task execution of individual agents. | core | `autonomy: high`, `needs_system: complex` |
| `resource_gathering` | Resource Gathering | The foundational loop of acquiring materials needed for survival and expansion. | core | `automation: medium` |
| `crafting_recipe` | Crafting Recipe | Converts raw resources into usable items, structures, and advanced materials. | core | `complexity: high` |
| `base_building` | Base Building | Allows players to construct shelters, defenses, and production facilities. | core | `grid_based: true` |
| `random_event` | Random Event | Injects unpredictability and challenge, driving the emergent narrative. | core | `frequency: variable`, `severity: high` |
| `procedural_gen` | Procedural Generation | Creates unique starting maps, biomes, and colonist traits for each playthrough. | important | `terrain: varied` |
| `tech_tree` | Tech Tree | Gates advanced structures and recipes, providing long-term progression goals. | important | `depth: deep` |
| `day_night_cycle` | Day/Night Cycle | Dictates colonist schedules, temperature shifts, and visibility. | important | `impacts_needs: true` |
| `biome_system` | Biome System | Defines the environmental challenges, available flora/fauna, and weather patterns. | important | `impacts_resources: true` |
| `permadeath` | Permadeath | Ensures consequences are permanent; dead colonists cannot be easily revived. | optional | `applies_to: colonists` |

## 4. Atom Coupling Matrix

1. **`colonist_ai` + `resource_gathering`**
   * **Interaction:** Colonists autonomously evaluate their environment and task priorities to gather resources, but their efficiency is dictated by their current needs and mood.
   * **Emergent Dynamic:** Resource bottlenecks occur not just from scarcity, but from logistical failures or colonist mental breakdowns, requiring players to manage morale to maintain production.
   * **Aesthetic:** Creates a sense of empathy and frustration, emphasizing that the player manages *people*, not just machines.

2. **`random_event` + `base_building`**
   * **Interaction:** Events like pirate raids, toxic fallout, or fires directly test the spatial layout, material strength, and defensive structures of the base.
   * **Emergent Dynamic:** Players are forced into a cycle of constant redesign and fortification, adapting their architecture to counter specific threats they have encountered.
   * **Aesthetic:** Fosters a feeling of survival and resilience, where the base becomes a physical manifestation of the colony's history and scars.

3. **`colonist_ai` + `random_event`**
   * **Interaction:** Colonists react emotionally and physically to random events (e.g., mourning a death from a raid, suffering heatstroke during a heatwave).
   * **Emergent Dynamic:** Cascading failures. A minor negative event can lower a colonist's mood, causing them to start a fight, which injures another colonist, leading to a lack of medical care and eventual colony collapse.
   * **Aesthetic:** Generates intense dramatic tension and the core emergent storytelling the genre is known for.

4. **`crafting_recipe` + `tech_tree`**
   * **Interaction:** Unlocking new nodes on the tech tree provides access to more complex crafting recipes, which in turn require new, rarer resources.
   * **Emergent Dynamic:** The colony's economic focus must constantly shift. Early game is about raw survival (wood/food), while late game involves complex supply chains (components/advanced medicine).
   * **Aesthetic:** Provides a satisfying sense of progression and mastery over the environment.

5. **`day_night_cycle` + `colonist_ai`**
   * **Interaction:** Colonists have circadian rhythms and require sleep, meaning the workforce is not active 24/7 unless specifically scheduled (which carries mood penalties).
   * **Emergent Dynamic:** Vulnerability periods. Raids or disasters that occur at night catch the colony off-guard, requiring emergency drafting of sleeping, groggy colonists.
   * **Aesthetic:** Adds a rhythmic pacing to the gameplay, alternating between the bustling activity of day and the tense quiet of night.

## 5. MDA Chain

**Mechanics:**
* Autonomous agents with complex physiological (hunger, rest) and psychological (mood, relationships) needs.
* Grid-based construction and spatial zoning (stockpiles, growing zones).
* Deep resource management, crafting chains, and temperature/electricity simulation.
* An AI storyteller that triggers procedural random events based on colony wealth and time.

**Dynamics:**
* **Balancing Short-term vs. Long-term:** Players must constantly weigh immediate survival needs (harvesting berries before winter) against long-term investments (researching geothermal power).
* **Managing Cascading Failures:** Players learn to build redundancies and manage risk to prevent a single mistake or bad event from spiraling into total destruction.
* **Optimizing Logistics:** Designing efficient base layouts to minimize colonist travel time and maximize production throughput.

**Aesthetics:**
* **Narrative (Emergent Storytelling):** The primary draw; players become attached to their colonists and the unique, often tragic stories that unfold.
* **Challenge:** Overcoming a hostile environment and unpredictable disasters through planning and adaptation.
* **Expression:** Designing and organizing a unique, aesthetically pleasing, and highly functional base.

## 6. Variant Spectrum

1. **Survival Colony Sim**
   * **Focus:** Extreme environmental hostility and resource scarcity.
   * **Atoms Added:** `harsh_environment`, `scarcity`, `disease_system`
   * **Atoms Removed:** `trade_network`, `diplomacy`
   * **Example:** *Frostpunk* (leans into city-builder, but shares the survival focus)

2. **City Builder Hybrid**
   * **Focus:** Larger scale populations where individual needs are abstracted into macro-metrics.
   * **Atoms Added:** `zoning_system`, `macro_economy`, `civic_policies`
   * **Atoms Removed:** `individual_inventory`, `detailed_relationships`
   * **Example:** *Banished*

3. **Automation Colony Sim**
   * **Focus:** Replacing colonist labor with machines and optimizing complex production lines.
   * **Atoms Added:** `belt_conveyor`, `logic_circuits`, `drone_logistics`
   * **Atoms Removed:** `colonist_mood`, `psychological_needs`
   * **Example:** *Factorio* (though primarily automation, it shares base-building and defense DNA)

## 7. Anti-Patterns

1. **The Death Spiral:** When negative events stack in a way that makes recovery mathematically impossible, leading to frustration rather than a satisfying tragic end. Good design provides "catch-up" mechanics or temporary reprieves.
2. **Micromanagement Hell:** When the AI is too incompetent to handle basic tasks (like eating or seeking shelter), forcing the player to manually command every action, which breaks the "overseer" fantasy.
3. **Opaque Systems:** When a colonist has a mental breakdown or a crop fails, and the game does not provide the UI tools for the player to understand *why* it happened, preventing them from learning and adapting.

## 8. Cross-Cutting Systems

* **Economy Simulation:** Trade systems with passing caravans or orbital ships, featuring dynamic pricing based on supply and demand.
* **Social Simulation:** Deep relationship webs between colonists (lovers, rivals, family members) that impact mood and behavior.
* **Event Director (AI Storyteller):** A meta-system that monitors the player's success (wealth, population) and dynamically adjusts the frequency and difficulty of challenges to maintain a dramatic arc.
