# Archetype Recipe: Dress-Up (换装类)

## 1. Archetype Identity

**Archetype ID:** `dress-up`
**English Name:** Dress-Up
**Chinese Name:** 换装类

**Definition:**
The Dress-Up archetype is a genre primarily focused on collecting, customizing, and styling characters with a vast array of clothing items, accessories, hairstyles, and makeup. Players engage in styling challenges where their outfits are evaluated based on specific aesthetic tags and attributes. The core gameplay loop revolves around resource management, item collection through gacha mechanics or crafting, and progressing through a narrative where styling serves as the primary method of conflict resolution.

**Benchmark Games:**
- *Love Nikki-Dress UP Queen* (2015)
- *Shining Nikki* (2019)
- *Time Princess* (2020)
- *Life Makeover* (2022)

## 2. Elemental Tetrad Analysis

**Mechanics:**
The core systems of the Dress-Up archetype are heavily reliant on resource management and collection. The primary mechanic is `outfit_scoring`, where players must match clothing attributes (e.g., Elegant, Cute, Sexy) to stage requirements. Progression is gated by `energy_stamina_gate`, requiring players to manage their playtime. Item acquisition is driven by `gacha_banner` for premium items and `crafting_recipe` for grindable progression.

**Aesthetics:**
Visual presentation is paramount in this archetype. High-quality 2D illustrations or advanced 3D models are essential. The aesthetic focus is on intricate details, fabric textures, and diverse fashion styles ranging from historical to futuristic. The UI is typically stylized, elegant, and designed to showcase the character prominently. Audio design features thematic, relaxing, or emotionally resonant music that complements the narrative tone.

**Story:**
Narrative plays a crucial role in contextualizing the styling challenges. The protagonist often travels through different worlds, eras, or nations, encountering various characters and cultures. Conflicts, negotiations, and battles are uniquely resolved through styling competitions. The story provides the motivation for acquiring new, region-specific clothing sets.

**Technology:**
For 2D games, technology focuses on layering systems to handle thousands of clothing combinations without clipping. For 3D games, advanced rendering techniques are required for realistic fabric simulation, hair physics, and lighting. Robust database management is critical to handle the vast inventory of items, their attributes, and player collections.

## 3. Atom Recipe Table

| Atom ID | Atom Name | Role in Archetype | Weight | Typical Config |
| :--- | :--- | :--- | :--- | :--- |
| `outfit_scoring` | Outfit Scoring | Evaluates player styling against stage requirements based on tags. | Core | `scoring_weights: dynamic`, `tag_matching: strict` |
| `gacha_banner` | Gacha Banner | Primary monetization and acquisition method for high-rarity sets. | Core | `pity_threshold: 100`, `rate_up: true` |
| `crafting_recipe` | Crafting Recipe | Allows players to grind for specific items needed for story progression. | Core | `material_cost: high`, `time_gate: true` |
| `energy_stamina_gate` | Energy/Stamina Gate | Paces player progression and drives daily logins. | Core | `regen_rate: 5_mins`, `max_cap: level_based` |
| `collection_log` | Collection Log | Tracks acquired items and rewards set completion. | Important | `completion_reward: premium_currency` |
| `daily_weekly_reset` | Daily/Weekly Reset | Structures recurring tasks to maintain player retention. | Important | `reset_time: 05:00` |
| `currency_dual` | Dual Currency | Separates grindable soft currency from premium hard currency. | Important | `conversion_rate: fixed` |
| `branching_dialogue` | Branching Dialogue | Adds depth to the narrative and allows player agency in story events. | Optional | `impact: minor_rewards` |
| `room_decoration` | Room Decoration | Provides an alternative creative outlet and resource sink. | Optional | `grid_system: free_placement` |
| `guild_clan` | Guild/Clan | Introduces social cooperation and exclusive guild-based rewards. | Optional | `member_cap: 50` |

## 4. Atom Coupling Matrix

1. **`outfit_scoring` + `gacha_banner`**
   - **Interaction:** Difficult stages require specific high-scoring tags that are predominantly found on items featured in the current gacha banner.
   - **Emergent Dynamic:** Creates a strong monetization drive where players feel compelled to pull for new items to overcome progression roadblocks.
   - **Aesthetic:** Exclusivity and prestige, as players showcase rare items that signify both luck and investment.

2. **`crafting_recipe` + `energy_stamina_gate`**
   - **Interaction:** Crafting requires materials that drop from specific stages, but farming these stages consumes stamina, which is strictly capped.
   - **Emergent Dynamic:** Forces players to plan their resource allocation over several days, creating a long-term pacing mechanism.
   - **Aesthetic:** Delayed gratification and routine, as players experience the satisfaction of finally completing a complex crafting project.

3. **`collection_log` + `gacha_banner`**
   - **Interaction:** The collection log visually highlights missing pieces of a set, incentivizing players to continue pulling on the gacha to complete it.
   - **Emergent Dynamic:** Drives completionist behavior, often leading players to spend more than intended to acquire the final missing item.
   - **Aesthetic:** Achievement and completeness, appealing to the human desire to fill empty slots and collect full sets.

4. **`outfit_scoring` + `collection_log`**
   - **Interaction:** A larger collection provides a wider variety of tags and attributes, making it easier to achieve high scores in diverse styling challenges.
   - **Emergent Dynamic:** Encourages broad collection rather than just focusing on a few strong items, rewarding long-term play.
   - **Aesthetic:** Expression and versatility, allowing players to be creative while still meeting mechanical requirements.

5. **`energy_stamina_gate` + `daily_weekly_reset`**
   - **Interaction:** Stamina regenerates daily, and daily tasks require spending stamina to earn consistent rewards.
   - **Emergent Dynamic:** Creates a habituation loop where players log in at specific times to ensure stamina doesn't overcap and tasks are completed.
   - **Aesthetic:** Submission to the game's schedule, integrating the game into the player's daily life routine.

## 5. MDA Chain

**Mechanics:**
The foundation is built on `outfit_scoring`, `gacha_banner`, `crafting_recipe`, and `energy_stamina_gate`. Players use stamina to clear stages, gather materials, and craft items. They use premium currency on gacha banners to acquire rare items. These items are then used to pass increasingly difficult styling challenges based on specific attribute tags.

**Dynamics:**
These mechanics create dynamics of meticulous resource management, daily habituation, and strategic styling optimization. Players must balance their stamina usage between progressing the story and farming materials. The gacha system introduces elements of chance and risk assessment. The styling challenges require players to optimize their outfits mathematically while often trying to maintain visual coherence.

**Aesthetics:**
- **Expression:** The core appeal is the ability to express oneself through fashion and styling.
- **Submission:** The stamina and daily reset systems create a comforting, predictable daily routine.
- **Narrative:** Engaging with the story and characters provides context and emotional investment.
- **Fellowship:** Sharing outfits, competing in arenas, and joining guilds foster a sense of community.

## 6. Variant Spectrum

1. **Narrative-Heavy Dress-Up**
   - **Focus:** Deep, branching storylines with multiple endings based on styling choices and dialogue.
   - **Atoms Added:** `branching_dialogue`, `multiple_endings`, `affinity_meter`.
   - **Atoms Removed:** `pvp_arena`, `guild_clan`.

2. **Competitive Dress-Up**
   - **Focus:** Player-versus-player styling battles and seasonal rankings.
   - **Atoms Added:** `pvp_arena`, `season_rank`, `meta_progression`.
   - **Atoms Removed:** `branching_dialogue`, `multiple_endings`.

3. **Simulation Dress-Up**
   - **Focus:** A broader lifestyle simulation including home decoration and virtual pet management.
   - **Atoms Added:** `room_decoration`, `fishing_minigame`, `resource_gathering`.
   - **Atoms Removed:** `energy_stamina_gate` (often relaxed), `strict outfit_scoring`.

## 7. Anti-Patterns

1. **Pay-to-Win Story Gating:** Making main story progression mathematically impossible without acquiring specific, high-rarity items from the premium gacha, leading to severe player frustration and churn.
2. **Cluttered and Overwhelming UI:** Introducing too many concurrent events, currencies, and sub-systems, resulting in a main screen that is confusing and visually unappealing, detracting from the core aesthetic focus.
3. **Meaningless or Conflicting Tags:** Implementing a tagging system that is overly complex or inconsistent, where items that visually fit a theme do not possess the corresponding tags, breaking the immersion and making scoring feel arbitrary.

## 8. Cross-Cutting Systems

- **Economy & Monetization:** Free-to-play model with dual currencies, battle passes, and aggressive gacha monetization for premium cosmetic sets.
- **Social & Multiplayer:** Asynchronous PvP styling arenas, friend systems for stamina exchange, and guild systems for collective goals.
- **Live Operations:** Frequent limited-time events, seasonal banners, and continuous story updates to maintain engagement.
