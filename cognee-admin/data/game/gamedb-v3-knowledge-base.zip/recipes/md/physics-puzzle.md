# Archetype Recipe: Physics Puzzle (物理解谜类)

## 1. Archetype Identity
- **ID:** physics-puzzle
- **Name (EN):** Physics Puzzle
- **Name (CN):** 物理解谜类
- **Definition:** A game genre where the core gameplay revolves around solving puzzles by utilizing simulated physics mechanics, such as gravity, momentum, friction, and collision. Players manipulate objects or the environment to achieve a specific goal, often relying on trial and error and emergent physical interactions.
- **Benchmark Games:**
  - *Angry Birds* (2009)
  - *Cut the Rope* (2010)
  - *World of Goo* (2008)
  - *Portal* (2007)

## 2. Elemental Tetrad Analysis
- **Mechanics:** The core loop involves observing a physics-based scenario, planning a sequence of actions (e.g., launching a projectile, cutting a rope, placing an object), executing the plan, and observing the simulated physical outcome. Systems heavily rely on rigid body dynamics, fluid dynamics, or soft body physics.
- **Aesthetics:** Visuals often feature clear, readable environments where interactive elements are distinctly highlighted. Audio provides immediate, satisfying feedback for physical interactions (e.g., collisions, bouncing, breaking).
- **Story:** Narrative is usually secondary, often serving as a lighthearted context for the puzzles (e.g., birds retrieving eggs from pigs). Some games, like *Portal*, integrate deep narrative elements into the puzzle-solving environment.
- **Technology:** Requires a robust physics engine (e.g., Box2D, Havok, PhysX) capable of handling consistent and predictable simulations. Performance optimization is crucial when dealing with many interacting physical bodies.

## 3. Atom Recipe Table

| Atom ID | Atom Name | Role in Archetype | Weight | Typical Config |
| :--- | :--- | :--- | :--- | :--- |
| physics_puzzle | Physics Puzzle | The core foundation of the gameplay, defining the primary interaction method. | Core | `gravity: 9.8`, `friction: standard` |
| projectile | Projectile | Often used as the primary player input mechanism to interact with the physics world. | Important | `trajectory_preview: true` |
| timing_window | Timing Window | Required for puzzles that involve moving parts or dynamic environments. | Optional | `tolerance: high` |
| collection_log | Collection Log | Used to track optional collectibles (e.g., stars) within levels. | Optional | `max_per_level: 3` |
| node_map | Node Map | Provides a structured progression through increasingly difficult puzzles. | Important | `unlock_condition: previous_cleared` |

## 4. Atom Coupling Matrix
1. **physics_puzzle + projectile:**
   - *Dynamic:* Players launch objects into a physics simulation to cause chain reactions.
   - *Aesthetic:* Satisfaction of destruction and emergent chaos (e.g., *Angry Birds*).
2. **physics_puzzle + timing_window:**
   - *Dynamic:* Players must execute actions at precise moments to interact with moving physical elements.
   - *Aesthetic:* Tension and relief upon successful execution (e.g., *Cut the Rope*).
3. **physics_puzzle + spatial_portal:**
   - *Dynamic:* Objects maintain momentum through spatial displacements, creating complex trajectory puzzles.
   - *Aesthetic:* Mind-bending spatial reasoning and "aha!" moments (e.g., *Portal*).
4. **projectile + collection_log:**
   - *Dynamic:* Players must optimize their projectile trajectories not just to clear the level, but to intersect with optional collectibles.
   - *Aesthetic:* Mastery and completionist satisfaction.
5. **physics_puzzle + logic_deduction:**
   - *Dynamic:* Players must deduce the correct sequence of physical interactions to achieve the goal.
   - *Aesthetic:* Intellectual triumph and problem-solving satisfaction.

## 5. MDA Chain
- **Mechanics:** Physics simulation (gravity, collision), object manipulation, trajectory aiming, level reset.
- **Dynamics:** Trial and error experimentation, chain reaction observation, trajectory optimization, timing-based execution.
- **Aesthetics:** Challenge (solving the puzzle), Discovery (understanding the physics interactions), Sensation (satisfying audio-visual feedback of physical collisions).

## 6. Variant Spectrum
- **Destruction Physics:** Focuses on breaking structures (e.g., *Angry Birds*). Added: `projectile`, `structural_integrity`. Removed: `precision_platforming`.
- **Construction Physics:** Focuses on building stable structures to achieve a goal (e.g., *World of Goo*, *Bridge Constructor*). Added: `resource_management`, `structural_stress`. Removed: `projectile`.
- **Fluid/Sand Physics:** Focuses on manipulating particles or fluids (e.g., *Where's My Water?*). Added: `fluid_dynamics`, `terrain_deformation`. Removed: `rigid_body_collision`.

## 7. Anti-Patterns
1. **Unpredictable Physics:** If the physics simulation is inconsistent or buggy, players cannot reliably plan their actions, leading to frustration rather than challenge.
2. **Hidden Information:** Puzzles that rely on off-screen elements or unclear physical properties (e.g., an object looks heavy but acts light) break the player's ability to deduce the solution.
3. **Overly Strict Execution:** Requiring pixel-perfect aiming or frame-perfect timing in a genre primarily focused on logic and planning can alienate the core audience.

## 8. Cross-Cutting Systems
- **Monetization:** Often utilizes a Free-to-Play (F2P) model with ads, energy systems (`energy_stamina_gate`), or paid hints/power-ups.
- **Social:** Leaderboards for high scores or fastest completion times, level sharing (user-generated content).
- **Progression:** Star rating systems based on efficiency or score, unlocking new level packs or cosmetic items.
