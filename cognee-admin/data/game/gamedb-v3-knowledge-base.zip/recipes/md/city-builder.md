# Archetype Recipe: City Builder

## 1. Archetype Identity
**ID:** city-builder
**Name (EN):** City Builder
**Name (CN):** 城市建造类

**Definition:** 
The City Builder archetype is a simulation and strategy genre where the primary gameplay loop revolves around planning, constructing, and managing a functional urban environment. Players act as an omnipotent mayor or planner, balancing resources, infrastructure, zoning, and citizen needs to foster growth and prevent systemic collapse. The genre emphasizes macro-level management, spatial optimization, and emergent complexity arising from the interactions of various simulated systems such as traffic, economy, and public services.

**Benchmark Games:**
- *SimCity* (1989)
- *Cities: Skylines* (2015)
- *Anno 1800* (2019)
- *Frostpunk* (2018)
- *Tropico 6* (2019)

## 2. Elemental Tetrad Analysis

### Mechanics
The core loops of a City Builder involve zoning areas for development, constructing infrastructure (roads, power, water), and managing the economy through taxation and trade. Systems are highly interconnected; for example, industrial zones require workers (residential zones) and goods transportation (roads), but generate pollution that negatively impacts residential happiness. The gameplay is driven by balancing these competing needs, optimizing spatial layouts, and responding to dynamic challenges like resource shortages or natural disasters.

### Aesthetics
Visually, City Builders often employ a "god game" perspective, typically an isometric or top-down 3D view, allowing players to oversee their creation. The aesthetic pattern heavily relies on visual feedback: bustling streets, glowing nightscapes, and visible pollution or decay serve as immediate indicators of the city's health. Audio design features ambient city noises, dynamic soundtracks that scale with city size, and distinct sound effects for construction and UI interactions.

### Story
Narrative in traditional City Builders is largely emergent, created by the player's decisions and the resulting successes or failures of their city. However, modern iterations often incorporate structured narrative patterns, such as scenario-based campaigns with specific goals (e.g., surviving a harsh winter in *Frostpunk* or managing political factions in *Tropico*). The overarching story is usually one of progress, survival, or utopian/dystopian development.

### Technology
City Builders require robust simulation engines capable of handling thousands of interacting agents (citizens, vehicles) and complex systemic calculations (fluid dynamics for water, pathfinding for traffic, economic models) in real-time. Technical requirements include efficient level-of-detail (LOD) rendering for massive scale, multithreading for simulation logic, and highly optimized data structures to manage the state of every building and entity.

## 3. Atom Recipe Table

| Atom ID | Atom Name | Role in Archetype | Weight | Typical Config |
| :--- | :--- | :--- | :--- | :--- |
| zoning_system | Zoning System | Defines areas for residential, commercial, and industrial development. | Core | `density_levels: 3`, `auto_build: true` |
| resource_gathering | Resource Gathering | Collecting raw materials (money, power, water) to fuel expansion. | Core | `passive_generation: true`, `storage_limits: true` |
| node_map | Node Map | Represents the underlying grid or network for infrastructure placement. | Core | `grid_type: "freeform_or_square"`, `snap_to_grid: true` |
| colonist_ai | Colonist AI | Simulates citizen behavior, needs, and pathfinding. | Core | `agent_based: true`, `needs_hierarchy: ["housing", "work", "services"]` |
| belt_conveyor | Belt Conveyor | (Adapted as Traffic/Transit) Manages the flow of goods and people. | Important | `capacity_limit: true`, `congestion_penalty: high` |
| tower_placement | Tower Placement | (Adapted as Service Buildings) Placing police, fire, and health services with specific radii. | Important | `area_of_effect: true`, `overlap_bonus: false` |
| tech_tree | Tech Tree | Unlocking new buildings, policies, and upgrades as the city grows. | Important | `unlock_condition: "population_milestones"` |
| random_affix | Random Affix | (Adapted as Events/Disasters) Unpredictable challenges like fires or earthquakes. | Optional | `frequency: "low"`, `severity: "variable"` |
| day_night_cycle | Day/Night Cycle | Affects traffic patterns, power consumption, and visual aesthetics. | Optional | `impacts_gameplay: true`, `cycle_duration: "10_minutes"` |
| procedural_gen | Procedural Generation | Generating initial terrain, resources, and map features. | Optional | `seed_based: true`, `biome_variety: high` |

## 4. Atom Coupling Matrix

1. **zoning_system + colonist_ai**
   - **Dynamic:** Citizens (colonist_ai) automatically populate and develop zones (zoning_system) based on desirability and needs.
   - **Aesthetic:** Creates the illusion of a living, breathing city that grows organically in response to player planning.

2. **belt_conveyor (Traffic) + tower_placement (Services)**
   - **Dynamic:** Service vehicles (fire trucks, ambulances) must navigate the traffic network to reach emergencies. Congestion delays response times.
   - **Aesthetic:** Induces tension and requires strategic spatial planning to ensure critical services are accessible.

3. **resource_gathering + tech_tree**
   - **Dynamic:** Accumulating specific resources or reaching population milestones unlocks advanced technologies and buildings.
   - **Aesthetic:** Provides a sense of progression, accomplishment, and evolving complexity as the city modernizes.

4. **colonist_ai + random_affix (Disasters)**
   - **Dynamic:** Disasters disrupt citizen routines, destroy homes, and drastically alter needs (e.g., sudden demand for healthcare).
   - **Aesthetic:** Shifts the emotional tone from calm management to frantic crisis response and recovery.

5. **zoning_system + day_night_cycle**
   - **Dynamic:** Commercial zones see high activity during the day, while residential zones consume more power at night.
   - **Aesthetic:** Enhances realism and visual variety, making the city feel dynamic and time-bound.

## 5. MDA Chain

**Mechanics:**
The player places zones, builds roads, manages budgets, and monitors data overlays (pollution, land value, traffic). The system simulates citizen agents, economic transactions, and resource flows based on these inputs.

**Dynamics:**
These mechanics create a dynamic of continuous optimization and balancing. Expanding the city increases revenue but also strains existing infrastructure, leading to traffic jams or power outages. The player must constantly diagnose bottlenecks using data overlays and implement spatial or policy solutions, creating a feedback loop of growth, crisis, and resolution.

**Aesthetics:**
The resulting aesthetics are primarily **Expression** (designing a unique city layout), **Challenge** (solving complex logistical and economic puzzles), and **Discovery** (understanding the deep systemic interactions). The overarching emotional experience is one of satisfaction and pride in watching a complex, self-sustaining system thrive under the player's guidance.

## 6. Variant Spectrum

1. **Survival City Builder (e.g., *Frostpunk*)**
   - **Added:** `energy_stamina_gate` (Harsh weather survival), `morality_system` (Tough ethical choices).
   - **Removed:** `sandbox_mode`, `unlimited_resources`.
2. **Historical/Production Chain Builder (e.g., *Anno 1800*)**
   - **Added:** `crafting_recipe` (Complex multi-tier production chains), `trade_routes`.
   - **Removed:** `modern_traffic_simulation`.
3. **Colony Sim (e.g., *RimWorld*)**
   - **Added:** `affinity_meter` (Interpersonal relationships), `permadeath` (Individual colonist importance).
   - **Removed:** `macro_zoning` (Focus is on micro-management of individuals).
4. **Transport Tycoon (e.g., *Transport Fever*)**
   - **Added:** `advanced_routing`, `vehicle_fleet_management`.
   - **Removed:** `zoning_system` (Cities grow automatically based on transport connections).

## 7. Anti-Patterns

1. **The "Death Spiral":** When a minor failure (e.g., a slight power shortage) cascades uncontrollably into total city collapse (abandonment, bankruptcy) without giving the player clear feedback or time to recover.
2. **Traffic Deadlocks:** Poorly implemented pathfinding or intersection logic that causes permanent, unresolvable traffic jams, breaking the entire simulation regardless of player road design.
3. **Waiting for Money:** Pacing issues where the player has optimized their current setup but must simply wait on fast-forward for hours to accumulate enough currency to afford the next meaningful expansion.

## 8. Cross-Cutting Systems

- **Economy/Monetization:** Often features premium DLCs adding new biomes, architectural styles, or specific gameplay systems (e.g., transit expansions, industries).
- **Social/Multiplayer:** Typically single-player, but may include asynchronous multiplayer features like visiting friends' cities, trading resources in a global market, or competing on leaderboards for city value/population. Modding support (Steam Workshop) is a crucial community system.
