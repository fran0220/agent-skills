# Archetype Recipe: Hack & Slash (hack-slash)

## 1. Archetype Identity
- **ID:** hack-slash
- **Name (EN):** Hack & Slash
- **Name (CN):** 破破烂烂类
- **Definition:** The Hack & Slash archetype is characterized by fast-paced, real-time melee combat against large numbers of enemies or challenging bosses. It emphasizes player skill, reflexes, and the mastery of complex combo systems to defeat foes efficiently and stylishly. The core loop revolves around engaging in combat, earning rewards or experience, and upgrading abilities to tackle even greater challenges.
- **Benchmark Games:**
  - *Dynasty Warriors* (1997)
  - *Devil May Cry* (2001)
  - *God of War* (2005)
  - *Bayonetta* (2009)
  - *Hyrule Warriors* (2014)

## 2. Elemental Tetrad Analysis
- **Mechanics:** The core loops consist of engaging in combat encounters, utilizing a variety of light and heavy attacks to form combos, dodging or parrying enemy attacks, and managing resources like health and special meters. Progression systems often involve acquiring new moves, upgrading weapons, and increasing stats.
- **Aesthetics:** Visually, these games often feature flashy, over-the-top animations, particle effects, and dynamic camera angles to emphasize the impact and style of combat. The audio is typically energetic, with heavy sound effects for hits and an adrenaline-pumping soundtrack.
- **Story:** Narratives frequently follow a powerful protagonist on a quest for vengeance, saving the world, or overcoming seemingly insurmountable odds. The story serves to contextualize the combat and provide motivation for the player's progression.
- **Technology:** Requires robust collision detection, fluid animation blending, responsive input handling, and the ability to render multiple enemies on screen simultaneously without significant performance drops.

## 3. Atom Recipe Table

| Atom ID | Atom Name | Role in Archetype | Weight | Typical Config |
| :--- | :--- | :--- | :--- | :--- |
| `melee_combo` | Melee Combo | Core offensive mechanism for dealing damage and controlling crowds. | Core | `combo_window: 0.5s` |
| `dodge_roll` | Dodge Roll | Primary defensive tool for avoiding damage and repositioning. | Core | `iframes: 0.2s` |
| `combo_counter` | Combo Counter | Tracks consecutive hits, rewarding sustained aggression. | Core | `max_combo: 9999` |
| `style_meter` | Style Meter | Evaluates combat performance, encouraging varied and skillful play. | Important | `decay_rate: 1.0/s` |
| `parry_riposte` | Parry & Riposte | High-risk defensive option that opens enemies to counterattacks. | Important | `window: 0.15s` |
| `xp_level` | XP & Leveling | Provides meta-progression and a sense of growing power. | Important | `curve: exponential` |
| `skill_tree` | Skill Tree | Allows players to customize their moveset and playstyle. | Important | `nodes: 50` |
| `stamina_combat` | Stamina Combat | Limits continuous actions, adding tactical depth to encounters. | Optional | `regen_rate: 10/s` |

## 4. Atom Coupling Matrix

1. **`melee_combo` + `combo_counter`**
   - **Interaction:** Landing hits in a melee combo increases the combo counter.
   - **Emergent Dynamic:** Encourages continuous aggression and punishes dropping combos.
   - **Aesthetic:** Creates a sense of flow and mastery as the player sustains long, uninterrupted chains of attacks.

2. **`dodge_roll` + `melee_combo`**
   - **Interaction:** Dodge rolling can cancel melee combo recovery frames.
   - **Emergent Dynamic:** Allows for fluid repositioning while maintaining offensive pressure.
   - **Aesthetic:** Enhances the feeling of agility and responsiveness, making combat feel fast and dynamic.

3. **`style_meter` + `melee_combo`**
   - **Interaction:** Using varied melee combos increases the style meter faster.
   - **Emergent Dynamic:** Incentivizes players to learn and use the full moveset rather than spamming one attack.
   - **Aesthetic:** Promotes expressive and creative gameplay, rewarding players for looking cool while fighting.

4. **`parry_riposte` + `style_meter`**
   - **Interaction:** Successful parries grant a massive boost to the style meter.
   - **Emergent Dynamic:** Rewards high-risk, high-reward defensive play with aesthetic and mechanical bonuses.
   - **Aesthetic:** Delivers a satisfying moment of triumph and mastery when perfectly timing a defense.

5. **`combo_counter` + `xp_level`**
   - **Interaction:** Higher combo counters multiply the XP gained from defeated enemies.
   - **Emergent Dynamic:** Creates a feedback loop where skilled play directly accelerates meta-progression.
   - **Aesthetic:** Reinforces the value of skillful execution by tying it directly to character growth.

## 5. MDA Chain
- **Mechanics:** Players utilize `melee_combo`, `dodge_roll`, and `parry_riposte` to defeat enemies. Performance is tracked via `combo_counter` and `style_meter`. Defeating enemies yields XP for `xp_level` and unlocks nodes in the `skill_tree`.
- **Dynamics:** The mechanics create a dynamic of continuous offensive pressure, where players must balance aggression with timely defense. The style meter and combo counter push players to experiment with different attacks and maintain a state of flow.
- **Aesthetics:** The resulting experience is one of intense challenge, thrilling sensation, and deep personal expression through combat mastery. Players feel a sense of fantasy fulfillment as a powerful warrior overcoming hordes of foes.

## 6. Variant Spectrum
- **Musou / Horde Slayer:** Focuses on defeating massive numbers of weak enemies. Adds `wave_system` and `node_map`. Removes `stamina_combat` and `parry_riposte` to streamline combat.
- **Character Action:** Emphasizes deep, complex combat systems and high skill ceilings. Adds `style_meter` and `parry_riposte`. Often removes or minimizes `xp_level` and `loot_rarity` to focus purely on player skill.
- **Looter Slasher:** Combines hack & slash combat with action RPG loot systems. Adds `loot_rarity` and `random_affix`. May remove `style_meter` to focus more on build optimization than combat expression.

## 7. Anti-Patterns
1. **Spongy Enemies:** Enemies with too much health that don't react to hits, making combat feel tedious and unrewarding.
2. **Unresponsive Controls:** Input delay or overly long animation locks that prevent players from reacting to enemy attacks, leading to frustration.
3. **Lack of Enemy Variety:** Fighting the same types of enemies repeatedly without new challenges or required tactics, causing the gameplay loop to become stale.

## 8. Cross-Cutting Systems
- **Economy / Monetization:** Often features `economy_f2p` models in mobile variants, with gacha systems for characters or weapons.
- **Social:** May include `social_multiplayer` features like co-op missions or leaderboards for high scores and fast clear times.
- **Progression:** Heavily relies on `achievement_system` to reward players for completing challenges, finding secrets, or mastering specific combat techniques.
