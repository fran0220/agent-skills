# Archetype Recipe: Walking Simulator

## 1. Archetype Identity
**ID:** walking-sim
**Name (EN):** Walking Simulator
**Name (CN):** 步行模拟类

**Definition:**
A Walking Simulator is a narrative-driven exploration game where the primary interaction is moving through an environment and examining objects. These games typically eschew traditional fail states, combat, and complex puzzles in favor of atmospheric storytelling, environmental narrative, and emotional resonance. The player's role is often that of an observer or investigator piecing together a story that has already happened or is unfolding around them.

**Benchmark Games:**
- *Dear Esther* (2012)
- *Gone Home* (2013)
- *The Stanley Parable* (2013)
- *Firewatch* (2016)
- *What Remains of Edith Finch* (2017)

## 2. Elemental Tetrad Analysis
**Mechanics:**
The core loops and systems are intentionally minimalist. The primary mechanics involve basic traversal (walking, sometimes running or jumping) and interaction with objects (picking up, rotating, reading text, listening to audio logs). The progression is usually gated by finding specific items or reaching specific locations rather than skill-based challenges.

**Aesthetics:**
Visual and audio style patterns are crucial, as they carry the weight of the experience. High-fidelity environments, meticulous set dressing, and evocative lighting are common. Sound design is paramount, featuring ambient soundscapes, high-quality voice acting, and emotionally resonant musical scores that dynamically shift based on location or narrative beats.

**Story:**
Narrative structure patterns often rely heavily on environmental storytelling and non-linear discovery. The story is frequently delivered through diegetic elements like letters, diaries, audio recordings, and the arrangement of objects in the world. The narrative arc is usually deeply personal, focusing on themes of memory, loss, identity, or philosophical inquiry.

**Technology:**
Typical technical requirements include robust physics engines for object manipulation, advanced lighting and rendering systems to create atmospheric environments, and sophisticated audio engines for spatial sound and dynamic music mixing. Streaming technology is often used to allow seamless exploration without loading screens.

## 3. Atom Recipe Table

| atom_id | atom_name | role_in_archetype | weight | typical_config |
| :--- | :--- | :--- | :--- | :--- |
| sprint_stamina | Sprint/Stamina | Allows limited faster traversal to prevent tedium while maintaining pacing. | optional | stamina_drain: low, recovery: fast |
| logic_deduction | Logic Deduction | Players piece together the narrative from environmental clues. | core | difficulty: low, guidance: high |
| branching_dialogue | Branching Dialogue | Provides player agency in narrative progression and character relationships. | optional | impact: narrative_only |
| multiple_endings | Multiple Endings | Rewards different interpretations or choices made during exploration. | optional | requirement: hidden_collectibles |
| interconnected_map | Interconnected Map | Encourages exploration and backtracking to discover new narrative layers. | important | fast_travel: disabled |
| day_night_cycle | Day/Night Cycle | Alters the atmosphere and can be used to signify the passage of time or narrative progression. | optional | duration: narrative_tied |
| room_decoration | Room Decoration | Environmental storytelling through the meticulous placement of objects. | core | interactivity: high |
| collection_log | Collection Log | Tracks discovered narrative fragments (letters, audio logs) for the player to review. | important | completion_reward: lore |

## 4. Atom Coupling Matrix

1. **room_decoration + logic_deduction**
   - **Interaction:** Players observe the arrangement of objects in a room to deduce past events or character traits.
   - **Emergent Dynamic:** Environmental investigation, where the space itself becomes a puzzle to be solved through observation.
   - **Aesthetic:** Discovery and immersion, making the player feel like a detective uncovering a hidden truth.

2. **interconnected_map + collection_log**
   - **Interaction:** Exploring different areas of the map yields narrative fragments that are stored in the collection log.
   - **Emergent Dynamic:** Scavenger hunt for lore, encouraging thorough exploration of every nook and cranny.
   - **Aesthetic:** Completionism and narrative satisfaction, rewarding the player's curiosity with a more complete understanding of the story.

3. **branching_dialogue + multiple_endings**
   - **Interaction:** Choices made in dialogue trees accumulate to determine the final outcome of the story.
   - **Emergent Dynamic:** Consequence tracking, where players weigh their words carefully to achieve a desired result.
   - **Aesthetic:** Agency and emotional investment, making the player feel responsible for the narrative's resolution.

4. **day_night_cycle + interconnected_map**
   - **Interaction:** The passage of time alters the accessibility or appearance of different areas on the map.
   - **Emergent Dynamic:** Temporal exploration, requiring players to revisit locations at different times to uncover new secrets.
   - **Aesthetic:** Atmosphere and progression, using lighting and environmental changes to reflect the narrative's mood.

5. **sprint_stamina + interconnected_map**
   - **Interaction:** Limited sprinting capability affects how players navigate the large, interconnected environment.
   - **Emergent Dynamic:** Pacing control, preventing players from rushing through the experience while still offering a way to traverse empty spaces quickly.
   - **Aesthetic:** Groundedness and realism, emphasizing the physical presence of the character in the world.

## 5. MDA Chain

**Mechanics:**
- First-person movement (walking, looking).
- Object interaction (picking up, inspecting, reading).
- Trigger volumes that activate voiceovers or environmental changes.
- Inventory or journal systems for tracking narrative progress.

**Dynamics:**
- **Pacing:** The slow movement speed forces the player to take in the environment, setting a deliberate, contemplative pace.
- **Exploration:** Players are intrinsically motivated to explore every corner to find the next piece of the narrative puzzle.
- **Piece-Meal Storytelling:** The narrative is constructed in the player's mind as they connect disparate pieces of information found in the world.

**Aesthetics:**
- **Narrative:** The primary aesthetic is the unfolding drama or mystery.
- **Discovery:** The joy of finding hidden details and understanding their significance.
- **Atmosphere/Immersion:** A deep sense of presence in a meticulously crafted, often melancholic or mysterious world.

## 6. Variant Spectrum

1. **The Mystery Investigator**
   - **Atoms Added:** logic_deduction, evidence_contradiction
   - **Atoms Removed:** branching_dialogue
   - **Description:** Focuses heavily on solving a specific mystery (e.g., *Return of the Obra Dinn*, though it borders on puzzle game).

2. **The Relational Drama**
   - **Atoms Added:** branching_dialogue, affinity_meter
   - **Atoms Removed:** interconnected_map (often more linear)
   - **Description:** Centers on conversations and relationships between characters (e.g., *Firewatch*).

3. **The Surreal/Philosophical Journey**
   - **Atoms Added:** spatial_portal, physics_puzzle (light)
   - **Atoms Removed:** collection_log
   - **Description:** Uses impossible geometry or surreal environments to explore abstract concepts (e.g., *The Stanley Parable*, *Superliminal*).

4. **The Horror Explorer**
   - **Atoms Added:** stealth_takedown (or just stealth), vision_cone
   - **Atoms Removed:** day_night_cycle (usually perpetually dark)
   - **Description:** Adds elements of dread and evasion without full combat mechanics (e.g., *Amnesia: The Dark Descent*, *Outlast*).

## 7. Anti-Patterns

1. **The Empty Museum:** Creating a beautiful environment with too few interactive elements or narrative payoffs, leading to boredom and a feeling of pointlessness.
2. **The Pixel Hunt:** Making crucial narrative triggers or objects too small or hidden, frustrating the player and breaking the pacing.
3. **The Disconnected Audio Tour:** Relying entirely on audio logs that have no relation to the environment they are found in, failing to utilize environmental storytelling.

## 8. Cross-Cutting Systems

- **Economy/Monetization:** Typically premium (pay-to-play) single-player experiences. Microtransactions are extremely rare and generally frowned upon in this genre.
- **Social:** Single-player focus. Social features are usually limited to out-of-game discussions, sharing screenshots, or community theorizing about ambiguous endings.
- **Progression:** Narrative progression replaces mechanical progression. Achievements/Trophies are often tied to finding all collectibles or experiencing different narrative branches.
