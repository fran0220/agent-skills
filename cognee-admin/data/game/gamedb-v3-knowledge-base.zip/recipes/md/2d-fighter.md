# Archetype Recipe: 2D Fighter

## 1. Archetype Identity

**ID:** `2d-fighter`
**English Name:** 2D Fighter
**Chinese Name:** 2D格斗类

**Definition:**
The 2D Fighter is a highly competitive, 1-on-1 combat archetype where players control characters on a two-dimensional plane, focusing on spacing, timing, and execution. The core gameplay loop revolves around depleting the opponent's health bar through a combination of strikes, throws, and special moves, often requiring precise inputs and deep knowledge of frame data. Success in this genre demands rapid decision-making, pattern recognition, and the physical dexterity to execute complex combos under pressure.

**Benchmark Games:**
- *Street Fighter 6* (2023)
- *Guilty Gear Strive* (2021)
- *Mortal Kombat 1* (2023)
- *Tekken 8* (2024) - Note: While technically 3D, it shares many 2D fighter fundamentals.
- *Dragon Ball FighterZ* (2018)

## 2. Elemental Tetrad Analysis

**Mechanics:**
The core systems are built around hitboxes (attacking areas) and hurtboxes (vulnerable areas). Players engage in "footsies" to control space, using normal attacks, special moves, and throws. The game state is heavily dictated by frame data—startup, active, and recovery frames—which determines advantage or disadvantage after an interaction. Resource management (super meters, burst gauges) adds strategic depth to offensive and defensive options.

**Aesthetics:**
Visually, 2D fighters rely on highly readable character silhouettes and exaggerated animations to communicate attack properties (high, low, overhead) instantly. Hitsparks, screen shake, and dynamic camera angles during super moves emphasize impact. Audio design is crucial, with distinct sound cues for hits, blocks, and character-specific voice lines aiding reaction times.

**Story:**
Narrative structures typically follow a tournament or global conflict framework, providing a reason for a diverse cast of characters to fight each other. Story modes often feature branching paths or a cinematic campaign that interweaves individual character arcs, though the narrative is generally secondary to the competitive gameplay.

**Technology:**
Technical requirements are extremely stringent. The genre demands a locked 60 frames per second (FPS) to ensure consistent frame data and input timing. Online play necessitates robust rollback netcode to minimize latency and provide a seamless competitive experience across different network conditions.

## 3. Atom Recipe Table

| atom_id | atom_name | role_in_archetype | weight | typical_config |
| :--- | :--- | :--- | :--- | :--- |
| `melee_combo` | Melee Combo | Core offensive sequence for maximizing damage | core | `cancel_windows: true`, `hit_stun: variable` |
| `timing_window` | Timing Window | Dictates execution strictness for links and cancels | core | `frame_data_strictness: high` |
| `combo_counter` | Combo Counter | Tracks consecutive hits and applies damage scaling | core | `damage_scaling: true` |
| `pvp_arena` | PvP Arena | The enclosed stage where combat occurs | core | `rollback_netcode: true` |
| `iframes` | Invincibility Frames | Provides defensive options on wakeup or through specific moves | important | `startup_invincibility: true` |
| `projectile` | Projectile | Tools for zoning and controlling space from a distance | important | `clash_system: true` |
| `parry_riposte` | Parry/Riposte | High-risk, high-reward defensive mechanic | important | `perfect_parry_window: 2-3 frames` |
| `energy_stamina_gate` | Energy/Stamina Gate | Super meter for EX moves and ultimate attacks | important | `super_meter: true`, `ex_moves: true` |
| `double_jump` | Double Jump | Enhances aerial mobility and mixup potential | optional | `air_dash_cancel: true` |
| `air_dash` | Air Dash | Enables rapid approach and high/low mixups | optional | `instant_air_dash: true` |

## 4. Atom Coupling Matrix

1. **`melee_combo` + `timing_window`**
   - **Interaction:** Linking normal attacks or canceling into special moves requires inputs within specific, often tight, frame windows.
   - **Emergent Dynamic:** Creates a high execution barrier where players must practice extensively to optimize their damage output.
   - **Aesthetic:** Produces a sense of mastery and spectacle when complex sequences are executed flawlessly in a match.

2. **`projectile` + `iframes`**
   - **Interaction:** Invincible moves (like a Shoryuken) can bypass the hitboxes of projectiles.
   - **Emergent Dynamic:** Generates a mind game where the zoner tries to bait the invincible reversal, while the attacker tries to anticipate the projectile.
   - **Aesthetic:** Tension and anticipation, culminating in a satisfying read or a punishing mistake.

3. **`energy_stamina_gate` + `parry_riposte`**
   - **Interaction:** Successfully parrying an attack might build super meter, or executing a parry might cost meter.
   - **Emergent Dynamic:** Ties resource management directly to defensive risk/reward, forcing players to decide when to spend resources for safety or save them for damage.
   - **Aesthetic:** Strategic depth and calculated risk-taking.

4. **`melee_combo` + `combo_counter`**
   - **Interaction:** As the combo counter increases, subsequent hits deal less damage (damage scaling).
   - **Emergent Dynamic:** Prevents "touch-of-death" scenarios and forces players to choose between ending a combo early for better positioning (okizeme) or spending resources for maximum damage.
   - **Aesthetic:** Balance and fairness, ensuring matches aren't decided by a single mistake.

5. **`air_dash` + `melee_combo`**
   - **Interaction:** Air dashes allow characters to quickly close the distance and initiate overhead attacks that lead into full combos.
   - **Emergent Dynamic:** Fosters a fast-paced, aggressive neutral game with hard-to-react high/low mixups.
   - **Aesthetic:** Frenetic, high-octane action typical of "anime" or "air-dasher" subgenres.

## 5. MDA Chain

**Mechanics:**
- Hitboxes, hurtboxes, and collision detection.
- Frame data governing startup, active, and recovery phases of animations.
- Health bars, round timers, and super meters.
- Directional inputs combined with button presses (e.g., quarter-circle forward).

**Dynamics:**
- **Spacing (Footsies):** Maneuvering to keep the opponent in range of your attacks while staying out of theirs.
- **Okizeme:** Applying pressure to an opponent as they are getting up from a knockdown.
- **Mixups:** Forcing the opponent to guess between high/low or strike/throw options.
- **Resource Management:** Deciding when to use meter for enhanced moves, defensive bursts, or super arts.

**Aesthetics:**
- **Competition:** The pure, unadulterated thrill of outsmarting and out-executing another human player.
- **Expression:** Developing a unique playstyle through character choice and combo optimization.
- **Challenge:** Overcoming the steep learning curve and mastering complex inputs.
- **Spectacle:** Enjoying the flashy animations, dramatic camera angles, and impactful sound design of high-level play.

## 6. Variant Spectrum

1. **Anime/Air Dasher (e.g., *Guilty Gear*, *BlazBlue*)**
   - **Atoms Added:** `air_dash`, `double_jump`, `burst_mechanic`
   - **Atoms Removed:** Focus on grounded footsies.
   - **Description:** Emphasizes extreme mobility, long aerial combos, and aggressive mixups.

2. **Platform Fighter (e.g., *Super Smash Bros.*, *Brawlhalla*)**
   - **Atoms Added:** `ring_out`, `percentage_damage`, `variable_jump`
   - **Atoms Removed:** Traditional health bars, strict command inputs.
   - **Description:** Focuses on knocking opponents off a stage rather than depleting health, with simplified inputs and high mobility.

3. **Tag Fighter (e.g., *Marvel vs. Capcom*, *Dragon Ball FighterZ*)**
   - **Atoms Added:** `assist_call`, `active_switch`, `delayed_hyper_combo`
   - **Atoms Removed:** Single-round focus.
   - **Description:** Players control teams of characters, using assists to extend combos or cover unsafe approaches, leading to chaotic, high-damage matches.

## 7. Anti-Patterns

1. **Infinite Combos:** Designing moves that can loop indefinitely without damage scaling or a way to break out, removing player agency and ruining the competitive integrity.
2. **Unreactable Unblockables:** Creating setups where a player is forced into a situation where they cannot block or avoid damage, leading to frustration and a feeling of unfairness.
3. **Poor Netcode:** Relying on delay-based netcode instead of rollback, resulting in sluggish inputs, visual stuttering, and an unplayable online experience.

## 8. Cross-Cutting Systems

- **Monetization:** `season_pass` (for new characters and stages), `cosmetic_microtransactions` (costumes, colors, titles).
- **Social/Progression:** `ranked_matchmaking` (Elo/MMR systems), `lobby_system` (virtual arcades for casual play), `replay_sharing` (for learning and community engagement).
