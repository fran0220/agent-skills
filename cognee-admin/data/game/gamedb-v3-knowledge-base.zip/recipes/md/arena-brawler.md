# Arena Brawler (竞技场乱斗) Archetype Recipe

## 1. Archetype Identity
**ID:** arena-brawler
**Names:** Arena Brawler, 竞技场乱斗
**Definition:** The Arena Brawler is a multiplayer action game subgenre focused on fast-paced, highly mobile combat within confined, often dynamic stages. Unlike traditional fighting games that emphasize complex inputs and health bars, arena brawlers typically prioritize spatial awareness, platforming mechanics, and ring-outs or percentage-based knockback systems. Players utilize a combination of light attacks, heavy attacks, and special abilities to build up damage on opponents, making them more susceptible to being launched off the stage.

**Benchmark Games:**
- Super Smash Bros. Melee (2001)
- Brawlhalla (2014)
- MultiVersus (2022)
- Rivals of Aether (2015)

## 2. Elemental Tetrad Analysis
- **Mechanics:** The core loop revolves around movement, attacking, and recovering. Players navigate platforms, execute attacks to increase opponent damage percentages, and attempt to launch them past the blast zones. Key systems include double jumping, dodging, shielding, and character-specific recovery moves.
- **Aesthetics:** Visually, these games often feature vibrant, distinct character designs to ensure readability amidst chaotic action. Audio cues are critical for hit confirms, ultimate abilities, and off-screen warnings. The overall aesthetic is usually energetic and competitive.
- **Story:** Narrative is typically secondary, often serving merely as a framing device to bring disparate characters together (e.g., a crossover tournament). The true "story" emerges from the player interactions and rivalries formed during matches.
- **Technology:** Requires robust rollback netcode for smooth online multiplayer, precise collision detection, and responsive input handling to accommodate high actions-per-minute (APM) gameplay.

## 3. Atom Recipe Table
| Atom ID | Atom Name | Role in Archetype | Weight | Typical Config |
|---------|-----------|-------------------|--------|----------------|
| `double_jump` | Double Jump | Essential for aerial mobility and recovering back to the stage. | Core | `max_jumps: 2` |
| `dodge_roll` | Dodge Roll | Primary defensive mechanic for avoiding attacks and repositioning. | Core | `invincibility_frames: 10` |
| `melee_combo` | Melee Combo | Core offensive mechanic for building damage percentage. | Core | `combo_window: 0.5s` |
| `iframes` | Invincibility Frames | Used during dodges and specific recovery moves to bypass damage. | Core | `duration: 0.2s` |
| `projectile` | Projectile | Used for zoning, edge-guarding, and controlling space. | Important | `speed: variable` |
| `parry_riposte` | Parry/Riposte | High-risk, high-reward defensive option (e.g., perfect shielding). | Important | `timing_window: 3 frames` |
| `ability_cooldown` | Ability Cooldown | Limits the spamming of powerful special moves. | Important | `cooldown_time: 5s` |
| `shrinking_zone` | Shrinking Zone | Sometimes used in variants or sudden death modes to force engagement. | Optional | `shrink_rate: slow` |
| `combo_counter` | Combo Counter | Provides visual feedback for consecutive hits, enhancing satisfaction. | Optional | `display: true` |

## 4. Atom Coupling Matrix
1. **`melee_combo` + `double_jump`**: Creates the dynamic of "aerial juggling," where players string attacks together in the air. This produces an aesthetic of high-skill expression and flashy gameplay.
2. **`dodge_roll` + `iframes`**: Generates the "bait and punish" dynamic. Players use invincibility to phase through attacks and counter, leading to tense, psychological mind games.
3. **`projectile` + `double_jump`**: Results in "zoning and approach" dynamics. One player controls space with projectiles while the other uses aerial mobility to navigate the obstacle course, creating a cat-and-mouse aesthetic.
4. **`parry_riposte` + `melee_combo`**: Creates "combo breaking" moments. A successful parry interrupts an opponent's momentum, shifting the advantage and producing a dramatic, hype-inducing aesthetic.
5. **`ability_cooldown` + `dodge_roll`**: Leads to "resource management" dynamics. Players must track opponent cooldowns to know when it's safe to engage or when they must focus on evasion, adding a layer of tactical depth.

## 5. MDA Chain
- **Mechanics:** Percentage-based damage, directional knockback, blast zones, double jumps, directional influence (DI), and diverse character movesets.
- **Dynamics:** Edge-guarding (preventing opponents from returning to the stage), juggling (keeping opponents in the air), spacing (maintaining optimal distance), and reading opponent habits.
- **Aesthetics:** Fellowship (in team modes or casual free-for-alls), Challenge (mastering complex mechanics and matchups), Expression (developing a unique playstyle with a chosen character), and Competition (striving for victory in a high-stakes environment).

## 6. Variant Spectrum
- **Platform Fighter (Core):** The standard Smash Bros. formula. Focuses on platforming and ring-outs.
- **3D Arena Brawler:** Games like Power Stone. Adds a Z-axis, focusing more on environmental interaction and item usage. (Added: `spatial_portal`, `physics_puzzle`; Removed: `double_jump` emphasis).
- **Health-Based Brawler:** Games like PlayStation All-Stars Battle Royale (partially). Uses traditional health bars or specific kill conditions instead of percentage knockback. (Added: `stamina_combat`; Removed: percentage knockback).
- **Battle Royale Brawler:** Games like Rumbleverse. Combines brawler combat with a massive map and shrinking zones. (Added: `shrinking_zone`, `loot_rarity`; Removed: small confined stages).

## 7. Anti-Patterns
- **Infinite Combos:** Designing moves that can be looped indefinitely without the opponent having any defensive options (like DI or combo breakers), leading to frustration and lack of interactivity.
- **Unreactable Options:** Creating attacks with startup frames so fast that human reaction time cannot counter them, reducing the game to guessing rather than skill.
- **Poor Readability:** Cluttered visual effects or character models that blend into the background, making it impossible for players to track the action in a fast-paced environment.

## 8. Cross-Cutting Systems
- **Economy/Monetization:** Free-to-play models with cosmetic microtransactions (skins, taunts, ring-out effects) and battle passes (`battle_pass`, `currency_dual`).
- **Social:** Robust matchmaking, ranked ladders (`season_rank`), clan/guild systems (`guild_clan`), and spectator modes for tournaments.
- **Progression:** Character mastery levels (`xp_level`), unlocking new fighters (`meta_progression`), and daily/weekly challenges (`daily_weekly_reset`).
