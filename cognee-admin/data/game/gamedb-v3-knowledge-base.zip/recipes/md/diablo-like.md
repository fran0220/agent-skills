# Diablo-like Archetype Recipe

## 1. Archetype Identity
**ID:** diablo-like
**Names:** Diablo-like (EN), ARPG刷宝类 (CN)

**Definition:** 
The Diablo-like archetype, often referred to as an Action Role-Playing Game (ARPG) or "loot-driven ARPG," is defined by its core loop of fast-paced, isometric or top-down combat against hordes of enemies, deeply intertwined with complex character progression and an extensive, randomized loot system. Players continuously slay monsters to acquire better gear, which in turn allows them to tackle more challenging content, creating a highly addictive cycle of power fantasy and optimization. The genre emphasizes build diversity, where players combine skills, passive nodes, and specific item affixes to create synergistic character builds capable of clearing screens of enemies efficiently.

**Benchmark Games:**
- *Diablo II* (2000)
- *Path of Exile* (2013)
- *Grim Dawn* (2016)
- *Last Epoch* (2024)
- *Diablo IV* (2023)

## 2. Elemental Tetrad Analysis

**Mechanics:**
The core loop revolves around combat, looting, and character progression. Players engage in real-time action combat, utilizing a combination of active skills and movement abilities to defeat large groups of enemies. The primary reward mechanism is the loot system, featuring items with randomized rarities, affixes, and unique properties. Character progression is multi-layered, involving experience points for leveling up, skill trees for unlocking and enhancing abilities, and sometimes secondary progression systems like paragon boards or devotion trees. The interplay between gear and skills forms the foundation of "build crafting," a central pillar of the archetype.

**Aesthetics:**
Visually, Diablo-likes often employ a dark, gothic, or high-fantasy art style, characterized by grim environments, visceral combat effects, and detailed character models that reflect equipped gear. The audio design is crucial, featuring impactful sound effects for hits, critical strikes, and the iconic "drop sounds" of valuable loot, which serve as powerful psychological triggers. The overall atmosphere is typically oppressive yet empowering, as the player character stands as a beacon of destruction against overwhelming odds.

**Story:**
Narrative structures in Diablo-likes usually follow a "hero's journey" against a supreme evil or apocalyptic threat. The story is often delivered through quest dialogue, environmental storytelling, and lore items, serving primarily as a backdrop and context for the action rather than the main focus. The narrative is typically linear, guiding the player through various acts or regions, culminating in epic boss encounters. Post-campaign, the story often takes a backseat to endless, repeatable endgame activities.

**Technology:**
Technically, these games require robust engines capable of handling numerous entities (enemies, projectiles, visual effects) on screen simultaneously without significant performance degradation. Advanced pathfinding and AI are necessary for enemy swarms. The underlying architecture must support complex calculations for damage, mitigation, and proc chances in real-time. Furthermore, modern Diablo-likes often require secure, server-side authoritative networking to prevent cheating in economies and leaderboards, as well as database systems to manage vast amounts of player data and item generation.

## 3. Atom Recipe Table

| Atom ID | Atom Name | Role in Archetype | Weight | Typical Config |
| :--- | :--- | :--- | :--- | :--- |
| `melee_combo` | Melee Combo | Basic attack chains for melee classes, generating resources or applying debuffs. | Important | `combo_length: 3`, `cancelable: true` |
| `dodge_roll` | Dodge Roll | Essential mobility tool for repositioning and avoiding telegraphed attacks. | Core | `iframes: 0.2s`, `cooldown: 3s` |
| `ability_cooldown` | Ability Cooldown | Manages the pacing of powerful skills, preventing spam and encouraging rotations. | Core | `base_cdr_cap: 75%` |
| `elemental_reaction` | Elemental Reaction | Adds depth to combat by allowing different damage types to interact (e.g., chill, freeze, ignite). | Important | `status_duration: 4s`, `stackable: true` |
| `xp_level` | XP Level | The primary measure of character growth, unlocking skill points and stat increases. | Core | `max_level: 100`, `curve: exponential` |
| `skill_tree` | Skill Tree | Provides branching paths for character customization and build definition. | Core | `respec_cost: gold`, `node_types: active, passive` |
| `class_job` | Class/Job | Defines the starting archetype, available skills, and thematic identity of the character. | Core | `num_classes: 5`, `gender_locked: false` |
| `loot_rarity` | Loot Rarity | The foundation of the reward system, categorizing items by power and complexity (e.g., Magic, Rare, Legendary). | Core | `tiers: Normal, Magic, Rare, Legendary, Unique` |
| `random_affix` | Random Affix | Generates the specific stats on items, driving the endless pursuit of perfect gear. | Core | `max_prefixes: 3`, `max_suffixes: 3` |
| `resource_gathering` | Resource Gathering | Collecting crafting materials from enemies or nodes to upgrade or modify gear. | Important | `auto_pickup: true` |
| `crafting_recipe` | Crafting Recipe | Allows players to deterministically improve or alter their gear, mitigating bad RNG. | Important | `success_rate: 100%`, `material_cost: scaling` |
| `procedural_gen` | Procedural Generation | Creates randomized layouts for dungeons and maps, ensuring replayability. | Core | `tile_size: large`, `seed_based: true` |
| `node_map` | Node Map | Often used for endgame systems (e.g., PoE's Atlas) to structure progression and target farming. | Important | `branching: high`, `node_types: encounter, reward` |
| `season_rank` | Season Rank | Drives player engagement through periodic resets and fresh economies (Seasons/Leagues). | Core | `duration: 3_months`, `rewards: cosmetic` |
| `daily_weekly_reset` | Daily/Weekly Reset | Structures recurring tasks or boss lockouts to pace progression. | Optional | `reset_time: 08:00 UTC` |

## 4. Atom Coupling Matrix

1. **`random_affix` + `skill_tree`**
   - **Dynamic:** Build Synergy. Players seek specific random affixes on gear (e.g., "+1 to Fire Skills," "Increased Attack Speed") that directly multiply the effectiveness of nodes chosen in their skill tree.
   - **Aesthetic:** Expression and Discovery. The player feels like a genius when they find an item that perfectly completes their planned build, resulting in a sudden, massive spike in power.

2. **`loot_rarity` + `procedural_gen`**
   - **Dynamic:** The Slot Machine Effect. Every procedurally generated room or elite pack presents a new opportunity for high-rarity loot to drop. The unpredictability of the environment mirrors the unpredictability of the rewards.
   - **Aesthetic:** Anticipation and Thrill. The constant "just one more run" feeling, driven by the hope that the next random encounter will yield a game-changing Unique item.

3. **`ability_cooldown` + `dodge_roll`**
   - **Dynamic:** Combat Rhythm. Players must manage their offensive cooldowns while keeping their defensive `dodge_roll` available for critical moments. Using a movement skill offensively might leave them vulnerable.
   - **Aesthetic:** Challenge and Mastery. Creates a dance-like flow in combat where positioning and timing are just as important as raw stats, especially in high-difficulty encounters.

4. **`xp_level` + `season_rank`**
   - **Dynamic:** The Race to the Top. The periodic reset of seasons turns the standard XP grind into a competitive race. Players optimize their leveling routes and strategies to reach the max level or highest tier first.
   - **Aesthetic:** Fellowship and Competition. Fosters a strong community event every few months, where players share strategies, form groups, and compete on leaderboards.

5. **`crafting_recipe` + `resource_gathering`**
   - **Dynamic:** Deterministic Progression. While `random_affix` provides the highs of RNG, gathering resources to use in crafting recipes provides a steady, reliable path to incrementally upgrade gear.
   - **Aesthetic:** Submission and Comfort. Gives players a sense of control over their progression, ensuring that even if they don't get lucky drops, their time spent gathering materials still results in character improvement.

## 5. MDA Chain

**Mechanics:**
The game provides a vast array of active skills, passive nodes (`skill_tree`), and items with randomized stats (`random_affix`, `loot_rarity`). Combat involves using these skills against hordes of enemies in procedurally generated environments (`procedural_gen`). Defeating enemies yields experience (`xp_level`) and more loot.

**Dynamics:**
Players engage in "theorycrafting," analyzing the mechanics to discover optimal combinations of skills and gear. In gameplay, this translates to "screen-clearing" efficiency, where players optimize their movement and damage output to farm content as quickly as possible. The dynamic is a continuous loop of: Kill -> Loot -> Upgrade -> Kill Faster.

**Aesthetics:**
The primary aesthetic is **Fantasy** (the power fantasy of becoming an unstoppable force) and **Expression** (creating a unique, personalized build). Secondary aesthetics include **Discovery** (finding new item synergies) and **Submission** (the relaxing, almost meditative state of grinding through familiar content).

## 6. Variant Spectrum

1. **The Complex Sandbox (e.g., Path of Exile)**
   - **Added:** `tech_tree` (massive passive tree), `economy_f2p` (complex player-driven trading), `meta_progression` (Atlas of Worlds).
   - **Removed:** `class_job` (strict class boundaries are blurred).
   - **Focus:** Extreme build depth, complex crafting, and a highly active trade economy.

2. **The Accessible Brawler (e.g., Diablo III)**
   - **Added:** `combo_counter` (massacre bonuses), `adaptive_difficulty` (dynamic scaling).
   - **Removed:** `skill_tree` (replaced with swappable runes), `random_affix` (simplified stat pools).
   - **Focus:** Fluid, visceral combat, easy respecs, and immediate action over deep planning.

3. **The Hybrid MMO-Lite (e.g., Diablo IV, Lost Ark)**
   - **Added:** `guild_clan`, `pvp_arena`, `world_bosses` (shared open world).
   - **Removed:** `procedural_gen` (for the overworld, kept for dungeons).
   - **Focus:** Social interaction, scheduled events, and a persistent shared world alongside traditional ARPG mechanics.

## 7. Anti-Patterns

1. **Inventory Tetris & Clutter:** Overwhelming the player with too much low-quality loot (`loot_rarity` imbalance) that requires constant inventory management, breaking the flow of combat and exploration.
2. **Illusion of Choice:** Designing a massive `skill_tree` where only a few specific paths are mathematically viable for endgame content, rendering the rest of the options useless traps for new players.
3. **Over-reliance on RNG:** Making crucial build-enabling items entirely dependent on extreme luck (`random_affix` without `crafting_recipe` mitigation), leading to frustration when players cannot progress their character despite significant time investment.

## 8. Cross-Cutting Systems

- **Economy/Monetization:** Often utilizes a Free-to-Play model with cosmetic microtransactions (stash tabs, character skins, skill effects) or a Buy-to-Play model with paid expansions and optional cosmetic battle passes (`battle_pass`). Player-to-player trading economies are common and highly influential.
- **Social Systems:** Guilds/Clans (`guild_clan`), global chat, party finding systems for group play, and competitive leaderboards for seasonal races (`season_rank`).
- **Live Service:** Regular seasonal updates (`season_rank`) that introduce new mechanics, items, and balance changes to keep the game fresh and encourage players to return and start anew.
