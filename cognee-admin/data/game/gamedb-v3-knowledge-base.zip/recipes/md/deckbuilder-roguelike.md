# Deckbuilder Roguelike Recipe

## 1. Archetype Identity
**ID:** deckbuilder-roguelike
**Name (EN):** Deckbuilder Roguelike
**Name (CN):** 卡组构建Rogue类

**Definition:**
A Deckbuilder Roguelike is a strategic game genre that merges the procedural generation and permadeath mechanics of roguelikes with the progressive deck-building mechanics of card games. Players start with a basic set of cards and must navigate through a series of procedurally generated encounters, acquiring new cards, upgrading existing ones, and removing weak cards to build a synergistic deck capable of overcoming increasingly difficult challenges. The core loop revolves around risk-reward decision-making, resource management, and adapting to the randomized elements of each run.

**Benchmark Games:**
- Slay the Spire (2017)
- Monster Train (2020)
- Inscryption (2021)

## 2. Elemental Tetrad Analysis
**Mechanics:**
The core loop consists of navigating a node-based map, engaging in turn-based card combat, and making strategic choices at reward screens (drafting cards, acquiring relics). Systems include energy/mana management, card draw mechanics, status effects, and meta-progression unlocks between runs.

**Aesthetics:**
Visually, these games often employ a 2D art style with clear UI elements to display card text, intent indicators for enemies, and distinct visual cues for status effects. Audio design focuses on satisfying card play sounds, impactful combat effects, and atmospheric music that builds tension during boss fights.

**Story:**
Narrative structures are typically run-based, with lore delivered through environmental storytelling, flavor text on cards and relics, and brief encounters with NPCs. The overarching goal is usually to reach the end of a challenging gauntlet, often with a cyclical or looping narrative justification for the repeated runs.

**Technology:**
Technical requirements emphasize robust state management for complex card interactions, procedural generation algorithms for maps and encounters, and highly responsive UI systems. AI for enemies is often deterministic or intent-based, requiring clear communication of future actions to the player.

## 3. Atom Recipe Table

| Atom ID | Atom Name | Role in Archetype | Weight | Typical Config |
| :--- | :--- | :--- | :--- | :--- |
| card_draft | Card Draft | Core mechanism for acquiring new abilities and shaping the deck's strategy after encounters. | Core | `choices: 3`, `skip_allowed: true` |
| deck_thinning | Deck Thinning | Essential for optimizing deck consistency by removing starter or weak cards. | Core | `cost_scaling: linear` |
| relic_artifact | Relic/Artifact | Provides passive bonuses that define or enhance the run's overarching strategy. | Core | `rarity_tiers: 3`, `unique_per_run: true` |
| energy_stamina_gate | Energy/Stamina Gate | Limits the number of cards played per turn, forcing tactical prioritization. | Core | `base_energy: 3`, `refresh_per_turn: true` |
| procedural_gen | Procedural Generation | Ensures each run offers a unique sequence of encounters, rewards, and map layouts. | Core | `seed_based: true` |
| permadeath | Permadeath | Resets the player's deck and progress upon failure, emphasizing the stakes of each run. | Core | `keep_meta_currency: true` |
| run_based | Run-Based | Structures the gameplay into distinct, self-contained attempts with a clear beginning and end. | Core | `average_duration: 45m` |
| node_map | Node Map | Provides a visual representation of the run's structure, allowing players to plan their path. | Core | `branching_paths: true`, `visible_nodes: 3` |
| meta_progression | Meta Progression | Unlocks new cards, relics, or classes for future runs, providing long-term goals. | Important | `unlock_type: pool_expansion` |
| random_affix | Random Affix | Adds variety to enemies or encounters, requiring players to adapt their strategies. | Important | `max_affixes: 2` |
| class_job | Class/Job | Offers distinct starting decks and unique card pools, encouraging different playstyles. | Important | `starting_classes: 3` |
| action_points | Action Points | An alternative or supplement to energy, governing specific actions or abilities. | Optional | `max_points: 5` |
| branching_dialogue | Branching Dialogue | Used in specific events to offer narrative choices with mechanical consequences. | Optional | `consequence_visible: partial` |

## 4. Atom Coupling Matrix

1. **card_draft + deck_thinning**
   - **Interaction:** Players must balance adding powerful new cards with removing weak ones to maintain a consistent deck size and draw probability.
   - **Emergent Dynamic:** The "deck bloat" dilemma, where players must decide if a good card is worth diluting their core synergy.
   - **Aesthetic:** Strategic satisfaction from crafting a lean, highly efficient deck.

2. **relic_artifact + card_draft**
   - **Interaction:** Acquiring a specific relic early can completely change the value of certain cards in the draft pool.
   - **Emergent Dynamic:** "Pivoting" a run's strategy based on a powerful relic drop, forcing players to adapt their drafting choices.
   - **Aesthetic:** The thrill of discovering a broken synergy and feeling overpowered.

3. **node_map + energy_stamina_gate (via Elite encounters)**
   - **Interaction:** Players must evaluate if their current deck and health can survive a difficult Elite node to gain a powerful relic, or if they should take a safer path.
   - **Emergent Dynamic:** Risk assessment and pathing strategy, balancing short-term survival with long-term power scaling.
   - **Aesthetic:** Tension and relief when successfully navigating a high-risk path.

4. **permadeath + meta_progression**
   - **Interaction:** Failing a run still contributes to unlocking new content, softening the blow of permadeath.
   - **Emergent Dynamic:** The "one more run" loop, driven by the desire to try newly unlocked cards or classes.
   - **Aesthetic:** A sense of continuous progression and discovery despite repeated failures.

5. **random_affix + energy_stamina_gate**
   - **Interaction:** Enemies with random affixes (e.g., adding unplayable status cards to the deck) disrupt the player's energy economy and draw consistency.
   - **Emergent Dynamic:** Forced adaptation during combat, requiring players to find ways to mitigate or play around the disruption.
   - **Aesthetic:** Frustration giving way to triumph when overcoming a particularly nasty enemy combination.

## 5. MDA Chain
**Mechanics:**
- Turn-based combat with a hand of cards drawn from a personal deck.
- Energy system limiting card plays per turn.
- Procedurally generated node map with branching paths.
- Drafting cards and acquiring relics as rewards.
- Permadeath with meta-progression unlocks.

**Dynamics:**
- **Synergy Seeking:** Players constantly evaluate new cards and relics to find combinations that multiply their effectiveness.
- **Risk Management:** Choosing between safe paths (campfires, regular enemies) and risky paths (Elites, unknown events) based on current health and deck strength.
- **Deck Optimization:** Balancing the addition of powerful cards with the removal of weak ones to ensure consistent draws.
- **Adaptation:** Adjusting strategies on the fly based on the randomized encounters and rewards offered in each run.

**Aesthetics:**
- **Challenge:** Overcoming difficult, sometimes seemingly unfair, encounters through strategic planning and execution.
- **Discovery:** Uncovering new synergies, unlocking hidden content, and learning the intricacies of different classes and enemies.
- **Expression:** Building a unique deck that reflects the player's preferred playstyle and strategic choices.
- **Submission:** Entering the "flow state" of the core loop, repeatedly attempting runs to master the game's systems.

## 6. Variant Spectrum
1. **Tactical Positioning Variant (e.g., Monster Train):** Adds spatial elements (multiple floors, unit placement) to the core card combat, increasing the importance of positioning and movement.
   - **Atoms Added:** `tower_placement`, `zoning_system`
   - **Atoms Removed:** `node_map` (often simplified)

2. **Narrative/Meta-Horror Variant (e.g., Inscryption):** Integrates escape room puzzles and deep narrative layers that break the fourth wall, shifting the focus from pure mechanics to story and atmosphere.
   - **Atoms Added:** `escape_room`, `multiple_endings`
   - **Atoms Removed:** `meta_progression` (traditional unlocks)

3. **Real-Time/Action Variant (e.g., One Step From Eden):** Replaces turn-based combat with real-time action on a grid, requiring quick reflexes alongside deckbuilding strategy.
   - **Atoms Added:** `dodge_roll`, `timing_window`
   - **Atoms Removed:** `action_points` (strict turn limits)

## 7. Anti-Patterns
1. **Diluted Card Pools:** Adding too many highly situational or weak cards to the draft pool, making it nearly impossible for players to reliably build synergistic decks, leading to frustrating, RNG-dependent runs.
2. **Lack of Deck Thinning:** Failing to provide adequate opportunities to remove starter cards, resulting in inconsistent draws and preventing players from executing their intended strategies in the late game.
3. **Snowballing Difficulty Spikes:** Designing bosses or elites that require specific, narrow solutions (e.g., a specific status effect immunity) without providing sufficient telegraphing or tools to prepare, causing abrupt and unfair run-ending moments.

## 8. Cross-Cutting Systems
- **Economy (Premium/F2P):** While traditionally premium, mobile adaptations may introduce `gacha_banner` for unlocking new classes or cosmetic skins, or `battle_pass` systems for seasonal rewards.
- **Social/Multiplayer:** Typically single-player, but some variants include asynchronous `daily_weekly_reset` leaderboards for specific seeded runs, or even synchronous `pvp_arena` modes where players draft decks to battle each other.
- **Live Ops:** Regular updates adding new cards, relics, and balance patches to keep the meta fresh and encourage replayability.
