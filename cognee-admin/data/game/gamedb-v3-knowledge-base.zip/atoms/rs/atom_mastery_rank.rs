#[derive(Debug, Clone)]
pub struct MasteryRankParams {
    pub base_xp_requirement: u32,
    pub xp_growth_factor: f32,
    pub max_rank: u32,
    pub xp_per_action: u32,
    pub prestige_multiplier: f32,
}

impl MasteryRankParams {
    /// Creates a new MasteryRankParams with default values based on Warframe benchmarks.
    pub fn new() -> Self {
        Self {
            base_xp_requirement: 1000,
            xp_growth_factor: 2.0,
            max_rank: 30,
            xp_per_action: 10,
            prestige_multiplier: 1.2,
        }
    }

    /// Calculates the total XP required to reach a specific rank.
    /// Uses a quadratic curve: base_xp * (rank ^ xp_growth_factor)
    pub fn xp_required_for_rank(&self, rank: u32) -> u32 {
        if rank == 0 {
            return 0;
        }
        if rank > self.max_rank {
            return self.xp_required_for_rank(self.max_rank);
        }
        
        let rank_f32 = rank as f32;
        let multiplier = rank_f32.powf(self.xp_growth_factor);
        (self.base_xp_requirement as f32 * multiplier) as u32
    }

    /// Calculates the number of actions required to reach a specific rank from 0 XP.
    pub fn actions_to_reach_rank(&self, rank: u32) -> u32 {
        let total_xp = self.xp_required_for_rank(rank);
        (total_xp + self.xp_per_action - 1) / self.xp_per_action // Ceiling division
    }

    /// Calculates the XP required for a rank after a certain number of prestige resets.
    pub fn xp_required_with_prestige(&self, rank: u32, prestige_level: u32) -> u32 {
        let base_req = self.xp_required_for_rank(rank);
        let prestige_mult = self.prestige_multiplier.powi(prestige_level as i32);
        (base_req as f32 * prestige_mult) as u32
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_xp_required_for_rank() {
        let params = MasteryRankParams::new();
        
        // Rank 0 requires 0 XP
        assert_eq!(params.xp_required_for_rank(0), 0);
        
        // Rank 1: 1000 * (1^2.0) = 1000
        assert_eq!(params.xp_required_for_rank(1), 1000);
        
        // Rank 2: 1000 * (2^2.0) = 4000
        assert_eq!(params.xp_required_for_rank(2), 4000);
        
        // Rank 3: 1000 * (3^2.0) = 9000
        assert_eq!(params.xp_required_for_rank(3), 9000);
        
        // Exceeding max rank should cap at max rank XP
        let max_xp = params.xp_required_for_rank(30);
        assert_eq!(params.xp_required_for_rank(31), max_xp);
    }

    #[test]
    fn test_actions_to_reach_rank() {
        let params = MasteryRankParams::new();
        
        // Rank 1 requires 1000 XP. At 10 XP per action, that's 100 actions.
        assert_eq!(params.actions_to_reach_rank(1), 100);
        
        // Rank 2 requires 4000 XP. At 10 XP per action, that's 400 actions.
        assert_eq!(params.actions_to_reach_rank(2), 400);
    }

    #[test]
    fn test_xp_required_with_prestige() {
        let params = MasteryRankParams::new();
        
        // Rank 2 base XP is 4000
        // Prestige 1: 4000 * 1.2 = 4800
        assert_eq!(params.xp_required_with_prestige(2, 1), 4800);
        
        // Prestige 2: 4000 * (1.2^2) = 4000 * 1.44 = 5760
        assert_eq!(params.xp_required_with_prestige(2, 2), 5760);
    }
}
