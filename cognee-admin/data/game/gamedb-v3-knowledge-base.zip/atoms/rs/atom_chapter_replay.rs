#[derive(Debug, Clone)]
pub struct ChapterReplayParams {
    pub max_replays: u32,
    pub checkpoint_granularity: f32,
    pub score_retention: bool,
}

impl ChapterReplayParams {
    pub fn new() -> Self {
        Self {
            max_replays: 9999,
            checkpoint_granularity: 5.0,
            score_retention: true,
        }
    }
}

#[derive(Debug, Clone, PartialEq)]
pub enum ReplayState {
    Locked,
    Unlocked,
    Replaying,
}

pub struct ChapterReplay {
    pub params: ChapterReplayParams,
    pub state: ReplayState,
    pub replay_count: u32,
}

impl ChapterReplay {
    pub fn new(params: ChapterReplayParams) -> Self {
        Self {
            params,
            state: ReplayState::Locked,
            replay_count: 0,
        }
    }

    pub fn complete_chapter(&mut self) -> Result<(), &'static str> {
        if self.state == ReplayState::Locked {
            self.state = ReplayState::Unlocked;
            Ok(())
        } else {
            Err("Chapter is already unlocked or currently replaying.")
        }
    }

    pub fn select_chapter(&mut self) -> Result<(), &'static str> {
        if self.state == ReplayState::Unlocked {
            if self.replay_count < self.params.max_replays {
                self.state = ReplayState::Replaying;
                self.replay_count += 1;
                Ok(())
            } else {
                Err("Maximum replay limit reached.")
            }
        } else {
            Err("Chapter must be unlocked to select for replay.")
        }
    }

    pub fn finish_or_abort(&mut self) -> Result<(), &'static str> {
        if self.state == ReplayState::Replaying {
            self.state = ReplayState::Unlocked;
            Ok(())
        } else {
            Err("Not currently replaying a chapter.")
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_chapter_unlock_and_replay() {
        let params = ChapterReplayParams::new();
        let mut replay_system = ChapterReplay::new(params);

        assert_eq!(replay_system.state, ReplayState::Locked);

        // Complete chapter to unlock
        assert!(replay_system.complete_chapter().is_ok());
        assert_eq!(replay_system.state, ReplayState::Unlocked);

        // Select chapter to replay
        assert!(replay_system.select_chapter().is_ok());
        assert_eq!(replay_system.state, ReplayState::Replaying);
        assert_eq!(replay_system.replay_count, 1);

        // Finish replay
        assert!(replay_system.finish_or_abort().is_ok());
        assert_eq!(replay_system.state, ReplayState::Unlocked);
    }

    #[test]
    fn test_max_replays_limit() {
        let mut params = ChapterReplayParams::new();
        params.max_replays = 1;
        let mut replay_system = ChapterReplay::new(params);

        // Unlock
        assert!(replay_system.complete_chapter().is_ok());

        // First replay
        assert!(replay_system.select_chapter().is_ok());
        assert!(replay_system.finish_or_abort().is_ok());

        // Second replay should fail
        assert!(replay_system.select_chapter().is_err());
        assert_eq!(replay_system.state, ReplayState::Unlocked);
        assert_eq!(replay_system.replay_count, 1);
    }
}
