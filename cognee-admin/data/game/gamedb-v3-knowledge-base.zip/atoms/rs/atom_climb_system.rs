#[derive(Debug, Clone, PartialEq)]
pub struct ClimbSystemParams {
    pub climb_speed_up: f32,
    pub climb_speed_down: f32,
    pub climb_speed_lateral: f32,
    pub stamina_drain_rate: f32,
    pub leap_stamina_cost: f32,
    pub leap_vertical_force: f32,
    pub attach_cooldown: f32,
}

impl ClimbSystemParams {
    /// Creates a new ClimbSystemParams with default values based on benchmark data (BotW).
    pub fn new() -> Self {
        Self {
            climb_speed_up: 2.5,
            climb_speed_down: 4.0,
            climb_speed_lateral: 2.0,
            stamina_drain_rate: 5.0,
            leap_stamina_cost: 25.0,
            leap_vertical_force: 8.0,
            attach_cooldown: 0.2,
        }
    }
}

impl Default for ClimbSystemParams {
    fn default() -> Self {
        Self::new()
    }
}

pub struct ClimbState {
    pub current_stamina: f32,
    pub is_climbing: bool,
    pub time_since_detach: f32,
}

impl ClimbState {
    pub fn new(max_stamina: f32) -> Self {
        Self {
            current_stamina: max_stamina,
            is_climbing: false,
            time_since_detach: 0.0,
        }
    }

    /// Attempts to attach to a wall. Returns true if successful.
    pub fn try_attach(&mut self, params: &ClimbSystemParams) -> bool {
        if !self.is_climbing && self.time_since_detach >= params.attach_cooldown && self.current_stamina > 0.0 {
            self.is_climbing = true;
            true
        } else {
            false
        }
    }

    /// Processes climbing movement for a given delta time.
    /// Returns the vertical distance moved.
    pub fn process_movement(&mut self, params: &ClimbSystemParams, delta_time: f32, move_input_y: f32) -> f32 {
        if !self.is_climbing {
            return 0.0;
        }

        // Drain stamina
        self.current_stamina -= params.stamina_drain_rate * delta_time;
        if self.current_stamina <= 0.0 {
            self.current_stamina = 0.0;
            self.detach();
            return 0.0;
        }

        // Calculate movement
        if move_input_y > 0.0 {
            params.climb_speed_up * move_input_y * delta_time
        } else if move_input_y < 0.0 {
            params.climb_speed_down * move_input_y * delta_time
        } else {
            0.0
        }
    }

    /// Attempts to perform a climb leap. Returns the applied vertical force if successful, or 0.0 if failed.
    pub fn try_leap(&mut self, params: &ClimbSystemParams) -> f32 {
        if !self.is_climbing {
            return 0.0;
        }

        if self.current_stamina >= params.leap_stamina_cost {
            self.current_stamina -= params.leap_stamina_cost;
            // A leap typically detaches the player momentarily or transitions to a leap state.
            // For simplicity, we just return the force applied.
            params.leap_vertical_force
        } else {
            // Not enough stamina to leap, might just detach or fail
            0.0
        }
    }

    pub fn detach(&mut self) {
        self.is_climbing = false;
        self.time_since_detach = 0.0;
    }

    pub fn update_cooldown(&mut self, delta_time: f32) {
        if !self.is_climbing {
            self.time_since_detach += delta_time;
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_climb_movement_and_stamina_drain() {
        let params = ClimbSystemParams::new();
        let mut state = ClimbState::new(100.0);
        
        // Fast forward cooldown
        state.update_cooldown(1.0);
        
        assert!(state.try_attach(&params));
        assert!(state.is_climbing);

        // Move up for 2 seconds
        let delta_time = 2.0;
        let move_input_y = 1.0;
        let distance = state.process_movement(&params, delta_time, move_input_y);

        // Expected distance: 2.5 * 1.0 * 2.0 = 5.0
        assert_eq!(distance, 5.0);
        
        // Expected stamina: 100.0 - (5.0 * 2.0) = 90.0
        assert_eq!(state.current_stamina, 90.0);
    }

    #[test]
    fn test_climb_leap_stamina_cost() {
        let params = ClimbSystemParams::new();
        let mut state = ClimbState::new(30.0);
        
        state.update_cooldown(1.0);
        state.try_attach(&params);

        let force = state.try_leap(&params);
        
        // Expected force: 8.0
        assert_eq!(force, 8.0);
        
        // Expected stamina: 30.0 - 25.0 = 5.0
        assert_eq!(state.current_stamina, 5.0);

        // Try leaping again with only 5.0 stamina (requires 25.0)
        let force2 = state.try_leap(&params);
        assert_eq!(force2, 0.0);
        assert_eq!(state.current_stamina, 5.0);
    }

    #[test]
    fn test_stamina_depletion_detaches_player() {
        let params = ClimbSystemParams::new();
        let mut state = ClimbState::new(5.0); // Only 5 stamina
        
        state.update_cooldown(1.0);
        state.try_attach(&params);

        // Move for 2 seconds, draining 10 stamina (more than we have)
        let distance = state.process_movement(&params, 2.0, 1.0);

        // Should have detached
        assert!(!state.is_climbing);
        assert_eq!(state.current_stamina, 0.0);
        assert_eq!(distance, 0.0);
    }
}
