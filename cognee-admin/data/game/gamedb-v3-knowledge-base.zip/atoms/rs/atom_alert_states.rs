#[derive(Debug, Clone, PartialEq)]
pub enum AlertState {
    Idle,
    Suspicious,
    Searching,
    Combat,
}

#[derive(Debug, Clone)]
pub struct AlertStatesParams {
    pub vision_range_idle: f32,
    pub vision_cone_angle: f32,
    pub hearing_radius: f32,
    pub suspicion_decay_rate: f32,
    pub search_duration: f32,
}

impl AlertStatesParams {
    pub fn new() -> Self {
        Self {
            vision_range_idle: 20.0,
            vision_cone_angle: 90.0,
            hearing_radius: 15.0,
            suspicion_decay_rate: 5.0,
            search_duration: 30.0,
        }
    }
}

pub struct AlertStateMachine {
    pub state: AlertState,
    pub params: AlertStatesParams,
    pub suspicion_level: f32,
    pub search_timer: f32,
}

impl AlertStateMachine {
    pub fn new(params: AlertStatesParams) -> Self {
        Self {
            state: AlertState::Idle,
            params,
            suspicion_level: 0.0,
            search_timer: 0.0,
        }
    }

    /// Updates the state machine based on sensory input and time delta.
    /// Returns true if a state transition occurred.
    pub fn update(&mut self, delta_time: f32, sees_player: bool, hears_noise: bool) -> bool {
        let old_state = self.state.clone();

        match self.state {
            AlertState::Idle => {
                if sees_player {
                    self.state = AlertState::Combat;
                } else if hears_noise {
                    self.state = AlertState::Suspicious;
                    self.suspicion_level = 50.0; // Arbitrary initial suspicion
                }
            }
            AlertState::Suspicious => {
                if sees_player {
                    self.state = AlertState::Combat;
                } else {
                    self.suspicion_level -= self.params.suspicion_decay_rate * delta_time;
                    if self.suspicion_level <= 0.0 {
                        self.suspicion_level = 0.0;
                        self.state = AlertState::Idle;
                    }
                }
            }
            AlertState::Combat => {
                if !sees_player {
                    self.state = AlertState::Searching;
                    self.search_timer = self.params.search_duration;
                }
            }
            AlertState::Searching => {
                if sees_player {
                    self.state = AlertState::Combat;
                } else {
                    self.search_timer -= delta_time;
                    if self.search_timer <= 0.0 {
                        self.search_timer = 0.0;
                        self.state = AlertState::Suspicious;
                        self.suspicion_level = 50.0;
                    }
                }
            }
        }

        old_state != self.state
    }

    /// Calculates the distance at which the player can be seen, 
    /// which might be modified by the current state.
    pub fn current_vision_range(&self) -> f32 {
        match self.state {
            AlertState::Idle => self.params.vision_range_idle,
            AlertState::Suspicious => self.params.vision_range_idle * 1.5,
            AlertState::Searching => self.params.vision_range_idle * 2.0,
            AlertState::Combat => self.params.vision_range_idle * 2.0,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_idle_to_suspicious_to_idle() {
        let params = AlertStatesParams::new();
        let mut sm = AlertStateMachine::new(params);
        
        assert_eq!(sm.state, AlertState::Idle);
        
        // Hear noise triggers suspicious
        let transitioned = sm.update(0.1, false, true);
        assert!(transitioned);
        assert_eq!(sm.state, AlertState::Suspicious);
        assert_eq!(sm.suspicion_level, 50.0);
        
        // Decay suspicion over time
        let decay_time = 50.0 / sm.params.suspicion_decay_rate;
        let transitioned = sm.update(decay_time + 0.1, false, false);
        assert!(transitioned);
        assert_eq!(sm.state, AlertState::Idle);
    }

    #[test]
    fn test_combat_to_searching_to_suspicious() {
        let params = AlertStatesParams::new();
        let mut sm = AlertStateMachine::new(params);
        
        // Force combat state
        sm.state = AlertState::Combat;
        
        // Lose sight triggers searching
        let transitioned = sm.update(0.1, false, false);
        assert!(transitioned);
        assert_eq!(sm.state, AlertState::Searching);
        assert_eq!(sm.search_timer, sm.params.search_duration);
        
        // Search timer expires triggers suspicious
        let transitioned = sm.update(sm.params.search_duration + 0.1, false, false);
        assert!(transitioned);
        assert_eq!(sm.state, AlertState::Suspicious);
    }

    #[test]
    fn test_vision_range_multiplier() {
        let params = AlertStatesParams::new();
        let mut sm = AlertStateMachine::new(params.clone());
        
        assert_eq!(sm.current_vision_range(), params.vision_range_idle);
        
        sm.state = AlertState::Searching;
        assert_eq!(sm.current_vision_range(), params.vision_range_idle * 2.0);
    }
}
