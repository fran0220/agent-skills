#[derive(Debug, Clone, PartialEq)]
pub enum FlashlightState {
    Off,
    On,
    Boosted,
}

#[derive(Debug, Clone)]
pub struct FlashlightAtom {
    pub max_battery: f32,
    pub drain_rate_normal: f32,
    pub drain_rate_boost: f32,
    pub recharge_rate: f32,
    pub cone_angle_normal: f32,
    pub cone_angle_boost: f32,
    pub intensity_normal: f32,
    pub intensity_boost: f32,
    pub range_normal: f32,
    
    pub current_battery: f32,
    pub state: FlashlightState,
}

impl FlashlightAtom {
    pub fn new() -> Self {
        Self {
            max_battery: 100.0,
            drain_rate_normal: 1.0,
            drain_rate_boost: 5.0,
            recharge_rate: 2.5,
            cone_angle_normal: 60.0,
            cone_angle_boost: 25.0,
            intensity_normal: 2.0,
            intensity_boost: 6.0,
            range_normal: 20.0,
            
            current_battery: 100.0,
            state: FlashlightState::Off,
        }
    }

    pub fn toggle(&mut self) {
        match self.state {
            FlashlightState::Off => {
                if self.current_battery > 0.0 {
                    self.state = FlashlightState::On;
                }
            }
            FlashlightState::On | FlashlightState::Boosted => {
                self.state = FlashlightState::Off;
            }
        }
    }

    pub fn set_boost(&mut self, boost: bool) {
        if self.state == FlashlightState::Off {
            return;
        }
        if boost {
            self.state = FlashlightState::Boosted;
        } else {
            self.state = FlashlightState::On;
        }
    }

    pub fn update(&mut self, delta_time: f32) {
        match self.state {
            FlashlightState::Off => {
                self.current_battery += self.recharge_rate * delta_time;
                if self.current_battery > self.max_battery {
                    self.current_battery = self.max_battery;
                }
            }
            FlashlightState::On => {
                self.current_battery -= self.drain_rate_normal * delta_time;
                if self.current_battery <= 0.0 {
                    self.current_battery = 0.0;
                    self.state = FlashlightState::Off;
                }
            }
            FlashlightState::Boosted => {
                self.current_battery -= self.drain_rate_boost * delta_time;
                if self.current_battery <= 0.0 {
                    self.current_battery = 0.0;
                    self.state = FlashlightState::Off;
                }
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_battery_drain_and_deplete() {
        let mut flashlight = FlashlightAtom::new();
        flashlight.toggle(); // Turn on
        assert_eq!(flashlight.state, FlashlightState::On);
        
        flashlight.update(10.0); // Drain for 10 seconds at 1.0/sec
        assert_eq!(flashlight.current_battery, 90.0);
        
        flashlight.update(100.0); // Drain past 0
        assert_eq!(flashlight.current_battery, 0.0);
        assert_eq!(flashlight.state, FlashlightState::Off); // Should auto turn off
    }

    #[test]
    fn test_boost_drain_and_recharge() {
        let mut flashlight = FlashlightAtom::new();
        flashlight.toggle(); // Turn on
        flashlight.set_boost(true);
        assert_eq!(flashlight.state, FlashlightState::Boosted);
        
        flashlight.update(10.0); // Drain for 10 seconds at 5.0/sec
        assert_eq!(flashlight.current_battery, 50.0);
        
        flashlight.toggle(); // Turn off
        assert_eq!(flashlight.state, FlashlightState::Off);
        
        flashlight.update(10.0); // Recharge for 10 seconds at 2.5/sec
        assert_eq!(flashlight.current_battery, 75.0);
    }
}
