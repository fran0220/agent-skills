#[derive(Debug, Clone, PartialEq)]
pub struct NoteHighwayParams {
    pub scroll_speed: f32,       // units/sec
    pub hit_window_perfect: f32, // ms
    pub hit_window_good: f32,    // ms
    pub note_density: f32,       // notes/sec
    pub highway_length: f32,     // units
}

impl NoteHighwayParams {
    /// Creates a new NoteHighwayParams with default values based on benchmark data.
    pub fn new() -> Self {
        Self {
            scroll_speed: 5.0,
            hit_window_perfect: 33.0,
            hit_window_good: 100.0,
            note_density: 8.0,
            highway_length: 20.0,
        }
    }

    /// Calculates the time it takes for a note to travel from spawn to the hit zone.
    pub fn calculate_travel_time(&self) -> f32 {
        if self.scroll_speed <= 0.0 {
            return f32::INFINITY;
        }
        self.highway_length / self.scroll_speed
    }

    /// Evaluates a hit based on the time difference (in ms) between the hit and the perfect timing.
    /// Returns a score multiplier or 0.0 for a miss.
    pub fn evaluate_hit(&self, time_diff_ms: f32) -> f32 {
        let abs_diff = time_diff_ms.abs();
        if abs_diff <= self.hit_window_perfect {
            1.0 // Perfect hit
        } else if abs_diff <= self.hit_window_good {
            0.5 // Good hit
        } else {
            0.0 // Miss
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_travel_time() {
        let params = NoteHighwayParams::new();
        // highway_length = 20.0, scroll_speed = 5.0
        // travel_time = 20.0 / 5.0 = 4.0 seconds
        assert_eq!(params.calculate_travel_time(), 4.0);
    }

    #[test]
    fn test_evaluate_hit() {
        let params = NoteHighwayParams::new();
        
        // Perfect hit (within 33.0 ms)
        assert_eq!(params.evaluate_hit(10.0), 1.0);
        assert_eq!(params.evaluate_hit(-30.0), 1.0);
        
        // Good hit (between 33.0 and 100.0 ms)
        assert_eq!(params.evaluate_hit(50.0), 0.5);
        assert_eq!(params.evaluate_hit(-99.0), 0.5);
        
        // Miss (outside 100.0 ms)
        assert_eq!(params.evaluate_hit(101.0), 0.0);
        assert_eq!(params.evaluate_hit(-150.0), 0.0);
    }
}
