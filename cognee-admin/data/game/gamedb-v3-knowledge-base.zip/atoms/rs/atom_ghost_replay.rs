#[derive(Debug, Clone)]
pub struct GhostReplayParams {
    pub record_tick_rate: u32,
    pub ghost_opacity: f32,
    pub max_record_time: f32,
}

impl GhostReplayParams {
    pub fn new() -> Self {
        Self {
            record_tick_rate: 30,
            ghost_opacity: 0.5,
            max_record_time: 300.0,
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct Transform {
    pub x: f32,
    pub y: f32,
    pub z: f32,
}

impl Transform {
    pub fn interpolate(a: &Transform, b: &Transform, t: f32) -> Transform {
        let t = t.clamp(0.0, 1.0);
        Transform {
            x: a.x + (b.x - a.x) * t,
            y: a.y + (b.y - a.y) * t,
            z: a.z + (b.z - a.z) * t,
        }
    }
}

#[derive(Debug, Clone)]
pub struct GhostReplay {
    pub params: GhostReplayParams,
    pub recorded_data: Vec<Transform>,
}

impl GhostReplay {
    pub fn new(params: GhostReplayParams) -> Self {
        Self {
            params,
            recorded_data: Vec::new(),
        }
    }

    pub fn record_frame(&mut self, current_time: f32, transform: Transform) -> bool {
        if current_time > self.params.max_record_time {
            return false;
        }
        
        let expected_frames = (current_time * self.params.record_tick_rate as f32) as usize;
        if self.recorded_data.len() <= expected_frames {
            self.recorded_data.push(transform);
            true
        } else {
            false
        }
    }

    pub fn get_ghost_transform(&self, playback_time: f32) -> Option<Transform> {
        if self.recorded_data.is_empty() {
            return None;
        }

        let exact_frame = playback_time * self.params.record_tick_rate as f32;
        let frame_idx = exact_frame.floor() as usize;
        let t = exact_frame - frame_idx as f32;

        if frame_idx >= self.recorded_data.len() - 1 {
            return Some(*self.recorded_data.last().unwrap());
        }

        let frame_a = &self.recorded_data[frame_idx];
        let frame_b = &self.recorded_data[frame_idx + 1];

        Some(Transform::interpolate(frame_a, frame_b, t))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_interpolation() {
        let a = Transform { x: 0.0, y: 0.0, z: 0.0 };
        let b = Transform { x: 10.0, y: 20.0, z: 30.0 };
        
        let mid = Transform::interpolate(&a, &b, 0.5);
        assert_eq!(mid.x, 5.0);
        assert_eq!(mid.y, 10.0);
        assert_eq!(mid.z, 15.0);
    }

    #[test]
    fn test_record_and_playback() {
        let params = GhostReplayParams::new();
        let mut replay = GhostReplay::new(params);

        // Record at 0.0s
        replay.record_frame(0.0, Transform { x: 0.0, y: 0.0, z: 0.0 });
        // Record at 1/30s (approx 0.033s)
        replay.record_frame(1.0 / 30.0, Transform { x: 30.0, y: 0.0, z: 0.0 });

        // Playback at 0.5/30s (halfway between frame 0 and 1)
        let ghost_transform = replay.get_ghost_transform(0.5 / 30.0).unwrap();
        
        // Should be interpolated halfway
        assert!((ghost_transform.x - 15.0).abs() < 0.001);
    }
    
    #[test]
    fn test_max_record_time() {
        let mut params = GhostReplayParams::new();
        params.max_record_time = 1.0; // 1 second max
        let mut replay = GhostReplay::new(params);
        
        assert!(replay.record_frame(0.5, Transform { x: 0.0, y: 0.0, z: 0.0 }));
        assert!(!replay.record_frame(1.5, Transform { x: 0.0, y: 0.0, z: 0.0 }));
    }
}
