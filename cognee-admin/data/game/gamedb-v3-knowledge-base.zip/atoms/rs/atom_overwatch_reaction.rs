#[derive(Debug, Clone, PartialEq)]
pub struct OverwatchReaction {
    pub aim_penalty_multiplier: f32,
    pub dash_penalty_multiplier: f32,
    pub trigger_radius: f32,
    pub action_point_cost: u32,
    pub max_triggers_per_turn: u32,
}

impl OverwatchReaction {
    /// Creates a new OverwatchReaction with default benchmark values (XCOM 2 v1.0)
    pub fn new() -> Self {
        Self {
            aim_penalty_multiplier: 0.7,
            dash_penalty_multiplier: 0.6,
            trigger_radius: 27.0,
            action_point_cost: 1,
            max_triggers_per_turn: 1,
        }
    }

    /// Calculates the final aim probability for an overwatch shot.
    /// 
    /// # Arguments
    /// * `base_aim` - The base aim probability of the unit (0.0 to 1.0)
    /// * `is_dashing` - Whether the target is dashing (sprinting)
    /// 
    /// # Returns
    /// The final aim probability after applying the overwatch penalty.
    pub fn calculate_overwatch_aim(&self, base_aim: f32, is_dashing: bool) -> f32 {
        let penalty = if is_dashing {
            self.dash_penalty_multiplier
        } else {
            self.aim_penalty_multiplier
        };
        
        (base_aim * penalty).clamp(0.0, 1.0)
    }

    /// Checks if an enemy movement triggers the overwatch reaction.
    /// 
    /// # Arguments
    /// * `distance_to_enemy` - The distance from the overwatching unit to the moving enemy
    /// * `triggers_used_this_turn` - The number of times this unit has already triggered overwatch this turn
    /// 
    /// # Returns
    /// `true` if the overwatch should trigger, `false` otherwise.
    pub fn check_trigger(&self, distance_to_enemy: f32, triggers_used_this_turn: u32) -> bool {
        if triggers_used_this_turn >= self.max_triggers_per_turn {
            return false;
        }
        
        distance_to_enemy <= self.trigger_radius
    }
}

impl Default for OverwatchReaction {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_overwatch_aim() {
        let overwatch = OverwatchReaction::new();
        
        // Base aim 0.8 (80%), standard movement
        let aim_standard = overwatch.calculate_overwatch_aim(0.8, false);
        assert!((aim_standard - 0.56).abs() < f32::EPSILON); // 0.8 * 0.7 = 0.56
        
        // Base aim 0.8 (80%), dashing movement
        let aim_dashing = overwatch.calculate_overwatch_aim(0.8, true);
        assert!((aim_dashing - 0.48).abs() < f32::EPSILON); // 0.8 * 0.6 = 0.48
    }

    #[test]
    fn test_check_trigger() {
        let overwatch = OverwatchReaction::new();
        
        // Enemy within radius, no triggers used yet
        assert!(overwatch.check_trigger(15.0, 0));
        
        // Enemy outside radius
        assert!(!overwatch.check_trigger(30.0, 0));
        
        // Enemy within radius, but max triggers already reached
        assert!(!overwatch.check_trigger(10.0, 1));
    }
}
