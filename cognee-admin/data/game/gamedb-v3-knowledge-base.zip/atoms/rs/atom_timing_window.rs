#[derive(Debug, Clone, PartialEq)]
pub enum TimingResult {
    Perfect,
    Good,
    Punish,
    Miss,
}

#[derive(Debug, Clone)]
pub struct TimingWindowParams {
    pub perfect_window: f32,
    pub good_window: f32,
    pub punish_window: f32,
    pub input_delay_compensation: f32,
}

impl TimingWindowParams {
    /// Creates a new TimingWindowParams with default values based on Sekiro/Dark Souls benchmarks.
    pub fn new() -> Self {
        Self {
            perfect_window: 0.033,
            good_window: 0.100,
            punish_window: 0.200,
            input_delay_compensation: 0.016,
        }
    }

    /// Evaluates an input time against a target time and returns the timing result.
    /// Both times are in seconds.
    pub fn evaluate_timing(&self, target_time: f32, input_time: f32) -> TimingResult {
        // Apply input delay compensation to the input time
        let compensated_input_time = input_time - self.input_delay_compensation;
        
        // Calculate the absolute time difference
        let time_diff = (target_time - compensated_input_time).abs();

        if time_diff <= self.perfect_window {
            TimingResult::Perfect
        } else if time_diff <= self.good_window {
            TimingResult::Good
        } else if time_diff <= self.punish_window {
            TimingResult::Punish
        } else {
            TimingResult::Miss
        }
    }

    /// Calculates a score multiplier based on the timing result.
    pub fn get_score_multiplier(&self, result: &TimingResult) -> f32 {
        match result {
            TimingResult::Perfect => 1.5,
            TimingResult::Good => 1.0,
            TimingResult::Punish => 0.5,
            TimingResult::Miss => 0.0,
        }
    }
}

impl Default for TimingWindowParams {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_perfect_timing() {
        let params = TimingWindowParams::new();
        let target_time = 1.0;
        // Input exactly at target time + compensation
        let input_time = 1.0 + params.input_delay_compensation;
        
        let result = params.evaluate_timing(target_time, input_time);
        assert_eq!(result, TimingResult::Perfect);
    }

    #[test]
    fn test_good_timing() {
        let params = TimingWindowParams::new();
        let target_time = 1.0;
        // Input slightly late, outside perfect but inside good
        let input_time = 1.0 + params.input_delay_compensation + 0.05;
        
        let result = params.evaluate_timing(target_time, input_time);
        assert_eq!(result, TimingResult::Good);
    }

    #[test]
    fn test_miss_timing() {
        let params = TimingWindowParams::new();
        let target_time = 1.0;
        // Input very late, outside punish window
        let input_time = 1.0 + params.input_delay_compensation + 0.3;
        
        let result = params.evaluate_timing(target_time, input_time);
        assert_eq!(result, TimingResult::Miss);
    }

    #[test]
    fn test_score_multiplier() {
        let params = TimingWindowParams::new();
        assert_eq!(params.get_score_multiplier(&TimingResult::Perfect), 1.5);
        assert_eq!(params.get_score_multiplier(&TimingResult::Miss), 0.0);
    }
}
