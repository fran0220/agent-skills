#[derive(Debug, Clone, PartialEq)]
pub enum MatchStatus {
    Correct,
    Present,
    Absent,
}

#[derive(Debug, Clone)]
pub struct WordPuzzleParams {
    pub word_length: u32,
    pub max_attempts: u32,
    pub time_limit: f32,
    pub dictionary_size: u32,
    pub hint_penalty: f32,
}

impl WordPuzzleParams {
    pub fn new() -> Self {
        Self {
            word_length: 5,
            max_attempts: 6,
            time_limit: 0.0,
            dictionary_size: 2315,
            hint_penalty: 0.0,
        }
    }

    /// Evaluates a guess against the target word, returning whether it's a full match
    /// and the status of each letter.
    pub fn evaluate_guess(&self, guess: &str, target: &str) -> (bool, Vec<MatchStatus>) {
        if guess.len() as u32 != self.word_length || target.len() as u32 != self.word_length {
            return (false, vec![]);
        }

        let guess_chars: Vec<char> = guess.chars().collect();
        let target_chars: Vec<char> = target.chars().collect();
        let mut statuses = vec![MatchStatus::Absent; self.word_length as usize];
        let mut target_used = vec![false; self.word_length as usize];

        // First pass: find exact matches
        for i in 0..self.word_length as usize {
            if guess_chars[i] == target_chars[i] {
                statuses[i] = MatchStatus::Correct;
                target_used[i] = true;
            }
        }

        // Second pass: find present but wrong position
        for i in 0..self.word_length as usize {
            if statuses[i] == MatchStatus::Correct {
                continue;
            }
            for j in 0..self.word_length as usize {
                if !target_used[j] && guess_chars[i] == target_chars[j] {
                    statuses[i] = MatchStatus::Present;
                    target_used[j] = true;
                    break;
                }
            }
        }

        let is_full_match = statuses.iter().all(|s| *s == MatchStatus::Correct);
        (is_full_match, statuses)
    }

    /// Calculates the final score based on attempts used and hints taken.
    pub fn calculate_score(&self, attempts_used: u32, hints_used: u32, base_score: f32) -> f32 {
        if attempts_used > self.max_attempts {
            return 0.0;
        }

        let attempt_multiplier = 1.0 - ((attempts_used as f32 - 1.0) / self.max_attempts as f32) * 0.5;
        let hint_deduction = hints_used as f32 * self.hint_penalty;
        
        let final_score = base_score * attempt_multiplier * (1.0 - hint_deduction);
        final_score.max(0.0)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_evaluate_guess() {
        let params = WordPuzzleParams::new();
        
        // Test exact match
        let (is_match, statuses) = params.evaluate_guess("apple", "apple");
        assert!(is_match);
        assert_eq!(statuses, vec![
            MatchStatus::Correct, MatchStatus::Correct, MatchStatus::Correct, 
            MatchStatus::Correct, MatchStatus::Correct
        ]);

        // Test partial match
        let (is_match, statuses) = params.evaluate_guess("pleas", "apple");
        assert!(!is_match);
        assert_eq!(statuses, vec![
            MatchStatus::Present, MatchStatus::Present, MatchStatus::Present, 
            MatchStatus::Present, MatchStatus::Absent
        ]);
        
        // Test duplicate letters
        let (is_match, statuses) = params.evaluate_guess("paper", "apple");
        assert!(!is_match);
        assert_eq!(statuses, vec![
            MatchStatus::Present, MatchStatus::Present, MatchStatus::Correct, 
            MatchStatus::Correct, MatchStatus::Absent
        ]);
    }

    #[test]
    fn test_calculate_score() {
        let mut params = WordPuzzleParams::new();
        params.hint_penalty = 0.1; // 10% penalty per hint
        
        // First attempt, no hints
        let score = params.calculate_score(1, 0, 100.0);
        assert_eq!(score, 100.0);
        
        // Last attempt, no hints
        let score = params.calculate_score(6, 0, 100.0);
        // 1.0 - (5.0 / 6.0) * 0.5 = 1.0 - 0.4166 = 0.5833
        assert!((score - 58.33333).abs() < 0.001);
        
        // First attempt, 2 hints
        let score = params.calculate_score(1, 2, 100.0);
        // 100.0 * 1.0 * (1.0 - 0.2) = 80.0
        assert_eq!(score, 80.0);
        
        // Failed attempt
        let score = params.calculate_score(7, 0, 100.0);
        assert_eq!(score, 0.0);
    }
}
