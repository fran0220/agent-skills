#[derive(Debug, Clone, PartialEq)]
pub struct LightShadowStealth {
    pub light_level: f32,
    pub detection_multiplier: f32,
    pub detection_speed: f32,
    pub shadow_threshold: f32,
}

impl LightShadowStealth {
    /// Creates a new LightShadowStealth atom with default values based on benchmark data.
    pub fn new() -> Self {
        Self {
            light_level: 0.0,
            detection_multiplier: 0.2,
            detection_speed: 2.0,
            shadow_threshold: 0.3,
        }
    }

    /// Calculates the visibility score based on the current light level and shadow threshold.
    /// Returns a value between 0.0 (completely hidden) and 1.0 (fully visible).
    pub fn calculate_visibility(&self, current_light_level: f32) -> f32 {
        if current_light_level <= self.shadow_threshold {
            // In deep shadow, visibility is heavily reduced
            current_light_level * self.detection_multiplier
        } else {
            // Above threshold, visibility scales up to 1.0
            let range = 1.0 - self.shadow_threshold;
            let excess = current_light_level - self.shadow_threshold;
            let base_visibility = self.shadow_threshold * self.detection_multiplier;
            
            // Linear interpolation from base_visibility to 1.0
            base_visibility + (1.0 - base_visibility) * (excess / range)
        }
    }

    /// Calculates the time required for an enemy to detect the player.
    /// Higher visibility results in faster detection (lower time).
    pub fn calculate_detection_time(&self, visibility: f32) -> f32 {
        // If visibility is 0, detection time is infinite (or very large)
        if visibility <= 0.0 {
            return f32::MAX;
        }
        
        // Detection time is inversely proportional to visibility
        // At 1.0 visibility, detection time is base detection_speed
        self.detection_speed / visibility
    }
}

impl Default for LightShadowStealth {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_visibility() {
        let stealth = LightShadowStealth::new();
        
        // Test in deep shadow (below threshold 0.3)
        let vis_shadow = stealth.calculate_visibility(0.15);
        assert_eq!(vis_shadow, 0.15 * 0.2); // 0.03
        
        // Test exactly at threshold
        let vis_threshold = stealth.calculate_visibility(0.3);
        assert_eq!(vis_threshold, 0.3 * 0.2); // 0.06
        
        // Test in full light
        let vis_light = stealth.calculate_visibility(1.0);
        assert_eq!(vis_light, 1.0);
    }

    #[test]
    fn test_calculate_detection_time() {
        let stealth = LightShadowStealth::new();
        
        // Test with full visibility
        let time_full = stealth.calculate_detection_time(1.0);
        assert_eq!(time_full, 2.0); // Base detection speed
        
        // Test with partial visibility
        let time_partial = stealth.calculate_detection_time(0.5);
        assert_eq!(time_partial, 4.0); // 2.0 / 0.5
        
        // Test with zero visibility
        let time_zero = stealth.calculate_detection_time(0.0);
        assert_eq!(time_zero, f32::MAX);
    }
}
