use std::collections::HashMap;

#[derive(Debug, Clone)]
pub struct DiscussionVoteParams {
    pub discussion_time: u32,
    pub voting_time: u32,
    pub anonymous_votes: bool,
    pub emergency_meetings: u32,
    pub votes_required_to_eject: f32,
}

impl DiscussionVoteParams {
    /// Creates a new DiscussionVoteParams with default values based on Among Us benchmark.
    pub fn new() -> Self {
        Self {
            discussion_time: 45,
            voting_time: 60,
            anonymous_votes: false,
            emergency_meetings: 1,
            votes_required_to_eject: 0.5,
        }
    }
}

pub struct VotingSystem {
    params: DiscussionVoteParams,
    votes: HashMap<String, String>, // voter_id -> target_id (or "skip")
    total_players: u32,
}

impl VotingSystem {
    pub fn new(params: DiscussionVoteParams, total_players: u32) -> Self {
        Self {
            params,
            votes: HashMap::new(),
            total_players,
        }
    }

    /// Casts a vote from a player to a target.
    pub fn cast_vote(&mut self, voter_id: String, target_id: String) -> Result<(), &'static str> {
        if self.votes.contains_key(&voter_id) {
            return Err("Player has already voted");
        }
        self.votes.insert(voter_id, target_id);
        Ok(())
    }

    /// Tallies the votes and determines the outcome.
    /// Returns the ID of the ejected player, or None if no one is ejected (e.g., tie or skip).
    pub fn tally_votes(&self) -> Option<String> {
        if self.votes.is_empty() {
            return None;
        }

        let mut vote_counts: HashMap<String, u32> = HashMap::new();
        for target in self.votes.values() {
            *vote_counts.entry(target.clone()).or_insert(0) += 1;
        }

        let mut max_votes = 0;
        let mut max_target = None;
        let mut is_tie = false;

        for (target, count) in &vote_counts {
            if *count > max_votes {
                max_votes = *count;
                max_target = Some(target.clone());
                is_tie = false;
            } else if *count == max_votes {
                is_tie = true;
            }
        }

        if is_tie {
            return None;
        }

        let required_votes = (self.total_players as f32 * self.params.votes_required_to_eject).ceil() as u32;

        if max_votes >= required_votes {
            if let Some(target) = max_target {
                if target == "skip" {
                    return None;
                }
                return Some(target);
            }
        }

        None
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_successful_ejection() {
        let params = DiscussionVoteParams::new();
        let mut system = VotingSystem::new(params, 5); // 5 players, needs 3 votes to eject (5 * 0.5 = 2.5 -> 3)

        assert!(system.cast_vote("p1".to_string(), "p3".to_string()).is_ok());
        assert!(system.cast_vote("p2".to_string(), "p3".to_string()).is_ok());
        assert!(system.cast_vote("p4".to_string(), "p3".to_string()).is_ok());
        assert!(system.cast_vote("p5".to_string(), "skip".to_string()).is_ok());

        let result = system.tally_votes();
        assert_eq!(result, Some("p3".to_string()));
    }

    #[test]
    fn test_tie_no_ejection() {
        let params = DiscussionVoteParams::new();
        let mut system = VotingSystem::new(params, 4); // 4 players, needs 2 votes to eject

        assert!(system.cast_vote("p1".to_string(), "p2".to_string()).is_ok());
        assert!(system.cast_vote("p3".to_string(), "p2".to_string()).is_ok());
        assert!(system.cast_vote("p2".to_string(), "p4".to_string()).is_ok());
        assert!(system.cast_vote("p4".to_string(), "p4".to_string()).is_ok());

        let result = system.tally_votes();
        assert_eq!(result, None); // Tie between p2 and p4
    }

    #[test]
    fn test_skip_wins() {
        let params = DiscussionVoteParams::new();
        let mut system = VotingSystem::new(params, 3); // 3 players, needs 2 votes

        assert!(system.cast_vote("p1".to_string(), "skip".to_string()).is_ok());
        assert!(system.cast_vote("p2".to_string(), "skip".to_string()).is_ok());
        assert!(system.cast_vote("p3".to_string(), "p1".to_string()).is_ok());

        let result = system.tally_votes();
        assert_eq!(result, None); // Skip wins, so no one is ejected
    }
}
