#[derive(Debug, Clone)]
pub struct WorkPriorityParams {
    pub priority_levels: u32,
    pub evaluation_interval: f32,
    pub distance_weight: f32,
    pub skill_weight: f32,
    pub task_timeout: f32,
}

impl WorkPriorityParams {
    /// Creates a new `WorkPriorityParams` with default values based on RimWorld benchmark.
    pub fn new() -> Self {
        Self {
            priority_levels: 4,
            evaluation_interval: 0.5,
            distance_weight: 1.0,
            skill_weight: 0.0,
            task_timeout: 60.0,
        }
    }

    /// Calculates the final score of a task for a specific agent.
    /// A lower score means higher priority (e.g., priority 1 is better than priority 4).
    /// Distance and skill can modify the effective priority.
    pub fn calculate_task_score(
        &self,
        base_priority: u32,
        distance: f32,
        skill_level: f32,
    ) -> f32 {
        // If priority is 0 or greater than allowed levels, it's considered invalid/disabled.
        // We return a very high score to represent "do not do this".
        if base_priority == 0 || base_priority > self.priority_levels {
            return f32::MAX;
        }

        // Base score is primarily driven by the priority level.
        // We multiply by a large factor so that priority level dominates distance.
        let priority_score = (base_priority as f32) * 1000.0;

        // Distance adds to the score (further away = higher score = worse).
        let distance_penalty = distance * self.distance_weight;

        // Skill reduces the score (higher skill = lower score = better).
        let skill_bonus = skill_level * self.skill_weight * 100.0;

        priority_score + distance_penalty - skill_bonus
    }

    /// Determines if a task evaluation should occur based on time elapsed.
    pub fn should_evaluate(&self, time_since_last_eval: f32) -> bool {
        time_since_last_eval >= self.evaluation_interval
    }
}

impl Default for WorkPriorityParams {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_task_score_priority_dominance() {
        let params = WorkPriorityParams::new();
        
        // Task 1: Priority 1, far away
        let score1 = params.calculate_task_score(1, 100.0, 0.0);
        
        // Task 2: Priority 2, very close
        let score2 = params.calculate_task_score(2, 1.0, 0.0);
        
        // Priority 1 should still have a lower (better) score than Priority 2
        // despite being further away, because distance_weight is 1.0 and priority multiplier is 1000.0.
        assert!(score1 < score2, "Priority 1 score {} should be less than Priority 2 score {}", score1, score2);
    }

    #[test]
    fn test_calculate_task_score_invalid_priority() {
        let params = WorkPriorityParams::new();
        
        // Priority 0 is disabled
        let score_disabled = params.calculate_task_score(0, 10.0, 0.0);
        assert_eq!(score_disabled, f32::MAX);
        
        // Priority > priority_levels is invalid
        let score_invalid = params.calculate_task_score(5, 10.0, 0.0);
        assert_eq!(score_invalid, f32::MAX);
    }

    #[test]
    fn test_should_evaluate() {
        let params = WorkPriorityParams::new();
        
        assert!(!params.should_evaluate(0.1));
        assert!(params.should_evaluate(0.5));
        assert!(params.should_evaluate(1.0));
    }
}
