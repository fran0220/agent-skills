#[derive(Debug, Clone, PartialEq)]
pub struct JuggleLaunchParams {
    pub launch_velocity_y: f32,
    pub gravity_scale: f32,
    pub hitstun_duration: f32,
    pub juggle_decay: f32,
    pub max_juggle_hits: u32,
}

impl JuggleLaunchParams {
    /// Creates a new JuggleLaunchParams with default benchmark values.
    pub fn new() -> Self {
        Self {
            launch_velocity_y: 15.0,
            gravity_scale: 1.2,
            hitstun_duration: 0.8,
            juggle_decay: 0.1,
            max_juggle_hits: 10,
        }
    }

    /// Calculates the effective launch velocity based on the defender's weight multiplier.
    /// A heavier defender (weight > 1.0) will be launched lower.
    pub fn calculate_launch_velocity(&self, defender_weight: f32) -> f32 {
        if defender_weight <= 0.0 {
            return self.launch_velocity_y;
        }
        self.launch_velocity_y / defender_weight
    }

    /// Calculates the effective gravity scale for a juggle hit.
    /// Gravity increases with each consecutive hit based on juggle_decay.
    pub fn calculate_juggle_gravity(&self, current_hits: u32) -> f32 {
        self.gravity_scale + (self.juggle_decay * current_hits as f32)
    }

    /// Checks if a juggle hit is still valid based on the maximum allowed hits.
    pub fn is_juggle_valid(&self, current_hits: u32) -> bool {
        current_hits < self.max_juggle_hits
    }
}

impl Default for JuggleLaunchParams {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_launch_velocity() {
        let params = JuggleLaunchParams::new();
        
        // Standard weight
        assert_eq!(params.calculate_launch_velocity(1.0), 15.0);
        
        // Heavy weight
        assert_eq!(params.calculate_launch_velocity(1.5), 10.0);
        
        // Light weight
        assert_eq!(params.calculate_launch_velocity(0.5), 30.0);
    }

    #[test]
    fn test_calculate_juggle_gravity() {
        let params = JuggleLaunchParams::new();
        
        // First hit (0 previous hits)
        assert_eq!(params.calculate_juggle_gravity(0), 1.2);
        
        // 5th hit
        assert_eq!(params.calculate_juggle_gravity(5), 1.7);
        
        // 10th hit
        assert_eq!(params.calculate_juggle_gravity(10), 2.2);
    }

    #[test]
    fn test_is_juggle_valid() {
        let params = JuggleLaunchParams::new();
        
        assert!(params.is_juggle_valid(0));
        assert!(params.is_juggle_valid(9));
        assert!(!params.is_juggle_valid(10));
        assert!(!params.is_juggle_valid(15));
    }
}
