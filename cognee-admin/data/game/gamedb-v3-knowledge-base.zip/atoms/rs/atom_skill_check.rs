#[derive(Debug, Clone, Copy)]
pub struct SkillCheckParams {
    pub difficulty_class: u32,
    pub skill_modifier: i32,
    pub critical_success_threshold: u32,
    pub critical_failure_threshold: u32,
    pub advantage: bool,
    pub disadvantage: bool,
}

impl SkillCheckParams {
    /// Creates a new SkillCheckParams with default values based on Baldur's Gate 3 benchmarks.
    pub fn new() -> Self {
        Self {
            difficulty_class: 15,
            skill_modifier: 3,
            critical_success_threshold: 20,
            critical_failure_threshold: 1,
            advantage: false,
            disadvantage: false,
        }
    }
}

#[derive(Debug, PartialEq, Eq)]
pub enum CheckResult {
    CriticalSuccess,
    Success,
    Failure,
    CriticalFailure,
}

/// Evaluates a skill check given a base roll and parameters.
/// 
/// # Arguments
/// * `base_roll` - The raw number rolled on the die (e.g., 1-20 for a d20).
/// * `params` - The parameters defining the skill check.
pub fn evaluate_skill_check(base_roll: u32, params: &SkillCheckParams) -> CheckResult {
    if base_roll >= params.critical_success_threshold {
        return CheckResult::CriticalSuccess;
    }
    
    if base_roll <= params.critical_failure_threshold {
        return CheckResult::CriticalFailure;
    }
    
    let total = (base_roll as i32) + params.skill_modifier;
    
    if total >= (params.difficulty_class as i32) {
        CheckResult::Success
    } else {
        CheckResult::Failure
    }
}

/// Calculates the probability of success (including critical success) for a given set of parameters.
/// Assumes a standard d20 roll (1-20).
pub fn calculate_success_probability(params: &SkillCheckParams) -> f32 {
    let mut successful_outcomes = 0;
    let total_outcomes = 20;
    
    for roll in 1..=20 {
        let result = evaluate_skill_check(roll, params);
        if result == CheckResult::Success || result == CheckResult::CriticalSuccess {
            successful_outcomes += 1;
        }
    }
    
    (successful_outcomes as f32) / (total_outcomes as f32)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_evaluate_skill_check() {
        let params = SkillCheckParams {
            difficulty_class: 15,
            skill_modifier: 5,
            critical_success_threshold: 20,
            critical_failure_threshold: 1,
            advantage: false,
            disadvantage: false,
        };

        // Critical Failure
        assert_eq!(evaluate_skill_check(1, &params), CheckResult::CriticalFailure);
        
        // Critical Success
        assert_eq!(evaluate_skill_check(20, &params), CheckResult::CriticalSuccess);
        
        // Normal Success (10 + 5 = 15 >= 15)
        assert_eq!(evaluate_skill_check(10, &params), CheckResult::Success);
        
        // Normal Failure (9 + 5 = 14 < 15)
        assert_eq!(evaluate_skill_check(9, &params), CheckResult::Failure);
    }

    #[test]
    fn test_calculate_success_probability() {
        let params = SkillCheckParams {
            difficulty_class: 15,
            skill_modifier: 0,
            critical_success_threshold: 20,
            critical_failure_threshold: 1,
            advantage: false,
            disadvantage: false,
        };

        // Needs 15 or higher on a d20. Rolls 15, 16, 17, 18, 19, 20 are successes (6 outcomes).
        // Probability = 6 / 20 = 0.3
        let prob = calculate_success_probability(&params);
        assert!((prob - 0.3).abs() < f32::EPSILON);
    }
}
