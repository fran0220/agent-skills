pub struct AchievementSystemParams {
    pub total_achievements: u32,
    pub rarity_threshold: f32,
    pub progress_steps: u32,
    pub points_value: u32,
}

impl AchievementSystemParams {
    pub fn new() -> Self {
        Self {
            total_achievements: 50,
            rarity_threshold: 0.10,
            progress_steps: 100,
            points_value: 15,
        }
    }

    pub fn calculate_rarity(&self, players_unlocked: u32, total_players: u32) -> f32 {
        if total_players == 0 {
            return 0.0;
        }
        (players_unlocked as f32) / (total_players as f32)
    }

    pub fn is_ultra_rare(&self, rarity: f32) -> bool {
        rarity <= self.rarity_threshold
    }

    pub fn calculate_progress_percentage(&self, current_steps: u32) -> f32 {
        if self.progress_steps == 0 {
            return 100.0;
        }
        let percentage = (current_steps as f32 / self.progress_steps as f32) * 100.0;
        if percentage > 100.0 {
            100.0
        } else {
            percentage
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_rarity() {
        let params = AchievementSystemParams::new();
        let rarity = params.calculate_rarity(10, 100);
        assert_eq!(rarity, 0.10);
        assert!(params.is_ultra_rare(rarity));
    }

    #[test]
    fn test_calculate_progress_percentage() {
        let params = AchievementSystemParams::new();
        let progress = params.calculate_progress_percentage(50);
        assert_eq!(progress, 50.0);
        
        let over_progress = params.calculate_progress_percentage(150);
        assert_eq!(over_progress, 100.0);
    }
}
