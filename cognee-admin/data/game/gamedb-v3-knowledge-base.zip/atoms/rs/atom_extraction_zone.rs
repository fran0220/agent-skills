#[derive(Debug, Clone, PartialEq)]
pub struct ExtractionZoneParams {
    pub extraction_time: f32,
    pub zone_radius: f32,
    pub activation_delay: f32,
    pub max_capacity: u32,
    pub requires_item: bool,
}

impl ExtractionZoneParams {
    /// Creates a new ExtractionZoneParams with default values based on Escape from Tarkov benchmarks.
    pub fn new() -> Self {
        Self {
            extraction_time: 7.0,
            zone_radius: 10.0,
            activation_delay: 0.0,
            max_capacity: 4,
            requires_item: true,
        }
    }
}

#[derive(Debug, Clone, PartialEq)]
pub enum ExtractionState {
    Inactive,
    Active,
    Extracting { time_remaining: f32, players_inside: u32 },
    Extracted,
    Failed,
}

pub struct ExtractionZone {
    pub params: ExtractionZoneParams,
    pub state: ExtractionState,
    pub time_since_match_start: f32,
}

impl ExtractionZone {
    pub fn new(params: ExtractionZoneParams) -> Self {
        Self {
            params,
            state: ExtractionState::Inactive,
            time_since_match_start: 0.0,
        }
    }

    /// Updates the state of the extraction zone based on time and player presence.
    pub fn update(&mut self, delta_time: f32, players_in_radius: u32, players_have_item: bool) {
        self.time_since_match_start += delta_time;

        match self.state {
            ExtractionState::Inactive => {
                if self.time_since_match_start >= self.params.activation_delay {
                    self.state = ExtractionState::Active;
                }
            }
            ExtractionState::Active => {
                if players_in_radius > 0 && players_in_radius <= self.params.max_capacity {
                    if !self.params.requires_item || players_have_item {
                        self.state = ExtractionState::Extracting {
                            time_remaining: self.params.extraction_time,
                            players_inside: players_in_radius,
                        };
                    }
                }
            }
            ExtractionState::Extracting { ref mut time_remaining, ref mut players_inside } => {
                if players_in_radius == 0 {
                    self.state = ExtractionState::Active;
                } else if players_in_radius > self.params.max_capacity {
                    // Over capacity, pause extraction or reset depending on design. Let's reset to active for simplicity.
                    self.state = ExtractionState::Active;
                } else if self.params.requires_item && !players_have_item {
                    self.state = ExtractionState::Active;
                } else {
                    *time_remaining -= delta_time;
                    *players_inside = players_in_radius;
                    if *time_remaining <= 0.0 {
                        self.state = ExtractionState::Extracted;
                    }
                }
            }
            ExtractionState::Extracted | ExtractionState::Failed => {
                // Terminal states
            }
        }
    }

    /// Checks if a player at a given distance is within the extraction zone.
    pub fn is_player_in_zone(&self, distance_to_center: f32) -> bool {
        distance_to_center <= self.params.zone_radius
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_extraction_success() {
        let params = ExtractionZoneParams::new();
        let mut zone = ExtractionZone::new(params);
        
        // Activate zone
        zone.update(0.1, 0, false);
        assert_eq!(zone.state, ExtractionState::Active);

        // Player enters
        zone.update(0.1, 1, true);
        if let ExtractionState::Extracting { time_remaining, .. } = zone.state {
            assert_eq!(time_remaining, 7.0);
        } else {
            panic!("Expected Extracting state");
        }

        // Wait for extraction
        zone.update(7.0, 1, true);
        assert_eq!(zone.state, ExtractionState::Extracted);
    }

    #[test]
    fn test_extraction_interrupted() {
        let params = ExtractionZoneParams::new();
        let mut zone = ExtractionZone::new(params);
        
        // Activate zone
        zone.update(0.1, 0, false);
        
        // Player enters
        zone.update(0.1, 1, true);
        
        // Player leaves before time is up
        zone.update(3.0, 0, true);
        assert_eq!(zone.state, ExtractionState::Active);
    }

    #[test]
    fn test_player_in_zone() {
        let params = ExtractionZoneParams::new();
        let zone = ExtractionZone::new(params);
        
        assert!(zone.is_player_in_zone(5.0));
        assert!(zone.is_player_in_zone(10.0));
        assert!(!zone.is_player_in_zone(10.1));
    }
}
