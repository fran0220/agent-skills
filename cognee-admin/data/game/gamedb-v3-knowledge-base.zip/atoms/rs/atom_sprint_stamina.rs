#[derive(Debug, Clone, PartialEq)]
pub struct SprintStaminaParams {
    pub max_stamina: f32,
    pub sprint_speed_multiplier: f32,
    pub stamina_drain_rate: f32,
    pub stamina_regen_rate: f32,
    pub regen_delay: f32,
    pub exhaustion_penalty_time: f32,
}

impl SprintStaminaParams {
    /// Creates a new SprintStaminaParams with default values based on Dark Souls III benchmark.
    pub fn new() -> Self {
        Self {
            max_stamina: 100.0,
            sprint_speed_multiplier: 1.45,
            stamina_drain_rate: 12.0,
            stamina_regen_rate: 45.0,
            regen_delay: 0.5,
            exhaustion_penalty_time: 0.0,
        }
    }
}

#[derive(Debug, Clone, PartialEq)]
pub enum SprintState {
    IdleWalk,
    Sprinting,
    Exhausted,
}

#[derive(Debug, Clone)]
pub struct SprintStaminaState {
    pub current_stamina: f32,
    pub state: SprintState,
    pub time_since_last_sprint: f32,
    pub time_in_exhaustion: f32,
}

impl SprintStaminaState {
    pub fn new(params: &SprintStaminaParams) -> Self {
        Self {
            current_stamina: params.max_stamina,
            state: SprintState::IdleWalk,
            time_since_last_sprint: 0.0,
            time_in_exhaustion: 0.0,
        }
    }

    /// Updates the stamina state based on delta time and sprint input.
    pub fn update(&mut self, dt: f32, sprint_input: bool, params: &SprintStaminaParams) {
        match self.state {
            SprintState::IdleWalk => {
                if sprint_input && self.current_stamina > 0.0 {
                    self.state = SprintState::Sprinting;
                    self.time_since_last_sprint = 0.0;
                } else {
                    self.time_since_last_sprint += dt;
                    if self.time_since_last_sprint >= params.regen_delay {
                        self.current_stamina = (self.current_stamina + params.stamina_regen_rate * dt).min(params.max_stamina);
                    }
                }
            }
            SprintState::Sprinting => {
                if !sprint_input {
                    self.state = SprintState::IdleWalk;
                    self.time_since_last_sprint = 0.0;
                } else {
                    self.current_stamina = (self.current_stamina - params.stamina_drain_rate * dt).max(0.0);
                    if self.current_stamina == 0.0 {
                        self.state = SprintState::Exhausted;
                        self.time_in_exhaustion = 0.0;
                    }
                }
            }
            SprintState::Exhausted => {
                self.time_in_exhaustion += dt;
                if self.time_in_exhaustion >= params.exhaustion_penalty_time {
                    self.state = SprintState::IdleWalk;
                    self.time_since_last_sprint = params.regen_delay; // Start regenerating immediately or based on delay
                }
            }
        }
    }

    /// Returns the current speed multiplier based on the state.
    pub fn get_speed_multiplier(&self, params: &SprintStaminaParams) -> f32 {
        match self.state {
            SprintState::Sprinting => params.sprint_speed_multiplier,
            _ => 1.0,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_sprint_drain() {
        let params = SprintStaminaParams::new();
        let mut state = SprintStaminaState::new(&params);
        
        // Start sprinting
        state.update(1.0, true, &params);
        assert_eq!(state.state, SprintState::Sprinting);
        assert_eq!(state.current_stamina, params.max_stamina - params.stamina_drain_rate * 1.0);
        assert_eq!(state.get_speed_multiplier(&params), params.sprint_speed_multiplier);
    }

    #[test]
    fn test_exhaustion_and_regen() {
        let params = SprintStaminaParams {
            max_stamina: 10.0,
            stamina_drain_rate: 10.0,
            exhaustion_penalty_time: 1.0,
            regen_delay: 0.5,
            stamina_regen_rate: 10.0,
            ..SprintStaminaParams::new()
        };
        let mut state = SprintStaminaState::new(&params);
        
        // Drain completely
        state.update(1.0, true, &params);
        assert_eq!(state.state, SprintState::Exhausted);
        assert_eq!(state.current_stamina, 0.0);
        
        // Try to sprint while exhausted
        state.update(0.5, true, &params);
        assert_eq!(state.state, SprintState::Exhausted); // Still exhausted
        
        // Wait for penalty to end
        state.update(0.6, false, &params);
        assert_eq!(state.state, SprintState::IdleWalk);
        
        // Wait for regen delay and regen
        state.update(0.5, false, &params);
        assert!(state.current_stamina > 0.0);
    }
}
