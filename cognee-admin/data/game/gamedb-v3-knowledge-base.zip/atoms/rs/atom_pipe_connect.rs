#[derive(Debug, Clone)]
pub struct PipeConnectParams {
    pub grid_width: u32,
    pub grid_height: u32,
    pub flow_speed: f32,
    pub flow_delay: f32,
    pub segment_types: u32,
}

impl PipeConnectParams {
    /// Creates a new PipeConnectParams with default values based on Pipe Mania v1.0 benchmark.
    pub fn new() -> Self {
        Self {
            grid_width: 10,
            grid_height: 10,
            flow_speed: 1.5,
            flow_delay: 5.0,
            segment_types: 6,
        }
    }

    /// Calculates the time required for the flow to travel a given distance.
    /// Distance is measured in tiles.
    pub fn calculate_flow_time(&self, distance: f32) -> f32 {
        if self.flow_speed <= 0.0 {
            return f32::INFINITY;
        }
        self.flow_delay + (distance / self.flow_speed)
    }

    /// Checks if a given coordinate is within the grid bounds.
    pub fn is_within_bounds(&self, x: u32, y: u32) -> bool {
        x < self.grid_width && y < self.grid_height
    }
    
    /// Calculates the maximum possible path length in the grid (without revisiting tiles).
    pub fn max_path_length(&self) -> u32 {
        self.grid_width * self.grid_height
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_flow_time() {
        let params = PipeConnectParams::new();
        // Distance = 3.0 tiles, speed = 1.5 tiles/sec, delay = 5.0 sec
        // Time = 5.0 + (3.0 / 1.5) = 5.0 + 2.0 = 7.0 sec
        let time = params.calculate_flow_time(3.0);
        assert!((time - 7.0).abs() < f32::EPSILON);
    }

    #[test]
    fn test_is_within_bounds() {
        let params = PipeConnectParams::new();
        assert!(params.is_within_bounds(0, 0));
        assert!(params.is_within_bounds(9, 9));
        assert!(!params.is_within_bounds(10, 9));
        assert!(!params.is_within_bounds(9, 10));
    }
    
    #[test]
    fn test_max_path_length() {
        let params = PipeConnectParams::new();
        assert_eq!(params.max_path_length(), 100);
    }
}
