#[derive(Debug, Clone)]
pub struct ScoreMultiplier {
    pub base_multiplier: f32,
    pub max_multiplier: f32,
    pub increment_step: f32,
    pub actions_to_increment: u32,
    pub timeout_duration: f32,
    
    // State variables
    pub current_multiplier: f32,
    pub consecutive_actions: u32,
    pub time_since_last_action: f32,
}

impl ScoreMultiplier {
    /// Creates a new ScoreMultiplier with default values based on Guitar Hero III benchmarks.
    pub fn new() -> Self {
        Self {
            base_multiplier: 1.0,
            max_multiplier: 8.0,
            increment_step: 1.0,
            actions_to_increment: 10,
            timeout_duration: 3.0,
            
            current_multiplier: 1.0,
            consecutive_actions: 0,
            time_since_last_action: 0.0,
        }
    }

    /// Registers a successful action and updates the multiplier.
    pub fn register_action(&mut self) {
        self.consecutive_actions += 1;
        self.time_since_last_action = 0.0;

        if self.consecutive_actions >= self.actions_to_increment {
            self.current_multiplier += self.increment_step;
            if self.current_multiplier > self.max_multiplier {
                self.current_multiplier = self.max_multiplier;
            }
            // Reset consecutive actions after incrementing the multiplier
            self.consecutive_actions = 0;
        }
    }

    /// Updates the time since the last action and resets the multiplier if the timeout is reached.
    pub fn update_time(&mut self, delta_time: f32) {
        self.time_since_last_action += delta_time;
        if self.time_since_last_action >= self.timeout_duration {
            self.reset();
        }
    }

    /// Resets the multiplier to its base state (e.g., on failure or timeout).
    pub fn reset(&mut self) {
        self.current_multiplier = self.base_multiplier;
        self.consecutive_actions = 0;
        self.time_since_last_action = 0.0;
    }

    /// Calculates the final score for a given base score using the current multiplier.
    pub fn calculate_score(&self, base_score: f32) -> f32 {
        base_score * self.current_multiplier
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_multiplier_increment() {
        let mut multiplier = ScoreMultiplier::new();
        multiplier.actions_to_increment = 3;
        multiplier.increment_step = 1.0;
        multiplier.max_multiplier = 4.0;

        assert_eq!(multiplier.current_multiplier, 1.0);

        // Perform 2 actions, multiplier should not increase yet
        multiplier.register_action();
        multiplier.register_action();
        assert_eq!(multiplier.current_multiplier, 1.0);

        // Perform 3rd action, multiplier should increase
        multiplier.register_action();
        assert_eq!(multiplier.current_multiplier, 2.0);

        // Perform 3 more actions, multiplier should increase again
        multiplier.register_action();
        multiplier.register_action();
        multiplier.register_action();
        assert_eq!(multiplier.current_multiplier, 3.0);
    }

    #[test]
    fn test_multiplier_cap() {
        let mut multiplier = ScoreMultiplier::new();
        multiplier.actions_to_increment = 1;
        multiplier.increment_step = 1.0;
        multiplier.max_multiplier = 3.0;

        multiplier.register_action(); // 2.0
        multiplier.register_action(); // 3.0
        multiplier.register_action(); // Should cap at 3.0

        assert_eq!(multiplier.current_multiplier, 3.0);
    }

    #[test]
    fn test_timeout_reset() {
        let mut multiplier = ScoreMultiplier::new();
        multiplier.actions_to_increment = 1;
        multiplier.timeout_duration = 2.0;

        multiplier.register_action(); // Multiplier is now 2.0
        assert_eq!(multiplier.current_multiplier, 2.0);

        multiplier.update_time(1.0); // Not timed out yet
        assert_eq!(multiplier.current_multiplier, 2.0);

        multiplier.update_time(1.5); // Total time 2.5 > 2.0, should reset
        assert_eq!(multiplier.current_multiplier, 1.0);
        assert_eq!(multiplier.consecutive_actions, 0);
    }

    #[test]
    fn test_calculate_score() {
        let mut multiplier = ScoreMultiplier::new();
        multiplier.actions_to_increment = 1;
        
        assert_eq!(multiplier.calculate_score(100.0), 100.0); // 100 * 1.0

        multiplier.register_action(); // Multiplier is now 2.0
        assert_eq!(multiplier.calculate_score(100.0), 200.0); // 100 * 2.0
    }
}
