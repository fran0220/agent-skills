#[derive(Debug, Clone)]
pub struct RoleAssignmentParams {
    pub impostor_ratio: f32,
    pub role_visibility: bool,
    pub action_cooldown: u32,
    pub discussion_time: u32,
}

impl RoleAssignmentParams {
    pub fn new() -> Self {
        Self {
            impostor_ratio: 0.2,
            role_visibility: false,
            action_cooldown: 30,
            discussion_time: 45,
        }
    }

    /// Calculates the number of impostors based on the total number of players.
    pub fn calculate_impostor_count(&self, total_players: u32) -> u32 {
        if total_players == 0 {
            return 0;
        }
        let count = (total_players as f32 * self.impostor_ratio).round() as u32;
        // Ensure at least 1 impostor if there are players, but don't exceed total players
        if count == 0 && total_players > 0 {
            1
        } else if count >= total_players {
            total_players - 1
        } else {
            count
        }
    }

    /// Checks if an action can be performed based on the time since the last action.
    pub fn can_perform_action(&self, time_since_last_action: u32) -> bool {
        time_since_last_action >= self.action_cooldown
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_impostor_count() {
        let params = RoleAssignmentParams::new();
        
        // 10 players * 0.2 = 2
        assert_eq!(params.calculate_impostor_count(10), 2);
        
        // 4 players * 0.2 = 0.8 -> 1
        assert_eq!(params.calculate_impostor_count(4), 1);
        
        // 15 players * 0.2 = 3
        assert_eq!(params.calculate_impostor_count(15), 3);
    }

    #[test]
    fn test_can_perform_action() {
        let params = RoleAssignmentParams::new();
        
        // Cooldown is 30
        assert_eq!(params.can_perform_action(29), false);
        assert_eq!(params.can_perform_action(30), true);
        assert_eq!(params.can_perform_action(45), true);
    }
}
