#[derive(Debug, Clone)]
pub struct DailyWeeklyReset {
    pub reset_interval_hours: u32,
    pub reset_hour_utc: u32,
    pub max_accumulated_charges: u32,
    pub missed_penalty_factor: f32,
}

impl DailyWeeklyReset {
    /// Creates a new DailyWeeklyReset with default values based on Genshin Impact / WoW benchmarks.
    pub fn new() -> Self {
        Self {
            reset_interval_hours: 24,
            reset_hour_utc: 8,
            max_accumulated_charges: 1,
            missed_penalty_factor: 0.0,
        }
    }

    /// Calculates the number of resets that have occurred between two timestamps (in hours).
    /// Assumes timestamps are absolute hours since some epoch.
    pub fn calculate_resets_passed(&self, last_played_hour: u32, current_hour: u32) -> u32 {
        if current_hour <= last_played_hour {
            return 0;
        }

        // Adjust hours relative to the reset hour
        let adjusted_last = if last_played_hour >= self.reset_hour_utc {
            last_played_hour - self.reset_hour_utc
        } else {
            // If before reset hour, it belongs to the previous cycle
            // We can just shift everything back by reset_hour_utc
            // To avoid underflow, we can just use absolute math
            0 // Simplified for this example, let's do proper math
        };

        // Let's use a simpler approach:
        // A reset occurs at every hour H where H % reset_interval_hours == reset_hour_utc
        
        // Find the next reset time after last_played_hour
        let mut next_reset = last_played_hour - (last_played_hour % self.reset_interval_hours) + self.reset_hour_utc;
        if next_reset <= last_played_hour {
            next_reset += self.reset_interval_hours;
        }

        if current_hour < next_reset {
            return 0;
        }

        let hours_past_first_reset = current_hour - next_reset;
        1 + (hours_past_first_reset / self.reset_interval_hours)
    }

    /// Calculates the available charges based on resets passed and current charges.
    pub fn calculate_available_charges(&self, current_charges: u32, resets_passed: u32) -> u32 {
        let new_charges = current_charges + resets_passed;
        if new_charges > self.max_accumulated_charges {
            self.max_accumulated_charges
        } else {
            new_charges
        }
    }
}

impl Default for DailyWeeklyReset {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_resets_passed() {
        let reset_system = DailyWeeklyReset {
            reset_interval_hours: 24,
            reset_hour_utc: 8,
            max_accumulated_charges: 3,
            missed_penalty_factor: 0.0,
        };

        // Last played at hour 5, current is hour 10. Reset is at 8.
        // 1 reset should have passed.
        assert_eq!(reset_system.calculate_resets_passed(5, 10), 1);

        // Last played at hour 10, current is hour 20. Reset is at 8.
        // 0 resets should have passed.
        assert_eq!(reset_system.calculate_resets_passed(10, 20), 0);

        // Last played at hour 10, current is hour 35 (next day 11:00).
        // 1 reset should have passed (at hour 32).
        assert_eq!(reset_system.calculate_resets_passed(10, 35), 1);
    }

    #[test]
    fn test_calculate_available_charges() {
        let reset_system = DailyWeeklyReset {
            reset_interval_hours: 24,
            reset_hour_utc: 8,
            max_accumulated_charges: 3,
            missed_penalty_factor: 0.0,
        };

        // 0 current charges, 2 resets passed -> 2 charges
        assert_eq!(reset_system.calculate_available_charges(0, 2), 2);

        // 2 current charges, 2 resets passed -> max 3 charges
        assert_eq!(reset_system.calculate_available_charges(2, 2), 3);
    }
}
