#[derive(Debug, Clone, PartialEq)]
pub struct EquipmentSlot {
    pub max_capacity: u32,
    pub stat_multiplier: f32,
    pub is_unlocked: bool,
    pub current_items: u32,
}

impl EquipmentSlot {
    /// Creates a new EquipmentSlot with default values based on benchmark data (e.g., WoW 1.12).
    pub fn new() -> Self {
        Self {
            max_capacity: 1,
            stat_multiplier: 1.0,
            is_unlocked: true,
            current_items: 0,
        }
    }

    /// Attempts to equip an item into the slot.
    /// Returns true if successful, false if the slot is full or locked.
    pub fn equip(&mut self) -> bool {
        if !self.is_unlocked {
            return false;
        }
        if self.current_items < self.max_capacity {
            self.current_items += 1;
            true
        } else {
            false
        }
    }

    /// Attempts to unequip an item from the slot.
    /// Returns true if successful, false if the slot is already empty.
    pub fn unequip(&mut self) -> bool {
        if self.current_items > 0 {
            self.current_items -= 1;
            true
        } else {
            false
        }
    }

    /// Calculates the effective stat bonus provided by the equipped item(s).
    /// The base stat is multiplied by the slot's stat_multiplier.
    pub fn calculate_effective_stat(&self, base_stat: f32) -> f32 {
        if self.current_items > 0 {
            base_stat * self.stat_multiplier
        } else {
            0.0
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_equip_and_unequip() {
        let mut slot = EquipmentSlot::new();
        
        // Initially empty
        assert_eq!(slot.current_items, 0);
        
        // Equip an item
        assert!(slot.equip());
        assert_eq!(slot.current_items, 1);
        
        // Cannot equip beyond max capacity
        assert!(!slot.equip());
        assert_eq!(slot.current_items, 1);
        
        // Unequip the item
        assert!(slot.unequip());
        assert_eq!(slot.current_items, 0);
        
        // Cannot unequip from empty slot
        assert!(!slot.unequip());
    }

    #[test]
    fn test_calculate_effective_stat() {
        let mut slot = EquipmentSlot::new();
        slot.stat_multiplier = 1.5;
        
        // Empty slot provides 0 stat
        assert_eq!(slot.calculate_effective_stat(10.0), 0.0);
        
        // Equipped slot provides multiplied stat
        slot.equip();
        assert_eq!(slot.calculate_effective_stat(10.0), 15.0);
    }

    #[test]
    fn test_locked_slot() {
        let mut slot = EquipmentSlot::new();
        slot.is_unlocked = false;
        
        // Cannot equip into a locked slot
        assert!(!slot.equip());
        assert_eq!(slot.current_items, 0);
    }
}
