#[derive(Debug, Clone)]
pub struct AdaptiveDifficultyParams {
    pub evaluation_interval: f32,
    pub performance_upper_threshold: f32,
    pub performance_lower_threshold: f32,
    pub difficulty_increase_step: f32,
    pub difficulty_decrease_step: f32,
    pub max_difficulty_multiplier: f32,
    pub min_difficulty_multiplier: f32,
}

impl AdaptiveDifficultyParams {
    pub fn new() -> Self {
        Self {
            evaluation_interval: 10.0,
            performance_upper_threshold: 0.8,
            performance_lower_threshold: 0.3,
            difficulty_increase_step: 0.05,
            difficulty_decrease_step: 0.1,
            max_difficulty_multiplier: 2.0,
            min_difficulty_multiplier: 0.5,
        }
    }
}

pub struct AdaptiveDifficultySystem {
    pub params: AdaptiveDifficultyParams,
    pub current_difficulty_multiplier: f32,
}

impl AdaptiveDifficultySystem {
    pub fn new(params: AdaptiveDifficultyParams) -> Self {
        Self {
            params,
            current_difficulty_multiplier: 1.0,
        }
    }

    pub fn evaluate_performance(&mut self, performance_metric: f32) -> f32 {
        if performance_metric > self.params.performance_upper_threshold {
            self.increase_difficulty();
        } else if performance_metric < self.params.performance_lower_threshold {
            self.decrease_difficulty();
        }
        self.current_difficulty_multiplier
    }

    fn increase_difficulty(&mut self) {
        self.current_difficulty_multiplier += self.params.difficulty_increase_step;
        if self.current_difficulty_multiplier > self.params.max_difficulty_multiplier {
            self.current_difficulty_multiplier = self.params.max_difficulty_multiplier;
        }
    }

    fn decrease_difficulty(&mut self) {
        self.current_difficulty_multiplier -= self.params.difficulty_decrease_step;
        if self.current_difficulty_multiplier < self.params.min_difficulty_multiplier {
            self.current_difficulty_multiplier = self.params.min_difficulty_multiplier;
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_increase_difficulty() {
        let params = AdaptiveDifficultyParams::new();
        let mut system = AdaptiveDifficultySystem::new(params);
        
        // Initial difficulty is 1.0
        assert_eq!(system.current_difficulty_multiplier, 1.0);
        
        // Performance > upper threshold (0.8)
        let new_diff = system.evaluate_performance(0.9);
        
        // Difficulty should increase by 0.05
        assert_eq!(new_diff, 1.05);
    }

    #[test]
    fn test_decrease_difficulty() {
        let params = AdaptiveDifficultyParams::new();
        let mut system = AdaptiveDifficultySystem::new(params);
        
        // Initial difficulty is 1.0
        assert_eq!(system.current_difficulty_multiplier, 1.0);
        
        // Performance < lower threshold (0.3)
        let new_diff = system.evaluate_performance(0.2);
        
        // Difficulty should decrease by 0.1
        assert_eq!(new_diff, 0.9);
    }

    #[test]
    fn test_maintain_difficulty() {
        let params = AdaptiveDifficultyParams::new();
        let mut system = AdaptiveDifficultySystem::new(params);
        
        // Initial difficulty is 1.0
        assert_eq!(system.current_difficulty_multiplier, 1.0);
        
        // Performance between thresholds (0.3 - 0.8)
        let new_diff = system.evaluate_performance(0.5);
        
        // Difficulty should remain 1.0
        assert_eq!(new_diff, 1.0);
    }

    #[test]
    fn test_max_difficulty_cap() {
        let mut params = AdaptiveDifficultyParams::new();
        params.max_difficulty_multiplier = 1.1;
        let mut system = AdaptiveDifficultySystem::new(params);
        
        system.evaluate_performance(0.9); // 1.05
        system.evaluate_performance(0.9); // 1.10
        let new_diff = system.evaluate_performance(0.9); // Should cap at 1.1
        
        assert_eq!(new_diff, 1.1);
    }
}
