#[derive(Debug, Clone)]
pub struct SocketGemParams {
    pub max_sockets: u32,
    pub socket_chance: f32,
    pub unsocket_cost: u32,
    pub gem_power_multiplier: f32,
}

impl SocketGemParams {
    pub fn new() -> Self {
        Self {
            max_sockets: 6,
            socket_chance: 0.15,
            unsocket_cost: 1,
            gem_power_multiplier: 1.0,
        }
    }

    /// Calculates the total power of a gem when socketed
    pub fn calculate_gem_power(&self, base_gem_power: f32) -> f32 {
        base_gem_power * self.gem_power_multiplier
    }

    /// Determines if an item successfully rolls a socket based on chance
    pub fn roll_socket(&self, rng_value: f32) -> bool {
        rng_value <= self.socket_chance
    }
    
    /// Calculates the cost to unsocket a given number of gems
    pub fn calculate_unsocket_cost(&self, num_gems: u32) -> u32 {
        self.unsocket_cost * num_gems
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_gem_power() {
        let params = SocketGemParams::new();
        assert_eq!(params.calculate_gem_power(10.0), 10.0);
    }

    #[test]
    fn test_roll_socket() {
        let params = SocketGemParams::new();
        assert!(params.roll_socket(0.10)); // 0.10 <= 0.15
        assert!(!params.roll_socket(0.20)); // 0.20 > 0.15
    }
    
    #[test]
    fn test_calculate_unsocket_cost() {
        let params = SocketGemParams::new();
        assert_eq!(params.calculate_unsocket_cost(3), 3);
    }
}
