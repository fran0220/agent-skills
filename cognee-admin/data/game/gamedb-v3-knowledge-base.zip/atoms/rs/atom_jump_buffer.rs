#[derive(Debug, Clone, PartialEq)]
pub struct JumpBufferParams {
    pub buffer_window: f32,
    pub allow_buffer_in_air: bool,
    pub consume_on_jump: bool,
}

impl JumpBufferParams {
    /// Creates a new JumpBufferParams with default values based on Celeste benchmark.
    pub fn new() -> Self {
        Self {
            buffer_window: 0.083, // 5 frames at 60fps
            allow_buffer_in_air: true,
            consume_on_jump: true,
        }
    }
}

#[derive(Debug, Clone)]
pub struct JumpBufferState {
    pub params: JumpBufferParams,
    pub buffer_timer: f32,
    pub is_buffered: bool,
}

impl JumpBufferState {
    pub fn new(params: JumpBufferParams) -> Self {
        Self {
            params,
            buffer_timer: 0.0,
            is_buffered: false,
        }
    }

    /// Registers a jump input.
    pub fn register_input(&mut self) {
        if self.params.allow_buffer_in_air || !self.is_buffered {
            self.is_buffered = true;
            self.buffer_timer = self.params.buffer_window;
        }
    }

    /// Updates the buffer timer. Should be called every frame.
    pub fn update(&mut self, delta_time: f32) {
        if self.is_buffered {
            self.buffer_timer -= delta_time;
            if self.buffer_timer <= 0.0 {
                self.is_buffered = false;
                self.buffer_timer = 0.0;
            }
        }
    }

    /// Checks if a jump should be executed given the current grounded state.
    /// If consume_on_jump is true, it will consume the buffer upon a successful jump.
    pub fn check_jump(&mut self, is_grounded: bool) -> bool {
        if is_grounded && self.is_buffered {
            if self.params.consume_on_jump {
                self.is_buffered = false;
                self.buffer_timer = 0.0;
            }
            return true;
        }
        false
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_jump_buffer_execution() {
        let params = JumpBufferParams::new();
        let mut state = JumpBufferState::new(params);

        // Register input in the air
        state.register_input();
        assert!(state.is_buffered);
        assert_eq!(state.buffer_timer, 0.083);

        // Update time, but not enough to expire the buffer
        state.update(0.05);
        assert!(state.is_buffered);

        // Land on the ground, jump should be executed
        let should_jump = state.check_jump(true);
        assert!(should_jump);
        
        // Buffer should be consumed
        assert!(!state.is_buffered);
    }

    #[test]
    fn test_jump_buffer_expiration() {
        let params = JumpBufferParams::new();
        let mut state = JumpBufferState::new(params);

        // Register input in the air
        state.register_input();
        assert!(state.is_buffered);

        // Update time past the buffer window
        state.update(0.1);
        assert!(!state.is_buffered);

        // Land on the ground, jump should NOT be executed
        let should_jump = state.check_jump(true);
        assert!(!should_jump);
    }
}
