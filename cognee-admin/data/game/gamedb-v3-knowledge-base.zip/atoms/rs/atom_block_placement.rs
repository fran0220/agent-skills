#[derive(Debug, Clone, PartialEq)]
pub struct BlockPlacementParams {
    pub placement_range: f32,
    pub destruction_range: f32,
    pub base_mining_time: f32,
    pub placement_cooldown: f32,
}

impl BlockPlacementParams {
    /// Creates a new instance with default values based on Minecraft 1.20 benchmarks.
    pub fn new() -> Self {
        Self {
            placement_range: 4.5,
            destruction_range: 4.5,
            base_mining_time: 1.5,
            placement_cooldown: 0.2,
        }
    }

    /// Checks if a target block position is within the player's placement range.
    pub fn can_place(&self, player_pos: (f32, f32, f32), target_pos: (f32, f32, f32)) -> bool {
        let dx = player_pos.0 - target_pos.0;
        let dy = player_pos.1 - target_pos.1;
        let dz = player_pos.2 - target_pos.2;
        let distance_squared = dx * dx + dy * dy + dz * dz;
        
        distance_squared <= self.placement_range * self.placement_range
    }

    /// Calculates the actual mining time required to destroy a block,
    /// taking into account the block's hardness and the tool's efficiency multiplier.
    pub fn calculate_mining_time(&self, block_hardness: f32, tool_multiplier: f32) -> f32 {
        if tool_multiplier <= 0.0 {
            return f32::INFINITY; // Cannot mine if tool multiplier is 0 or negative
        }
        
        // Formula: base_time * hardness / tool_multiplier
        (self.base_mining_time * block_hardness) / tool_multiplier
    }
}

impl Default for BlockPlacementParams {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_can_place_within_range() {
        let params = BlockPlacementParams::new();
        let player_pos = (0.0, 0.0, 0.0);
        
        // Target is 4 units away on X axis, which is <= 4.5
        let target_pos_valid = (4.0, 0.0, 0.0);
        assert!(params.can_place(player_pos, target_pos_valid));
        
        // Target is 5 units away on X axis, which is > 4.5
        let target_pos_invalid = (5.0, 0.0, 0.0);
        assert!(!params.can_place(player_pos, target_pos_invalid));
    }

    #[test]
    fn test_calculate_mining_time() {
        let params = BlockPlacementParams::new(); // base_mining_time = 1.5
        
        // Hardness 2.0, Tool multiplier 1.0 -> 1.5 * 2.0 / 1.0 = 3.0
        let time1 = params.calculate_mining_time(2.0, 1.0);
        assert!((time1 - 3.0).abs() < f32::EPSILON);
        
        // Hardness 2.0, Tool multiplier 3.0 -> 1.5 * 2.0 / 3.0 = 1.0
        let time2 = params.calculate_mining_time(2.0, 3.0);
        assert!((time2 - 1.0).abs() < f32::EPSILON);
    }
}
