pub struct ProceduralGenParams {
    pub seed: u32,
    pub noise_scale: f32,
    pub octaves: u32,
    pub persistence: f32,
    pub lacunarity: f32,
    pub threshold: f32,
}

impl ProceduralGenParams {
    /// Creates a new ProceduralGenParams with default values based on benchmark data.
    pub fn new() -> Self {
        Self {
            seed: 123456789,
            noise_scale: 0.05,
            octaves: 4,
            persistence: 0.5,
            lacunarity: 2.0,
            threshold: 0.45,
        }
    }

    /// A simple 1D pseudo-random noise function based on the seed and position.
    pub fn generate_noise_1d(&self, x: f32) -> f32 {
        let scaled_x = x * self.noise_scale;
        let mut total = 0.0;
        let mut frequency = 1.0;
        let mut amplitude = 1.0;
        let mut max_value = 0.0;

        for _ in 0..self.octaves {
            // A very basic pseudo-random hash function for demonstration
            let hash = ((scaled_x * frequency).sin() * 43758.5453123 + self.seed as f32).fract();
            total += hash * amplitude;
            max_value += amplitude;
            amplitude *= self.persistence;
            frequency *= self.lacunarity;
        }

        total / max_value
    }

    /// Determines if a feature should be placed at a given 1D coordinate based on the threshold.
    pub fn should_place_feature(&self, x: f32) -> bool {
        let noise_val = self.generate_noise_1d(x);
        noise_val > self.threshold
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_default_params() {
        let params = ProceduralGenParams::new();
        assert_eq!(params.seed, 123456789);
        assert_eq!(params.octaves, 4);
        assert_eq!(params.noise_scale, 0.05);
    }

    #[test]
    fn test_generate_noise_1d_bounds() {
        let params = ProceduralGenParams::new();
        let noise = params.generate_noise_1d(10.0);
        assert!(noise >= 0.0 && noise <= 1.0, "Noise value {} is out of bounds", noise);
    }

    #[test]
    fn test_should_place_feature() {
        let mut params = ProceduralGenParams::new();
        params.threshold = 0.0; // Always place
        assert!(params.should_place_feature(5.0));

        params.threshold = 1.0; // Never place
        assert!(!params.should_place_feature(5.0));
    }
}
