#[derive(Debug, Clone, PartialEq)]
pub struct AudioCueParams {
    pub max_hearing_distance: f32,
    pub attenuation_rolloff: f32,
    pub occlusion_muffling: f32,
    pub doppler_level: f32,
    pub spatial_blend: f32,
}

impl AudioCueParams {
    /// Creates a new AudioCueParams with default values based on Hunt: Showdown benchmarks.
    pub fn new() -> Self {
        Self {
            max_hearing_distance: 150.0,
            attenuation_rolloff: 2.0,
            occlusion_muffling: 0.6,
            doppler_level: 0.0,
            spatial_blend: 1.0,
        }
    }

    /// Calculates the perceived volume of a sound based on distance and attenuation rolloff.
    /// Uses a simple logarithmic attenuation model.
    pub fn calculate_volume(&self, distance: f32, base_volume: f32) -> f32 {
        if distance >= self.max_hearing_distance {
            return 0.0;
        }
        if distance <= 1.0 {
            return base_volume;
        }
        
        // Attenuation formula: volume = base_volume / (distance ^ rolloff)
        // Normalized to max_hearing_distance
        let distance_factor = distance / self.max_hearing_distance;
        let attenuation = 1.0 - distance_factor.powf(1.0 / self.attenuation_rolloff);
        
        (base_volume * attenuation).max(0.0)
    }

    /// Calculates the final volume considering occlusion (e.g., walls).
    pub fn calculate_occluded_volume(&self, distance: f32, base_volume: f32, is_occluded: bool) -> f32 {
        let mut volume = self.calculate_volume(distance, base_volume);
        if is_occluded {
            volume *= 1.0 - self.occlusion_muffling;
        }
        volume
    }
}

impl Default for AudioCueParams {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_volume() {
        let params = AudioCueParams::new();
        
        // At distance 0 or 1, volume should be base_volume
        assert_eq!(params.calculate_volume(1.0, 1.0), 1.0);
        
        // At max distance, volume should be 0
        assert_eq!(params.calculate_volume(150.0, 1.0), 0.0);
        
        // At half distance (75.0), with rolloff 2.0
        // distance_factor = 0.5
        // attenuation = 1.0 - sqrt(0.5) = 1.0 - 0.707 = 0.293
        let vol = params.calculate_volume(75.0, 1.0);
        assert!((vol - 0.2928932).abs() < 1e-5);
    }

    #[test]
    fn test_calculate_occluded_volume() {
        let params = AudioCueParams::new();
        
        // Not occluded
        let vol_unoccluded = params.calculate_occluded_volume(75.0, 1.0, false);
        
        // Occluded
        let vol_occluded = params.calculate_occluded_volume(75.0, 1.0, true);
        
        // Occluded volume should be reduced by occlusion_muffling (0.6)
        // So it should be 40% of the unoccluded volume
        assert!((vol_occluded - (vol_unoccluded * 0.4)).abs() < 1e-5);
    }
}
