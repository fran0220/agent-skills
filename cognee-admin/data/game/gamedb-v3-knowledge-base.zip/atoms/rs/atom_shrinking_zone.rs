pub struct ShrinkingZoneParams {
    pub initial_radius: f32,
    pub shrink_factor: f32,
    pub wait_time: f32,
    pub shrink_time: f32,
    pub damage_per_tick: f32,
}

impl ShrinkingZoneParams {
    pub fn new() -> Self {
        Self {
            initial_radius: 4500.0,
            shrink_factor: 0.5,
            wait_time: 120.0,
            shrink_time: 90.0,
            damage_per_tick: 1.5,
        }
    }

    pub fn calculate_next_radius(&self, current_radius: f32) -> f32 {
        current_radius * self.shrink_factor
    }

    pub fn calculate_damage(&self, distance_from_center: f32, current_radius: f32) -> f32 {
        if distance_from_center > current_radius {
            self.damage_per_tick
        } else {
            0.0
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_next_radius() {
        let params = ShrinkingZoneParams::new();
        let next_radius = params.calculate_next_radius(4500.0);
        assert_eq!(next_radius, 2250.0);
    }

    #[test]
    fn test_calculate_damage() {
        let params = ShrinkingZoneParams::new();
        let damage_inside = params.calculate_damage(1000.0, 2250.0);
        assert_eq!(damage_inside, 0.0);

        let damage_outside = params.calculate_damage(3000.0, 2250.0);
        assert_eq!(damage_outside, 1.5);
    }
}
