#[derive(Debug, Clone, PartialEq)]
pub struct BoardPositioningParams {
    pub board_width: u32,
    pub board_height: u32,
    pub max_units: u32,
    pub placement_time: f32,
    pub hex_size: f32,
}

impl BoardPositioningParams {
    /// Creates a new `BoardPositioningParams` with default values based on Teamfight Tactics Set 13.
    pub fn new() -> Self {
        Self {
            board_width: 7,
            board_height: 4,
            max_units: 9,
            placement_time: 30.0,
            hex_size: 1.0,
        }
    }

    /// Checks if a given coordinate (x, y) is within the valid board boundaries.
    pub fn is_valid_position(&self, x: u32, y: u32) -> bool {
        x < self.board_width && y < self.board_height
    }

    /// Calculates the Euclidean distance between two hex centers, assuming a simple grid layout.
    /// Note: True hex distance is more complex, but this serves as a basic approximation.
    pub fn calculate_distance(&self, x1: u32, y1: u32, x2: u32, y2: u32) -> f32 {
        let dx = (x2 as f32 - x1 as f32) * self.hex_size;
        let dy = (y2 as f32 - y1 as f32) * self.hex_size;
        (dx * dx + dy * dy).sqrt()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_default_params() {
        let params = BoardPositioningParams::new();
        assert_eq!(params.board_width, 7);
        assert_eq!(params.board_height, 4);
        assert_eq!(params.max_units, 9);
        assert_eq!(params.placement_time, 30.0);
        assert_eq!(params.hex_size, 1.0);
    }

    #[test]
    fn test_is_valid_position() {
        let params = BoardPositioningParams::new();
        assert!(params.is_valid_position(0, 0));
        assert!(params.is_valid_position(6, 3));
        assert!(!params.is_valid_position(7, 3));
        assert!(!params.is_valid_position(6, 4));
    }

    #[test]
    fn test_calculate_distance() {
        let params = BoardPositioningParams::new();
        let dist = params.calculate_distance(0, 0, 3, 4);
        assert_eq!(dist, 5.0);
    }
}
