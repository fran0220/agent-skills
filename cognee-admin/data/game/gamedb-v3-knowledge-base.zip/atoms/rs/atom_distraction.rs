#[derive(Debug, Clone, PartialEq)]
pub struct DistractionParams {
    pub stimulus_radius: f32,
    pub investigation_time: f32,
    pub movement_speed_modifier: f32,
    pub cooldown: f32,
    pub suspicion_increase: f32,
}

impl DistractionParams {
    /// Creates a new DistractionParams with default values based on benchmark data (Hitman 3 / MGSV).
    pub fn new() -> Self {
        Self {
            stimulus_radius: 15.0,
            investigation_time: 5.0,
            movement_speed_modifier: 0.8,
            cooldown: 0.0,
            suspicion_increase: 10.0,
        }
    }

    /// Checks if an AI entity is within the stimulus radius.
    pub fn is_within_radius(&self, distance_to_stimulus: f32) -> bool {
        distance_to_stimulus <= self.stimulus_radius
    }

    /// Calculates the modified movement speed of the AI while investigating.
    pub fn calculate_investigation_speed(&self, base_speed: f32) -> f32 {
        base_speed * self.movement_speed_modifier
    }

    /// Calculates the new suspicion level after a distraction is detected.
    pub fn calculate_new_suspicion(&self, current_suspicion: f32) -> f32 {
        (current_suspicion + self.suspicion_increase).min(100.0)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_is_within_radius() {
        let params = DistractionParams::new();
        assert!(params.is_within_radius(10.0));
        assert!(params.is_within_radius(15.0));
        assert!(!params.is_within_radius(15.1));
    }

    #[test]
    fn test_calculate_investigation_speed() {
        let params = DistractionParams::new();
        let base_speed = 5.0;
        let expected_speed = 5.0 * 0.8;
        assert_eq!(params.calculate_investigation_speed(base_speed), expected_speed);
    }

    #[test]
    fn test_calculate_new_suspicion() {
        let params = DistractionParams::new();
        assert_eq!(params.calculate_new_suspicion(50.0), 60.0);
        assert_eq!(params.calculate_new_suspicion(95.0), 100.0); // Should cap at 100.0
    }
}
