pub struct ComboCounter {
    pub combo_window: f32,
    pub max_combo: u32,
    pub damage_multiplier_base: f32,
    pub damage_multiplier_step: f32,
    pub score_multiplier_base: f32,
    
    // State variables
    pub current_combo: u32,
    pub time_since_last_hit: f32,
}

impl ComboCounter {
    pub fn new() -> Self {
        Self {
            combo_window: 3.0, // Default from DMC 5 benchmark
            max_combo: 999,
            damage_multiplier_base: 1.0,
            damage_multiplier_step: 0.05,
            score_multiplier_base: 1.0,
            current_combo: 0,
            time_since_last_hit: 0.0,
        }
    }

    /// Updates the combo counter based on elapsed time.
    /// If the time since the last hit exceeds the combo window, the combo resets.
    pub fn update(&mut self, delta_time: f32) {
        if self.current_combo > 0 {
            self.time_since_last_hit += delta_time;
            if self.time_since_last_hit > self.combo_window {
                self.reset();
            }
        }
    }

    /// Registers a successful hit, incrementing the combo counter and resetting the timer.
    pub fn register_hit(&mut self) {
        if self.current_combo < self.max_combo {
            self.current_combo += 1;
        }
        self.time_since_last_hit = 0.0;
    }

    /// Resets the combo counter to zero.
    pub fn reset(&mut self) {
        self.current_combo = 0;
        self.time_since_last_hit = 0.0;
    }

    /// Calculates the current damage multiplier based on the combo count.
    pub fn get_damage_multiplier(&self) -> f32 {
        if self.current_combo == 0 {
            return self.damage_multiplier_base;
        }
        self.damage_multiplier_base + (self.current_combo as f32 - 1.0) * self.damage_multiplier_step
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_combo_increment_and_multiplier() {
        let mut counter = ComboCounter::new();
        assert_eq!(counter.current_combo, 0);
        assert_eq!(counter.get_damage_multiplier(), 1.0);

        counter.register_hit();
        assert_eq!(counter.current_combo, 1);
        assert_eq!(counter.get_damage_multiplier(), 1.0);

        counter.register_hit();
        assert_eq!(counter.current_combo, 2);
        assert_eq!(counter.get_damage_multiplier(), 1.05);
        
        counter.register_hit();
        assert_eq!(counter.current_combo, 3);
        assert_eq!(counter.get_damage_multiplier(), 1.10);
    }

    #[test]
    fn test_combo_timeout() {
        let mut counter = ComboCounter::new();
        counter.register_hit();
        counter.register_hit();
        assert_eq!(counter.current_combo, 2);

        // Update with time less than window
        counter.update(2.0);
        assert_eq!(counter.current_combo, 2);

        // Update with time exceeding window
        counter.update(1.1);
        assert_eq!(counter.current_combo, 0);
        assert_eq!(counter.get_damage_multiplier(), 1.0);
    }
}
