#[derive(Debug, Clone, PartialEq)]
pub struct SpecialPieceParams {
    pub match_threshold: u32,
    pub effect_radius: f32,
    pub spawn_delay: f32,
    pub score_multiplier: f32,
}

impl SpecialPieceParams {
    /// Creates a new SpecialPieceParams with default values based on Candy Crush Saga benchmark.
    pub fn new() -> Self {
        Self {
            match_threshold: 4,
            effect_radius: 1.0,
            spawn_delay: 0.2,
            score_multiplier: 2.0,
        }
    }
}

impl Default for SpecialPieceParams {
    fn default() -> Self {
        Self::new()
    }
}

/// Represents the state of a special piece generation process.
#[derive(Debug, Clone, PartialEq)]
pub enum SpecialPieceState {
    Idle,
    Generating(f32), // time elapsed
    SpecialPieceIdle,
    Activating,
    Destroyed,
}

pub struct SpecialPieceAtom {
    pub params: SpecialPieceParams,
    pub state: SpecialPieceState,
}

impl SpecialPieceAtom {
    pub fn new(params: SpecialPieceParams) -> Self {
        Self {
            params,
            state: SpecialPieceState::Idle,
        }
    }

    /// Checks if a match size is sufficient to trigger special piece generation.
    pub fn check_match(&mut self, match_size: u32) -> bool {
        if self.state == SpecialPieceState::Idle && match_size >= self.params.match_threshold {
            self.state = SpecialPieceState::Generating(0.0);
            true
        } else {
            false
        }
    }

    /// Updates the generation process over time.
    pub fn update_generation(&mut self, delta_time: f32) {
        if let SpecialPieceState::Generating(elapsed) = self.state {
            let new_elapsed = elapsed + delta_time;
            if new_elapsed >= self.params.spawn_delay {
                self.state = SpecialPieceState::SpecialPieceIdle;
            } else {
                self.state = SpecialPieceState::Generating(new_elapsed);
            }
        }
    }

    /// Calculates the score for activating the special piece.
    pub fn calculate_activation_score(&self, base_score: f32) -> f32 {
        base_score * self.params.score_multiplier
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_check_match_triggers_generation() {
        let params = SpecialPieceParams::new();
        let mut atom = SpecialPieceAtom::new(params);

        // Match size 3 is below threshold 4
        assert!(!atom.check_match(3));
        assert_eq!(atom.state, SpecialPieceState::Idle);

        // Match size 4 meets threshold
        assert!(atom.check_match(4));
        assert_eq!(atom.state, SpecialPieceState::Generating(0.0));
    }

    #[test]
    fn test_update_generation_completes() {
        let params = SpecialPieceParams::new();
        let mut atom = SpecialPieceAtom::new(params);
        
        atom.state = SpecialPieceState::Generating(0.0);
        
        // Update by half the delay
        atom.update_generation(0.1);
        assert_eq!(atom.state, SpecialPieceState::Generating(0.1));
        
        // Update past the delay
        atom.update_generation(0.15);
        assert_eq!(atom.state, SpecialPieceState::SpecialPieceIdle);
    }

    #[test]
    fn test_calculate_activation_score() {
        let params = SpecialPieceParams::new();
        let atom = SpecialPieceAtom::new(params);
        
        let score = atom.calculate_activation_score(100.0);
        assert_eq!(score, 200.0); // 100.0 * 2.0 multiplier
    }
}
