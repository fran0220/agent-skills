#[derive(Debug, Clone, PartialEq)]
pub struct InstantRestartParams {
    pub restart_delay: f32,
    pub fade_duration: f32,
    pub auto_restart: bool,
}

impl InstantRestartParams {
    /// Creates a new InstantRestartParams with default values based on Super Meat Boy benchmark.
    pub fn new() -> Self {
        Self {
            restart_delay: 0.1,
            fade_duration: 0.0,
            auto_restart: false,
        }
    }

    /// Calculates the total time taken for a restart sequence to complete.
    pub fn total_restart_time(&self) -> f32 {
        self.restart_delay + self.fade_duration
    }

    /// Determines if a restart should be triggered automatically upon failure.
    pub fn should_auto_restart(&self, is_failed: bool) -> bool {
        is_failed && self.auto_restart
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_total_restart_time() {
        let params = InstantRestartParams {
            restart_delay: 0.5,
            fade_duration: 0.2,
            auto_restart: true,
        };
        assert_eq!(params.total_restart_time(), 0.7);
    }

    #[test]
    fn test_should_auto_restart() {
        let mut params = InstantRestartParams::new();
        
        // Default is auto_restart = false
        assert_eq!(params.should_auto_restart(true), false);
        assert_eq!(params.should_auto_restart(false), false);

        // Change to auto_restart = true
        params.auto_restart = true;
        assert_eq!(params.should_auto_restart(true), true);
        assert_eq!(params.should_auto_restart(false), false);
    }
}
