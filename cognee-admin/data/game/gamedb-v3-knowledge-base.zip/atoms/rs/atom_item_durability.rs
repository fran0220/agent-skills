#[derive(Debug, Clone, PartialEq)]
pub enum ItemState {
    Pristine,
    Damaged,
    Broken,
    Destroyed,
}

#[derive(Debug, Clone)]
pub struct ItemDurability {
    pub max_durability: u32,
    pub current_durability: u32,
    pub degradation_rate: f32,
    pub repair_cost_multiplier: f32,
    pub state: ItemState,
}

impl ItemDurability {
    /// Creates a new ItemDurability instance with default values based on benchmark data.
    pub fn new() -> Self {
        Self {
            max_durability: 100,
            current_durability: 100,
            degradation_rate: 1.0,
            repair_cost_multiplier: 2.0,
            state: ItemState::Pristine,
        }
    }

    /// Simulates using the item, decreasing its durability.
    /// Returns the new state of the item.
    pub fn use_item(&mut self, uses: u32) -> ItemState {
        if self.state == ItemState::Broken || self.state == ItemState::Destroyed {
            return self.state.clone();
        }

        let damage = (uses as f32 * self.degradation_rate).round() as u32;
        
        if self.current_durability <= damage {
            self.current_durability = 0;
            self.state = ItemState::Broken;
        } else {
            self.current_durability -= damage;
            if self.current_durability < self.max_durability {
                self.state = ItemState::Damaged;
            }
        }

        self.state.clone()
    }

    /// Calculates the resource cost to fully repair the item.
    pub fn calculate_repair_cost(&self) -> f32 {
        if self.state == ItemState::Destroyed {
            return f32::INFINITY; // Cannot repair a destroyed item
        }
        
        let missing_durability = self.max_durability - self.current_durability;
        missing_durability as f32 * self.repair_cost_multiplier
    }

    /// Repairs the item by a specific amount of durability.
    pub fn repair(&mut self, amount: u32) {
        if self.state == ItemState::Destroyed {
            return;
        }

        self.current_durability = (self.current_durability + amount).min(self.max_durability);
        
        if self.current_durability == self.max_durability {
            self.state = ItemState::Pristine;
        } else if self.current_durability > 0 {
            self.state = ItemState::Damaged;
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_use_item_degradation() {
        let mut item = ItemDurability::new();
        assert_eq!(item.state, ItemState::Pristine);
        
        // Use item 10 times
        let state = item.use_item(10);
        assert_eq!(state, ItemState::Damaged);
        assert_eq!(item.current_durability, 90);
        
        // Use item until broken
        let state = item.use_item(100);
        assert_eq!(state, ItemState::Broken);
        assert_eq!(item.current_durability, 0);
    }

    #[test]
    fn test_repair_cost_and_action() {
        let mut item = ItemDurability::new();
        item.use_item(50); // Durability drops to 50
        
        let cost = item.calculate_repair_cost();
        assert_eq!(cost, 100.0); // 50 missing * 2.0 multiplier
        
        item.repair(25);
        assert_eq!(item.current_durability, 75);
        assert_eq!(item.state, ItemState::Damaged);
        
        item.repair(50); // Over-repair
        assert_eq!(item.current_durability, 100);
        assert_eq!(item.state, ItemState::Pristine);
    }
}
