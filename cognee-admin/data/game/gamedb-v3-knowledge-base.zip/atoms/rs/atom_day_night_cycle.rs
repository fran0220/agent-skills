#[derive(Debug, Clone, PartialEq)]
pub enum TimeOfDayState {
    Dawn,
    Day,
    Dusk,
    Night,
}

#[derive(Debug, Clone)]
pub struct DayNightCycle {
    pub real_seconds_per_game_day: f32,
    pub day_duration_ratio: f32,
    pub night_duration_ratio: f32,
    pub dawn_dusk_duration_ratio: f32,
    pub time_scale_multiplier: f32,
    
    pub elapsed_real_seconds: f32,
}

impl DayNightCycle {
    /// Creates a new DayNightCycle with default values based on Minecraft 1.19 benchmark.
    pub fn new() -> Self {
        Self {
            real_seconds_per_game_day: 1200.0,
            day_duration_ratio: 0.5,
            night_duration_ratio: 0.33,
            dawn_dusk_duration_ratio: 0.083,
            time_scale_multiplier: 72.0,
            elapsed_real_seconds: 0.0,
        }
    }

    /// Advances the internal clock by a given amount of real-world seconds.
    pub fn advance_time(&mut self, delta_seconds: f32) {
        self.elapsed_real_seconds += delta_seconds;
    }

    /// Returns the current time of day as a normalized value between 0.0 and 1.0.
    /// 0.0 represents the start of the day cycle (e.g., 00:00).
    pub fn get_normalized_time(&self) -> f32 {
        let total_seconds = self.elapsed_real_seconds % self.real_seconds_per_game_day;
        total_seconds / self.real_seconds_per_game_day
    }

    /// Determines the current state of the day/night cycle based on normalized time.
    /// Assuming the cycle starts at Dawn (0.0).
    pub fn get_current_state(&self) -> TimeOfDayState {
        let time = self.get_normalized_time();
        
        let dawn_end = self.dawn_dusk_duration_ratio;
        let day_end = dawn_end + self.day_duration_ratio;
        let dusk_end = day_end + self.dawn_dusk_duration_ratio;
        
        if time < dawn_end {
            TimeOfDayState::Dawn
        } else if time < day_end {
            TimeOfDayState::Day
        } else if time < dusk_end {
            TimeOfDayState::Dusk
        } else {
            TimeOfDayState::Night
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_time_advancement_and_normalization() {
        let mut cycle = DayNightCycle::new();
        assert_eq!(cycle.get_normalized_time(), 0.0);
        
        // Advance by half a day
        cycle.advance_time(600.0);
        assert_eq!(cycle.get_normalized_time(), 0.5);
        
        // Advance by another full day
        cycle.advance_time(1200.0);
        assert_eq!(cycle.get_normalized_time(), 0.5);
    }

    #[test]
    fn test_state_transitions() {
        let mut cycle = DayNightCycle::new();
        
        // Start at 0.0 -> Dawn
        assert_eq!(cycle.get_current_state(), TimeOfDayState::Dawn);
        
        // Advance past dawn (0.083 * 1200 = 99.6 seconds)
        cycle.advance_time(100.0);
        assert_eq!(cycle.get_current_state(), TimeOfDayState::Day);
        
        // Advance past day (0.583 * 1200 = 699.6 seconds)
        cycle.advance_time(600.0);
        assert_eq!(cycle.get_current_state(), TimeOfDayState::Dusk);
        
        // Advance past dusk (0.666 * 1200 = 799.2 seconds)
        cycle.advance_time(100.0);
        assert_eq!(cycle.get_current_state(), TimeOfDayState::Night);
    }
}
