#[derive(Debug, Clone, PartialEq)]
pub struct MemoryMatchParams {
    pub grid_width: u32,
    pub grid_height: u32,
    pub reveal_delay: f32,
    pub time_limit: f32,
    pub max_attempts: u32,
}

impl MemoryMatchParams {
    /// Creates a new MemoryMatchParams with default values based on benchmark data.
    pub fn new() -> Self {
        Self {
            grid_width: 4,
            grid_height: 4,
            reveal_delay: 1.0,
            time_limit: 60.0,
            max_attempts: 20,
        }
    }

    /// Calculates the total number of pairs in the grid.
    /// Returns 0 if the total number of cells is odd.
    pub fn total_pairs(&self) -> u32 {
        let total_cells = self.grid_width * self.grid_height;
        if total_cells % 2 != 0 {
            0 // Invalid grid for memory match
        } else {
            total_cells / 2
        }
    }

    /// Checks if the game is over based on attempts or time elapsed.
    pub fn is_game_over(&self, attempts: u32, time_elapsed: f32) -> bool {
        attempts >= self.max_attempts || time_elapsed >= self.time_limit
    }

    /// Calculates a score multiplier based on consecutive matches.
    /// Base multiplier is 1.0, each consecutive match adds 0.5.
    pub fn score_multiplier(&self, consecutive_matches: u32) -> f32 {
        if consecutive_matches == 0 {
            1.0
        } else {
            1.0 + (consecutive_matches as f32 - 1.0) * 0.5
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_total_pairs() {
        let params = MemoryMatchParams::new();
        assert_eq!(params.total_pairs(), 8); // 4x4 grid = 16 cells = 8 pairs

        let mut odd_params = MemoryMatchParams::new();
        odd_params.grid_width = 3;
        odd_params.grid_height = 3;
        assert_eq!(odd_params.total_pairs(), 0); // 3x3 grid = 9 cells = invalid
    }

    #[test]
    fn test_is_game_over() {
        let params = MemoryMatchParams::new();
        
        // Not over
        assert!(!params.is_game_over(10, 30.0));
        
        // Over by attempts
        assert!(params.is_game_over(20, 30.0));
        assert!(params.is_game_over(25, 30.0));
        
        // Over by time
        assert!(params.is_game_over(10, 60.0));
        assert!(params.is_game_over(10, 65.0));
    }

    #[test]
    fn test_score_multiplier() {
        let params = MemoryMatchParams::new();
        
        assert_eq!(params.score_multiplier(0), 1.0);
        assert_eq!(params.score_multiplier(1), 1.0);
        assert_eq!(params.score_multiplier(2), 1.5);
        assert_eq!(params.score_multiplier(3), 2.0);
    }
}
