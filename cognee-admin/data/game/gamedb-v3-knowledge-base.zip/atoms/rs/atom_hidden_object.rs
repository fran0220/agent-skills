#[derive(Debug, Clone)]
pub struct HiddenObjectParams {
    pub total_targets: u32,
    pub hitbox_margin: f32,
    pub penalty_cooldown: f32,
    pub hint_cooldown: f32,
    pub zoom_levels: u32,
    pub distractor_density: f32,
}

impl HiddenObjectParams {
    pub fn new() -> Self {
        Self {
            total_targets: 15,
            hitbox_margin: 2.0,
            penalty_cooldown: 0.0,
            hint_cooldown: 30.0,
            zoom_levels: 3,
            distractor_density: 0.7,
        }
    }

    /// Checks if a click is within the target's hitbox, considering the margin.
    /// Returns true if it's a hit, false otherwise.
    pub fn check_hit(&self, click_x: f32, click_y: f32, target_x: f32, target_y: f32, target_radius: f32) -> bool {
        let effective_radius = target_radius + self.hitbox_margin;
        let dx = click_x - target_x;
        let dy = click_y - target_y;
        let distance_squared = dx * dx + dy * dy;
        distance_squared <= effective_radius * effective_radius
    }

    /// Calculates the penalty duration based on consecutive misses.
    /// If penalty_cooldown is 0, returns 0. Otherwise, scales with misses.
    pub fn calculate_penalty(&self, consecutive_misses: u32) -> f32 {
        if self.penalty_cooldown <= 0.0 {
            return 0.0;
        }
        // Example formula: base penalty + (misses - 1) * 0.5 * base penalty
        if consecutive_misses == 0 {
            0.0
        } else {
            self.penalty_cooldown + (consecutive_misses as f32 - 1.0) * 0.5 * self.penalty_cooldown
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_check_hit() {
        let params = HiddenObjectParams::new();
        // target at (10, 10) with radius 5. effective radius = 5 + 2 = 7.
        // click at (10, 16) -> distance 6 <= 7 -> true
        assert!(params.check_hit(10.0, 16.0, 10.0, 10.0, 5.0));
        
        // click at (10, 18) -> distance 8 > 7 -> false
        assert!(!params.check_hit(10.0, 18.0, 10.0, 10.0, 5.0));
    }

    #[test]
    fn test_calculate_penalty() {
        let mut params = HiddenObjectParams::new();
        params.penalty_cooldown = 2.0; // Set a non-zero penalty for testing

        assert_eq!(params.calculate_penalty(0), 0.0);
        assert_eq!(params.calculate_penalty(1), 2.0);
        assert_eq!(params.calculate_penalty(2), 3.0); // 2.0 + 1 * 0.5 * 2.0 = 3.0
        assert_eq!(params.calculate_penalty(3), 4.0); // 2.0 + 2 * 0.5 * 2.0 = 4.0
    }
}
