#[derive(Debug, Clone)]
pub struct LimitedResourcesParams {
    pub max_ammo_capacity: u32,
    pub health_item_spawn_rate: f32,
    pub enemy_drop_chance: f32,
    pub inventory_slots: u32,
}

impl LimitedResourcesParams {
    pub fn new() -> Self {
        Self {
            max_ammo_capacity: 30,
            health_item_spawn_rate: 0.05,
            enemy_drop_chance: 0.1,
            inventory_slots: 8,
        }
    }
}

pub struct PlayerInventory {
    pub current_ammo: u32,
    pub params: LimitedResourcesParams,
}

impl PlayerInventory {
    pub fn new(params: LimitedResourcesParams) -> Self {
        Self {
            current_ammo: 0,
            params,
        }
    }

    pub fn add_ammo(&mut self, amount: u32) -> u32 {
        let space_left = self.params.max_ammo_capacity.saturating_sub(self.current_ammo);
        let added = amount.min(space_left);
        self.current_ammo += added;
        added
    }

    pub fn consume_ammo(&mut self, amount: u32) -> bool {
        if self.current_ammo >= amount {
            self.current_ammo -= amount;
            true
        } else {
            false
        }
    }

    pub fn calculate_drop_chance(&self, base_chance: f32) -> f32 {
        // Dynamic drop chance: increases as ammo gets lower
        let ammo_ratio = self.current_ammo as f32 / self.params.max_ammo_capacity as f32;
        let dynamic_multiplier = 1.0 + (1.0 - ammo_ratio);
        (base_chance * dynamic_multiplier).min(1.0)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_add_ammo_limit() {
        let params = LimitedResourcesParams::new();
        let mut inventory = PlayerInventory::new(params);
        
        let added = inventory.add_ammo(40);
        assert_eq!(added, 30);
        assert_eq!(inventory.current_ammo, 30);
        
        let added_more = inventory.add_ammo(10);
        assert_eq!(added_more, 0);
        assert_eq!(inventory.current_ammo, 30);
    }

    #[test]
    fn test_consume_ammo() {
        let params = LimitedResourcesParams::new();
        let mut inventory = PlayerInventory::new(params);
        
        inventory.add_ammo(20);
        assert!(inventory.consume_ammo(10));
        assert_eq!(inventory.current_ammo, 10);
        
        assert!(!inventory.consume_ammo(15));
        assert_eq!(inventory.current_ammo, 10);
    }

    #[test]
    fn test_dynamic_drop_chance() {
        let params = LimitedResourcesParams::new();
        let mut inventory = PlayerInventory::new(params);
        
        // Empty inventory, max multiplier (2.0)
        assert_eq!(inventory.calculate_drop_chance(0.1), 0.2);
        
        // Full inventory, min multiplier (1.0)
        inventory.add_ammo(30);
        assert_eq!(inventory.calculate_drop_chance(0.1), 0.1);
    }
}
