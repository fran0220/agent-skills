#[derive(Debug, Clone, PartialEq)]
pub struct IoGrowthParams {
    pub base_speed: f32,
    pub speed_decay_factor: f32,
    pub starting_mass: f32,
    pub mass_absorption_rate: f32,
    pub passive_mass_loss: f32,
}

impl IoGrowthParams {
    /// Creates a new `IoGrowthParams` with default values based on Agar.io v1.0 benchmark.
    pub fn new() -> Self {
        Self {
            base_speed: 30.0,
            speed_decay_factor: 0.5,
            starting_mass: 10.0,
            mass_absorption_rate: 1.0,
            passive_mass_loss: 0.002,
        }
    }

    /// Calculates the current speed of an entity based on its mass.
    /// Formula: speed = base_speed * (starting_mass / mass)^speed_decay_factor
    pub fn calculate_speed(&self, current_mass: f32) -> f32 {
        if current_mass <= 0.0 {
            return 0.0;
        }
        self.base_speed * (self.starting_mass / current_mass).powf(self.speed_decay_factor)
    }

    /// Calculates the new mass after consuming another entity.
    /// Formula: new_mass = current_mass + (consumed_mass * mass_absorption_rate)
    pub fn consume_mass(&self, current_mass: f32, consumed_mass: f32) -> f32 {
        current_mass + (consumed_mass * self.mass_absorption_rate)
    }

    /// Calculates the mass after applying passive mass loss over a given delta time.
    /// Formula: new_mass = current_mass - (current_mass * passive_mass_loss * delta_time)
    pub fn apply_passive_loss(&self, current_mass: f32, delta_time: f32) -> f32 {
        let loss = current_mass * self.passive_mass_loss * delta_time;
        let new_mass = current_mass - loss;
        if new_mass < self.starting_mass {
            self.starting_mass
        } else {
            new_mass
        }
    }
}

impl Default for IoGrowthParams {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_speed() {
        let params = IoGrowthParams::new();
        
        // At starting mass, speed should be base_speed
        let speed_at_start = params.calculate_speed(10.0);
        assert!((speed_at_start - 30.0).abs() < f32::EPSILON);
        
        // At 4x mass, speed should be halved (since decay factor is 0.5, i.e., square root)
        let speed_at_40 = params.calculate_speed(40.0);
        assert!((speed_at_40 - 15.0).abs() < f32::EPSILON);
    }

    #[test]
    fn test_consume_mass() {
        let params = IoGrowthParams::new();
        
        // Consuming 5.0 mass with 1.0 absorption rate
        let new_mass = params.consume_mass(10.0, 5.0);
        assert!((new_mass - 15.0).abs() < f32::EPSILON);
        
        // Test with a different absorption rate
        let mut custom_params = IoGrowthParams::new();
        custom_params.mass_absorption_rate = 0.8;
        let new_mass_custom = custom_params.consume_mass(10.0, 5.0);
        assert!((new_mass_custom - 14.0).abs() < f32::EPSILON);
    }

    #[test]
    fn test_apply_passive_loss() {
        let params = IoGrowthParams::new();
        
        // Loss over 1 second for 100.0 mass
        let new_mass = params.apply_passive_loss(100.0, 1.0);
        // 100.0 - (100.0 * 0.002 * 1.0) = 100.0 - 0.2 = 99.8
        assert!((new_mass - 99.8).abs() < f32::EPSILON);
        
        // Should not drop below starting mass
        let new_mass_min = params.apply_passive_loss(10.0, 10.0);
        assert!((new_mass_min - 10.0).abs() < f32::EPSILON);
    }
}
