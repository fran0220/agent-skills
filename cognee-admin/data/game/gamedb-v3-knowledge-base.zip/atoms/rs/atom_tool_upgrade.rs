#[derive(Debug, Clone, PartialEq)]
pub struct ToolUpgradeParams {
    pub cost_currency: u32,
    pub cost_materials: u32,
    pub upgrade_duration: u32,
    pub efficiency_multiplier: f32,
    pub stamina_reduction: f32,
}

impl ToolUpgradeParams {
    pub fn new() -> Self {
        Self {
            cost_currency: 2000,
            cost_materials: 5,
            upgrade_duration: 2,
            efficiency_multiplier: 2.0,
            stamina_reduction: 0.1,
        }
    }
}

pub struct Tool {
    pub tier: u32,
    pub base_efficiency: f32,
    pub base_stamina_cost: f32,
}

impl Tool {
    pub fn new(base_efficiency: f32, base_stamina_cost: f32) -> Self {
        Self {
            tier: 0,
            base_efficiency,
            base_stamina_cost,
        }
    }

    pub fn upgrade(&mut self, params: &ToolUpgradeParams) {
        self.tier += 1;
        self.base_efficiency *= params.efficiency_multiplier;
        self.base_stamina_cost *= 1.0 - params.stamina_reduction;
    }

    pub fn get_current_efficiency(&self) -> f32 {
        self.base_efficiency
    }

    pub fn get_current_stamina_cost(&self) -> f32 {
        self.base_stamina_cost
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_tool_upgrade_efficiency() {
        let params = ToolUpgradeParams::new();
        let mut tool = Tool::new(1.0, 10.0);
        
        assert_eq!(tool.get_current_efficiency(), 1.0);
        
        tool.upgrade(&params);
        
        assert_eq!(tool.get_current_efficiency(), 2.0);
        assert_eq!(tool.tier, 1);
    }

    #[test]
    fn test_tool_upgrade_stamina_cost() {
        let params = ToolUpgradeParams::new();
        let mut tool = Tool::new(1.0, 10.0);
        
        assert_eq!(tool.get_current_stamina_cost(), 10.0);
        
        tool.upgrade(&params);
        
        assert_eq!(tool.get_current_stamina_cost(), 9.0);
    }
}
