#[derive(Debug, Clone, PartialEq)]
pub struct BranchingDialogueParams {
    pub max_options: u32,
    pub time_limit: f32,
    pub skill_check_threshold: u32,
    pub relationship_impact: f32,
}

impl BranchingDialogueParams {
    /// Creates a new BranchingDialogueParams with default values based on benchmark data.
    pub fn new() -> Self {
        Self {
            max_options: 4,
            time_limit: 0.0,
            skill_check_threshold: 10,
            relationship_impact: 5.0,
        }
    }

    /// Calculates the final relationship change based on the base impact and the player's charisma multiplier.
    pub fn calculate_relationship_change(&self, base_impact: f32, player_charisma_multiplier: f32) -> f32 {
        let impact = base_impact * player_charisma_multiplier;
        // Clamp the impact to a reasonable range, e.g., [-self.relationship_impact * 2.0, self.relationship_impact * 2.0]
        let max_impact = self.relationship_impact * 2.0;
        impact.clamp(-max_impact, max_impact)
    }

    /// Determines if a skill check is successful based on the player's skill level and a dice roll.
    pub fn check_skill_success(&self, player_skill: u32, dice_roll: u32) -> bool {
        let total_score = player_skill.saturating_add(dice_roll);
        total_score >= self.skill_check_threshold
    }

    /// Checks if the time limit for a dialogue choice has expired.
    /// If time_limit is 0.0, it means there is no time limit.
    pub fn is_time_expired(&self, elapsed_time: f32) -> bool {
        if self.time_limit <= 0.0 {
            return false;
        }
        elapsed_time >= self.time_limit
    }
}

impl Default for BranchingDialogueParams {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_relationship_change() {
        let params = BranchingDialogueParams::new();
        
        // Positive impact with high charisma
        let change1 = params.calculate_relationship_change(5.0, 1.5);
        assert_eq!(change1, 7.5);
        
        // Negative impact with low charisma
        let change2 = params.calculate_relationship_change(-4.0, 0.8);
        assert_eq!(change2, -3.2);
        
        // Clamping test
        let change3 = params.calculate_relationship_change(10.0, 2.0);
        assert_eq!(change3, 10.0); // Max impact is 5.0 * 2.0 = 10.0
    }

    #[test]
    fn test_check_skill_success() {
        let params = BranchingDialogueParams::new(); // threshold is 10
        
        // Success: skill + roll >= threshold
        assert!(params.check_skill_success(5, 5));
        assert!(params.check_skill_success(8, 3));
        
        // Failure: skill + roll < threshold
        assert!(!params.check_skill_success(4, 5));
        assert!(!params.check_skill_success(0, 9));
    }

    #[test]
    fn test_is_time_expired() {
        let mut params = BranchingDialogueParams::new();
        
        // Default time_limit is 0.0 (no limit)
        assert!(!params.is_time_expired(100.0));
        
        // Set a time limit
        params.time_limit = 10.0;
        
        // Not expired
        assert!(!params.is_time_expired(5.0));
        assert!(!params.is_time_expired(9.9));
        
        // Expired
        assert!(params.is_time_expired(10.0));
        assert!(params.is_time_expired(15.0));
    }
}
