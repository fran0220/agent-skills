#[derive(Debug, Clone, PartialEq)]
pub struct NodeMapParams {
    pub num_layers: u32,
    pub nodes_per_layer: u32,
    pub branching_factor: f32,
    pub elite_density: f32,
    pub shop_density: f32,
}

impl NodeMapParams {
    /// Creates a new NodeMapParams with default values based on Slay the Spire benchmarks.
    pub fn new() -> Self {
        Self {
            num_layers: 15,
            nodes_per_layer: 5,
            branching_factor: 1.5,
            elite_density: 0.12,
            shop_density: 0.08,
        }
    }

    /// Calculates the expected total number of nodes in the map.
    pub fn expected_total_nodes(&self) -> u32 {
        self.num_layers * self.nodes_per_layer
    }

    /// Calculates the expected number of elite nodes in the map.
    pub fn expected_elite_nodes(&self) -> u32 {
        let total_nodes = self.expected_total_nodes() as f32;
        (total_nodes * self.elite_density).round() as u32
    }

    /// Calculates the expected number of shop nodes in the map.
    pub fn expected_shop_nodes(&self) -> u32 {
        let total_nodes = self.expected_total_nodes() as f32;
        (total_nodes * self.shop_density).round() as u32
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_expected_total_nodes() {
        let params = NodeMapParams::new();
        assert_eq!(params.expected_total_nodes(), 75); // 15 * 5
    }

    #[test]
    fn test_expected_elite_nodes() {
        let params = NodeMapParams::new();
        // 75 * 0.12 = 9.0
        assert_eq!(params.expected_elite_nodes(), 9);
    }

    #[test]
    fn test_expected_shop_nodes() {
        let params = NodeMapParams::new();
        // 75 * 0.08 = 6.0
        assert_eq!(params.expected_shop_nodes(), 6);
    }
}
