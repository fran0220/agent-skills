#[derive(Debug, Clone)]
pub struct RaidMechanicParams {
    pub enrage_timer: f32,
    pub mechanic_interval: f32,
    pub wipe_damage: u32,
    pub safe_zone_radius: f32,
    pub requires_soak: bool,
}

impl RaidMechanicParams {
    /// Creates a new RaidMechanicParams with default values based on benchmark data.
    pub fn new() -> Self {
        Self {
            enrage_timer: 600.0,
            mechanic_interval: 30.0,
            wipe_damage: 999999,
            safe_zone_radius: 5.0,
            requires_soak: true,
        }
    }

    /// Calculates the number of mechanics that will occur before the enrage timer is reached.
    pub fn total_mechanics_before_enrage(&self) -> u32 {
        if self.mechanic_interval <= 0.0 {
            return 0;
        }
        (self.enrage_timer / self.mechanic_interval).floor() as u32
    }

    /// Determines if a player is safe from a mechanic based on their distance to the safe zone center.
    pub fn is_player_safe(&self, player_distance: f32) -> bool {
        player_distance <= self.safe_zone_radius
    }

    /// Calculates the damage taken by a player. If they are not safe, they take wipe damage.
    pub fn calculate_damage_taken(&self, player_distance: f32) -> u32 {
        if self.is_player_safe(player_distance) {
            0
        } else {
            self.wipe_damage
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_total_mechanics_before_enrage() {
        let params = RaidMechanicParams::new();
        // 600.0 / 30.0 = 20
        assert_eq!(params.total_mechanics_before_enrage(), 20);

        let mut custom_params = RaidMechanicParams::new();
        custom_params.enrage_timer = 300.0;
        custom_params.mechanic_interval = 45.0;
        // 300.0 / 45.0 = 6.66... -> 6
        assert_eq!(custom_params.total_mechanics_before_enrage(), 6);
    }

    #[test]
    fn test_is_player_safe() {
        let params = RaidMechanicParams::new();
        assert!(params.is_player_safe(3.0));
        assert!(params.is_player_safe(5.0));
        assert!(!params.is_player_safe(5.1));
    }

    #[test]
    fn test_calculate_damage_taken() {
        let params = RaidMechanicParams::new();
        assert_eq!(params.calculate_damage_taken(2.0), 0);
        assert_eq!(params.calculate_damage_taken(6.0), 999999);
    }
}
