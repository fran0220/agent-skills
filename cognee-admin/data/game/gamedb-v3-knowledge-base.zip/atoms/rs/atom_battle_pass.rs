#[derive(Debug, Clone)]
pub struct BattlePass {
    pub max_level: u32,
    pub xp_per_level: u32,
    pub season_duration: u32,
    pub premium_cost: u32,
    pub total_rewards: u32,
    pub current_xp: u32,
    pub is_premium: bool,
}

impl BattlePass {
    pub fn new() -> Self {
        Self {
            max_level: 100,
            xp_per_level: 80000,
            season_duration: 70,
            premium_cost: 950,
            total_rewards: 100,
            current_xp: 0,
            is_premium: false,
        }
    }

    pub fn add_xp(&mut self, xp: u32) {
        let max_xp = self.max_level * self.xp_per_level;
        self.current_xp = (self.current_xp + xp).min(max_xp);
    }

    pub fn get_current_level(&self) -> u32 {
        (self.current_xp / self.xp_per_level).min(self.max_level)
    }

    pub fn upgrade_to_premium(&mut self) -> Result<(), &'static str> {
        if self.is_premium {
            return Err("Already premium");
        }
        self.is_premium = true;
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_add_xp_and_level_up() {
        let mut bp = BattlePass::new();
        assert_eq!(bp.get_current_level(), 0);
        
        bp.add_xp(80000);
        assert_eq!(bp.get_current_level(), 1);
        
        bp.add_xp(40000);
        assert_eq!(bp.get_current_level(), 1);
        
        bp.add_xp(40000);
        assert_eq!(bp.get_current_level(), 2);
    }

    #[test]
    fn test_max_level_cap() {
        let mut bp = BattlePass::new();
        bp.add_xp(bp.max_level * bp.xp_per_level + 10000);
        assert_eq!(bp.get_current_level(), bp.max_level);
        assert_eq!(bp.current_xp, bp.max_level * bp.xp_per_level);
    }
}
