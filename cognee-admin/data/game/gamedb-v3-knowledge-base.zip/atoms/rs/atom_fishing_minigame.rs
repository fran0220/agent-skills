#[derive(Debug, Clone, Copy)]
pub struct FishingMinigameParams {
    pub bite_delay_min: f32,
    pub bite_delay_max: f32,
    pub hook_window: f32,
    pub fish_speed: f32,
    pub bar_size: f32,
    pub tension_increase_rate: f32,
    pub tension_decrease_rate: f32,
    pub max_tension: f32,
}

impl FishingMinigameParams {
    /// Creates a new `FishingMinigameParams` with default values based on Stardew Valley benchmarks.
    pub fn new() -> Self {
        Self {
            bite_delay_min: 2.0,
            bite_delay_max: 10.0,
            hook_window: 0.75,
            fish_speed: 40.0,
            bar_size: 25.0,
            tension_increase_rate: 15.0,
            tension_decrease_rate: 20.0,
            max_tension: 100.0,
        }
    }
}

impl Default for FishingMinigameParams {
    fn default() -> Self {
        Self::new()
    }
}

pub struct FishingMinigameState {
    pub params: FishingMinigameParams,
    pub current_tension: f32,
    pub is_hooked: bool,
}

impl FishingMinigameState {
    pub fn new(params: FishingMinigameParams) -> Self {
        Self {
            params,
            current_tension: 0.0,
            is_hooked: false,
        }
    }

    /// Simulates the hooking action. Returns true if successful.
    pub fn try_hook(&mut self, reaction_time: f32) -> bool {
        if reaction_time <= self.params.hook_window {
            self.is_hooked = true;
            true
        } else {
            self.is_hooked = false;
            false
        }
    }

    /// Updates the tension based on player input and delta time.
    /// Returns true if the line snaps (tension exceeds max).
    pub fn update_tension(&mut self, is_reeling: bool, delta_time: f32) -> bool {
        if !self.is_hooked {
            return false;
        }

        if is_reeling {
            self.current_tension += self.params.tension_increase_rate * delta_time;
        } else {
            self.current_tension -= self.params.tension_decrease_rate * delta_time;
        }

        // Clamp tension to not go below 0
        if self.current_tension < 0.0 {
            self.current_tension = 0.0;
        }

        // Check if line snapped
        self.current_tension > self.params.max_tension
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_try_hook_success() {
        let params = FishingMinigameParams::new();
        let mut state = FishingMinigameState::new(params);
        
        // Reaction time is within the 0.75s window
        assert!(state.try_hook(0.5));
        assert!(state.is_hooked);
    }

    #[test]
    fn test_try_hook_failure() {
        let params = FishingMinigameParams::new();
        let mut state = FishingMinigameState::new(params);
        
        // Reaction time is outside the 0.75s window
        assert!(!state.try_hook(1.0));
        assert!(!state.is_hooked);
    }

    #[test]
    fn test_update_tension_increase() {
        let params = FishingMinigameParams::new();
        let mut state = FishingMinigameState::new(params);
        state.is_hooked = true;
        
        // Reel for 1 second
        let snapped = state.update_tension(true, 1.0);
        assert!(!snapped);
        assert_eq!(state.current_tension, 15.0); // 0 + 15.0 * 1.0
    }

    #[test]
    fn test_update_tension_snap() {
        let params = FishingMinigameParams::new();
        let mut state = FishingMinigameState::new(params);
        state.is_hooked = true;
        
        // Reel for 10 seconds (150 tension, max is 100)
        let snapped = state.update_tension(true, 10.0);
        assert!(snapped);
        assert!(state.current_tension > params.max_tension);
    }
}
