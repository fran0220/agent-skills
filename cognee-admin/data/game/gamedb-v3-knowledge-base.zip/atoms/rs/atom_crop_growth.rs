#[derive(Debug, Clone, PartialEq)]
pub enum CropState {
    Seed,
    Sprout,
    Seedling,
    Mature,
    Harvestable,
    Dead,
}

#[derive(Debug, Clone)]
pub struct CropGrowthParams {
    pub growth_days: u32,
    pub water_required: bool,
    pub multi_harvest: bool,
    pub regrowth_days: u32,
}

impl CropGrowthParams {
    pub fn new() -> Self {
        // Default values based on Stardew Valley Parsnip benchmark
        Self {
            growth_days: 4,
            water_required: true,
            multi_harvest: false,
            regrowth_days: 0,
        }
    }
}

#[derive(Debug, Clone)]
pub struct CropEntity {
    pub state: CropState,
    pub days_grown: u32,
    pub is_watered: bool,
    pub days_unwatered: u32,
    pub params: CropGrowthParams,
}

impl CropEntity {
    pub fn new(params: CropGrowthParams) -> Self {
        Self {
            state: CropState::Seed,
            days_grown: 0,
            is_watered: false,
            days_unwatered: 0,
            params,
        }
    }

    pub fn water(&mut self) {
        self.is_watered = true;
        self.days_unwatered = 0;
    }

    pub fn advance_day(&mut self) {
        if self.state == CropState::Dead || self.state == CropState::Harvestable {
            return;
        }

        if self.params.water_required && !self.is_watered {
            self.days_unwatered += 1;
            if self.days_unwatered >= 3 {
                self.state = CropState::Dead;
            }
            return;
        }

        self.days_grown += 1;
        self.is_watered = false; // Reset watering status for the new day

        self.update_state();
    }

    fn update_state(&mut self) {
        let progress = self.days_grown as f32 / self.params.growth_days as f32;

        if progress >= 1.0 {
            self.state = CropState::Harvestable;
        } else if progress >= 0.75 {
            self.state = CropState::Mature;
        } else if progress >= 0.5 {
            self.state = CropState::Seedling;
        } else if progress >= 0.25 {
            self.state = CropState::Sprout;
        }
    }

    pub fn harvest(&mut self) -> bool {
        if self.state == CropState::Harvestable {
            if self.params.multi_harvest {
                self.state = CropState::Mature;
                self.days_grown = self.params.growth_days - self.params.regrowth_days;
            } else {
                self.state = CropState::Dead; // Or removed
            }
            true
        } else {
            false
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_crop_growth_cycle() {
        let params = CropGrowthParams::new();
        let mut crop = CropEntity::new(params);

        assert_eq!(crop.state, CropState::Seed);

        // Day 1
        crop.water();
        crop.advance_day();
        assert_eq!(crop.state, CropState::Sprout);

        // Day 2
        crop.water();
        crop.advance_day();
        assert_eq!(crop.state, CropState::Seedling);

        // Day 3
        crop.water();
        crop.advance_day();
        assert_eq!(crop.state, CropState::Mature);

        // Day 4
        crop.water();
        crop.advance_day();
        assert_eq!(crop.state, CropState::Harvestable);
    }

    #[test]
    fn test_crop_death_by_unwatered() {
        let params = CropGrowthParams::new();
        let mut crop = CropEntity::new(params);

        // Unwatered for 3 days
        crop.advance_day();
        crop.advance_day();
        crop.advance_day();

        assert_eq!(crop.state, CropState::Dead);
    }

    #[test]
    fn test_multi_harvest() {
        let mut params = CropGrowthParams::new();
        params.growth_days = 13;
        params.multi_harvest = true;
        params.regrowth_days = 4;

        let mut crop = CropEntity::new(params);

        // Grow to harvestable
        for _ in 0..13 {
            crop.water();
            crop.advance_day();
        }
        assert_eq!(crop.state, CropState::Harvestable);

        // Harvest
        let success = crop.harvest();
        assert!(success);
        assert_eq!(crop.state, CropState::Mature);
        assert_eq!(crop.days_grown, 9); // 13 - 4

        // Regrow
        for _ in 0..4 {
            crop.water();
            crop.advance_day();
        }
        assert_eq!(crop.state, CropState::Harvestable);
    }
}
