#[derive(Debug, Clone, PartialEq)]
pub struct SwimDiveParams {
    pub base_swim_speed: f32,
    pub fluid_drag: f32,
    pub buoyancy_force: f32,
    pub max_oxygen: f32,
    pub oxygen_depletion_rate: f32,
    pub dive_speed: f32,
}

impl SwimDiveParams {
    /// Creates a new SwimDiveParams with default values based on Subnautica benchmark.
    pub fn new() -> Self {
        Self {
            base_swim_speed: 4.5,
            fluid_drag: 2.0,
            buoyancy_force: 0.5,
            max_oxygen: 45.0,
            oxygen_depletion_rate: 1.0,
            dive_speed: 5.0,
        }
    }

    /// Calculates the effective swim speed given an input vector magnitude and fluid drag.
    /// Formula: effective_speed = (base_swim_speed * input_magnitude) / fluid_drag
    pub fn calculate_effective_speed(&self, input_magnitude: f32) -> f32 {
        let clamped_input = input_magnitude.clamp(0.0, 1.0);
        (self.base_swim_speed * clamped_input) / self.fluid_drag
    }

    /// Calculates the remaining oxygen after a given time delta.
    /// Formula: new_oxygen = max(0.0, current_oxygen - (oxygen_depletion_rate * delta_time))
    pub fn calculate_remaining_oxygen(&self, current_oxygen: f32, delta_time: f32) -> f32 {
        let depletion = self.oxygen_depletion_rate * delta_time;
        (current_oxygen - depletion).max(0.0)
    }

    /// Calculates the vertical velocity component considering buoyancy and dive input.
    /// Formula: vertical_velocity = buoyancy_force - (dive_speed * dive_input)
    pub fn calculate_vertical_velocity(&self, dive_input: f32) -> f32 {
        let clamped_input = dive_input.clamp(0.0, 1.0);
        self.buoyancy_force - (self.dive_speed * clamped_input)
    }
}

impl Default for SwimDiveParams {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_effective_speed() {
        let params = SwimDiveParams::new();
        
        // Full input
        let speed_full = params.calculate_effective_speed(1.0);
        assert_eq!(speed_full, 4.5 / 2.0); // 2.25
        
        // Half input
        let speed_half = params.calculate_effective_speed(0.5);
        assert_eq!(speed_half, (4.5 * 0.5) / 2.0); // 1.125
        
        // Zero input
        let speed_zero = params.calculate_effective_speed(0.0);
        assert_eq!(speed_zero, 0.0);
    }

    #[test]
    fn test_calculate_remaining_oxygen() {
        let params = SwimDiveParams::new();
        
        // Normal depletion
        let oxygen_after_10s = params.calculate_remaining_oxygen(45.0, 10.0);
        assert_eq!(oxygen_after_10s, 35.0);
        
        // Depletion to zero
        let oxygen_empty = params.calculate_remaining_oxygen(10.0, 15.0);
        assert_eq!(oxygen_empty, 0.0);
    }

    #[test]
    fn test_calculate_vertical_velocity() {
        let params = SwimDiveParams::new();
        
        // No dive input, should float up due to buoyancy
        let vel_up = params.calculate_vertical_velocity(0.0);
        assert_eq!(vel_up, 0.5);
        
        // Full dive input, should go down
        let vel_down = params.calculate_vertical_velocity(1.0);
        assert_eq!(vel_down, 0.5 - 5.0); // -4.5
    }
}
