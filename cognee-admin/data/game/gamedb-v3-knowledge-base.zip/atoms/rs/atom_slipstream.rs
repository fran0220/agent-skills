#[derive(Debug, Clone, Copy)]
pub struct SlipstreamParams {
    pub wake_length: f32,
    pub wake_width_angle: f32,
    pub drag_reduction_max: f32,
    pub speed_threshold: f32,
    pub dirty_air_downforce_loss: f32,
}

impl SlipstreamParams {
    /// Creates a new SlipstreamParams with default values based on F1 23 benchmark.
    pub fn new() -> Self {
        Self {
            wake_length: 60.0,
            wake_width_angle: 10.0,
            drag_reduction_max: 0.18,
            speed_threshold: 30.0,
            dirty_air_downforce_loss: 0.30,
        }
    }
}

impl Default for SlipstreamParams {
    fn default() -> Self {
        Self::new()
    }
}

/// Calculates the drag reduction multiplier based on distance and angle to the leading vehicle.
/// Returns a value between 0.0 (no reduction) and `drag_reduction_max`.
pub fn calculate_drag_reduction(
    params: &SlipstreamParams,
    distance: f32,
    angle_degrees: f32,
    leader_speed: f32,
) -> f32 {
    if leader_speed < params.speed_threshold {
        return 0.0;
    }

    if distance < 0.0 || distance > params.wake_length {
        return 0.0;
    }

    if angle_degrees.abs() > params.wake_width_angle {
        return 0.0;
    }

    // Linear falloff based on distance and angle
    let distance_factor = 1.0 - (distance / params.wake_length);
    let angle_factor = 1.0 - (angle_degrees.abs() / params.wake_width_angle);

    params.drag_reduction_max * distance_factor * angle_factor
}

/// Calculates the downforce loss multiplier due to dirty air.
/// Returns a value between 0.0 (no loss) and `dirty_air_downforce_loss`.
pub fn calculate_dirty_air_loss(
    params: &SlipstreamParams,
    distance: f32,
    angle_degrees: f32,
) -> f32 {
    if distance < 0.0 || distance > params.wake_length {
        return 0.0;
    }

    if angle_degrees.abs() > params.wake_width_angle {
        return 0.0;
    }

    // Dirty air effect is stronger closer to the leading vehicle
    let distance_factor = 1.0 - (distance / params.wake_length);
    let angle_factor = 1.0 - (angle_degrees.abs() / params.wake_width_angle);

    params.dirty_air_downforce_loss * distance_factor * angle_factor
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_drag_reduction_optimal_position() {
        let params = SlipstreamParams::new();
        // Very close, directly behind, leader going fast
        let reduction = calculate_drag_reduction(&params, 0.0, 0.0, 50.0);
        assert!((reduction - params.drag_reduction_max).abs() < f32::EPSILON);
    }

    #[test]
    fn test_drag_reduction_out_of_wake() {
        let params = SlipstreamParams::new();
        // Too far away
        let reduction_far = calculate_drag_reduction(&params, 100.0, 0.0, 50.0);
        assert_eq!(reduction_far, 0.0);

        // Too wide angle
        let reduction_wide = calculate_drag_reduction(&params, 10.0, 20.0, 50.0);
        assert_eq!(reduction_wide, 0.0);

        // Leader too slow
        let reduction_slow = calculate_drag_reduction(&params, 10.0, 0.0, 20.0);
        assert_eq!(reduction_slow, 0.0);
    }

    #[test]
    fn test_dirty_air_loss() {
        let params = SlipstreamParams::new();
        // Very close, directly behind
        let loss = calculate_dirty_air_loss(&params, 0.0, 0.0);
        assert!((loss - params.dirty_air_downforce_loss).abs() < f32::EPSILON);

        // Halfway back
        let loss_half = calculate_dirty_air_loss(&params, params.wake_length / 2.0, 0.0);
        assert!((loss_half - (params.dirty_air_downforce_loss / 2.0)).abs() < f32::EPSILON);
    }
}
