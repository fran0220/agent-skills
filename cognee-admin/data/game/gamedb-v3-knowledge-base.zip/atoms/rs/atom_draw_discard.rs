#[derive(Debug, Clone)]
pub struct DrawDiscardParams {
    pub draw_amount: u32,
    pub max_hand_size: u32,
    pub reshuffle_penalty: u32,
    pub initial_deck_size: u32,
}

impl DrawDiscardParams {
    /// Creates a new DrawDiscardParams with default values based on Slay the Spire v2.3 benchmark.
    pub fn new() -> Self {
        Self {
            draw_amount: 5,
            max_hand_size: 10,
            reshuffle_penalty: 0,
            initial_deck_size: 10,
        }
    }
}

#[derive(Debug, Clone)]
pub struct DrawDiscardState {
    pub draw_pile: u32,
    pub discard_pile: u32,
    pub hand: u32,
    pub health: u32,
}

impl DrawDiscardState {
    pub fn new(initial_deck_size: u32, health: u32) -> Self {
        Self {
            draw_pile: initial_deck_size,
            discard_pile: 0,
            hand: 0,
            health,
        }
    }

    /// Simulates drawing cards, handling reshuffling and penalties if the draw pile is empty.
    /// Returns the number of cards actually drawn.
    pub fn draw_cards(&mut self, params: &DrawDiscardParams) -> u32 {
        let mut cards_drawn = 0;
        let mut cards_to_draw = params.draw_amount;

        // Limit draw by max hand size
        if self.hand + cards_to_draw > params.max_hand_size {
            cards_to_draw = params.max_hand_size.saturating_sub(self.hand);
        }

        while cards_to_draw > 0 {
            if self.draw_pile > 0 {
                self.draw_pile -= 1;
                self.hand += 1;
                cards_drawn += 1;
                cards_to_draw -= 1;
            } else if self.discard_pile > 0 {
                // Reshuffle
                self.draw_pile = self.discard_pile;
                self.discard_pile = 0;
                self.health = self.health.saturating_sub(params.reshuffle_penalty);
            } else {
                // No cards left to draw or reshuffle
                break;
            }
        }

        cards_drawn
    }

    /// Discards a specified number of cards from the hand.
    pub fn discard_cards(&mut self, amount: u32) -> u32 {
        let actual_discard = amount.min(self.hand);
        self.hand -= actual_discard;
        self.discard_pile += actual_discard;
        actual_discard
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_draw_with_reshuffle() {
        let params = DrawDiscardParams {
            draw_amount: 5,
            max_hand_size: 10,
            reshuffle_penalty: 2,
            initial_deck_size: 10,
        };
        let mut state = DrawDiscardState::new(3, 10); // 3 in draw pile, 10 health

        // Put 4 cards in discard pile
        state.discard_pile = 4;

        // Draw 5 cards. Should draw 3, reshuffle (take 2 damage), then draw 2 more.
        let drawn = state.draw_cards(&params);

        assert_eq!(drawn, 5);
        assert_eq!(state.hand, 5);
        assert_eq!(state.draw_pile, 2); // 4 reshuffled - 2 drawn
        assert_eq!(state.discard_pile, 0);
        assert_eq!(state.health, 8); // 10 - 2 penalty
    }

    #[test]
    fn test_max_hand_size_limit() {
        let params = DrawDiscardParams::new(); // max hand size 10, draw 5
        let mut state = DrawDiscardState::new(20, 10);

        state.hand = 8; // Already have 8 cards

        let drawn = state.draw_cards(&params);

        assert_eq!(drawn, 2); // Can only draw 2 to reach max hand size of 10
        assert_eq!(state.hand, 10);
        assert_eq!(state.draw_pile, 18);
    }
}
