#[derive(Debug, Clone, PartialEq)]
pub struct BodyHidingParams {
    pub carry_speed_multiplier: f32,
    pub pickup_duration: f32,
    pub conceal_duration: f32,
    pub container_capacity: u32,
    pub noise_radius_drop: f32,
}

impl BodyHidingParams {
    /// Creates a new BodyHidingParams with default values based on Hitman 3 benchmarks.
    pub fn new() -> Self {
        Self {
            carry_speed_multiplier: 0.6,
            pickup_duration: 1.5,
            conceal_duration: 2.0,
            container_capacity: 2,
            noise_radius_drop: 3.0,
        }
    }

    /// Calculates the effective movement speed while carrying a body.
    /// 
    /// # Arguments
    /// * `base_speed` - The character's normal movement speed.
    /// 
    /// # Returns
    /// The adjusted movement speed.
    pub fn calculate_carry_speed(&self, base_speed: f32) -> f32 {
        base_speed * self.carry_speed_multiplier
    }

    /// Determines if a body can be hidden in a specific container.
    /// 
    /// # Arguments
    /// * `current_bodies_in_container` - The number of bodies currently in the container.
    /// 
    /// # Returns
    /// `true` if the container has space, `false` otherwise.
    pub fn can_hide_in_container(&self, current_bodies_in_container: u32) -> bool {
        current_bodies_in_container < self.container_capacity
    }

    /// Calculates the total time required to pick up and conceal a body.
    /// 
    /// # Returns
    /// The total duration in seconds.
    pub fn total_hiding_time(&self) -> f32 {
        self.pickup_duration + self.conceal_duration
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_carry_speed() {
        let params = BodyHidingParams::new();
        let base_speed = 5.0;
        let expected_speed = 5.0 * 0.6;
        assert_eq!(params.calculate_carry_speed(base_speed), expected_speed);
    }

    #[test]
    fn test_can_hide_in_container() {
        let params = BodyHidingParams::new();
        
        // Container is empty
        assert!(params.can_hide_in_container(0));
        
        // Container has 1 body (capacity is 2)
        assert!(params.can_hide_in_container(1));
        
        // Container is full
        assert!(!params.can_hide_in_container(2));
        
        // Container is overfull
        assert!(!params.can_hide_in_container(3));
    }

    #[test]
    fn test_total_hiding_time() {
        let params = BodyHidingParams::new();
        let expected_time = 1.5 + 2.0;
        assert_eq!(params.total_hiding_time(), expected_time);
    }
}
