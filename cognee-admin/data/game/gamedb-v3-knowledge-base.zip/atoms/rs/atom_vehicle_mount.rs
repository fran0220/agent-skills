pub struct VehicleMountParams {
    pub max_speed: f32,
    pub acceleration: f32,
    pub turn_speed: f32,
    pub mount_health: f32,
    pub stamina_capacity: f32,
    pub mount_time: f32,
    pub dismount_time: f32,
    pub collision_damage_multiplier: f32,
}

impl VehicleMountParams {
    /// Creates a new VehicleMountParams with default values based on benchmark data.
    pub fn new() -> Self {
        Self {
            max_speed: 25.0,
            acceleration: 8.0,
            turn_speed: 90.0,
            mount_health: 150.0,
            stamina_capacity: 5.0,
            mount_time: 1.2,
            dismount_time: 0.8,
            collision_damage_multiplier: 2.0,
        }
    }

    /// Calculates the new speed after applying acceleration for a given delta time.
    /// Speed is capped at max_speed.
    pub fn calculate_speed(&self, current_speed: f32, delta_time: f32, is_accelerating: bool) -> f32 {
        if is_accelerating {
            let new_speed = current_speed + self.acceleration * delta_time;
            if new_speed > self.max_speed {
                self.max_speed
            } else {
                new_speed
            }
        } else {
            // Simple friction/deceleration when not accelerating
            let deceleration = self.acceleration * 0.5;
            let new_speed = current_speed - deceleration * delta_time;
            if new_speed < 0.0 {
                0.0
            } else {
                new_speed
            }
        }
    }

    /// Calculates the damage taken by the mount upon collision based on impact speed.
    pub fn calculate_collision_damage(&self, impact_speed: f32) -> f32 {
        // Base damage is proportional to impact speed and the collision multiplier
        impact_speed * self.collision_damage_multiplier
    }

    /// Checks if the mount is destroyed based on current health and incoming damage.
    pub fn is_destroyed(&self, current_health: f32, incoming_damage: f32) -> bool {
        current_health - incoming_damage <= 0.0
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_speed_acceleration() {
        let params = VehicleMountParams::new();
        let initial_speed = 10.0;
        let delta_time = 1.0;
        
        // Accelerating for 1 second at 8.0 m/s^2
        let new_speed = params.calculate_speed(initial_speed, delta_time, true);
        assert_eq!(new_speed, 18.0);
        
        // Accelerating beyond max speed
        let high_speed = 20.0;
        let capped_speed = params.calculate_speed(high_speed, delta_time, true);
        assert_eq!(capped_speed, 25.0); // Capped at max_speed (25.0)
    }

    #[test]
    fn test_calculate_collision_damage() {
        let params = VehicleMountParams::new();
        let impact_speed = 15.0;
        
        let damage = params.calculate_collision_damage(impact_speed);
        assert_eq!(damage, 30.0); // 15.0 * 2.0 (collision_damage_multiplier)
    }

    #[test]
    fn test_is_destroyed() {
        let params = VehicleMountParams::new();
        
        assert!(params.is_destroyed(50.0, 60.0));
        assert!(!params.is_destroyed(100.0, 50.0));
    }
}
