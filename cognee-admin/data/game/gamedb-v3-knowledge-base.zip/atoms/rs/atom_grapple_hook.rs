#[derive(Debug, Clone, PartialEq)]
pub struct GrappleHookParams {
    pub max_range: f32,
    pub extension_speed: f32,
    pub pull_acceleration: f32,
    pub max_pull_speed: f32,
    pub cooldown: f32,
    pub auto_aim_angle: f32,
    pub swing_gravity_scale: f32,
    pub detach_jump_boost: f32,
}

impl GrappleHookParams {
    /// Creates a new GrappleHookParams with default values based on benchmark data (Just Cause 4 / Sekiro).
    pub fn new() -> Self {
        Self {
            max_range: 50.0,
            extension_speed: 120.0,
            pull_acceleration: 45.0,
            max_pull_speed: 40.0,
            cooldown: 0.5,
            auto_aim_angle: 15.0,
            swing_gravity_scale: 1.2,
            detach_jump_boost: 10.0,
        }
    }

    /// Calculates the time it takes for the grapple hook to reach a target at a given distance.
    /// Returns None if the distance exceeds the max_range.
    pub fn calculate_extension_time(&self, distance: f32) -> Option<f32> {
        if distance > self.max_range {
            return None;
        }
        Some(distance / self.extension_speed)
    }

    /// Calculates the new pull speed after applying acceleration over a given delta time.
    /// The speed is capped at max_pull_speed.
    pub fn calculate_pull_speed(&self, current_speed: f32, delta_time: f32) -> f32 {
        let new_speed = current_speed + (self.pull_acceleration * delta_time);
        if new_speed > self.max_pull_speed {
            self.max_pull_speed
        } else {
            new_speed
        }
    }

    /// Calculates the effective gravity applied to the player while swinging.
    pub fn calculate_swing_gravity(&self, base_gravity: f32) -> f32 {
        base_gravity * self.swing_gravity_scale
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_extension_time() {
        let params = GrappleHookParams::new();
        
        // Within range
        let time = params.calculate_extension_time(24.0);
        assert_eq!(time, Some(0.2)); // 24.0 / 120.0 = 0.2
        
        // Out of range
        let time_out = params.calculate_extension_time(60.0);
        assert_eq!(time_out, None);
    }

    #[test]
    fn test_pull_speed() {
        let params = GrappleHookParams::new();
        
        // Normal acceleration
        let speed1 = params.calculate_pull_speed(10.0, 0.5);
        assert_eq!(speed1, 32.5); // 10.0 + (45.0 * 0.5) = 32.5
        
        // Capped at max speed
        let speed2 = params.calculate_pull_speed(30.0, 0.5);
        assert_eq!(speed2, 40.0); // 30.0 + 22.5 = 52.5, capped at 40.0
    }

    #[test]
    fn test_swing_gravity() {
        let params = GrappleHookParams::new();
        let gravity = params.calculate_swing_gravity(9.81);
        assert_eq!(gravity, 9.81 * 1.2);
    }
}
