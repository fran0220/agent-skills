#[derive(Debug, Clone)]
pub struct SeasonRankParams {
    pub placement_matches: u32,
    pub season_duration_days: u32,
    pub tiers_count: u32,
    pub divisions_per_tier: u32,
    pub points_per_division: u32,
    pub win_point_gain: f32,
    pub loss_point_deduction: f32,
    pub demotion_protection_games: u32,
}

impl SeasonRankParams {
    pub fn new() -> Self {
        Self {
            placement_matches: 5,
            season_duration_days: 90,
            tiers_count: 9,
            divisions_per_tier: 4,
            points_per_division: 100,
            win_point_gain: 20.0,
            loss_point_deduction: 15.0,
            demotion_protection_games: 3,
        }
    }

    /// Calculates the new points after a match result.
    /// `current_points`: The player's current rank points.
    /// `is_win`: Whether the player won the match.
    /// `performance_multiplier`: A multiplier based on individual performance (1.0 is average).
    pub fn calculate_new_points(&self, current_points: f32, is_win: bool, performance_multiplier: f32) -> f32 {
        if is_win {
            current_points + (self.win_point_gain * performance_multiplier)
        } else {
            let deduction = self.loss_point_deduction / performance_multiplier;
            let new_points = current_points - deduction;
            if new_points < 0.0 {
                0.0
            } else {
                new_points
            }
        }
    }

    /// Determines the tier and division based on total points.
    /// Returns a tuple of (tier, division).
    pub fn get_tier_and_division(&self, total_points: f32) -> (u32, u32) {
        let points_per_tier = (self.divisions_per_tier * self.points_per_division) as f32;
        let tier = (total_points / points_per_tier).floor() as u32;
        
        if tier >= self.tiers_count {
            return (self.tiers_count - 1, self.divisions_per_tier - 1);
        }
        
        let remaining_points = total_points - (tier as f32 * points_per_tier);
        let division = (remaining_points / self.points_per_division as f32).floor() as u32;
        
        (tier, division)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_new_points() {
        let params = SeasonRankParams::new();
        
        // Win with average performance
        let points_after_win = params.calculate_new_points(100.0, true, 1.0);
        assert_eq!(points_after_win, 120.0);
        
        // Loss with average performance
        let points_after_loss = params.calculate_new_points(100.0, false, 1.0);
        assert_eq!(points_after_loss, 85.0);
        
        // Loss resulting in 0 points (no negative points)
        let points_after_heavy_loss = params.calculate_new_points(10.0, false, 1.0);
        assert_eq!(points_after_heavy_loss, 0.0);
    }

    #[test]
    fn test_get_tier_and_division() {
        let params = SeasonRankParams::new();
        // points_per_tier = 4 * 100 = 400
        
        // 0 points -> Tier 0, Division 0
        assert_eq!(params.get_tier_and_division(0.0), (0, 0));
        
        // 150 points -> Tier 0, Division 1
        assert_eq!(params.get_tier_and_division(150.0), (0, 1));
        
        // 450 points -> Tier 1, Division 0
        assert_eq!(params.get_tier_and_division(450.0), (1, 0));
        
        // Max points (e.g., 4000) -> Max Tier, Max Division
        assert_eq!(params.get_tier_and_division(4000.0), (8, 3));
    }
}
