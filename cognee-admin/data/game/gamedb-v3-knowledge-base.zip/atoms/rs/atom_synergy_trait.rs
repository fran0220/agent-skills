#[derive(Debug, Clone)]
pub struct SynergyTraitParameters {
    pub trait_thresholds: Vec<u32>,
    pub bonus_magnitude: f32,
    pub unique_requirement: bool,
    pub max_traits_per_entity: u32,
}

impl SynergyTraitParameters {
    /// Creates a new SynergyTraitParameters with default values based on TFT Set 9 benchmark.
    pub fn new() -> Self {
        Self {
            trait_thresholds: vec![3, 5, 7, 9],
            bonus_magnitude: 0.15,
            unique_requirement: true,
            max_traits_per_entity: 3,
        }
    }

    /// Calculates the active tier of the synergy based on the count of entities.
    /// Returns the index of the highest threshold met (0-indexed), or None if no threshold is met.
    pub fn calculate_active_tier(&self, entity_count: u32) -> Option<usize> {
        let mut active_tier = None;
        for (index, &threshold) in self.trait_thresholds.iter().enumerate() {
            if entity_count >= threshold {
                active_tier = Some(index);
            } else {
                break;
            }
        }
        active_tier
    }

    /// Calculates the total bonus multiplier based on the active tier.
    /// The bonus scales linearly with the tier level (tier 1 = 1x bonus, tier 2 = 2x bonus, etc.).
    pub fn calculate_total_bonus(&self, entity_count: u32) -> f32 {
        if let Some(tier) = self.calculate_active_tier(entity_count) {
            // Tier is 0-indexed, so we add 1 to get the multiplier
            let tier_multiplier = (tier + 1) as f32;
            tier_multiplier * self.bonus_magnitude
        } else {
            0.0
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_active_tier() {
        let params = SynergyTraitParameters::new();
        
        // Below first threshold
        assert_eq!(params.calculate_active_tier(2), None);
        
        // Exactly at first threshold
        assert_eq!(params.calculate_active_tier(3), Some(0));
        
        // Between first and second threshold
        assert_eq!(params.calculate_active_tier(4), Some(0));
        
        // At highest threshold
        assert_eq!(params.calculate_active_tier(9), Some(3));
        
        // Above highest threshold
        assert_eq!(params.calculate_active_tier(12), Some(3));
    }

    #[test]
    fn test_calculate_total_bonus() {
        let params = SynergyTraitParameters::new();
        
        // No bonus
        assert_eq!(params.calculate_total_bonus(2), 0.0);
        
        // Tier 1 bonus (1 * 0.15)
        assert_eq!(params.calculate_total_bonus(3), 0.15);
        
        // Tier 2 bonus (2 * 0.15)
        assert_eq!(params.calculate_total_bonus(5), 0.30);
        
        // Tier 4 bonus (4 * 0.15)
        assert_eq!(params.calculate_total_bonus(10), 0.60);
    }
}
