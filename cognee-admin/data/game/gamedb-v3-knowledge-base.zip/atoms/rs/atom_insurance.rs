#[derive(Debug, Clone)]
pub struct InsuranceParameters {
    pub premium_rate: f32,
    pub return_time_min: u32,
    pub return_time_max: u32,
    pub claim_duration: u32,
    pub return_chance: f32,
}

impl InsuranceParameters {
    pub fn new() -> Self {
        Self {
            premium_rate: 0.10,
            return_time_min: 12,
            return_time_max: 24,
            claim_duration: 72,
            return_chance: 1.0,
        }
    }
}

pub struct InsuranceSystem {
    pub params: InsuranceParameters,
}

impl InsuranceSystem {
    pub fn new(params: InsuranceParameters) -> Self {
        Self { params }
    }

    pub fn calculate_premium(&self, item_value: f32) -> f32 {
        item_value * self.params.premium_rate
    }

    pub fn calculate_return_time(&self, random_factor: f32) -> u32 {
        let range = self.params.return_time_max - self.params.return_time_min;
        self.params.return_time_min + (range as f32 * random_factor) as u32
    }

    pub fn is_returned(&self, random_roll: f32) -> bool {
        random_roll <= self.params.return_chance
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_premium() {
        let params = InsuranceParameters::new();
        let system = InsuranceSystem::new(params);
        let premium = system.calculate_premium(1000.0);
        assert_eq!(premium, 100.0);
    }

    #[test]
    fn test_calculate_return_time() {
        let params = InsuranceParameters::new();
        let system = InsuranceSystem::new(params);
        let time = system.calculate_return_time(0.5);
        assert_eq!(time, 18);
    }

    #[test]
    fn test_is_returned() {
        let mut params = InsuranceParameters::new();
        params.return_chance = 0.8;
        let system = InsuranceSystem::new(params);
        assert!(system.is_returned(0.5));
        assert!(!system.is_returned(0.9));
    }
}
