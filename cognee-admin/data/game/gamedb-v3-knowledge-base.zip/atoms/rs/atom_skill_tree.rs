#[derive(Debug, Clone)]
pub struct SkillTreeParams {
    pub total_nodes: u32,
    pub max_points: u32,
    pub points_per_level: u32,
    pub respec_cost: f32,
    pub branching_factor: f32,
}

impl SkillTreeParams {
    /// Creates a new SkillTreeParams with default values based on Path of Exile benchmarks.
    pub fn new() -> Self {
        Self {
            total_nodes: 1328,
            max_points: 123,
            points_per_level: 1,
            respec_cost: 1.0,
            branching_factor: 2.5,
        }
    }

    /// Calculates the total number of skill points available at a given character level.
    /// Assumes level 1 starts with 0 points from leveling.
    pub fn calculate_available_points(&self, current_level: u32, quest_points: u32) -> u32 {
        if current_level == 0 {
            return quest_points;
        }
        let level_points = (current_level - 1) * self.points_per_level;
        let total = level_points + quest_points;
        if total > self.max_points {
            self.max_points
        } else {
            total
        }
    }

    /// Calculates the total cost to respec a given number of nodes.
    pub fn calculate_respec_cost(&self, nodes_to_respec: u32) -> f32 {
        (nodes_to_respec as f32) * self.respec_cost
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_available_points() {
        let params = SkillTreeParams::new();
        
        // Level 1, 0 quest points -> 0 points
        assert_eq!(params.calculate_available_points(1, 0), 0);
        
        // Level 10, 2 quest points -> 9 * 1 + 2 = 11 points
        assert_eq!(params.calculate_available_points(10, 2), 11);
        
        // Exceeding max points
        assert_eq!(params.calculate_available_points(150, 30), params.max_points);
    }

    #[test]
    fn test_calculate_respec_cost() {
        let params = SkillTreeParams::new();
        
        // Respec 5 nodes at 1.0 cost each
        assert_eq!(params.calculate_respec_cost(5), 5.0);
        
        // Respec 0 nodes
        assert_eq!(params.calculate_respec_cost(0), 0.0);
    }
}
