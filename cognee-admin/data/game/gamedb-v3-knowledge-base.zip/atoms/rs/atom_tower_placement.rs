#[derive(Debug, Clone, PartialEq)]
pub struct TowerPlacementParams {
    pub cost: u32,
    pub footprint_radius: f32,
    pub attack_range: f32,
    pub build_time: f32,
    pub refund_rate: f32,
}

impl TowerPlacementParams {
    /// Creates a new TowerPlacementParams with default values based on benchmark data (e.g., Bloons TD 6 Dart Monkey).
    pub fn new() -> Self {
        Self {
            cost: 200,
            footprint_radius: 1.0,
            attack_range: 32.0,
            build_time: 0.0,
            refund_rate: 0.7,
        }
    }

    /// Checks if the player has enough resources to afford the tower.
    pub fn can_afford(&self, current_resources: u32) -> bool {
        current_resources >= self.cost
    }

    /// Calculates the refund amount when the tower is sold or destroyed.
    pub fn calculate_refund(&self) -> u32 {
        (self.cost as f32 * self.refund_rate).floor() as u32
    }

    /// Checks if a target is within the tower's attack range.
    pub fn is_in_range(&self, tower_x: f32, tower_y: f32, target_x: f32, target_y: f32) -> bool {
        let dx = target_x - tower_x;
        let dy = target_y - tower_y;
        let distance_squared = dx * dx + dy * dy;
        distance_squared <= self.attack_range * self.attack_range
    }
}

impl Default for TowerPlacementParams {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_can_afford() {
        let params = TowerPlacementParams::new();
        assert!(params.can_afford(250));
        assert!(params.can_afford(200));
        assert!(!params.can_afford(150));
    }

    #[test]
    fn test_calculate_refund() {
        let params = TowerPlacementParams::new();
        // Cost is 200, refund rate is 0.7. Refund should be 140.
        assert_eq!(params.calculate_refund(), 140);
        
        let mut custom_params = TowerPlacementParams::new();
        custom_params.cost = 70;
        custom_params.refund_rate = 0.6;
        // Cost is 70, refund rate is 0.6. Refund should be 42.
        assert_eq!(custom_params.calculate_refund(), 42);
    }

    #[test]
    fn test_is_in_range() {
        let mut params = TowerPlacementParams::new();
        params.attack_range = 5.0;
        
        // Target exactly on the edge
        assert!(params.is_in_range(0.0, 0.0, 3.0, 4.0));
        
        // Target inside
        assert!(params.is_in_range(0.0, 0.0, 2.0, 2.0));
        
        // Target outside
        assert!(!params.is_in_range(0.0, 0.0, 4.0, 4.0));
    }
}
