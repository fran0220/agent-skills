#[derive(Debug, Clone, PartialEq)]
pub struct StarRatingParams {
    pub star_1_threshold: u32,
    pub star_2_threshold: u32,
    pub star_3_threshold: u32,
    pub max_stars: u8,
}

impl StarRatingParams {
    /// Creates a new StarRatingParams with default values based on Candy Crush Saga v1.2 benchmark.
    pub fn new() -> Self {
        Self {
            star_1_threshold: 1000,
            star_2_threshold: 2500,
            star_3_threshold: 5000,
            max_stars: 3,
        }
    }

    /// Calculates the number of stars earned based on the final score.
    pub fn calculate_stars(&self, score: u32) -> u8 {
        if score >= self.star_3_threshold {
            3
        } else if score >= self.star_2_threshold {
            2
        } else if score >= self.star_1_threshold {
            1
        } else {
            0
        }
    }

    /// Calculates the progress percentage towards the next star.
    /// Returns 1.0 if max stars are already achieved.
    pub fn progress_to_next_star(&self, score: u32) -> f32 {
        if score >= self.star_3_threshold {
            return 1.0;
        }

        let (current_threshold, next_threshold) = if score >= self.star_2_threshold {
            (self.star_2_threshold, self.star_3_threshold)
        } else if score >= self.star_1_threshold {
            (self.star_1_threshold, self.star_2_threshold)
        } else {
            (0, self.star_1_threshold)
        };

        let progress = (score - current_threshold) as f32 / (next_threshold - current_threshold) as f32;
        progress.clamp(0.0, 1.0)
    }
}

impl Default for StarRatingParams {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_stars() {
        let params = StarRatingParams::new();
        
        assert_eq!(params.calculate_stars(500), 0);
        assert_eq!(params.calculate_stars(1000), 1);
        assert_eq!(params.calculate_stars(1500), 1);
        assert_eq!(params.calculate_stars(2500), 2);
        assert_eq!(params.calculate_stars(4999), 2);
        assert_eq!(params.calculate_stars(5000), 3);
        assert_eq!(params.calculate_stars(10000), 3);
    }

    #[test]
    fn test_progress_to_next_star() {
        let params = StarRatingParams::new();
        
        // Progress to 1st star (0 to 1000)
        assert_eq!(params.progress_to_next_star(500), 0.5);
        
        // Progress to 2nd star (1000 to 2500)
        assert_eq!(params.progress_to_next_star(1750), 0.5);
        
        // Progress to 3rd star (2500 to 5000)
        assert_eq!(params.progress_to_next_star(3750), 0.5);
        
        // Max stars achieved
        assert_eq!(params.progress_to_next_star(5000), 1.0);
        assert_eq!(params.progress_to_next_star(6000), 1.0);
    }
}
