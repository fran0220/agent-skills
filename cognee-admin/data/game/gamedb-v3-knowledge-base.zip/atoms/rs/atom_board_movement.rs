pub struct BoardMovementParams {
    pub dice_count: u32,
    pub faces_per_die: u32,
    pub move_speed: f32,
    pub base_modifier: i32,
}

impl BoardMovementParams {
    pub fn new() -> Self {
        Self {
            dice_count: 1,
            faces_per_die: 6,
            move_speed: 2.5,
            base_modifier: 0,
        }
    }

    pub fn calculate_max_roll(&self) -> u32 {
        self.dice_count * self.faces_per_die
    }

    pub fn calculate_min_roll(&self) -> u32 {
        self.dice_count
    }

    pub fn calculate_total_movement(&self, roll_result: u32) -> i32 {
        roll_result as i32 + self.base_modifier
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_max_roll() {
        let params = BoardMovementParams {
            dice_count: 2,
            faces_per_die: 6,
            move_speed: 2.5,
            base_modifier: 0,
        };
        assert_eq!(params.calculate_max_roll(), 12);
    }

    #[test]
    fn test_calculate_min_roll() {
        let params = BoardMovementParams {
            dice_count: 2,
            faces_per_die: 6,
            move_speed: 2.5,
            base_modifier: 0,
        };
        assert_eq!(params.calculate_min_roll(), 2);
    }

    #[test]
    fn test_calculate_total_movement() {
        let params = BoardMovementParams {
            dice_count: 1,
            faces_per_die: 6,
            move_speed: 2.5,
            base_modifier: -1,
        };
        assert_eq!(params.calculate_total_movement(4), 3);
    }
}
