#[derive(Debug, Clone, PartialEq)]
pub struct EnergyPerTurnParams {
    pub base_energy: u32,
    pub max_energy: u32,
    pub carry_over: bool,
}

impl EnergyPerTurnParams {
    pub fn new() -> Self {
        Self {
            base_energy: 3,
            max_energy: 999,
            carry_over: false,
        }
    }
}

#[derive(Debug, Clone, PartialEq)]
pub struct EnergyState {
    pub current_energy: u32,
    pub params: EnergyPerTurnParams,
}

impl EnergyState {
    pub fn new(params: EnergyPerTurnParams) -> Self {
        Self {
            current_energy: 0,
            params,
        }
    }

    /// Triggered at the start of the turn to regenerate energy.
    pub fn on_turn_start(&mut self) {
        if self.params.carry_over {
            self.current_energy = std::cmp::min(
                self.current_energy + self.params.base_energy,
                self.params.max_energy,
            );
        } else {
            self.current_energy = std::cmp::min(self.params.base_energy, self.params.max_energy);
        }
    }

    /// Checks if an action with the given cost can be performed.
    pub fn can_spend(&self, cost: u32) -> bool {
        self.current_energy >= cost
    }

    /// Spends the given amount of energy if possible.
    pub fn spend(&mut self, cost: u32) -> Result<(), &'static str> {
        if self.can_spend(cost) {
            self.current_energy -= cost;
            Ok(())
        } else {
            Err("Not enough energy")
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_turn_start_no_carry_over() {
        let params = EnergyPerTurnParams::new();
        let mut state = EnergyState::new(params);
        
        state.on_turn_start();
        assert_eq!(state.current_energy, 3);
        
        // Spend some energy
        assert!(state.spend(2).is_ok());
        assert_eq!(state.current_energy, 1);
        
        // Next turn start, should reset to base_energy
        state.on_turn_start();
        assert_eq!(state.current_energy, 3);
    }

    #[test]
    fn test_turn_start_with_carry_over() {
        let mut params = EnergyPerTurnParams::new();
        params.carry_over = true;
        let mut state = EnergyState::new(params);
        
        state.on_turn_start();
        assert_eq!(state.current_energy, 3);
        
        // Spend some energy
        assert!(state.spend(1).is_ok());
        assert_eq!(state.current_energy, 2);
        
        // Next turn start, should add base_energy to current
        state.on_turn_start();
        assert_eq!(state.current_energy, 5);
    }

    #[test]
    fn test_spend_energy() {
        let params = EnergyPerTurnParams::new();
        let mut state = EnergyState::new(params);
        
        state.on_turn_start();
        
        assert!(state.can_spend(2));
        assert!(state.spend(2).is_ok());
        assert_eq!(state.current_energy, 1);
        
        assert!(!state.can_spend(2));
        assert!(state.spend(2).is_err());
        assert_eq!(state.current_energy, 1);
    }
}
