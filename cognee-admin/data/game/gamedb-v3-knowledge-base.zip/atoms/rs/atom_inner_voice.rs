#[derive(Debug, Clone)]
pub struct InnerVoiceParams {
    pub max_slots: u32,
    pub initial_slots: u32,
    pub internalization_time: f32,
    pub forget_cost: u32,
    pub unlock_slot_cost: u32,
}

impl InnerVoiceParams {
    pub fn new() -> Self {
        Self {
            max_slots: 12,
            initial_slots: 3,
            internalization_time: 4.0,
            forget_cost: 1,
            unlock_slot_cost: 1,
        }
    }
}

#[derive(Debug, Clone, PartialEq)]
pub enum ThoughtState {
    Undiscovered,
    Discovered,
    Internalizing { progress: f32 },
    Internalized,
    Forgotten,
}

#[derive(Debug, Clone)]
pub struct Thought {
    pub id: String,
    pub state: ThoughtState,
    pub required_time: f32,
}

impl Thought {
    pub fn new(id: String, required_time: f32) -> Self {
        Self {
            id,
            state: ThoughtState::Undiscovered,
            required_time,
        }
    }

    pub fn discover(&mut self) -> Result<(), &'static str> {
        if self.state == ThoughtState::Undiscovered || self.state == ThoughtState::Forgotten {
            self.state = ThoughtState::Discovered;
            Ok(())
        } else {
            Err("Thought is already discovered or in a later state.")
        }
    }

    pub fn start_internalizing(&mut self) -> Result<(), &'static str> {
        if self.state == ThoughtState::Discovered {
            self.state = ThoughtState::Internalizing { progress: 0.0 };
            Ok(())
        } else {
            Err("Thought must be discovered to start internalizing.")
        }
    }

    pub fn advance_time(&mut self, delta_time: f32) -> Result<bool, &'static str> {
        if let ThoughtState::Internalizing { ref mut progress } = self.state {
            *progress += delta_time;
            if *progress >= self.required_time {
                self.state = ThoughtState::Internalized;
                Ok(true) // Finished internalizing
            } else {
                Ok(false) // Still internalizing
            }
        } else {
            Err("Thought is not currently internalizing.")
        }
    }

    pub fn forget(&mut self) -> Result<(), &'static str> {
        if self.state == ThoughtState::Internalized {
            self.state = ThoughtState::Forgotten;
            Ok(())
        } else {
            Err("Only internalized thoughts can be forgotten.")
        }
    }
}

#[derive(Debug, Clone)]
pub struct ThoughtCabinet {
    pub params: InnerVoiceParams,
    pub unlocked_slots: u32,
    pub thoughts: Vec<Thought>,
    pub skill_points: u32,
}

impl ThoughtCabinet {
    pub fn new(params: InnerVoiceParams, skill_points: u32) -> Self {
        Self {
            unlocked_slots: params.initial_slots,
            params,
            thoughts: Vec::new(),
            skill_points,
        }
    }

    pub fn add_thought(&mut self, thought: Thought) {
        self.thoughts.push(thought);
    }

    pub fn unlock_slot(&mut self) -> Result<(), &'static str> {
        if self.unlocked_slots >= self.params.max_slots {
            return Err("Maximum slots reached.");
        }
        if self.skill_points >= self.params.unlock_slot_cost {
            self.skill_points -= self.params.unlock_slot_cost;
            self.unlocked_slots += 1;
            Ok(())
        } else {
            Err("Not enough skill points to unlock a slot.")
        }
    }

    pub fn get_active_thoughts_count(&self) -> u32 {
        self.thoughts
            .iter()
            .filter(|t| {
                matches!(
                    t.state,
                    ThoughtState::Internalizing { .. } | ThoughtState::Internalized
                )
            })
            .count() as u32
    }

    pub fn equip_thought(&mut self, thought_id: &str) -> Result<(), &'static str> {
        if self.get_active_thoughts_count() >= self.unlocked_slots {
            return Err("No empty slots available.");
        }

        if let Some(thought) = self.thoughts.iter_mut().find(|t| t.id == thought_id) {
            thought.start_internalizing()
        } else {
            Err("Thought not found.")
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_thought_state_transitions() {
        let mut thought = Thought::new("test_thought".to_string(), 4.0);
        
        assert_eq!(thought.state, ThoughtState::Undiscovered);
        
        assert!(thought.discover().is_ok());
        assert_eq!(thought.state, ThoughtState::Discovered);
        
        assert!(thought.start_internalizing().is_ok());
        if let ThoughtState::Internalizing { progress } = thought.state {
            assert_eq!(progress, 0.0);
        } else {
            panic!("Expected Internalizing state");
        }
        
        assert_eq!(thought.advance_time(2.0).unwrap(), false);
        assert_eq!(thought.advance_time(2.5).unwrap(), true);
        assert_eq!(thought.state, ThoughtState::Internalized);
        
        assert!(thought.forget().is_ok());
        assert_eq!(thought.state, ThoughtState::Forgotten);
    }

    #[test]
    fn test_thought_cabinet_slots() {
        let params = InnerVoiceParams::new();
        let mut cabinet = ThoughtCabinet::new(params, 2); // 2 skill points
        
        assert_eq!(cabinet.unlocked_slots, 3);
        
        assert!(cabinet.unlock_slot().is_ok());
        assert_eq!(cabinet.unlocked_slots, 4);
        assert_eq!(cabinet.skill_points, 1);
        
        assert!(cabinet.unlock_slot().is_ok());
        assert_eq!(cabinet.unlocked_slots, 5);
        assert_eq!(cabinet.skill_points, 0);
        
        assert!(cabinet.unlock_slot().is_err()); // Not enough skill points
    }

    #[test]
    fn test_equip_thought() {
        let params = InnerVoiceParams::new();
        let mut cabinet = ThoughtCabinet::new(params, 0);
        
        let mut t1 = Thought::new("t1".to_string(), 1.0);
        t1.discover().unwrap();
        cabinet.add_thought(t1);
        
        let mut t2 = Thought::new("t2".to_string(), 1.0);
        t2.discover().unwrap();
        cabinet.add_thought(t2);
        
        let mut t3 = Thought::new("t3".to_string(), 1.0);
        t3.discover().unwrap();
        cabinet.add_thought(t3);
        
        let mut t4 = Thought::new("t4".to_string(), 1.0);
        t4.discover().unwrap();
        cabinet.add_thought(t4);
        
        assert!(cabinet.equip_thought("t1").is_ok());
        assert!(cabinet.equip_thought("t2").is_ok());
        assert!(cabinet.equip_thought("t3").is_ok());
        
        // Initial slots is 3, so 4th should fail
        assert!(cabinet.equip_thought("t4").is_err());
    }
}
