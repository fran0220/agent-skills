#[derive(Debug, Clone, Copy)]
pub struct HitscanParameters {
    pub base_damage: f32,
    pub fire_rate: f32,
    pub max_range: f32,
    pub damage_falloff: f32,
    pub headshot_multiplier: f32,
    pub base_spread: f32,
}

impl HitscanParameters {
    /// Creates a new HitscanParameters instance with default values based on CS:GO AK-47 benchmark.
    pub fn new() -> Self {
        Self {
            base_damage: 33.0,
            fire_rate: 10.0,
            max_range: 8192.0,
            damage_falloff: 0.98, // Multiplier per 500 units
            headshot_multiplier: 4.0,
            base_spread: 0.6,
        }
    }

    /// Calculates the final damage based on distance and whether it was a headshot.
    pub fn calculate_damage(&self, distance: f32, is_headshot: bool) -> f32 {
        if distance > self.max_range {
            return 0.0;
        }

        // Calculate falloff multiplier based on distance (per 500 units)
        let falloff_steps = distance / 500.0;
        let falloff_multiplier = self.damage_falloff.powf(falloff_steps);

        let mut final_damage = self.base_damage * falloff_multiplier;

        if is_headshot {
            final_damage *= self.headshot_multiplier;
        }

        final_damage
    }

    /// Calculates the time between shots (cooldown) based on fire rate.
    pub fn calculate_cooldown(&self) -> f32 {
        if self.fire_rate <= 0.0 {
            return 0.0;
        }
        1.0 / self.fire_rate
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_damage_point_blank() {
        let params = HitscanParameters::new();
        
        // Point blank body shot
        let damage = params.calculate_damage(0.0, false);
        assert!((damage - 33.0).abs() < f32::EPSILON);

        // Point blank headshot
        let hs_damage = params.calculate_damage(0.0, true);
        assert!((hs_damage - 132.0).abs() < f32::EPSILON);
    }

    #[test]
    fn test_calculate_damage_with_falloff() {
        let params = HitscanParameters::new();
        
        // 500 units away, should apply 0.98 multiplier once
        let damage_500 = params.calculate_damage(500.0, false);
        assert!((damage_500 - (33.0 * 0.98)).abs() < f32::EPSILON);

        // 1000 units away, should apply 0.98 multiplier twice
        let damage_1000 = params.calculate_damage(1000.0, false);
        assert!((damage_1000 - (33.0 * 0.98 * 0.98)).abs() < 0.001);
    }

    #[test]
    fn test_calculate_damage_out_of_range() {
        let params = HitscanParameters::new();
        
        // Beyond max range
        let damage = params.calculate_damage(9000.0, false);
        assert_eq!(damage, 0.0);
    }

    #[test]
    fn test_calculate_cooldown() {
        let params = HitscanParameters::new();
        
        // 10 rounds per second = 0.1 seconds per round
        let cooldown = params.calculate_cooldown();
        assert!((cooldown - 0.1).abs() < f32::EPSILON);
    }
}
