#[derive(Debug, Clone, Copy)]
pub struct CoyoteTimeParams {
    pub coyote_time_duration: f32,
    pub allow_coyote_jump: bool,
    pub coyote_jump_velocity_multiplier: f32,
}

impl CoyoteTimeParams {
    /// Creates a new CoyoteTimeParams with default values based on Celeste benchmarks.
    pub fn new() -> Self {
        Self {
            coyote_time_duration: 0.083, // ~5 frames at 60fps
            allow_coyote_jump: true,
            coyote_jump_velocity_multiplier: 1.0,
        }
    }
}

impl Default for CoyoteTimeParams {
    fn default() -> Self {
        Self::new()
    }
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub enum PlayerState {
    Grounded,
    CoyoteTimeActive,
    Jumping,
    Falling,
}

pub struct CoyoteTimeState {
    pub params: CoyoteTimeParams,
    pub current_state: PlayerState,
    pub time_since_left_ground: f32,
}

impl CoyoteTimeState {
    pub fn new(params: CoyoteTimeParams) -> Self {
        Self {
            params,
            current_state: PlayerState::Grounded,
            time_since_left_ground: 0.0,
        }
    }

    /// Updates the coyote time state based on delta time and ground contact.
    pub fn update(&mut self, delta_time: f32, is_grounded: bool) {
        if is_grounded {
            self.current_state = PlayerState::Grounded;
            self.time_since_left_ground = 0.0;
        } else {
            if self.current_state == PlayerState::Grounded {
                self.current_state = PlayerState::CoyoteTimeActive;
                self.time_since_left_ground = 0.0;
            }

            if self.current_state == PlayerState::CoyoteTimeActive {
                self.time_since_left_ground += delta_time;
                if self.time_since_left_ground > self.params.coyote_time_duration {
                    self.current_state = PlayerState::Falling;
                }
            }
        }
    }

    /// Attempts to execute a jump. Returns true if a jump (including coyote jump) was successful.
    pub fn try_jump(&mut self) -> bool {
        if self.current_state == PlayerState::Grounded {
            self.current_state = PlayerState::Jumping;
            return true;
        }

        if self.current_state == PlayerState::CoyoteTimeActive && self.params.allow_coyote_jump {
            self.current_state = PlayerState::Jumping;
            return true;
        }

        false
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_coyote_jump_success() {
        let params = CoyoteTimeParams::new();
        let mut state = CoyoteTimeState::new(params);

        // Start grounded
        state.update(0.016, true);
        assert_eq!(state.current_state, PlayerState::Grounded);

        // Leave ground
        state.update(0.016, false);
        assert_eq!(state.current_state, PlayerState::CoyoteTimeActive);

        // Try jump within coyote time (0.016 < 0.083)
        let jump_success = state.try_jump();
        assert!(jump_success);
        assert_eq!(state.current_state, PlayerState::Jumping);
    }

    #[test]
    fn test_coyote_jump_failure_after_timeout() {
        let params = CoyoteTimeParams::new();
        let mut state = CoyoteTimeState::new(params);

        // Start grounded
        state.update(0.016, true);
        
        // Leave ground
        state.update(0.016, false);
        
        // Wait past coyote time
        state.update(0.1, false);
        assert_eq!(state.current_state, PlayerState::Falling);

        // Try jump
        let jump_success = state.try_jump();
        assert!(!jump_success);
        assert_eq!(state.current_state, PlayerState::Falling);
    }
}
