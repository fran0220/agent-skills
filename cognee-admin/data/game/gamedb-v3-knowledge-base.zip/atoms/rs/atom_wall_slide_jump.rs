#[derive(Debug, Clone, PartialEq)]
pub struct WallSlideJumpParams {
    pub slide_speed_max: f32,
    pub slide_acceleration: f32,
    pub jump_force_x: f32,
    pub jump_force_y: f32,
    pub input_lockout_time: f32,
    pub coyote_time_wall: f32,
}

impl WallSlideJumpParams {
    /// Creates a new WallSlideJumpParams with default values based on Celeste benchmark.
    pub fn new() -> Self {
        Self {
            slide_speed_max: 4.0,
            slide_acceleration: 10.0,
            jump_force_x: 8.0,
            jump_force_y: 15.0,
            input_lockout_time: 0.15,
            coyote_time_wall: 0.08,
        }
    }

    /// Calculates the new vertical velocity when sliding down a wall.
    /// 
    /// # Arguments
    /// * `current_vy` - The current vertical velocity (positive is downwards).
    /// * `dt` - Delta time in seconds.
    /// 
    /// # Returns
    /// The updated vertical velocity.
    pub fn calculate_slide_velocity(&self, current_vy: f32, dt: f32) -> f32 {
        let new_vy = current_vy + self.slide_acceleration * dt;
        if new_vy > self.slide_speed_max {
            self.slide_speed_max
        } else {
            new_vy
        }
    }

    /// Calculates the velocity vector after a wall jump.
    /// 
    /// # Arguments
    /// * `wall_direction` - The direction of the wall relative to the player (-1.0 for left, 1.0 for right).
    /// 
    /// # Returns
    /// A tuple `(vx, vy)` representing the new velocity vector.
    pub fn calculate_jump_velocity(&self, wall_direction: f32) -> (f32, f32) {
        // Jump away from the wall
        let vx = -wall_direction * self.jump_force_x;
        // Jump upwards (negative vy is upwards in many 2D coordinate systems, but we'll use positive for upward force here, 
        // assuming standard math coordinates where +y is up. Let's return positive for upward force).
        let vy = self.jump_force_y;
        (vx, vy)
    }
}

impl Default for WallSlideJumpParams {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_slide_velocity() {
        let params = WallSlideJumpParams::new();
        
        // Test acceleration
        let vy1 = params.calculate_slide_velocity(0.0, 0.1);
        assert_eq!(vy1, 1.0); // 0.0 + 10.0 * 0.1 = 1.0
        
        // Test max speed capping
        let vy2 = params.calculate_slide_velocity(3.5, 0.1);
        assert_eq!(vy2, 4.0); // 3.5 + 1.0 = 4.5, capped at 4.0
        
        // Test already at max speed
        let vy3 = params.calculate_slide_velocity(4.0, 0.1);
        assert_eq!(vy3, 4.0);
    }

    #[test]
    fn test_calculate_jump_velocity() {
        let params = WallSlideJumpParams::new();
        
        // Wall on the right (1.0)
        let (vx1, vy1) = params.calculate_jump_velocity(1.0);
        assert_eq!(vx1, -8.0); // Jump left
        assert_eq!(vy1, 15.0); // Jump up
        
        // Wall on the left (-1.0)
        let (vx2, vy2) = params.calculate_jump_velocity(-1.0);
        assert_eq!(vx2, 8.0); // Jump right
        assert_eq!(vy2, 15.0); // Jump up
    }
}
