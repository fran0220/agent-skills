#[derive(Debug, Clone)]
pub struct MultipleEndings {
    pub ending_count: u32,
    pub branch_points: u32,
    pub true_ending_req: f32,
    pub morality_threshold: f32,
}

impl MultipleEndings {
    /// Creates a new MultipleEndings instance with default values based on benchmark data.
    pub fn new() -> Self {
        Self {
            ending_count: 5,
            branch_points: 15,
            true_ending_req: 1.0,
            morality_threshold: 0.5,
        }
    }

    /// Determines the ending based on the player's morality score.
    /// Returns 1 for good ending, -1 for bad ending, and 0 for neutral ending.
    pub fn determine_morality_ending(&self, player_morality: f32) -> i32 {
        if player_morality >= self.morality_threshold {
            1 // Good ending
        } else if player_morality <= -self.morality_threshold {
            -1 // Bad ending
        } else {
            0 // Neutral ending
        }
    }

    /// Checks if the player has met the requirements for the true ending.
    pub fn check_true_ending(&self, completion_ratio: f32) -> bool {
        completion_ratio >= self.true_ending_req
    }

    /// Calculates the percentage of endings unlocked by the player.
    pub fn calculate_unlocked_percentage(&self, unlocked_endings: u32) -> f32 {
        if self.ending_count == 0 {
            return 0.0;
        }
        (unlocked_endings as f32 / self.ending_count as f32) * 100.0
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_determine_morality_ending() {
        let endings = MultipleEndings::new();
        assert_eq!(endings.determine_morality_ending(0.8), 1);
        assert_eq!(endings.determine_morality_ending(-0.6), -1);
        assert_eq!(endings.determine_morality_ending(0.2), 0);
    }

    #[test]
    fn test_check_true_ending() {
        let endings = MultipleEndings::new();
        assert_eq!(endings.check_true_ending(1.0), true);
        assert_eq!(endings.check_true_ending(0.9), false);
    }

    #[test]
    fn test_calculate_unlocked_percentage() {
        let endings = MultipleEndings::new();
        assert_eq!(endings.calculate_unlocked_percentage(1), 20.0);
        assert_eq!(endings.calculate_unlocked_percentage(5), 100.0);
    }
}
