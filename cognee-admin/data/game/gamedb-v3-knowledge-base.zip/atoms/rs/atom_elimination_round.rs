#[derive(Debug, Clone, PartialEq)]
pub struct EliminationRoundParams {
    pub initial_player_count: u32,
    pub elimination_rate: f32,
    pub round_time_limit: f32,
    pub qualification_threshold: u32,
}

impl EliminationRoundParams {
    /// Creates a new EliminationRoundParams with default values based on Fall Guys v1.0 benchmark.
    pub fn new() -> Self {
        Self {
            initial_player_count: 60,
            elimination_rate: 0.3,
            round_time_limit: 120.0,
            qualification_threshold: 42,
        }
    }

    /// Calculates the target number of qualifiers based on the current player count and elimination rate.
    /// It ensures that the number of qualifiers does not exceed the qualification_threshold.
    pub fn calculate_target_qualifiers(&self, current_players: u32) -> u32 {
        let survivors = (current_players as f32 * (1.0 - self.elimination_rate)).round() as u32;
        survivors.min(self.qualification_threshold)
    }

    /// Determines if a player is qualified based on their rank and the target number of qualifiers.
    /// Rank is 1-indexed (1st place is 1).
    pub fn is_qualified(&self, player_rank: u32, target_qualifiers: u32) -> bool {
        player_rank > 0 && player_rank <= target_qualifiers
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_target_qualifiers() {
        let params = EliminationRoundParams::new();
        
        // 60 players, 30% elimination -> 42 survivors
        assert_eq!(params.calculate_target_qualifiers(60), 42);
        
        // 100 players, 30% elimination -> 70 survivors, but capped at threshold 42
        assert_eq!(params.calculate_target_qualifiers(100), 42);
        
        // 10 players, 30% elimination -> 7 survivors
        assert_eq!(params.calculate_target_qualifiers(10), 7);
    }

    #[test]
    fn test_is_qualified() {
        let params = EliminationRoundParams::new();
        let target_qualifiers = 42;
        
        // Rank 1 is qualified
        assert!(params.is_qualified(1, target_qualifiers));
        
        // Rank 42 is qualified
        assert!(params.is_qualified(42, target_qualifiers));
        
        // Rank 43 is eliminated
        assert!(!params.is_qualified(43, target_qualifiers));
        
        // Rank 0 is invalid, should not qualify
        assert!(!params.is_qualified(0, target_qualifiers));
    }
}
