#[derive(Debug, Clone, PartialEq)]
pub enum MonthlyCardState {
    Inactive,
    ActiveUnclaimed,
    ActiveClaimed,
}

#[derive(Debug, Clone)]
pub struct MonthlyCard {
    pub duration_days: u32,
    pub upfront_reward: u32,
    pub daily_reward: u32,
    pub max_stack_days: u32,
    pub price_usd: f32,
    
    pub state: MonthlyCardState,
    pub days_remaining: u32,
}

impl MonthlyCard {
    /// Creates a new MonthlyCard with default benchmark values (e.g., Genshin Impact v4.0)
    pub fn new() -> Self {
        Self {
            duration_days: 30,
            upfront_reward: 300,
            daily_reward: 90,
            max_stack_days: 180,
            price_usd: 4.99,
            state: MonthlyCardState::Inactive,
            days_remaining: 0,
        }
    }

    /// Purchases or renews the monthly card, returning the upfront reward.
    pub fn purchase(&mut self) -> Result<u32, &'static str> {
        if self.days_remaining + self.duration_days > self.max_stack_days {
            return Err("Exceeds maximum stack days");
        }
        
        self.days_remaining += self.duration_days;
        
        if self.state == MonthlyCardState::Inactive {
            self.state = MonthlyCardState::ActiveUnclaimed;
        }
        
        Ok(self.upfront_reward)
    }

    /// Claims the daily reward if eligible.
    pub fn claim_daily(&mut self) -> Result<u32, &'static str> {
        match self.state {
            MonthlyCardState::ActiveUnclaimed => {
                self.state = MonthlyCardState::ActiveClaimed;
                Ok(self.daily_reward)
            }
            MonthlyCardState::ActiveClaimed => Err("Already claimed today"),
            MonthlyCardState::Inactive => Err("No active monthly card"),
        }
    }

    /// Processes the daily reset, decrementing days remaining and updating state.
    pub fn daily_reset(&mut self) {
        if self.days_remaining > 0 {
            self.days_remaining -= 1;
            if self.days_remaining == 0 {
                self.state = MonthlyCardState::Inactive;
            } else {
                self.state = MonthlyCardState::ActiveUnclaimed;
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_purchase_and_claim() {
        let mut card = MonthlyCard::new();
        assert_eq!(card.state, MonthlyCardState::Inactive);
        
        // Purchase
        let upfront = card.purchase().unwrap();
        assert_eq!(upfront, 300);
        assert_eq!(card.days_remaining, 30);
        assert_eq!(card.state, MonthlyCardState::ActiveUnclaimed);
        
        // Claim
        let daily = card.claim_daily().unwrap();
        assert_eq!(daily, 90);
        assert_eq!(card.state, MonthlyCardState::ActiveClaimed);
        
        // Cannot claim again
        assert!(card.claim_daily().is_err());
    }

    #[test]
    fn test_daily_reset_and_expiration() {
        let mut card = MonthlyCard::new();
        card.purchase().unwrap();
        card.claim_daily().unwrap();
        
        // Reset
        card.daily_reset();
        assert_eq!(card.days_remaining, 29);
        assert_eq!(card.state, MonthlyCardState::ActiveUnclaimed);
        
        // Fast forward to expiration
        for _ in 0..29 {
            card.daily_reset();
        }
        
        assert_eq!(card.days_remaining, 0);
        assert_eq!(card.state, MonthlyCardState::Inactive);
    }

    #[test]
    fn test_max_stack() {
        let mut card = MonthlyCard::new();
        
        // Buy 6 times (180 days)
        for _ in 0..6 {
            assert!(card.purchase().is_ok());
        }
        
        assert_eq!(card.days_remaining, 180);
        
        // 7th time should fail
        assert!(card.purchase().is_err());
    }
}
