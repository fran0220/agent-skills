#[derive(Debug, Clone, PartialEq)]
pub struct PhotoModeParams {
    pub field_of_view: f32,
    pub roll: f32,
    pub depth_of_field: f32,
    pub focus_distance: f32,
    pub exposure_bias: f32,
    pub time_of_day: f32,
    pub filter_intensity: f32,
}

impl PhotoModeParams {
    /// Creates a new PhotoModeParams with default values based on Ghost of Tsushima benchmark.
    pub fn new() -> Self {
        Self {
            field_of_view: 50.0,
            roll: 0.0,
            depth_of_field: 10.0,
            focus_distance: 5.0,
            exposure_bias: 0.0,
            time_of_day: 12.0,
            filter_intensity: 1.0,
        }
    }

    /// Calculates the effective focal length based on the field of view (assuming a 35mm full-frame sensor).
    /// Formula: focal_length = 36.0 / (2.0 * tan(fov / 2.0))
    pub fn calculate_focal_length(&self) -> f32 {
        let fov_radians = self.field_of_view.to_radians();
        let sensor_width = 36.0; // 35mm full-frame sensor width in mm
        sensor_width / (2.0 * (fov_radians / 2.0).tan())
    }

    /// Calculates the exposure multiplier based on the exposure bias.
    /// Formula: multiplier = 2.0 ^ exposure_bias
    pub fn calculate_exposure_multiplier(&self) -> f32 {
        2.0_f32.powf(self.exposure_bias)
    }
    
    /// Clamps the time of day to be within 0.0 and 24.0 hours.
    pub fn normalize_time_of_day(&mut self) {
        self.time_of_day = self.time_of_day % 24.0;
        if self.time_of_day < 0.0 {
            self.time_of_day += 24.0;
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_focal_length() {
        let mut params = PhotoModeParams::new();
        // For a 90 degree FOV, tan(45) = 1, so focal length = 36 / 2 = 18mm
        params.field_of_view = 90.0;
        let focal_length = params.calculate_focal_length();
        assert!((focal_length - 18.0).abs() < 0.01);
    }

    #[test]
    fn test_calculate_exposure_multiplier() {
        let mut params = PhotoModeParams::new();
        
        params.exposure_bias = 0.0;
        assert_eq!(params.calculate_exposure_multiplier(), 1.0);
        
        params.exposure_bias = 1.0;
        assert_eq!(params.calculate_exposure_multiplier(), 2.0);
        
        params.exposure_bias = -1.0;
        assert_eq!(params.calculate_exposure_multiplier(), 0.5);
    }
    
    #[test]
    fn test_normalize_time_of_day() {
        let mut params = PhotoModeParams::new();
        
        params.time_of_day = 25.5;
        params.normalize_time_of_day();
        assert!((params.time_of_day - 1.5).abs() < 0.001);
        
        params.time_of_day = -2.0;
        params.normalize_time_of_day();
        assert!((params.time_of_day - 22.0).abs() < 0.001);
    }
}
