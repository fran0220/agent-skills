#[derive(Debug, Clone, PartialEq)]
pub enum MoralityState {
    Neutral,
    Good,
    MaxGood,
    Evil,
    MaxEvil,
}

#[derive(Debug, Clone)]
pub struct MoralitySystem {
    pub morality_score: f32,
    pub good_threshold: f32,
    pub evil_threshold: f32,
    pub action_weight: f32,
    pub decay_rate: f32,
}

impl MoralitySystem {
    /// Creates a new MoralitySystem with default values based on benchmark data.
    pub fn new() -> Self {
        Self {
            morality_score: 0.0,
            good_threshold: 75.0,
            evil_threshold: -75.0,
            action_weight: 5.0,
            decay_rate: 0.0,
        }
    }

    /// Applies a moral action to the system, adjusting the score.
    /// A positive weight indicates a good action, negative indicates evil.
    pub fn apply_action(&mut self, weight_multiplier: f32) {
        self.morality_score += self.action_weight * weight_multiplier;
        // Clamp the score to a reasonable range, e.g., -100.0 to 100.0
        self.morality_score = self.morality_score.clamp(-100.0, 100.0);
    }

    /// Applies daily decay to the morality score, moving it towards neutral (0.0).
    pub fn apply_decay(&mut self, days: f32) {
        if self.morality_score > 0.0 {
            self.morality_score = (self.morality_score - self.decay_rate * days).max(0.0);
        } else if self.morality_score < 0.0 {
            self.morality_score = (self.morality_score + self.decay_rate * days).min(0.0);
        }
    }

    /// Returns the current state of the morality system based on thresholds.
    pub fn current_state(&self) -> MoralityState {
        if self.morality_score >= 100.0 {
            MoralityState::MaxGood
        } else if self.morality_score >= self.good_threshold {
            MoralityState::Good
        } else if self.morality_score <= -100.0 {
            MoralityState::MaxEvil
        } else if self.morality_score <= self.evil_threshold {
            MoralityState::Evil
        } else {
            MoralityState::Neutral
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_apply_action_and_state() {
        let mut system = MoralitySystem::new();
        assert_eq!(system.current_state(), MoralityState::Neutral);

        // Apply good actions
        system.apply_action(10.0); // +50.0
        assert_eq!(system.morality_score, 50.0);
        assert_eq!(system.current_state(), MoralityState::Neutral);

        system.apply_action(10.0); // +50.0 -> 100.0
        assert_eq!(system.morality_score, 100.0);
        assert_eq!(system.current_state(), MoralityState::MaxGood);

        // Apply evil actions
        system.apply_action(-40.0); // -200.0 -> clamped to -100.0
        assert_eq!(system.morality_score, -100.0);
        assert_eq!(system.current_state(), MoralityState::MaxEvil);
    }

    #[test]
    fn test_apply_decay() {
        let mut system = MoralitySystem::new();
        system.decay_rate = 2.0;
        
        system.morality_score = 10.0;
        system.apply_decay(3.0); // 10.0 - 6.0 = 4.0
        assert_eq!(system.morality_score, 4.0);

        system.morality_score = -10.0;
        system.apply_decay(3.0); // -10.0 + 6.0 = -4.0
        assert_eq!(system.morality_score, -4.0);

        // Decay should not cross 0
        system.morality_score = 5.0;
        system.apply_decay(5.0); // 5.0 - 10.0 -> max(0.0) = 0.0
        assert_eq!(system.morality_score, 0.0);
    }
}
