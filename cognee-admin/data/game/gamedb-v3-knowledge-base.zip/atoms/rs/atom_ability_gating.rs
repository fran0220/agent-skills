#[derive(Debug, Clone, PartialEq)]
pub struct AbilityGatingParams {
    pub gate_health: u32,
    pub bypass_distance: f32,
    pub is_consumable: bool,
}

impl AbilityGatingParams {
    /// Creates a new AbilityGatingParams with default values based on benchmark data.
    pub fn new() -> Self {
        Self {
            gate_health: 1,
            bypass_distance: 5.0,
            is_consumable: false,
        }
    }
}

pub struct AbilityGatingState {
    pub has_ability: bool,
    pub is_traversed: bool,
    pub current_gate_health: u32,
}

impl AbilityGatingState {
    pub fn new(params: &AbilityGatingParams) -> Self {
        Self {
            has_ability: false,
            is_traversed: false,
            current_gate_health: params.gate_health,
        }
    }

    /// Attempts to unlock the gate. Returns true if successful.
    pub fn try_unlock(&mut self, params: &AbilityGatingParams, ability_power: u32, distance_to_gate: f32) -> bool {
        if !self.has_ability {
            return false;
        }

        if distance_to_gate > params.bypass_distance {
            return false;
        }

        if self.current_gate_health > ability_power {
            self.current_gate_health -= ability_power;
            return false;
        }

        self.current_gate_health = 0;
        self.is_traversed = true;
        true
    }

    /// Acquires the required ability.
    pub fn acquire_ability(&mut self) {
        self.has_ability = true;
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_unlock_success() {
        let params = AbilityGatingParams::new();
        let mut state = AbilityGatingState::new(&params);

        // Cannot unlock without ability
        assert!(!state.try_unlock(&params, 1, 2.0));

        // Acquire ability
        state.acquire_ability();

        // Cannot unlock if too far
        assert!(!state.try_unlock(&params, 1, 10.0));

        // Successful unlock
        assert!(state.try_unlock(&params, 1, 2.0));
        assert!(state.is_traversed);
    }

    #[test]
    fn test_unlock_with_health() {
        let params = AbilityGatingParams {
            gate_health: 3,
            bypass_distance: 5.0,
            is_consumable: false,
        };
        let mut state = AbilityGatingState::new(&params);
        state.acquire_ability();

        // First hit
        assert!(!state.try_unlock(&params, 1, 2.0));
        assert_eq!(state.current_gate_health, 2);

        // Second hit
        assert!(!state.try_unlock(&params, 1, 2.0));
        assert_eq!(state.current_gate_health, 1);

        // Third hit - unlocks
        assert!(state.try_unlock(&params, 1, 2.0));
        assert_eq!(state.current_gate_health, 0);
        assert!(state.is_traversed);
    }
}
