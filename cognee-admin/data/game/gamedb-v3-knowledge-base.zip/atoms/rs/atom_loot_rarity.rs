#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Rarity {
    Common,
    Magic,
    Rare,
    Legendary,
}

#[derive(Debug, Clone)]
pub struct LootRarityParams {
    pub common_weight: f32,
    pub magic_weight: f32,
    pub rare_weight: f32,
    pub legendary_weight: f32,
    pub stat_multiplier_magic: f32,
    pub stat_multiplier_rare: f32,
    pub stat_multiplier_legendary: f32,
    pub affix_count_magic: u32,
    pub affix_count_rare: u32,
    pub affix_count_legendary: u32,
}

impl LootRarityParams {
    /// Creates a new LootRarityParams with default benchmark values (Diablo 3 v2.7).
    pub fn new() -> Self {
        Self {
            common_weight: 0.70,
            magic_weight: 0.20,
            rare_weight: 0.09,
            legendary_weight: 0.01,
            stat_multiplier_magic: 1.2,
            stat_multiplier_rare: 1.5,
            stat_multiplier_legendary: 2.0,
            affix_count_magic: 1,
            affix_count_rare: 4,
            affix_count_legendary: 6,
        }
    }

    /// Rolls a rarity based on a random value between 0.0 and 1.0.
    /// The random value should be uniformly distributed.
    pub fn roll_rarity(&self, roll: f32) -> Rarity {
        let total_weight = self.common_weight + self.magic_weight + self.rare_weight + self.legendary_weight;
        let normalized_roll = roll * total_weight;

        let mut cumulative = 0.0;
        
        cumulative += self.legendary_weight;
        if normalized_roll <= cumulative {
            return Rarity::Legendary;
        }
        
        cumulative += self.rare_weight;
        if normalized_roll <= cumulative {
            return Rarity::Rare;
        }
        
        cumulative += self.magic_weight;
        if normalized_roll <= cumulative {
            return Rarity::Magic;
        }
        
        Rarity::Common
    }

    /// Returns the stat multiplier for a given rarity.
    pub fn get_stat_multiplier(&self, rarity: Rarity) -> f32 {
        match rarity {
            Rarity::Common => 1.0,
            Rarity::Magic => self.stat_multiplier_magic,
            Rarity::Rare => self.stat_multiplier_rare,
            Rarity::Legendary => self.stat_multiplier_legendary,
        }
    }

    /// Returns the number of affixes for a given rarity.
    pub fn get_affix_count(&self, rarity: Rarity) -> u32 {
        match rarity {
            Rarity::Common => 0,
            Rarity::Magic => self.affix_count_magic,
            Rarity::Rare => self.affix_count_rare,
            Rarity::Legendary => self.affix_count_legendary,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_roll_rarity() {
        let params = LootRarityParams::new();
        
        // Total weight is 0.70 + 0.20 + 0.09 + 0.01 = 1.00
        // Legendary: 0.0 to 0.01
        // Rare: 0.01 to 0.10
        // Magic: 0.10 to 0.30
        // Common: 0.30 to 1.00
        
        assert_eq!(params.roll_rarity(0.005), Rarity::Legendary);
        assert_eq!(params.roll_rarity(0.05), Rarity::Rare);
        assert_eq!(params.roll_rarity(0.20), Rarity::Magic);
        assert_eq!(params.roll_rarity(0.50), Rarity::Common);
        assert_eq!(params.roll_rarity(0.99), Rarity::Common);
    }

    #[test]
    fn test_get_stat_multiplier() {
        let params = LootRarityParams::new();
        
        assert_eq!(params.get_stat_multiplier(Rarity::Common), 1.0);
        assert_eq!(params.get_stat_multiplier(Rarity::Magic), 1.2);
        assert_eq!(params.get_stat_multiplier(Rarity::Rare), 1.5);
        assert_eq!(params.get_stat_multiplier(Rarity::Legendary), 2.0);
    }

    #[test]
    fn test_get_affix_count() {
        let params = LootRarityParams::new();
        
        assert_eq!(params.get_affix_count(Rarity::Common), 0);
        assert_eq!(params.get_affix_count(Rarity::Magic), 1);
        assert_eq!(params.get_affix_count(Rarity::Rare), 4);
        assert_eq!(params.get_affix_count(Rarity::Legendary), 6);
    }
}
