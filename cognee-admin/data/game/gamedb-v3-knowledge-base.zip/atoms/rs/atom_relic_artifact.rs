#[derive(Debug, Clone, PartialEq)]
pub struct RelicArtifact {
    pub rarity_weight: f32,
    pub cost: u32,
    pub trigger_chance: f32,
    pub cooldown: f32,
    pub effect_magnitude: f32,
    pub current_cooldown: f32,
}

impl RelicArtifact {
    /// Creates a new RelicArtifact with default values based on benchmark data (Slay the Spire).
    pub fn new() -> Self {
        Self {
            rarity_weight: 0.1,
            cost: 150,
            trigger_chance: 1.0,
            cooldown: 0.0,
            effect_magnitude: 3.0,
            current_cooldown: 0.0,
        }
    }

    /// Attempts to trigger the relic's effect.
    /// Returns the effect magnitude if successful, or 0.0 if on cooldown or trigger fails.
    pub fn trigger(&mut self, random_value: f32) -> f32 {
        if self.current_cooldown > 0.0 {
            return 0.0; // On cooldown
        }

        if random_value <= self.trigger_chance {
            self.current_cooldown = self.cooldown;
            self.effect_magnitude
        } else {
            0.0 // Trigger failed
        }
    }

    /// Updates the cooldown of the relic.
    pub fn update_cooldown(&mut self, delta_time: f32) {
        if self.current_cooldown > 0.0 {
            self.current_cooldown -= delta_time;
            if self.current_cooldown < 0.0 {
                self.current_cooldown = 0.0;
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_relic_trigger_success() {
        let mut relic = RelicArtifact::new();
        relic.trigger_chance = 0.5;
        relic.effect_magnitude = 10.0;
        
        // Random value is less than trigger chance, should succeed
        let effect = relic.trigger(0.4);
        assert_eq!(effect, 10.0);
    }

    #[test]
    fn test_relic_trigger_failure() {
        let mut relic = RelicArtifact::new();
        relic.trigger_chance = 0.5;
        relic.effect_magnitude = 10.0;
        
        // Random value is greater than trigger chance, should fail
        let effect = relic.trigger(0.6);
        assert_eq!(effect, 0.0);
    }

    #[test]
    fn test_relic_cooldown() {
        let mut relic = RelicArtifact::new();
        relic.trigger_chance = 1.0;
        relic.cooldown = 5.0;
        relic.effect_magnitude = 10.0;
        
        // First trigger should succeed and set cooldown
        let effect1 = relic.trigger(0.5);
        assert_eq!(effect1, 10.0);
        assert_eq!(relic.current_cooldown, 5.0);
        
        // Second trigger immediately after should fail due to cooldown
        let effect2 = relic.trigger(0.5);
        assert_eq!(effect2, 0.0);
        
        // Update cooldown by 3.0 seconds
        relic.update_cooldown(3.0);
        assert_eq!(relic.current_cooldown, 2.0);
        
        // Still on cooldown
        let effect3 = relic.trigger(0.5);
        assert_eq!(effect3, 0.0);
        
        // Update cooldown by another 2.0 seconds
        relic.update_cooldown(2.0);
        assert_eq!(relic.current_cooldown, 0.0);
        
        // Should trigger successfully now
        let effect4 = relic.trigger(0.5);
        assert_eq!(effect4, 10.0);
    }
}
