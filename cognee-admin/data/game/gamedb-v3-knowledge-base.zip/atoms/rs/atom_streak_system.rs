#[derive(Debug, Clone)]
pub struct StreakSystemParams {
    pub grace_period_hours: u32,
    pub max_streak_rewards: u32,
    pub streak_freeze_cost: u32,
    pub reward_multiplier: f32,
}

impl StreakSystemParams {
    pub fn new() -> Self {
        Self {
            grace_period_hours: 24,
            max_streak_rewards: 7,
            streak_freeze_cost: 200,
            reward_multiplier: 1.5,
        }
    }
}

pub struct StreakState {
    pub current_streak: u32,
    pub last_checkin_timestamp: u64,
    pub freezes_available: u32,
}

impl StreakState {
    pub fn new() -> Self {
        Self {
            current_streak: 0,
            last_checkin_timestamp: 0,
            freezes_available: 0,
        }
    }

    pub fn check_in(&mut self, current_timestamp: u64, params: &StreakSystemParams) -> bool {
        let hours_since_last = if self.last_checkin_timestamp == 0 {
            0
        } else {
            (current_timestamp - self.last_checkin_timestamp) / 3600
        };

        if self.last_checkin_timestamp == 0 || hours_since_last <= params.grace_period_hours as u64 {
            self.current_streak += 1;
            self.last_checkin_timestamp = current_timestamp;
            true
        } else if self.freezes_available > 0 {
            self.freezes_available -= 1;
            self.current_streak += 1;
            self.last_checkin_timestamp = current_timestamp;
            true
        } else {
            self.current_streak = 1;
            self.last_checkin_timestamp = current_timestamp;
            false
        }
    }

    pub fn calculate_reward(&self, base_reward: f32, params: &StreakSystemParams) -> f32 {
        let streak_cap = if self.current_streak > params.max_streak_rewards {
            params.max_streak_rewards
        } else {
            self.current_streak
        };
        
        if streak_cap == 0 {
            return base_reward;
        }

        base_reward * (1.0 + (streak_cap as f32 - 1.0) * (params.reward_multiplier - 1.0))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_check_in_success() {
        let params = StreakSystemParams::new();
        let mut state = StreakState::new();
        
        assert_eq!(state.check_in(3600, &params), true);
        assert_eq!(state.current_streak, 1);
        
        assert_eq!(state.check_in(3600 + 20 * 3600, &params), true);
        assert_eq!(state.current_streak, 2);
    }

    #[test]
    fn test_check_in_fail_and_reset() {
        let params = StreakSystemParams::new();
        let mut state = StreakState::new();
        
        state.check_in(3600, &params);
        assert_eq!(state.current_streak, 1);
        
        // 48 hours later, missed grace period
        assert_eq!(state.check_in(3600 + 48 * 3600, &params), false);
        assert_eq!(state.current_streak, 1); // Reset to 1
    }

    #[test]
    fn test_calculate_reward() {
        let params = StreakSystemParams::new();
        let mut state = StreakState::new();
        
        state.current_streak = 1;
        assert_eq!(state.calculate_reward(100.0, &params), 100.0);
        
        state.current_streak = 2;
        assert_eq!(state.calculate_reward(100.0, &params), 150.0);
        
        state.current_streak = 10; // Cap is 7
        assert_eq!(state.calculate_reward(100.0, &params), 100.0 * (1.0 + 6.0 * 0.5)); // 400.0
    }
}
