#[derive(Debug, Clone, PartialEq)]
pub struct WeaponSwitchParams {
    pub switch_duration: f32,
    pub switch_cooldown: f32,
    pub cancel_window_start: f32,
    pub invincibility_frames: u32,
    pub buffer_window: f32,
}

impl WeaponSwitchParams {
    /// Creates a new WeaponSwitchParams with default values based on Devil May Cry 5 benchmark.
    pub fn new() -> Self {
        Self {
            switch_duration: 0.1,
            switch_cooldown: 0.0,
            cancel_window_start: 0.3,
            invincibility_frames: 0,
            buffer_window: 0.15,
        }
    }

    /// Checks if a weapon switch can be initiated based on the current attack animation progress.
    /// `current_anim_progress` is a normalized value from 0.0 to 1.0.
    pub fn can_cancel_attack(&self, current_anim_progress: f32) -> bool {
        current_anim_progress >= self.cancel_window_start
    }

    /// Calculates the total time required before another switch can be performed.
    pub fn total_lockout_time(&self) -> f32 {
        self.switch_duration + self.switch_cooldown
    }

    /// Determines if an input is within the buffer window for the next action after switching.
    /// `time_since_switch_start` is the time elapsed since the switch began.
    pub fn is_input_buffered(&self, time_since_switch_start: f32) -> bool {
        let time_remaining = self.switch_duration - time_since_switch_start;
        time_remaining > 0.0 && time_remaining <= self.buffer_window
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_can_cancel_attack() {
        let params = WeaponSwitchParams::new();
        
        // Cannot cancel before the window starts
        assert!(!params.can_cancel_attack(0.2));
        
        // Can cancel exactly at the window start
        assert!(params.can_cancel_attack(0.3));
        
        // Can cancel after the window starts
        assert!(params.can_cancel_attack(0.8));
    }

    #[test]
    fn test_total_lockout_time() {
        let mut params = WeaponSwitchParams::new();
        assert_eq!(params.total_lockout_time(), 0.1); // 0.1 + 0.0
        
        params.switch_duration = 0.2;
        params.switch_cooldown = 0.5;
        assert_eq!(params.total_lockout_time(), 0.7); // 0.2 + 0.5
    }

    #[test]
    fn test_is_input_buffered() {
        let mut params = WeaponSwitchParams::new();
        params.switch_duration = 0.5;
        params.buffer_window = 0.2;
        
        // Input too early, not in buffer window
        assert!(!params.is_input_buffered(0.1));
        
        // Input within buffer window (0.5 - 0.4 = 0.1 <= 0.2)
        assert!(params.is_input_buffered(0.4));
        
        // Input exactly at the start of buffer window (0.5 - 0.3 = 0.2 <= 0.2)
        assert!(params.is_input_buffered(0.3));
        
        // Switch already finished
        assert!(!params.is_input_buffered(0.6));
    }
}
