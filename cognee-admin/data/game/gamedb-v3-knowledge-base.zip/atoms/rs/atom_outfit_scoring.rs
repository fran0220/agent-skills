#[derive(Debug, Clone)]
pub struct OutfitScoringParams {
    pub base_attribute_score: f32,
    pub theme_multiplier: f32,
    pub tag_bonus: f32,
    pub penalty_factor: f32,
    pub max_items_per_category: u32,
}

impl OutfitScoringParams {
    /// Creates a new `OutfitScoringParams` with default values based on Love Nikki v8.0 benchmark.
    pub fn new() -> Self {
        Self {
            base_attribute_score: 1500.0,
            theme_multiplier: 1.5,
            tag_bonus: 2.0,
            penalty_factor: 0.5,
            max_items_per_category: 1,
        }
    }

    /// Calculates the score for a single clothing item.
    /// 
    /// # Arguments
    /// * `item_base_score` - The base score of the item for the relevant attribute.
    /// * `matches_theme` - Whether the item matches the current theme.
    /// * `matches_tag` - Whether the item has a bonus tag for the current theme.
    /// * `is_clashing` - Whether the item clashes with the theme (penalty).
    pub fn calculate_item_score(
        &self,
        item_base_score: f32,
        matches_theme: bool,
        matches_tag: bool,
        is_clashing: bool,
    ) -> f32 {
        let mut score = item_base_score;

        if matches_theme {
            score *= self.theme_multiplier;
        }

        if matches_tag {
            score *= self.tag_bonus;
        }

        if is_clashing {
            score *= self.penalty_factor;
        }

        score
    }

    /// Calculates the total score for an outfit (a collection of items).
    pub fn calculate_total_score(&self, item_scores: &[f32]) -> f32 {
        item_scores.iter().sum()
    }
}

impl Default for OutfitScoringParams {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_item_score() {
        let params = OutfitScoringParams::new();
        
        // Base score only
        let score1 = params.calculate_item_score(1000.0, false, false, false);
        assert_eq!(score1, 1000.0);

        // Matches theme
        let score2 = params.calculate_item_score(1000.0, true, false, false);
        assert_eq!(score2, 1500.0); // 1000 * 1.5

        // Matches theme and tag
        let score3 = params.calculate_item_score(1000.0, true, true, false);
        assert_eq!(score3, 3000.0); // 1000 * 1.5 * 2.0

        // Clashing item
        let score4 = params.calculate_item_score(1000.0, false, false, true);
        assert_eq!(score4, 500.0); // 1000 * 0.5
    }

    #[test]
    fn test_calculate_total_score() {
        let params = OutfitScoringParams::new();
        let item_scores = vec![1500.0, 3000.0, 500.0];
        let total = params.calculate_total_score(&item_scores);
        assert_eq!(total, 5000.0);
    }
}
