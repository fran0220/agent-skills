#[derive(Debug, Clone)]
pub struct DungeonFinderParams {
    pub max_queue_time_target: u32,
    pub role_requirement_tank: u32,
    pub role_requirement_healer: u32,
    pub role_requirement_dps: u32,
    pub mmr_expansion_rate: f32,
    pub confirmation_timeout: u32,
    pub deserter_penalty_duration: u32,
}

impl DungeonFinderParams {
    pub fn new() -> Self {
        Self {
            max_queue_time_target: 900,
            role_requirement_tank: 1,
            role_requirement_healer: 1,
            role_requirement_dps: 3,
            mmr_expansion_rate: 2.5,
            confirmation_timeout: 40,
            deserter_penalty_duration: 1800,
        }
    }

    /// Calculates the expanded MMR range based on time spent in queue.
    pub fn calculate_mmr_range(&self, base_mmr: f32, time_in_queue_seconds: u32) -> (f32, f32) {
        let expansion = self.mmr_expansion_rate * (time_in_queue_seconds as f32);
        let min_mmr = (base_mmr - expansion).max(0.0);
        let max_mmr = base_mmr + expansion;
        (min_mmr, max_mmr)
    }

    /// Checks if a group composition meets the role requirements.
    pub fn is_group_valid(&self, tanks: u32, healers: u32, dps: u32) -> bool {
        tanks == self.role_requirement_tank
            && healers == self.role_requirement_healer
            && dps == self.role_requirement_dps
    }
    
    /// Calculates the estimated wait time based on role demand.
    /// A simple formula where higher demand roles have shorter wait times.
    pub fn estimate_wait_time(&self, role: &str, tank_queue_size: u32, healer_queue_size: u32, dps_queue_size: u32) -> u32 {
        let total_needed = self.role_requirement_tank + self.role_requirement_healer + self.role_requirement_dps;
        if total_needed == 0 {
            return 0;
        }
        
        match role {
            "tank" => {
                if self.role_requirement_tank == 0 { return 0; }
                let ratio = tank_queue_size as f32 / self.role_requirement_tank as f32;
                (ratio * 10.0) as u32
            },
            "healer" => {
                if self.role_requirement_healer == 0 { return 0; }
                let ratio = healer_queue_size as f32 / self.role_requirement_healer as f32;
                (ratio * 10.0) as u32
            },
            "dps" => {
                if self.role_requirement_dps == 0 { return 0; }
                let ratio = dps_queue_size as f32 / self.role_requirement_dps as f32;
                (ratio * 10.0) as u32
            },
            _ => self.max_queue_time_target,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_mmr_range_expansion() {
        let params = DungeonFinderParams::new();
        let base_mmr = 1500.0;
        
        // At 0 seconds, range should be exactly base_mmr
        let (min0, max0) = params.calculate_mmr_range(base_mmr, 0);
        assert_eq!(min0, 1500.0);
        assert_eq!(max0, 1500.0);
        
        // At 100 seconds, expansion is 2.5 * 100 = 250
        let (min100, max100) = params.calculate_mmr_range(base_mmr, 100);
        assert_eq!(min100, 1250.0);
        assert_eq!(max100, 1750.0);
    }

    #[test]
    fn test_group_validity() {
        let params = DungeonFinderParams::new();
        
        // Valid WoW group
        assert!(params.is_group_valid(1, 1, 3));
        
        // Invalid groups
        assert!(!params.is_group_valid(0, 1, 3)); // No tank
        assert!(!params.is_group_valid(1, 0, 3)); // No healer
        assert!(!params.is_group_valid(1, 1, 2)); // Not enough DPS
        assert!(!params.is_group_valid(2, 1, 3)); // Too many tanks
    }
}
