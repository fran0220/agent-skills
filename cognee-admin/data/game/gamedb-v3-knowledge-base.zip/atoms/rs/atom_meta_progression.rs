#[derive(Debug, Clone)]
pub struct MetaProgressionParams {
    pub base_health_upgrade_cost: u32,
    pub health_increase_per_level: f32,
    pub max_upgrade_levels: u32,
    pub resource_retention_rate: f32,
    pub unlock_cost_multiplier: f32,
}

impl MetaProgressionParams {
    /// Creates a new `MetaProgressionParams` with default values based on Hades v1.0 benchmarks.
    pub fn new() -> Self {
        Self {
            base_health_upgrade_cost: 50,
            health_increase_per_level: 10.0,
            max_upgrade_levels: 10,
            resource_retention_rate: 1.0,
            unlock_cost_multiplier: 1.5,
        }
    }

    /// Calculates the cost of the next health upgrade based on the current level.
    /// The cost increases by the unlock_cost_multiplier for each level.
    pub fn calculate_upgrade_cost(&self, current_level: u32) -> Option<u32> {
        if current_level >= self.max_upgrade_levels {
            return None; // Max level reached
        }
        
        let multiplier = self.unlock_cost_multiplier.powf(current_level as f32);
        let cost = (self.base_health_upgrade_cost as f32 * multiplier).round() as u32;
        Some(cost)
    }

    /// Calculates the total health bonus provided by the current upgrade level.
    pub fn calculate_health_bonus(&self, current_level: u32) -> f32 {
        let effective_level = current_level.min(self.max_upgrade_levels);
        effective_level as f32 * self.health_increase_per_level
    }

    /// Calculates the amount of resources retained after a run ends.
    pub fn calculate_retained_resources(&self, collected_resources: u32) -> u32 {
        (collected_resources as f32 * self.resource_retention_rate).round() as u32
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_upgrade_cost() {
        let params = MetaProgressionParams::new();
        
        // Level 0 cost should be base cost
        assert_eq!(params.calculate_upgrade_cost(0), Some(50));
        
        // Level 1 cost should be base cost * 1.5
        assert_eq!(params.calculate_upgrade_cost(1), Some(75));
        
        // Level 2 cost should be base cost * 1.5^2 = 50 * 2.25 = 112.5 -> 113
        assert_eq!(params.calculate_upgrade_cost(2), Some(113));
        
        // Max level reached
        assert_eq!(params.calculate_upgrade_cost(10), None);
    }

    #[test]
    fn test_calculate_health_bonus() {
        let params = MetaProgressionParams::new();
        
        // Level 0 bonus should be 0
        assert_eq!(params.calculate_health_bonus(0), 0.0);
        
        // Level 5 bonus should be 5 * 10.0 = 50.0
        assert_eq!(params.calculate_health_bonus(5), 50.0);
        
        // Level 15 (above max) should be capped at max_upgrade_levels (10) * 10.0 = 100.0
        assert_eq!(params.calculate_health_bonus(15), 100.0);
    }

    #[test]
    fn test_calculate_retained_resources() {
        let mut params = MetaProgressionParams::new();
        
        // Default retention rate is 1.0
        assert_eq!(params.calculate_retained_resources(100), 100);
        
        // Change retention rate to 0.5
        params.resource_retention_rate = 0.5;
        assert_eq!(params.calculate_retained_resources(100), 50);
        
        // Change retention rate to 0.0
        params.resource_retention_rate = 0.0;
        assert_eq!(params.calculate_retained_resources(100), 0);
    }
}
