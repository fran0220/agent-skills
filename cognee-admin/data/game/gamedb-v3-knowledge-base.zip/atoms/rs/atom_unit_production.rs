#[derive(Debug, Clone)]
pub struct UnitProductionParams {
    pub build_time: f32,
    pub cost_minerals: u32,
    pub cost_gas: u32,
    pub max_queue_size: u32,
    pub refund_ratio: f32,
}

impl UnitProductionParams {
    pub fn new() -> Self {
        Self {
            build_time: 12.0,
            cost_minerals: 50,
            cost_gas: 0,
            max_queue_size: 5,
            refund_ratio: 1.0,
        }
    }
}

#[derive(Debug, Clone)]
pub struct ProductionQueue {
    pub params: UnitProductionParams,
    pub queue: Vec<f32>, // Stores remaining build time for each unit in queue
    pub minerals: u32,
    pub gas: u32,
}

impl ProductionQueue {
    pub fn new(params: UnitProductionParams, initial_minerals: u32, initial_gas: u32) -> Self {
        Self {
            params,
            queue: Vec::new(),
            minerals: initial_minerals,
            gas: initial_gas,
        }
    }

    /// Attempts to queue a new unit. Returns true if successful, false otherwise.
    pub fn queue_unit(&mut self) -> bool {
        if self.queue.len() as u32 >= self.params.max_queue_size {
            return false; // Queue is full
        }
        if self.minerals < self.params.cost_minerals || self.gas < self.params.cost_gas {
            return false; // Insufficient resources
        }

        // Deduct resources
        self.minerals -= self.params.cost_minerals;
        self.gas -= self.params.cost_gas;

        // Add to queue
        self.queue.push(self.params.build_time);
        true
    }

    /// Advances production by the given delta time. Returns the number of units completed.
    pub fn update(&mut self, delta_time: f32) -> u32 {
        if self.queue.is_empty() {
            return 0;
        }

        let mut completed_units = 0;
        let mut remaining_dt = delta_time;

        while !self.queue.is_empty() && remaining_dt > 0.0 {
            if self.queue[0] <= remaining_dt {
                remaining_dt -= self.queue[0];
                self.queue.remove(0);
                completed_units += 1;
            } else {
                self.queue[0] -= remaining_dt;
                remaining_dt = 0.0;
            }
        }

        completed_units
    }

    /// Cancels the last unit in the queue. Returns true if a unit was canceled.
    pub fn cancel_last(&mut self) -> bool {
        if self.queue.is_empty() {
            return false;
        }

        self.queue.pop();
        
        // Refund resources
        let refund_minerals = (self.params.cost_minerals as f32 * self.params.refund_ratio) as u32;
        let refund_gas = (self.params.cost_gas as f32 * self.params.refund_ratio) as u32;
        
        self.minerals += refund_minerals;
        self.gas += refund_gas;

        true
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_queue_and_update() {
        let params = UnitProductionParams::new();
        let mut queue = ProductionQueue::new(params, 100, 0);

        // Queue 2 units
        assert!(queue.queue_unit());
        assert!(queue.queue_unit());
        assert_eq!(queue.queue.len(), 2);
        assert_eq!(queue.minerals, 0); // 100 - 50*2

        // Update by 10 seconds (not enough for 1 unit)
        let completed = queue.update(10.0);
        assert_eq!(completed, 0);
        assert_eq!(queue.queue.len(), 2);
        assert_eq!(queue.queue[0], 2.0);

        // Update by 5 seconds (completes 1 unit, 3 seconds into next)
        let completed = queue.update(5.0);
        assert_eq!(completed, 1);
        assert_eq!(queue.queue.len(), 1);
        assert_eq!(queue.queue[0], 9.0);
    }

    #[test]
    fn test_cancel_refund() {
        let mut params = UnitProductionParams::new();
        params.refund_ratio = 0.5; // 50% refund
        let mut queue = ProductionQueue::new(params, 50, 0);

        assert!(queue.queue_unit());
        assert_eq!(queue.minerals, 0);

        assert!(queue.cancel_last());
        assert_eq!(queue.queue.len(), 0);
        assert_eq!(queue.minerals, 25); // 50% of 50
    }
    
    #[test]
    fn test_queue_limit() {
        let mut params = UnitProductionParams::new();
        params.max_queue_size = 2;
        let mut queue = ProductionQueue::new(params, 1000, 1000);
        
        assert!(queue.queue_unit());
        assert!(queue.queue_unit());
        assert!(!queue.queue_unit()); // Should fail due to max queue size
    }
}
