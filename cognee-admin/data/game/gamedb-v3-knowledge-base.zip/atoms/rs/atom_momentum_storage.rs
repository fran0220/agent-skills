#[derive(Debug, Clone, Copy)]
pub struct MomentumStorageParams {
    pub momentum_multiplier: f32,
    pub storage_window_frames: u32,
    pub max_stored_velocity: f32,
    pub friction_decay_rate: f32,
}

impl MomentumStorageParams {
    /// Creates a new MomentumStorageParams with default values based on Celeste v1.4 benchmark.
    pub fn new() -> Self {
        Self {
            momentum_multiplier: 1.2,
            storage_window_frames: 3,
            max_stored_velocity: 500.0,
            friction_decay_rate: 0.95,
        }
    }

    /// Calculates the stored momentum given an input velocity.
    /// The stored momentum is multiplied by the momentum_multiplier and capped at max_stored_velocity.
    pub fn store_momentum(&self, input_velocity: f32) -> f32 {
        let stored = input_velocity * self.momentum_multiplier;
        if stored.abs() > self.max_stored_velocity {
            self.max_stored_velocity * stored.signum()
        } else {
            stored
        }
    }

    /// Applies friction decay to the stored momentum over a single frame.
    pub fn apply_friction(&self, current_stored_velocity: f32) -> f32 {
        current_stored_velocity * self.friction_decay_rate
    }

    /// Releases the stored momentum, combining it with a base action velocity (e.g., jump velocity).
    pub fn release_momentum(&self, stored_velocity: f32, base_velocity: f32) -> f32 {
        // Simple additive release, capped by max_stored_velocity if they are in the same direction
        let combined = base_velocity + stored_velocity;
        if combined.abs() > self.max_stored_velocity && combined.signum() == stored_velocity.signum() {
            self.max_stored_velocity * combined.signum()
        } else {
            combined
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_store_momentum_capping() {
        let params = MomentumStorageParams::new();
        
        // Test normal storage
        let stored1 = params.store_momentum(200.0);
        assert_eq!(stored1, 240.0); // 200 * 1.2
        
        // Test capping
        let stored2 = params.store_momentum(600.0);
        assert_eq!(stored2, 500.0); // 600 * 1.2 = 720, capped at 500
        
        // Test negative capping
        let stored3 = params.store_momentum(-600.0);
        assert_eq!(stored3, -500.0);
    }

    #[test]
    fn test_apply_friction() {
        let params = MomentumStorageParams::new();
        
        let velocity = 100.0;
        let decayed = params.apply_friction(velocity);
        assert_eq!(decayed, 95.0); // 100 * 0.95
    }

    #[test]
    fn test_release_momentum() {
        let params = MomentumStorageParams::new();
        
        // Test normal release
        let released1 = params.release_momentum(200.0, 100.0);
        assert_eq!(released1, 300.0);
        
        // Test capped release
        let released2 = params.release_momentum(400.0, 200.0);
        assert_eq!(released2, 500.0); // 400 + 200 = 600, capped at 500
    }
}
