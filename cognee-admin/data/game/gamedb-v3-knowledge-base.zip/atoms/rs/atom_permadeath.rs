#[derive(Debug, Clone, PartialEq)]
pub struct PermadeathParams {
    pub lives_count: u32,
    pub save_deletion: bool,
    pub legacy_multiplier: f32,
    pub grace_period_ms: u32,
}

impl PermadeathParams {
    /// Creates a new PermadeathParams with default values based on benchmark data.
    pub fn new() -> Self {
        Self {
            lives_count: 1,
            save_deletion: true,
            legacy_multiplier: 0.0,
            grace_period_ms: 0,
        }
    }

    /// Calculates the remaining lives after taking a fatal hit.
    /// Returns the new lives count and a boolean indicating if the character is permanently dead.
    pub fn take_fatal_hit(&self, current_lives: u32) -> (u32, bool) {
        if current_lives > 0 {
            let new_lives = current_lives - 1;
            (new_lives, new_lives == 0)
        } else {
            (0, true)
        }
    }

    /// Calculates the legacy resources carried over to the next run upon permanent death.
    /// Returns the amount of resources to carry over.
    pub fn calculate_legacy_resources(&self, accumulated_resources: f32) -> f32 {
        accumulated_resources * self.legacy_multiplier
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_take_fatal_hit() {
        let params = PermadeathParams::new();
        
        // Test with 1 life (standard permadeath)
        let (lives, is_dead) = params.take_fatal_hit(1);
        assert_eq!(lives, 0);
        assert_eq!(is_dead, true);

        // Test with multiple lives
        let (lives, is_dead) = params.take_fatal_hit(3);
        assert_eq!(lives, 2);
        assert_eq!(is_dead, false);
        
        // Test already dead
        let (lives, is_dead) = params.take_fatal_hit(0);
        assert_eq!(lives, 0);
        assert_eq!(is_dead, true);
    }

    #[test]
    fn test_calculate_legacy_resources() {
        let mut params = PermadeathParams::new();
        
        // Pure roguelike (no legacy)
        params.legacy_multiplier = 0.0;
        assert_eq!(params.calculate_legacy_resources(1000.0), 0.0);

        // Roguelite (partial legacy)
        params.legacy_multiplier = 0.5;
        assert_eq!(params.calculate_legacy_resources(1000.0), 500.0);
    }
}
