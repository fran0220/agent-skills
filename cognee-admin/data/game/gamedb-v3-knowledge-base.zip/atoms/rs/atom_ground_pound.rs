#[derive(Debug, Clone, PartialEq)]
pub struct GroundPoundParams {
    pub stall_duration: f32,
    pub descent_velocity: f32,
    pub impact_radius: f32,
    pub damage: u32,
    pub recovery_duration: f32,
}

impl GroundPoundParams {
    /// Creates a new GroundPoundParams with default values based on Super Mario 64 benchmark.
    pub fn new() -> Self {
        Self {
            stall_duration: 0.25,
            descent_velocity: 35.0,
            impact_radius: 2.0,
            damage: 10,
            recovery_duration: 0.4,
        }
    }
}

impl Default for GroundPoundParams {
    fn default() -> Self {
        Self::new()
    }
}

#[derive(Debug, Clone, PartialEq)]
pub enum GroundPoundState {
    Idle,
    Airborne,
    Stalling { timer: f32 },
    Descending,
    Impact,
    Recovery { timer: f32 },
}

pub struct GroundPoundAtom {
    pub params: GroundPoundParams,
    pub state: GroundPoundState,
}

impl GroundPoundAtom {
    pub fn new(params: GroundPoundParams) -> Self {
        Self {
            params,
            state: GroundPoundState::Idle,
        }
    }

    /// Initiates the ground pound from an airborne state.
    pub fn initiate(&mut self) -> bool {
        if let GroundPoundState::Airborne = self.state {
            self.state = GroundPoundState::Stalling { timer: 0.0 };
            true
        } else {
            false
        }
    }

    /// Updates the state machine based on delta time.
    pub fn update(&mut self, dt: f32, is_grounded: bool) {
        match self.state {
            GroundPoundState::Stalling { ref mut timer } => {
                *timer += dt;
                if *timer >= self.params.stall_duration {
                    self.state = GroundPoundState::Descending;
                }
            }
            GroundPoundState::Descending => {
                if is_grounded {
                    self.state = GroundPoundState::Impact;
                }
            }
            GroundPoundState::Impact => {
                // Impact logic is typically handled in one frame, then transitions to recovery
                self.state = GroundPoundState::Recovery { timer: 0.0 };
            }
            GroundPoundState::Recovery { ref mut timer } => {
                *timer += dt;
                if *timer >= self.params.recovery_duration {
                    self.state = GroundPoundState::Idle;
                }
            }
            _ => {}
        }
    }

    /// Calculates the current vertical velocity based on the state.
    pub fn get_vertical_velocity(&self, current_velocity: f32) -> f32 {
        match self.state {
            GroundPoundState::Stalling { .. } => 0.0, // Halt vertical momentum
            GroundPoundState::Descending => -self.params.descent_velocity, // Apply downward velocity
            _ => current_velocity,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_initiate_ground_pound() {
        let mut atom = GroundPoundAtom::new(GroundPoundParams::new());
        
        // Cannot initiate from Idle
        assert!(!atom.initiate());
        
        // Can initiate from Airborne
        atom.state = GroundPoundState::Airborne;
        assert!(atom.initiate());
        assert_eq!(atom.state, GroundPoundState::Stalling { timer: 0.0 });
    }

    #[test]
    fn test_state_transitions() {
        let mut atom = GroundPoundAtom::new(GroundPoundParams::new());
        atom.state = GroundPoundState::Stalling { timer: 0.0 };
        
        // Update during stall
        atom.update(0.1, false);
        assert_eq!(atom.state, GroundPoundState::Stalling { timer: 0.1 });
        
        // Transition to descending
        atom.update(0.2, false); // Total time 0.3 > 0.25
        assert_eq!(atom.state, GroundPoundState::Descending);
        
        // Transition to impact
        atom.update(0.1, true);
        assert_eq!(atom.state, GroundPoundState::Recovery { timer: 0.0 });
        
        // Transition to idle
        atom.update(0.5, true); // Total time 0.5 > 0.4
        assert_eq!(atom.state, GroundPoundState::Idle);
    }

    #[test]
    fn test_vertical_velocity() {
        let mut atom = GroundPoundAtom::new(GroundPoundParams::new());
        
        atom.state = GroundPoundState::Stalling { timer: 0.0 };
        assert_eq!(atom.get_vertical_velocity(-10.0), 0.0);
        
        atom.state = GroundPoundState::Descending;
        assert_eq!(atom.get_vertical_velocity(-10.0), -35.0);
        
        atom.state = GroundPoundState::Idle;
        assert_eq!(atom.get_vertical_velocity(-10.0), -10.0);
    }
}
