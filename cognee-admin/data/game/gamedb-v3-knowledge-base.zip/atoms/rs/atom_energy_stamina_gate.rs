#[derive(Debug, Clone)]
pub struct EnergyStaminaGate {
    pub max_energy: u32,
    pub regen_rate_minutes: u32,
    pub current_energy: u32,
    pub last_update_timestamp: u64, // Unix timestamp in seconds
}

impl EnergyStaminaGate {
    /// Creates a new EnergyStaminaGate with default values based on Genshin Impact benchmark.
    pub fn new(current_timestamp: u64) -> Self {
        Self {
            max_energy: 160,
            regen_rate_minutes: 8,
            current_energy: 160,
            last_update_timestamp: current_timestamp,
        }
    }

    /// Updates the current energy based on the time elapsed since the last update.
    pub fn update_energy(&mut self, current_timestamp: u64) -> u32 {
        if self.current_energy >= self.max_energy {
            self.last_update_timestamp = current_timestamp;
            return self.current_energy;
        }

        let elapsed_seconds = current_timestamp.saturating_sub(self.last_update_timestamp);
        let regen_rate_seconds = (self.regen_rate_minutes * 60) as u64;
        
        let energy_to_add = (elapsed_seconds / regen_rate_seconds) as u32;
        
        if energy_to_add > 0 {
            self.current_energy = std::cmp::min(self.max_energy, self.current_energy + energy_to_add);
            // Update timestamp to account for the exact time used for regeneration
            self.last_update_timestamp += (energy_to_add as u64) * regen_rate_seconds;
        }

        self.current_energy
    }

    /// Attempts to consume energy for an action. Returns true if successful, false otherwise.
    pub fn consume_energy(&mut self, cost: u32, current_timestamp: u64) -> bool {
        self.update_energy(current_timestamp);
        
        if self.current_energy >= cost {
            self.current_energy -= cost;
            // If we were at max energy, start the regeneration timer now
            if self.current_energy + cost >= self.max_energy {
                self.last_update_timestamp = current_timestamp;
            }
            true
        } else {
            false
        }
    }

    /// Refills energy by a specific amount, potentially overflowing the max cap.
    pub fn refill_energy(&mut self, amount: u32) {
        self.current_energy += amount;
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_energy_regeneration() {
        let start_time = 1000000;
        let mut gate = EnergyStaminaGate::new(start_time);
        
        // Consume some energy
        gate.current_energy = 100;
        gate.last_update_timestamp = start_time;

        // Wait for 16 minutes (2 energy points at 8 mins/point)
        let current_time = start_time + (16 * 60);
        gate.update_energy(current_time);

        assert_eq!(gate.current_energy, 102);
        assert_eq!(gate.last_update_timestamp, start_time + (16 * 60));
    }

    #[test]
    fn test_consume_energy() {
        let start_time = 1000000;
        let mut gate = EnergyStaminaGate::new(start_time);
        
        // Try to consume 20 energy (success)
        assert!(gate.consume_energy(20, start_time));
        assert_eq!(gate.current_energy, 140);

        // Try to consume 150 energy (fail, only 140 left)
        assert!(!gate.consume_energy(150, start_time));
        assert_eq!(gate.current_energy, 140);
    }

    #[test]
    fn test_energy_cap() {
        let start_time = 1000000;
        let mut gate = EnergyStaminaGate::new(start_time);
        
        gate.current_energy = 159;
        gate.last_update_timestamp = start_time;

        // Wait for 24 minutes (3 energy points, but should cap at 160)
        let current_time = start_time + (24 * 60);
        gate.update_energy(current_time);

        assert_eq!(gate.current_energy, 160);
    }
}
