#[derive(Debug, Clone, PartialEq)]
pub struct ActionPoints {
    pub max_ap: u32,
    pub current_ap: u32,
    pub base_ap_regen: u32,
    pub move_cost: u32,
    pub attack_cost: u32,
    pub overwatch_cost: u32,
}

impl ActionPoints {
    /// Creates a new ActionPoints instance with default values based on XCOM: Enemy Unknown benchmark.
    pub fn new() -> Self {
        Self {
            max_ap: 2,
            current_ap: 2,
            base_ap_regen: 2,
            move_cost: 1,
            attack_cost: 1,
            overwatch_cost: 1,
        }
    }

    /// Replenishes AP at the start of a turn, up to the maximum AP.
    pub fn replenish(&mut self) {
        self.current_ap = (self.current_ap + self.base_ap_regen).min(self.max_ap);
    }

    /// Attempts to spend AP for an action. Returns true if successful, false if insufficient AP.
    pub fn spend(&mut self, cost: u32) -> bool {
        if self.current_ap >= cost {
            self.current_ap -= cost;
            true
        } else {
            false
        }
    }

    /// Checks if a specific action can be performed based on its cost.
    pub fn can_afford(&self, cost: u32) -> bool {
        self.current_ap >= cost
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_replenish_ap() {
        let mut ap = ActionPoints::new();
        ap.current_ap = 0;
        ap.replenish();
        assert_eq!(ap.current_ap, 2);

        // Test capping at max_ap
        ap.max_ap = 5;
        ap.base_ap_regen = 4;
        ap.current_ap = 2;
        ap.replenish();
        assert_eq!(ap.current_ap, 5);
    }

    #[test]
    fn test_spend_ap() {
        let mut ap = ActionPoints::new();
        
        // Successful spend
        assert!(ap.spend(ap.move_cost));
        assert_eq!(ap.current_ap, 1);

        // Unsuccessful spend
        assert!(!ap.spend(ap.attack_cost + 1));
        assert_eq!(ap.current_ap, 1); // AP should not change
    }

    #[test]
    fn test_can_afford() {
        let ap = ActionPoints::new();
        assert!(ap.can_afford(ap.move_cost));
        assert!(!ap.can_afford(ap.max_ap + 1));
    }
}
