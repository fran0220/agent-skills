pub struct WeaponBloom {
    pub base_spread: f32,
    pub max_spread: f32,
    pub spread_per_shot: f32,
    pub recovery_rate: f32,
    pub movement_multiplier: f32,
    pub crouch_multiplier: f32,
    pub jump_multiplier: f32,
    
    pub current_spread: f32,
}

impl WeaponBloom {
    /// Creates a new WeaponBloom instance with default values based on Fortnite v28.00 Assault Rifle benchmark.
    pub fn new() -> Self {
        Self {
            base_spread: 0.1,
            max_spread: 3.5,
            spread_per_shot: 0.15,
            recovery_rate: 12.0,
            movement_multiplier: 1.5,
            crouch_multiplier: 0.65,
            jump_multiplier: 3.0,
            current_spread: 0.1,
        }
    }

    /// Calculates the current spread after firing a shot.
    pub fn fire_shot(&mut self) -> f32 {
        self.current_spread += self.spread_per_shot;
        if self.current_spread > self.max_spread {
            self.current_spread = self.max_spread;
        }
        self.current_spread
    }

    /// Calculates the spread recovery over a given delta time (in seconds).
    pub fn recover(&mut self, delta_time: f32) -> f32 {
        self.current_spread -= self.recovery_rate * delta_time;
        if self.current_spread < self.base_spread {
            self.current_spread = self.base_spread;
        }
        self.current_spread
    }

    /// Calculates the effective spread based on the player's current state.
    pub fn get_effective_spread(&self, is_moving: bool, is_crouching: bool, is_jumping: bool) -> f32 {
        let mut multiplier = 1.0;
        
        if is_jumping {
            multiplier *= self.jump_multiplier;
        } else if is_moving {
            multiplier *= self.movement_multiplier;
        }
        
        if is_crouching && !is_jumping {
            multiplier *= self.crouch_multiplier;
        }
        
        self.current_spread * multiplier
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_fire_shot_increases_spread() {
        let mut bloom = WeaponBloom::new();
        let initial_spread = bloom.current_spread;
        
        let new_spread = bloom.fire_shot();
        
        assert!(new_spread > initial_spread);
        assert_eq!(new_spread, initial_spread + bloom.spread_per_shot);
    }

    #[test]
    fn test_fire_shot_caps_at_max_spread() {
        let mut bloom = WeaponBloom::new();
        bloom.current_spread = bloom.max_spread - (bloom.spread_per_shot / 2.0);
        
        let new_spread = bloom.fire_shot();
        
        assert_eq!(new_spread, bloom.max_spread);
    }

    #[test]
    fn test_recover_decreases_spread() {
        let mut bloom = WeaponBloom::new();
        bloom.current_spread = 2.0;
        
        let delta_time = 0.1; // 100ms
        let expected_spread = 2.0 - (bloom.recovery_rate * delta_time);
        
        let new_spread = bloom.recover(delta_time);
        
        assert_eq!(new_spread, expected_spread);
    }

    #[test]
    fn test_recover_caps_at_base_spread() {
        let mut bloom = WeaponBloom::new();
        bloom.current_spread = bloom.base_spread + 0.1;
        
        let delta_time = 1.0; // 1 second, should fully recover
        
        let new_spread = bloom.recover(delta_time);
        
        assert_eq!(new_spread, bloom.base_spread);
    }

    #[test]
    fn test_effective_spread_modifiers() {
        let bloom = WeaponBloom::new();
        
        // Base spread
        assert_eq!(bloom.get_effective_spread(false, false, false), bloom.current_spread);
        
        // Moving
        assert_eq!(bloom.get_effective_spread(true, false, false), bloom.current_spread * bloom.movement_multiplier);
        
        // Crouching
        assert_eq!(bloom.get_effective_spread(false, true, false), bloom.current_spread * bloom.crouch_multiplier);
        
        // Jumping
        assert_eq!(bloom.get_effective_spread(false, false, true), bloom.current_spread * bloom.jump_multiplier);
        
        // Moving and Crouching
        assert_eq!(bloom.get_effective_spread(true, true, false), bloom.current_spread * bloom.movement_multiplier * bloom.crouch_multiplier);
    }
}
