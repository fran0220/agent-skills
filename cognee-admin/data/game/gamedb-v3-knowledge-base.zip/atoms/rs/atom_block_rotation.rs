#[derive(Debug, Clone, PartialEq)]
pub struct BlockRotationParams {
    pub fall_speed: f32,
    pub lock_delay: u32,
    pub das: u32,
    pub arr: u32,
    pub soft_drop_multiplier: f32,
}

impl BlockRotationParams {
    /// Creates a new `BlockRotationParams` with default values based on Tetris Guideline benchmarks.
    pub fn new() -> Self {
        Self {
            fall_speed: 0.016,
            lock_delay: 30,
            das: 10,
            arr: 2,
            soft_drop_multiplier: 20.0,
        }
    }

    /// Calculates the effective fall speed when soft dropping.
    pub fn calculate_soft_drop_speed(&self) -> f32 {
        self.fall_speed * self.soft_drop_multiplier
    }

    /// Determines if the lock delay has expired.
    pub fn is_locked(&self, current_lock_frames: u32) -> bool {
        current_lock_frames >= self.lock_delay
    }

    /// Calculates the number of frames to wait before auto-repeating movement.
    pub fn calculate_das_delay(&self) -> u32 {
        self.das
    }
}

impl Default for BlockRotationParams {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_soft_drop_speed() {
        let params = BlockRotationParams::new();
        let soft_drop_speed = params.calculate_soft_drop_speed();
        assert_eq!(soft_drop_speed, 0.016 * 20.0);
    }

    #[test]
    fn test_is_locked() {
        let params = BlockRotationParams::new();
        assert!(!params.is_locked(29));
        assert!(params.is_locked(30));
        assert!(params.is_locked(31));
    }

    #[test]
    fn test_das_delay() {
        let params = BlockRotationParams::new();
        assert_eq!(params.calculate_das_delay(), 10);
    }
}
