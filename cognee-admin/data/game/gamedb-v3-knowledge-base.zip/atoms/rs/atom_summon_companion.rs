#[derive(Debug, Clone, PartialEq)]
pub struct SummonCompanionParams {
    pub summon_cost: f32,
    pub cast_time: f32,
    pub duration: f32,
    pub cooldown: f32,
    pub max_hp_ratio: f32,
    pub damage_ratio: f32,
    pub aggro_multiplier: f32,
    pub max_active_summons: u32,
}

impl SummonCompanionParams {
    /// Creates a new `SummonCompanionParams` with default values based on Diablo III benchmarks.
    pub fn new() -> Self {
        Self {
            summon_cost: 25.0,
            cast_time: 1.5,
            duration: 9999.0, // Infinite
            cooldown: 60.0,
            max_hp_ratio: 0.5,
            damage_ratio: 0.3,
            aggro_multiplier: 2.0,
            max_active_summons: 1,
        }
    }
}

impl Default for SummonCompanionParams {
    fn default() -> Self {
        Self::new()
    }
}

#[derive(Debug, Clone, PartialEq)]
pub struct CompanionStats {
    pub max_hp: f32,
    pub damage: f32,
    pub aggro_generation: f32,
}

pub struct SummonCompanionAtom {
    pub params: SummonCompanionParams,
    pub active_summons: u32,
    pub last_summon_time: f32,
}

impl SummonCompanionAtom {
    pub fn new(params: SummonCompanionParams) -> Self {
        Self {
            params,
            active_summons: 0,
            last_summon_time: -9999.0,
        }
    }

    /// Calculates the stats of the summoned companion based on the player's stats.
    pub fn calculate_companion_stats(&self, player_max_hp: f32, player_damage: f32, base_aggro: f32) -> CompanionStats {
        CompanionStats {
            max_hp: player_max_hp * self.params.max_hp_ratio,
            damage: player_damage * self.params.damage_ratio,
            aggro_generation: base_aggro * self.params.aggro_multiplier,
        }
    }

    /// Attempts to summon a companion. Returns true if successful, false otherwise.
    pub fn try_summon(&mut self, current_time: f32, current_resource: f32) -> bool {
        if self.active_summons >= self.params.max_active_summons {
            return false; // Max summons reached
        }

        if current_time - self.last_summon_time < self.params.cooldown {
            return false; // On cooldown
        }

        if current_resource < self.params.summon_cost {
            return false; // Not enough resource
        }

        // Summon successful
        self.active_summons += 1;
        self.last_summon_time = current_time;
        true
    }

    /// Handles the death or dismissal of a companion.
    pub fn on_companion_removed(&mut self) {
        if self.active_summons > 0 {
            self.active_summons -= 1;
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_companion_stats() {
        let params = SummonCompanionParams::new();
        let atom = SummonCompanionAtom::new(params);

        let player_hp = 1000.0;
        let player_dmg = 100.0;
        let base_aggro = 50.0;

        let stats = atom.calculate_companion_stats(player_hp, player_dmg, base_aggro);

        assert_eq!(stats.max_hp, 500.0); // 1000 * 0.5
        assert_eq!(stats.damage, 30.0);  // 100 * 0.3
        assert_eq!(stats.aggro_generation, 100.0); // 50 * 2.0
    }

    #[test]
    fn test_try_summon_success_and_limits() {
        let mut params = SummonCompanionParams::new();
        params.max_active_summons = 2;
        params.cooldown = 10.0;
        params.summon_cost = 20.0;

        let mut atom = SummonCompanionAtom::new(params);

        // First summon: success
        assert!(atom.try_summon(100.0, 50.0));
        assert_eq!(atom.active_summons, 1);

        // Second summon immediately: fail due to cooldown
        assert!(!atom.try_summon(105.0, 30.0));
        assert_eq!(atom.active_summons, 1);

        // Second summon after cooldown: success
        assert!(atom.try_summon(115.0, 30.0));
        assert_eq!(atom.active_summons, 2);

        // Third summon: fail due to max active summons
        assert!(!atom.try_summon(130.0, 10.0));
        assert_eq!(atom.active_summons, 2);

        // Remove one and summon again: fail due to resource
        atom.on_companion_removed();
        assert_eq!(atom.active_summons, 1);
        assert!(!atom.try_summon(140.0, 10.0)); // Cost is 20, only have 10
    }
}
