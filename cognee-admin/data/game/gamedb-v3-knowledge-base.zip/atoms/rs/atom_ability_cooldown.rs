pub struct AbilityCooldown {
    pub base_cooldown: f32,
    pub cooldown_reduction: f32,
    pub has_charges: bool,
    pub max_charges: u32,
    pub current_charges: u32,
    pub current_cooldown: f32,
}

impl AbilityCooldown {
    /// Creates a new AbilityCooldown with default values based on Overwatch benchmark.
    pub fn new() -> Self {
        Self {
            base_cooldown: 10.0,
            cooldown_reduction: 0.0,
            has_charges: false,
            max_charges: 1,
            current_charges: 1,
            current_cooldown: 0.0,
        }
    }

    /// Calculates the effective cooldown time after applying cooldown reduction.
    pub fn effective_cooldown(&self) -> f32 {
        self.base_cooldown * (1.0 - self.cooldown_reduction).max(0.0)
    }

    /// Attempts to use the ability. Returns true if successful, false if on cooldown.
    pub fn use_ability(&mut self) -> bool {
        if self.current_charges > 0 {
            self.current_charges -= 1;
            if self.current_cooldown <= 0.0 {
                self.current_cooldown = self.effective_cooldown();
            }
            true
        } else {
            false
        }
    }

    /// Updates the cooldown timer by the given delta time.
    pub fn update(&mut self, delta_time: f32) {
        if self.current_cooldown > 0.0 {
            self.current_cooldown -= delta_time;
            if self.current_cooldown <= 0.0 {
                self.current_cooldown = 0.0;
                if self.current_charges < self.max_charges {
                    self.current_charges += 1;
                    if self.current_charges < self.max_charges {
                        self.current_cooldown = self.effective_cooldown();
                    }
                }
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_effective_cooldown() {
        let mut cooldown = AbilityCooldown::new();
        cooldown.base_cooldown = 10.0;
        cooldown.cooldown_reduction = 0.2;
        assert_eq!(cooldown.effective_cooldown(), 8.0);
    }

    #[test]
    fn test_use_ability_and_update() {
        let mut cooldown = AbilityCooldown::new();
        cooldown.base_cooldown = 10.0;
        
        // Initially ready
        assert!(cooldown.use_ability());
        assert_eq!(cooldown.current_charges, 0);
        assert_eq!(cooldown.current_cooldown, 10.0);
        
        // Cannot use while on cooldown
        assert!(!cooldown.use_ability());
        
        // Update by 5 seconds
        cooldown.update(5.0);
        assert_eq!(cooldown.current_cooldown, 5.0);
        assert_eq!(cooldown.current_charges, 0);
        
        // Update by another 5 seconds
        cooldown.update(5.0);
        assert_eq!(cooldown.current_cooldown, 0.0);
        assert_eq!(cooldown.current_charges, 1);
        
        // Ready again
        assert!(cooldown.use_ability());
    }

    #[test]
    fn test_charges() {
        let mut cooldown = AbilityCooldown::new();
        cooldown.base_cooldown = 5.0;
        cooldown.has_charges = true;
        cooldown.max_charges = 2;
        cooldown.current_charges = 2;

        // Use first charge
        assert!(cooldown.use_ability());
        assert_eq!(cooldown.current_charges, 1);
        assert_eq!(cooldown.current_cooldown, 5.0);

        // Use second charge
        assert!(cooldown.use_ability());
        assert_eq!(cooldown.current_charges, 0);
        assert_eq!(cooldown.current_cooldown, 5.0);

        // Cannot use third charge
        assert!(!cooldown.use_ability());

        // Update to restore one charge
        cooldown.update(5.0);
        assert_eq!(cooldown.current_charges, 1);
        assert_eq!(cooldown.current_cooldown, 5.0); // Cooldown starts for the next charge

        // Update to restore second charge
        cooldown.update(5.0);
        assert_eq!(cooldown.current_charges, 2);
        assert_eq!(cooldown.current_cooldown, 0.0);
    }
}
