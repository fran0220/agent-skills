#[derive(Debug, Clone)]
pub struct ChaseSequenceParams {
    pub pursuer_speed: f32,
    pub player_sprint_speed: f32,
    pub stamina_drain_rate: f32,
    pub detection_radius: f32,
    pub search_duration: f32,
    pub catch_distance: f32,
}

impl ChaseSequenceParams {
    /// Creates a new `ChaseSequenceParams` with default values based on Outlast benchmarks.
    pub fn new() -> Self {
        Self {
            pursuer_speed: 5.5,
            player_sprint_speed: 6.0,
            stamina_drain_rate: 10.0,
            detection_radius: 20.0,
            search_duration: 30.0,
            catch_distance: 1.2,
        }
    }

    /// Calculates the time it takes for the pursuer to catch the player given an initial distance.
    /// Returns `None` if the player is faster and will never be caught.
    pub fn time_to_catch(&self, initial_distance: f32) -> Option<f32> {
        if self.pursuer_speed <= self.player_sprint_speed {
            return None;
        }
        let relative_speed = self.pursuer_speed - self.player_sprint_speed;
        let distance_to_close = initial_distance - self.catch_distance;
        if distance_to_close <= 0.0 {
            return Some(0.0);
        }
        Some(distance_to_close / relative_speed)
    }

    /// Calculates the maximum distance the player can sprint before running out of stamina.
    pub fn max_sprint_distance(&self, initial_stamina: f32) -> f32 {
        if self.stamina_drain_rate <= 0.0 {
            return f32::INFINITY;
        }
        let sprint_time = initial_stamina / self.stamina_drain_rate;
        sprint_time * self.player_sprint_speed
    }

    /// Checks if the player is within the detection radius.
    pub fn is_player_detected(&self, distance_to_player: f32) -> bool {
        distance_to_player <= self.detection_radius
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_time_to_catch() {
        let mut params = ChaseSequenceParams::new();
        // Make pursuer faster to test catch time
        params.pursuer_speed = 7.0;
        params.player_sprint_speed = 5.0;
        params.catch_distance = 1.0;
        
        // Relative speed = 2.0 m/s
        // Initial distance = 11.0 m, distance to close = 10.0 m
        // Time to catch = 10.0 / 2.0 = 5.0 s
        let time = params.time_to_catch(11.0);
        assert_eq!(time, Some(5.0));

        // If player is faster, should return None
        params.pursuer_speed = 5.0;
        params.player_sprint_speed = 6.0;
        assert_eq!(params.time_to_catch(10.0), None);
    }

    #[test]
    fn test_max_sprint_distance() {
        let params = ChaseSequenceParams::new();
        // Default stamina drain rate is 10.0 %/s, player sprint speed is 6.0 m/s
        // With 100.0 stamina, sprint time = 10.0 s
        // Max distance = 10.0 s * 6.0 m/s = 60.0 m
        let distance = params.max_sprint_distance(100.0);
        assert_eq!(distance, 60.0);
    }

    #[test]
    fn test_is_player_detected() {
        let params = ChaseSequenceParams::new();
        // Default detection radius is 20.0 m
        assert!(params.is_player_detected(15.0));
        assert!(!params.is_player_detected(25.0));
    }
}
