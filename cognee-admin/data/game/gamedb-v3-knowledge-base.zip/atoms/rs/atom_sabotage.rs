#[derive(Debug, Clone, PartialEq)]
pub struct SabotageParameters {
    pub sabotage_cooldown: f32,
    pub kill_cooldown: f32,
    pub emergency_duration: f32,
    pub saboteur_ratio: f32,
    pub vision_reduction: f32,
}

impl SabotageParameters {
    /// Creates a new SabotageParameters instance with default values based on Among Us benchmarks.
    pub fn new() -> Self {
        Self {
            sabotage_cooldown: 30.0,
            kill_cooldown: 45.0,
            emergency_duration: 30.0,
            saboteur_ratio: 0.2,
            vision_reduction: 0.5,
        }
    }

    /// Calculates the number of saboteurs based on the total number of players.
    /// Ensures there is at least 1 saboteur if there are players.
    pub fn calculate_saboteur_count(&self, total_players: u32) -> u32 {
        if total_players == 0 {
            return 0;
        }
        let count = (total_players as f32 * self.saboteur_ratio).round() as u32;
        if count == 0 {
            1
        } else {
            count
        }
    }

    /// Checks if a sabotage action can be performed based on the time since the last sabotage.
    pub fn can_sabotage(&self, time_since_last_sabotage: f32) -> bool {
        time_since_last_sabotage >= self.sabotage_cooldown
    }

    /// Calculates the effective vision range of innocent players during a sabotage event.
    pub fn calculate_sabotaged_vision(&self, base_vision: f32) -> f32 {
        base_vision * (1.0 - self.vision_reduction)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_saboteur_count() {
        let params = SabotageParameters::new();
        
        // 10 players * 0.2 = 2
        assert_eq!(params.calculate_saboteur_count(10), 2);
        
        // 4 players * 0.2 = 0.8 -> 1
        assert_eq!(params.calculate_saboteur_count(4), 1);
        
        // 0 players -> 0
        assert_eq!(params.calculate_saboteur_count(0), 0);
    }

    #[test]
    fn test_can_sabotage() {
        let params = SabotageParameters::new();
        
        // Cooldown is 30.0
        assert_eq!(params.can_sabotage(29.9), false);
        assert_eq!(params.can_sabotage(30.0), true);
        assert_eq!(params.can_sabotage(45.0), true);
    }

    #[test]
    fn test_calculate_sabotaged_vision() {
        let params = SabotageParameters::new();
        
        // Base vision 10.0, reduction 0.5 -> 5.0
        assert_eq!(params.calculate_sabotaged_vision(10.0), 5.0);
    }
}
