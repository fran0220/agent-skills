#[derive(Debug, Clone)]
pub struct TechTreeParams {
    pub base_cost: u32,
    pub cost_multiplier_per_tier: f32,
    pub research_speed: f32,
    pub max_concurrent_research: u32,
}

impl TechTreeParams {
    /// Creates a new TechTreeParams with default values based on benchmark data.
    pub fn new() -> Self {
        Self {
            base_cost: 50,
            cost_multiplier_per_tier: 1.5,
            research_speed: 1.0,
            max_concurrent_research: 1,
        }
    }

    /// Calculates the total research cost for a technology at a specific tier.
    /// Tier is 1-indexed (tier 1 is the base tier).
    pub fn calculate_tech_cost(&self, tier: u32) -> f32 {
        if tier == 0 {
            return 0.0;
        }
        let base = self.base_cost as f32;
        let multiplier = self.cost_multiplier_per_tier.powi((tier - 1) as i32);
        base * multiplier
    }

    /// Calculates the time (in ticks) required to research a technology given its cost.
    pub fn calculate_research_time(&self, cost: f32) -> f32 {
        if self.research_speed <= 0.0 {
            return f32::INFINITY;
        }
        cost / self.research_speed
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_tech_cost() {
        let params = TechTreeParams::new();
        
        // Tier 1 cost should be base_cost
        assert_eq!(params.calculate_tech_cost(1), 50.0);
        
        // Tier 2 cost should be base_cost * 1.5
        assert_eq!(params.calculate_tech_cost(2), 75.0);
        
        // Tier 3 cost should be base_cost * 1.5^2 = 50 * 2.25 = 112.5
        assert_eq!(params.calculate_tech_cost(3), 112.5);
    }

    #[test]
    fn test_calculate_research_time() {
        let mut params = TechTreeParams::new();
        
        // Cost 100, speed 1.0 -> time 100.0
        assert_eq!(params.calculate_research_time(100.0), 100.0);
        
        // Cost 100, speed 2.0 -> time 50.0
        params.research_speed = 2.0;
        assert_eq!(params.calculate_research_time(100.0), 50.0);
        
        // Cost 100, speed 0.5 -> time 200.0
        params.research_speed = 0.5;
        assert_eq!(params.calculate_research_time(100.0), 200.0);
    }
}
