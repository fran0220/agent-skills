#[derive(Debug, Clone, PartialEq)]
pub struct SkinCosmeticParams {
    pub rarity_tier: u32,
    pub price_premium: u32,
    pub price_freemium: u32,
    pub is_limited_time: bool,
    pub visual_effects_level: u32,
}

impl SkinCosmeticParams {
    /// Creates a new SkinCosmeticParams with default values based on Fortnite v28.00 Epic skin benchmark.
    pub fn new() -> Self {
        Self {
            rarity_tier: 3,
            price_premium: 1500,
            price_freemium: 6300, // LoL benchmark
            is_limited_time: false,
            visual_effects_level: 2,
        }
    }

    /// Calculates the discount price based on a given discount percentage (0.0 to 1.0).
    pub fn calculate_discounted_premium_price(&self, discount_rate: f32) -> u32 {
        let discount_rate = discount_rate.clamp(0.0, 1.0);
        let discount_amount = (self.price_premium as f32 * discount_rate).round() as u32;
        self.price_premium.saturating_sub(discount_amount)
    }

    /// Determines if the cosmetic is considered "high tier" based on rarity and visual effects.
    pub fn is_high_tier(&self) -> bool {
        self.rarity_tier >= 4 || self.visual_effects_level >= 3
    }
    
    /// Calculates a dynamic freemium price based on the premium price and a conversion rate.
    pub fn calculate_dynamic_freemium_price(&self, conversion_rate: f32) -> u32 {
        (self.price_premium as f32 * conversion_rate).round() as u32
    }
}

impl Default for SkinCosmeticParams {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_discounted_premium_price() {
        let params = SkinCosmeticParams::new();
        // 1500 * 0.2 = 300 discount -> 1200
        assert_eq!(params.calculate_discounted_premium_price(0.2), 1200);
        
        // 1500 * 0.5 = 750 discount -> 750
        assert_eq!(params.calculate_discounted_premium_price(0.5), 750);
        
        // 1500 * 1.0 = 1500 discount -> 0
        assert_eq!(params.calculate_discounted_premium_price(1.0), 0);
        
        // 1500 * 1.5 (clamped to 1.0) -> 0
        assert_eq!(params.calculate_discounted_premium_price(1.5), 0);
    }

    #[test]
    fn test_is_high_tier() {
        let mut params = SkinCosmeticParams::new();
        // Default is rarity 3, vfx 2 -> false
        assert!(!params.is_high_tier());
        
        params.rarity_tier = 4;
        assert!(params.is_high_tier());
        
        params.rarity_tier = 3;
        params.visual_effects_level = 3;
        assert!(params.is_high_tier());
    }
    
    #[test]
    fn test_calculate_dynamic_freemium_price() {
        let params = SkinCosmeticParams::new();
        // 1500 * 4.2 = 6300
        assert_eq!(params.calculate_dynamic_freemium_price(4.2), 6300);
    }
}
