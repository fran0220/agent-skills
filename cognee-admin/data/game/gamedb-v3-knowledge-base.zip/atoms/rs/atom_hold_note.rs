#[derive(Debug, Clone, PartialEq)]
pub struct HoldNoteParams {
    pub start_timing_window: f32,
    pub end_timing_window: f32,
    pub tick_interval: f32,
    pub minimum_hold_duration: f32,
    pub drop_tolerance: f32,
}

impl HoldNoteParams {
    /// Creates a new `HoldNoteParams` with default values based on benchmark data.
    pub fn new() -> Self {
        Self {
            start_timing_window: 0.05,
            end_timing_window: 0.10,
            tick_interval: 0.10,
            minimum_hold_duration: 0.20,
            drop_tolerance: 0.10,
        }
    }
}

impl Default for HoldNoteParams {
    fn default() -> Self {
        Self::new()
    }
}

#[derive(Debug, Clone, PartialEq)]
pub enum HoldNoteState {
    Idle,
    Holding,
    Completed,
    Missed,
    Dropped,
}

pub struct HoldNote {
    pub params: HoldNoteParams,
    pub state: HoldNoteState,
    pub start_time: f32,
    pub end_time: f32,
    pub last_tick_time: f32,
    pub drop_time: Option<f32>,
}

impl HoldNote {
    pub fn new(start_time: f32, end_time: f32, params: HoldNoteParams) -> Self {
        Self {
            params,
            state: HoldNoteState::Idle,
            start_time,
            end_time,
            last_tick_time: start_time,
            drop_time: None,
        }
    }

    /// Evaluates an initial press action.
    pub fn evaluate_press(&mut self, current_time: f32) -> bool {
        if self.state != HoldNoteState::Idle {
            return false;
        }

        let time_diff = (current_time - self.start_time).abs();
        if time_diff <= self.params.start_timing_window {
            self.state = HoldNoteState::Holding;
            self.last_tick_time = current_time;
            true
        } else if current_time > self.start_time + self.params.start_timing_window {
            self.state = HoldNoteState::Missed;
            false
        } else {
            false
        }
    }

    /// Evaluates a release action.
    pub fn evaluate_release(&mut self, current_time: f32) -> bool {
        if self.state != HoldNoteState::Holding {
            return false;
        }

        let time_diff = (current_time - self.end_time).abs();
        if time_diff <= self.params.end_timing_window {
            self.state = HoldNoteState::Completed;
            true
        } else {
            // Released too early or too late
            self.state = HoldNoteState::Dropped;
            self.drop_time = Some(current_time);
            false
        }
    }

    /// Updates the state of the hold note over time, handling ticks and drops.
    pub fn update(&mut self, current_time: f32, is_holding: bool) -> u32 {
        let mut ticks_awarded = 0;

        match self.state {
            HoldNoteState::Idle => {
                if current_time > self.start_time + self.params.start_timing_window {
                    self.state = HoldNoteState::Missed;
                }
            }
            HoldNoteState::Holding => {
                if !is_holding {
                    if let Some(drop_t) = self.drop_time {
                        if current_time - drop_t > self.params.drop_tolerance {
                            self.state = HoldNoteState::Dropped;
                        }
                    } else {
                        self.drop_time = Some(current_time);
                    }
                } else {
                    self.drop_time = None; // Recovered from drop
                    
                    // Calculate ticks
                    while current_time - self.last_tick_time >= self.params.tick_interval {
                        ticks_awarded += 1;
                        self.last_tick_time += self.params.tick_interval;
                    }
                }

                // Auto-complete if held past end time
                if current_time > self.end_time + self.params.end_timing_window {
                    if is_holding {
                        self.state = HoldNoteState::Completed;
                    } else {
                        self.state = HoldNoteState::Dropped;
                    }
                }
            }
            _ => {}
        }

        ticks_awarded
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_successful_hold() {
        let params = HoldNoteParams::new();
        let mut note = HoldNote::new(1.0, 3.0, params);

        // Press exactly on time
        assert!(note.evaluate_press(1.0));
        assert_eq!(note.state, HoldNoteState::Holding);

        // Update during hold
        let ticks = note.update(1.5, true);
        assert!(ticks > 0);

        // Release exactly on time
        assert!(note.evaluate_release(3.0));
        assert_eq!(note.state, HoldNoteState::Completed);
    }

    #[test]
    fn test_missed_press() {
        let params = HoldNoteParams::new();
        let mut note = HoldNote::new(1.0, 3.0, params);

        // Try to press too late
        assert!(!note.evaluate_press(1.5));
        assert_eq!(note.state, HoldNoteState::Missed);
    }

    #[test]
    fn test_dropped_hold() {
        let params = HoldNoteParams::new();
        let mut note = HoldNote::new(1.0, 3.0, params);

        // Press on time
        assert!(note.evaluate_press(1.0));

        // Release too early
        assert!(!note.evaluate_release(2.0));
        assert_eq!(note.state, HoldNoteState::Dropped);
    }
    
    #[test]
    fn test_drop_tolerance() {
        let params = HoldNoteParams::new();
        let mut note = HoldNote::new(1.0, 3.0, params.clone());
        
        assert!(note.evaluate_press(1.0));
        
        // Stop holding briefly
        note.update(1.05, false);
        assert_eq!(note.state, HoldNoteState::Holding); // Still holding due to tolerance
        
        // Resume holding
        note.update(1.10, true);
        assert_eq!(note.state, HoldNoteState::Holding);
        
        // Stop holding for longer than tolerance
        note.update(1.15, false);
        note.update(1.15 + params.drop_tolerance + 0.01, false);
        assert_eq!(note.state, HoldNoteState::Dropped);
    }
}
