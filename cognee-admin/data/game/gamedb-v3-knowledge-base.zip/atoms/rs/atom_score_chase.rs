#[derive(Debug, Clone)]
pub struct ScoreChaseParams {
    pub base_score: u32,
    pub combo_multiplier_max: f32,
    pub combo_timeout: f32,
    pub score_decay_rate: f32,
    pub bonus_threshold: u32,
}

impl ScoreChaseParams {
    /// Creates a new ScoreChaseParams with default values based on Pac-Man benchmarks.
    pub fn new() -> Self {
        Self {
            base_score: 100,
            combo_multiplier_max: 8.0,
            combo_timeout: 2.5,
            score_decay_rate: 0.0,
            bonus_threshold: 10000,
        }
    }
}

impl Default for ScoreChaseParams {
    fn default() -> Self {
        Self::new()
    }
}

#[derive(Debug, Clone)]
pub struct ScoreState {
    pub current_score: u32,
    pub current_combo: f32,
    pub time_since_last_score: f32,
}

impl ScoreState {
    pub fn new() -> Self {
        Self {
            current_score: 0,
            current_combo: 1.0,
            time_since_last_score: 0.0,
        }
    }

    /// Updates the score state based on time elapsed.
    /// Handles combo timeout and score decay.
    pub fn update(&mut self, delta_time: f32, params: &ScoreChaseParams) {
        self.time_since_last_score += delta_time;

        if self.time_since_last_score >= params.combo_timeout {
            self.current_combo = 1.0;
        }

        if params.score_decay_rate > 0.0 {
            let decay = (params.score_decay_rate * delta_time) as u32;
            self.current_score = self.current_score.saturating_sub(decay);
        }
    }

    /// Adds score based on an event, applying the current combo multiplier.
    pub fn add_score(&mut self, event_base_score: u32, params: &ScoreChaseParams) {
        let score_to_add = (event_base_score as f32 * self.current_combo) as u32;
        self.current_score += score_to_add;
        self.time_since_last_score = 0.0;
    }

    /// Increases the combo multiplier, up to the maximum allowed.
    pub fn increase_combo(&mut self, amount: f32, params: &ScoreChaseParams) {
        self.current_combo = (self.current_combo + amount).min(params.combo_multiplier_max);
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_score_addition_with_combo() {
        let params = ScoreChaseParams::new();
        let mut state = ScoreState::new();

        // Initial score event
        state.add_score(params.base_score, &params);
        assert_eq!(state.current_score, 100);

        // Increase combo and add score
        state.increase_combo(1.0, &params); // Combo is now 2.0
        state.add_score(params.base_score, &params);
        assert_eq!(state.current_score, 100 + 200); // 300
    }

    #[test]
    fn test_combo_timeout() {
        let params = ScoreChaseParams::new();
        let mut state = ScoreState::new();

        state.increase_combo(2.0, &params); // Combo is now 3.0
        assert_eq!(state.current_combo, 3.0);

        // Wait longer than combo timeout
        state.update(params.combo_timeout + 0.1, &params);
        assert_eq!(state.current_combo, 1.0);
    }

    #[test]
    fn test_score_decay() {
        let mut params = ScoreChaseParams::new();
        params.score_decay_rate = 10.0; // 10 points per second
        let mut state = ScoreState::new();

        state.add_score(100, &params);
        assert_eq!(state.current_score, 100);

        // Update by 2 seconds
        state.update(2.0, &params);
        assert_eq!(state.current_score, 80); // 100 - (10 * 2)
    }
}
