#[derive(Debug, Clone)]
pub struct PassiveWebParams {
    pub total_points_available: u32,
    pub minor_node_stat_value: f32,
    pub notable_node_multiplier: f32,
    pub refund_point_cost: u32,
    pub max_distance_from_start: u32,
}

impl PassiveWebParams {
    pub fn new() -> Self {
        Self {
            total_points_available: 123,
            minor_node_stat_value: 10.0,
            notable_node_multiplier: 3.0,
            refund_point_cost: 1,
            max_distance_from_start: 35,
        }
    }

    /// Calculates the total stat value gained from a given number of minor nodes.
    pub fn calculate_minor_stats(&self, minor_nodes_allocated: u32) -> f32 {
        (minor_nodes_allocated as f32) * self.minor_node_stat_value
    }

    /// Calculates the stat value of a notable node based on the multiplier.
    pub fn calculate_notable_stat_value(&self) -> f32 {
        self.minor_node_stat_value * self.notable_node_multiplier
    }

    /// Calculates the total cost to refund a given number of nodes.
    pub fn calculate_refund_cost(&self, nodes_to_refund: u32) -> u32 {
        nodes_to_refund * self.refund_point_cost
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_minor_stats() {
        let params = PassiveWebParams::new();
        assert_eq!(params.calculate_minor_stats(5), 50.0);
        assert_eq!(params.calculate_minor_stats(0), 0.0);
    }

    #[test]
    fn test_calculate_notable_stat_value() {
        let params = PassiveWebParams::new();
        assert_eq!(params.calculate_notable_stat_value(), 30.0);
    }

    #[test]
    fn test_calculate_refund_cost() {
        let params = PassiveWebParams::new();
        assert_eq!(params.calculate_refund_cost(10), 10);
    }
}
