#[derive(Debug, Clone, PartialEq)]
pub struct SwipeGestureParams {
    pub min_distance: f32,
    pub max_duration: f32,
    pub velocity_threshold: f32,
    pub angle_tolerance: f32,
}

impl SwipeGestureParams {
    /// Creates a new SwipeGestureParams with default values based on Temple Run benchmarks.
    pub fn new() -> Self {
        Self {
            min_distance: 20.0,
            max_duration: 0.3,
            velocity_threshold: 300.0,
            angle_tolerance: 30.0,
        }
    }
}

impl Default for SwipeGestureParams {
    fn default() -> Self {
        Self::new()
    }
}

#[derive(Debug, Clone, PartialEq)]
pub enum SwipeDirection {
    Up,
    Down,
    Left,
    Right,
    Invalid,
}

pub struct SwipeGesture {
    pub params: SwipeGestureParams,
}

impl SwipeGesture {
    pub fn new(params: SwipeGestureParams) -> Self {
        Self { params }
    }

    /// Evaluates a swipe based on start/end coordinates and duration.
    /// Returns the direction if valid, or Invalid if it fails the thresholds.
    pub fn evaluate_swipe(
        &self,
        start_x: f32,
        start_y: f32,
        end_x: f32,
        end_y: f32,
        duration: f32,
    ) -> SwipeDirection {
        if duration > self.params.max_duration {
            return SwipeDirection::Invalid;
        }

        let dx = end_x - start_x;
        let dy = end_y - start_y;
        let distance = (dx * dx + dy * dy).sqrt();

        if distance < self.params.min_distance {
            return SwipeDirection::Invalid;
        }

        let velocity = distance / duration;
        if velocity < self.params.velocity_threshold {
            return SwipeDirection::Invalid;
        }

        // Calculate angle in degrees (-180 to 180)
        let angle = dy.atan2(dx).to_degrees();

        // Determine direction based on angle and tolerance
        // Right: 0 degrees
        // Up: 90 degrees (assuming y goes up)
        // Left: 180 or -180 degrees
        // Down: -90 degrees
        
        let right_diff = angle.abs();
        let up_diff = (angle - 90.0).abs();
        let left_diff = if angle > 0.0 { (angle - 180.0).abs() } else { (angle + 180.0).abs() };
        let down_diff = (angle + 90.0).abs();

        if right_diff <= self.params.angle_tolerance {
            SwipeDirection::Right
        } else if up_diff <= self.params.angle_tolerance {
            SwipeDirection::Up
        } else if left_diff <= self.params.angle_tolerance {
            SwipeDirection::Left
        } else if down_diff <= self.params.angle_tolerance {
            SwipeDirection::Down
        } else {
            SwipeDirection::Invalid
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_valid_swipe_right() {
        let params = SwipeGestureParams::new();
        let gesture = SwipeGesture::new(params);
        
        // Swipe right: dx = 100, dy = 0, duration = 0.2s
        // distance = 100 (> 20)
        // velocity = 500 (> 300)
        // angle = 0 (within 30 deg of Right)
        let dir = gesture.evaluate_swipe(0.0, 0.0, 100.0, 0.0, 0.2);
        assert_eq!(dir, SwipeDirection::Right);
    }

    #[test]
    fn test_invalid_swipe_too_slow() {
        let params = SwipeGestureParams::new();
        let gesture = SwipeGesture::new(params);
        
        // Swipe right but too slow: dx = 100, dy = 0, duration = 0.4s
        // duration > max_duration (0.3)
        let dir = gesture.evaluate_swipe(0.0, 0.0, 100.0, 0.0, 0.4);
        assert_eq!(dir, SwipeDirection::Invalid);
    }

    #[test]
    fn test_invalid_swipe_too_short() {
        let params = SwipeGestureParams::new();
        let gesture = SwipeGesture::new(params);
        
        // Swipe right but too short: dx = 15, dy = 0, duration = 0.1s
        // distance < min_distance (20)
        let dir = gesture.evaluate_swipe(0.0, 0.0, 15.0, 0.0, 0.1);
        assert_eq!(dir, SwipeDirection::Invalid);
    }

    #[test]
    fn test_valid_swipe_up() {
        let params = SwipeGestureParams::new();
        let gesture = SwipeGesture::new(params);
        
        // Swipe up: dx = 10, dy = 100, duration = 0.2s
        // angle is approx 84 degrees, within 30 deg of Up (90)
        let dir = gesture.evaluate_swipe(0.0, 0.0, 10.0, 100.0, 0.2);
        assert_eq!(dir, SwipeDirection::Up);
    }
}
