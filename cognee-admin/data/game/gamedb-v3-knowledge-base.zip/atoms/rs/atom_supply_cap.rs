#[derive(Debug, Clone, PartialEq)]
pub struct SupplyCapParameters {
    pub absolute_max_supply: u32,
    pub starting_supply: u32,
    pub supply_per_structure: u32,
    pub structure_cost: u32,
    pub unit_supply_cost: u32,
}

impl SupplyCapParameters {
    pub fn new() -> Self {
        Self {
            absolute_max_supply: 200,
            starting_supply: 15,
            supply_per_structure: 8,
            structure_cost: 100,
            unit_supply_cost: 1,
        }
    }
}

#[derive(Debug, Clone, PartialEq)]
pub struct SupplyCapState {
    pub current_supply_used: u32,
    pub current_supply_capacity: u32,
    pub parameters: SupplyCapParameters,
}

impl SupplyCapState {
    pub fn new(parameters: SupplyCapParameters) -> Self {
        let starting_capacity = parameters.starting_supply;
        Self {
            current_supply_used: 0,
            current_supply_capacity: starting_capacity,
            parameters,
        }
    }

    /// Checks if a unit can be produced based on current supply and capacity.
    pub fn can_produce_unit(&self, unit_cost: u32) -> bool {
        self.current_supply_used + unit_cost <= self.current_supply_capacity
    }

    /// Produces a unit, consuming supply. Returns true if successful, false if supply blocked.
    pub fn produce_unit(&mut self, unit_cost: u32) -> bool {
        if self.can_produce_unit(unit_cost) {
            self.current_supply_used += unit_cost;
            true
        } else {
            false
        }
    }

    /// Expands the current supply capacity by building a structure, up to the absolute maximum.
    pub fn expand_capacity(&mut self) -> u32 {
        let new_capacity = self.current_supply_capacity + self.parameters.supply_per_structure;
        self.current_supply_capacity = new_capacity.min(self.parameters.absolute_max_supply);
        self.current_supply_capacity
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_produce_unit_success_and_block() {
        let params = SupplyCapParameters::new();
        let mut state = SupplyCapState::new(params);
        
        // Starting capacity is 15. Produce 15 units of cost 1.
        for _ in 0..15 {
            assert!(state.produce_unit(1));
        }
        
        // 16th unit should be blocked.
        assert!(!state.produce_unit(1));
        assert_eq!(state.current_supply_used, 15);
    }

    #[test]
    fn test_expand_capacity_limits() {
        let mut params = SupplyCapParameters::new();
        params.starting_supply = 190;
        params.supply_per_structure = 8;
        params.absolute_max_supply = 200;
        
        let mut state = SupplyCapState::new(params);
        
        // Expand once: 190 + 8 = 198
        state.expand_capacity();
        assert_eq!(state.current_supply_capacity, 198);
        
        // Expand again: 198 + 8 = 206, but capped at 200
        state.expand_capacity();
        assert_eq!(state.current_supply_capacity, 200);
    }
}
