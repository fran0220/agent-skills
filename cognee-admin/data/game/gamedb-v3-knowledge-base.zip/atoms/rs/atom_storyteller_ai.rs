#[derive(Debug, Clone, PartialEq)]
pub struct StorytellerAiParams {
    pub target_stress: f32,
    pub stress_decay_rate: f32,
    pub cooldown_duration: f32,
    pub max_active_threats: u32,
    pub event_weight_multiplier: f32,
}

impl StorytellerAiParams {
    /// Creates a new StorytellerAiParams with default values based on benchmark data.
    pub fn new() -> Self {
        Self {
            target_stress: 50.0,
            stress_decay_rate: 1.5,
            cooldown_duration: 60.0,
            max_active_threats: 30,
            event_weight_multiplier: 1.0,
        }
    }

    /// Calculates the current stress level after a given time delta, applying decay.
    /// Stress cannot fall below 0.0.
    pub fn calculate_decayed_stress(&self, current_stress: f32, delta_time: f32) -> f32 {
        let decay = self.stress_decay_rate * delta_time;
        (current_stress - decay).max(0.0)
    }

    /// Determines the intensity of the next event based on the difference between
    /// current stress and target stress. Returns a multiplier for event weight.
    pub fn calculate_event_intensity(&self, current_stress: f32) -> f32 {
        if current_stress >= self.target_stress {
            // If stress is at or above target, reduce event intensity
            0.1 * self.event_weight_multiplier
        } else {
            // If stress is below target, increase intensity proportionally
            let stress_deficit = self.target_stress - current_stress;
            let intensity_factor = 1.0 + (stress_deficit / self.target_stress);
            intensity_factor * self.event_weight_multiplier
        }
    }

    /// Checks if a new threat can be spawned based on the current active threats.
    pub fn can_spawn_threat(&self, current_active_threats: u32) -> bool {
        current_active_threats < self.max_active_threats
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_decayed_stress() {
        let params = StorytellerAiParams::new();
        
        // Test normal decay
        let new_stress = params.calculate_decayed_stress(60.0, 10.0);
        assert_eq!(new_stress, 45.0); // 60.0 - (1.5 * 10.0) = 45.0

        // Test decay not falling below 0
        let new_stress_zero = params.calculate_decayed_stress(10.0, 10.0);
        assert_eq!(new_stress_zero, 0.0); // 10.0 - 15.0 = -5.0 -> 0.0
    }

    #[test]
    fn test_calculate_event_intensity() {
        let params = StorytellerAiParams::new();
        
        // Test high stress (should return low intensity)
        let intensity_high = params.calculate_event_intensity(60.0);
        assert_eq!(intensity_high, 0.1);

        // Test low stress (should return higher intensity)
        let intensity_low = params.calculate_event_intensity(25.0);
        assert_eq!(intensity_low, 1.5); // 1.0 + (25.0 / 50.0) = 1.5
    }

    #[test]
    fn test_can_spawn_threat() {
        let params = StorytellerAiParams::new();
        
        assert!(params.can_spawn_threat(20));
        assert!(!params.can_spawn_threat(30));
        assert!(!params.can_spawn_threat(35));
    }
}
