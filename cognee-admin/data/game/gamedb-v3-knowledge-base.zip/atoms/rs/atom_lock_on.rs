pub struct LockOnParams {
    pub max_lock_distance: f32,
    pub lock_angle_fov: f32,
    pub break_distance_margin: f32,
    pub target_switch_cooldown: f32,
    pub soft_lock_weight_distance: f32,
    pub soft_lock_weight_angle: f32,
}

impl LockOnParams {
    pub fn new() -> Self {
        Self {
            max_lock_distance: 25.0,
            lock_angle_fov: 90.0,
            break_distance_margin: 5.0,
            target_switch_cooldown: 0.2,
            soft_lock_weight_distance: 0.6,
            soft_lock_weight_angle: 0.4,
        }
    }

    /// Checks if a target is within the initial lock-on range and angle.
    pub fn can_lock_on(&self, distance: f32, angle_degrees: f32) -> bool {
        distance <= self.max_lock_distance && angle_degrees.abs() <= (self.lock_angle_fov / 2.0)
    }

    /// Checks if an existing lock-on should be broken due to distance.
    pub fn should_break_lock(&self, distance: f32) -> bool {
        distance > (self.max_lock_distance + self.break_distance_margin)
    }

    /// Calculates a score for a potential target (lower is better).
    pub fn calculate_target_score(&self, distance: f32, angle_degrees: f32) -> f32 {
        let distance_score = distance / self.max_lock_distance;
        let angle_score = angle_degrees.abs() / (self.lock_angle_fov / 2.0);
        
        (distance_score * self.soft_lock_weight_distance) + (angle_score * self.soft_lock_weight_angle)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_can_lock_on() {
        let params = LockOnParams::new();
        // Within range and angle
        assert!(params.can_lock_on(20.0, 30.0));
        // Out of range
        assert!(!params.can_lock_on(30.0, 30.0));
        // Out of angle
        assert!(!params.can_lock_on(20.0, 50.0));
    }

    #[test]
    fn test_should_break_lock() {
        let params = LockOnParams::new();
        // Within max distance
        assert!(!params.should_break_lock(20.0));
        // Within margin
        assert!(!params.should_break_lock(28.0));
        // Outside margin
        assert!(params.should_break_lock(31.0));
    }
    
    #[test]
    fn test_calculate_target_score() {
        let params = LockOnParams::new();
        let score1 = params.calculate_target_score(10.0, 0.0);
        let score2 = params.calculate_target_score(20.0, 0.0);
        // Closer target should have a lower (better) score
        assert!(score1 < score2);
    }
}
