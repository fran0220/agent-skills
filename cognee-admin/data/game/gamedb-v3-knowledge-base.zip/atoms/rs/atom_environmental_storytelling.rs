#[derive(Debug, Clone, PartialEq)]
pub struct EnvironmentalStorytelling {
    pub clue_density: f32,
    pub visibility_radius: f32,
    pub ambiguity_level: f32,
    pub interaction_required: bool,
}

impl EnvironmentalStorytelling {
    pub fn new() -> Self {
        Self {
            clue_density: 2.5, // Bioshock v1.0 benchmark
            visibility_radius: 15.0, // Gone Home v1.2 benchmark
            ambiguity_level: 0.8, // Dark Souls v1.0 benchmark
            interaction_required: false,
        }
    }

    /// Calculates the probability of a player noticing a clue based on distance and visibility radius.
    pub fn calculate_notice_probability(&self, distance_to_clue: f32) -> f32 {
        if distance_to_clue > self.visibility_radius {
            return 0.0;
        }
        let ratio = 1.0 - (distance_to_clue / self.visibility_radius);
        // Higher ambiguity reduces the base notice probability slightly
        let ambiguity_factor = 1.0 - (self.ambiguity_level * 0.2);
        (ratio * ambiguity_factor).clamp(0.0, 1.0)
    }

    /// Calculates the time required to fully understand a scene based on clue density and ambiguity.
    pub fn calculate_understanding_time(&self, room_size_sqm: f32) -> f32 {
        let total_clues = self.clue_density * (room_size_sqm / 10.0); // Assume density is per 10 sqm
        let base_time_per_clue = if self.interaction_required { 5.0 } else { 2.0 };
        let ambiguity_multiplier = 1.0 + self.ambiguity_level;
        
        total_clues * base_time_per_clue * ambiguity_multiplier
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_notice_probability() {
        let atom = EnvironmentalStorytelling::new();
        
        // Inside radius
        let prob_close = atom.calculate_notice_probability(5.0);
        assert!(prob_close > 0.0 && prob_close <= 1.0);
        
        // Outside radius
        let prob_far = atom.calculate_notice_probability(20.0);
        assert_eq!(prob_far, 0.0);
    }

    #[test]
    fn test_understanding_time() {
        let mut atom = EnvironmentalStorytelling::new();
        atom.clue_density = 2.0;
        atom.ambiguity_level = 0.5;
        atom.interaction_required = false;
        
        let time = atom.calculate_understanding_time(20.0);
        // total_clues = 2.0 * (20.0 / 10.0) = 4.0
        // base_time = 2.0
        // ambiguity_multiplier = 1.5
        // time = 4.0 * 2.0 * 1.5 = 12.0
        assert_eq!(time, 12.0);
    }
}
