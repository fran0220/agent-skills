pub struct XpLevelParams {
    pub base_xp_requirement: u32,
    pub xp_scaling_factor: f32,
    pub max_level: u32,
}

impl XpLevelParams {
    /// Creates a new XpLevelParams with default values based on WoW Classic benchmarks.
    pub fn new() -> Self {
        Self {
            base_xp_requirement: 400,
            xp_scaling_factor: 1.5,
            max_level: 60,
        }
    }

    /// Calculates the total XP required to reach a specific level from level 1.
    /// Uses a simple polynomial scaling formula for demonstration.
    pub fn xp_required_for_level(&self, level: u32) -> u32 {
        if level <= 1 {
            return 0;
        }
        if level > self.max_level {
            return self.xp_required_for_level(self.max_level);
        }
        
        let mut total_xp = 0;
        for l in 1..level {
            let required_for_next = (self.base_xp_requirement as f32 * self.xp_scaling_factor.powi((l - 1) as i32)) as u32;
            total_xp += required_for_next;
        }
        total_xp
    }

    /// Determines the current level based on total accumulated XP.
    pub fn calculate_level(&self, total_xp: u32) -> u32 {
        let mut current_level = 1;
        let mut xp_accumulated = 0;

        while current_level < self.max_level {
            let required_for_next = (self.base_xp_requirement as f32 * self.xp_scaling_factor.powi((current_level - 1) as i32)) as u32;
            if total_xp >= xp_accumulated + required_for_next {
                xp_accumulated += required_for_next;
                current_level += 1;
            } else {
                break;
            }
        }
        current_level
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_xp_required_for_level() {
        let params = XpLevelParams::new();
        
        // Level 1 requires 0 XP
        assert_eq!(params.xp_required_for_level(1), 0);
        
        // Level 2 requires base_xp_requirement (400)
        assert_eq!(params.xp_required_for_level(2), 400);
        
        // Level 3 requires 400 + 400 * 1.5 = 1000
        assert_eq!(params.xp_required_for_level(3), 1000);
    }

    #[test]
    fn test_calculate_level() {
        let params = XpLevelParams::new();
        
        // 0 XP is level 1
        assert_eq!(params.calculate_level(0), 1);
        
        // 399 XP is still level 1
        assert_eq!(params.calculate_level(399), 1);
        
        // 400 XP is level 2
        assert_eq!(params.calculate_level(400), 2);
        
        // 1000 XP is level 3
        assert_eq!(params.calculate_level(1000), 3);
        
        // 1000000 XP should cap at max_level (60)
        assert_eq!(params.calculate_level(100000000), 60);
    }
}
