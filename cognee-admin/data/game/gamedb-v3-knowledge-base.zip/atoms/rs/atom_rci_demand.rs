#[derive(Debug, Clone)]
pub struct RciDemandParams {
    pub base_r_demand: f32,
    pub base_c_demand: f32,
    pub base_i_demand: f32,
    pub tax_penalty_multiplier: f32,
    pub education_modifier: f32,
    pub unemployment_tolerance: f32,
}

impl RciDemandParams {
    /// Creates a new RciDemandParams with default values based on SimCity 4 benchmarks.
    pub fn new() -> Self {
        Self {
            base_r_demand: 1000.0,
            base_c_demand: 500.0,
            base_i_demand: 500.0,
            tax_penalty_multiplier: 1.2,
            education_modifier: 1.0,
            unemployment_tolerance: 0.05,
        }
    }
}

pub struct RciState {
    pub population: f32,
    pub available_jobs: f32,
    pub available_goods: f32,
    pub tax_rate: f32,
    pub education_level: f32,
}

pub struct RciDemand {
    pub r_demand: f32,
    pub c_demand: f32,
    pub i_demand: f32,
}

/// Calculates the current RCI demand based on the city state and parameters.
pub fn calculate_rci_demand(params: &RciDemandParams, state: &RciState) -> RciDemand {
    // Calculate base demands modified by population and jobs
    let unemployment_rate = if state.population > 0.0 {
        (state.population - state.available_jobs).max(0.0) / state.population
    } else {
        0.0
    };

    // Residential demand increases if there are more jobs than people
    let r_demand_base = params.base_r_demand + (state.available_jobs - state.population) * 0.5;
    
    // Commercial demand increases with population and education
    let c_demand_base = params.base_c_demand + (state.population * 0.2 * state.education_level * params.education_modifier) - state.available_goods;
    
    // Industrial demand increases with unemployment
    let i_demand_base = params.base_i_demand + (unemployment_rate - params.unemployment_tolerance) * 10000.0;

    // Apply tax penalties (assuming neutral tax rate is 9.0%)
    let tax_penalty = if state.tax_rate > 9.0 {
        (state.tax_rate - 9.0) * params.tax_penalty_multiplier * 100.0
    } else {
        0.0
    };

    RciDemand {
        r_demand: (r_demand_base - tax_penalty).clamp(-6000.0, 6000.0),
        c_demand: (c_demand_base - tax_penalty).clamp(-6000.0, 6000.0),
        i_demand: (i_demand_base - tax_penalty).clamp(-6000.0, 6000.0),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_high_unemployment_increases_i_demand() {
        let params = RciDemandParams::new();
        let state = RciState {
            population: 10000.0,
            available_jobs: 8000.0, // 20% unemployment
            available_goods: 1000.0,
            tax_rate: 9.0,
            education_level: 1.0,
        };

        let demand = calculate_rci_demand(&params, &state);
        
        // Unemployment is 0.2, tolerance is 0.05. Difference is 0.15.
        // i_demand_base = 500 + 0.15 * 10000 = 2000
        assert!(demand.i_demand > params.base_i_demand);
        assert_eq!(demand.i_demand, 2000.0);
    }

    #[test]
    fn test_high_taxes_decrease_all_demand() {
        let params = RciDemandParams::new();
        let state_normal_tax = RciState {
            population: 10000.0,
            available_jobs: 10000.0,
            available_goods: 2000.0,
            tax_rate: 9.0,
            education_level: 1.0,
        };
        
        let state_high_tax = RciState {
            population: 10000.0,
            available_jobs: 10000.0,
            available_goods: 2000.0,
            tax_rate: 14.0, // 5% above neutral
            education_level: 1.0,
        };

        let demand_normal = calculate_rci_demand(&params, &state_normal_tax);
        let demand_high = calculate_rci_demand(&params, &state_high_tax);

        assert!(demand_high.r_demand < demand_normal.r_demand);
        assert!(demand_high.c_demand < demand_normal.c_demand);
        assert!(demand_high.i_demand < demand_normal.i_demand);
        
        // Penalty should be (14 - 9) * 1.2 * 100 = 600
        assert_eq!(demand_high.r_demand, demand_normal.r_demand - 600.0);
    }
}
