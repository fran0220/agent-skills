#[derive(Debug, Clone, PartialEq)]
pub struct AtomAds {
    pub ads_time: f32,
    pub movement_speed_multiplier: f32,
    pub fov_multiplier: f32,
    pub spread_multiplier: f32,
    pub recoil_multiplier: f32,
}

impl AtomAds {
    /// Creates a new AtomAds instance with default values based on benchmark data (Call of Duty: Modern Warfare 2019).
    pub fn new() -> Self {
        Self {
            ads_time: 0.25,
            movement_speed_multiplier: 0.5,
            fov_multiplier: 0.8,
            spread_multiplier: 0.1,
            recoil_multiplier: 0.8,
        }
    }

    /// Calculates the current movement speed based on the ADS progress.
    /// `base_speed`: The player's base movement speed.
    /// `progress`: The current ADS progress (0.0 = HipFire, 1.0 = FullyADS).
    pub fn calculate_current_speed(&self, base_speed: f32, progress: f32) -> f32 {
        let clamped_progress = progress.clamp(0.0, 1.0);
        let current_multiplier = 1.0 - (1.0 - self.movement_speed_multiplier) * clamped_progress;
        base_speed * current_multiplier
    }

    /// Calculates the current FOV based on the ADS progress.
    /// `base_fov`: The player's base Field of View.
    /// `progress`: The current ADS progress (0.0 = HipFire, 1.0 = FullyADS).
    pub fn calculate_current_fov(&self, base_fov: f32, progress: f32) -> f32 {
        let clamped_progress = progress.clamp(0.0, 1.0);
        let current_multiplier = 1.0 - (1.0 - self.fov_multiplier) * clamped_progress;
        base_fov * current_multiplier
    }

    /// Calculates the current weapon spread based on the ADS progress.
    /// `base_spread`: The weapon's base spread in HipFire.
    /// `progress`: The current ADS progress (0.0 = HipFire, 1.0 = FullyADS).
    pub fn calculate_current_spread(&self, base_spread: f32, progress: f32) -> f32 {
        let clamped_progress = progress.clamp(0.0, 1.0);
        let current_multiplier = 1.0 - (1.0 - self.spread_multiplier) * clamped_progress;
        base_spread * current_multiplier
    }
}

impl Default for AtomAds {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_current_speed() {
        let ads = AtomAds::new();
        let base_speed = 10.0;

        // At HipFire (progress = 0.0), speed should be base_speed
        assert_eq!(ads.calculate_current_speed(base_speed, 0.0), 10.0);

        // At FullyADS (progress = 1.0), speed should be base_speed * movement_speed_multiplier
        assert_eq!(ads.calculate_current_speed(base_speed, 1.0), 5.0);

        // At half progress (progress = 0.5), speed should be halfway between base and fully ADS speed
        assert_eq!(ads.calculate_current_speed(base_speed, 0.5), 7.5);
    }

    #[test]
    fn test_calculate_current_fov() {
        let ads = AtomAds::new();
        let base_fov = 90.0;

        // At HipFire (progress = 0.0), FOV should be base_fov
        assert_eq!(ads.calculate_current_fov(base_fov, 0.0), 90.0);

        // At FullyADS (progress = 1.0), FOV should be base_fov * fov_multiplier
        assert_eq!(ads.calculate_current_fov(base_fov, 1.0), 72.0);

        // At half progress (progress = 0.5), FOV should be halfway between base and fully ADS FOV
        assert_eq!(ads.calculate_current_fov(base_fov, 0.5), 81.0);
    }

    #[test]
    fn test_calculate_current_spread() {
        let ads = AtomAds::new();
        let base_spread = 5.0;

        // At HipFire (progress = 0.0), spread should be base_spread
        assert_eq!(ads.calculate_current_spread(base_spread, 0.0), 5.0);

        // At FullyADS (progress = 1.0), spread should be base_spread * spread_multiplier
        assert_eq!(ads.calculate_current_spread(base_spread, 1.0), 0.5);

        // At half progress (progress = 0.5), spread should be halfway between base and fully ADS spread
        assert_eq!(ads.calculate_current_spread(base_spread, 0.5), 2.75);
    }
}
