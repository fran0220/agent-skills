#[derive(Debug, Clone, PartialEq)]
pub struct CardDraftParams {
    pub options_count: u32,
    pub can_skip: bool,
    pub rare_chance: f32,
    pub uncommon_chance: f32,
    pub picks_allowed: u32,
}

impl CardDraftParams {
    /// Creates a new CardDraftParams with default values based on Slay the Spire (v2.3) benchmarks.
    pub fn new() -> Self {
        Self {
            options_count: 3,
            can_skip: true,
            rare_chance: 0.03,
            uncommon_chance: 0.37,
            picks_allowed: 1,
        }
    }

    /// Calculates the probability of a specific rarity being generated.
    /// Returns the probability of generating a rare, uncommon, or common card.
    pub fn get_rarity_probability(&self, is_rare: bool, is_uncommon: bool) -> f32 {
        if is_rare {
            self.rare_chance
        } else if is_uncommon {
            self.uncommon_chance
        } else {
            // Common chance is the remaining probability
            let common_chance = 1.0 - self.rare_chance - self.uncommon_chance;
            if common_chance < 0.0 {
                0.0
            } else {
                common_chance
            }
        }
    }

    /// Calculates the probability of seeing at least one rare card in the draft options.
    pub fn probability_of_at_least_one_rare(&self) -> f32 {
        let prob_no_rare = (1.0 - self.rare_chance).powi(self.options_count as i32);
        1.0 - prob_no_rare
    }
    
    /// Validates if a player's selection is valid based on the draft parameters.
    pub fn is_selection_valid(&self, selected_count: u32) -> bool {
        if selected_count == 0 {
            self.can_skip
        } else {
            selected_count <= self.picks_allowed
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_default_values() {
        let params = CardDraftParams::new();
        assert_eq!(params.options_count, 3);
        assert_eq!(params.can_skip, true);
        assert_eq!(params.rare_chance, 0.03);
        assert_eq!(params.uncommon_chance, 0.37);
        assert_eq!(params.picks_allowed, 1);
    }

    #[test]
    fn test_rarity_probability() {
        let params = CardDraftParams::new();
        assert_eq!(params.get_rarity_probability(true, false), 0.03);
        assert_eq!(params.get_rarity_probability(false, true), 0.37);
        // Common chance should be 1.0 - 0.03 - 0.37 = 0.60
        let common_prob = params.get_rarity_probability(false, false);
        assert!((common_prob - 0.60).abs() < f32::EPSILON);
    }

    #[test]
    fn test_probability_of_at_least_one_rare() {
        let params = CardDraftParams::new();
        // 1 - (1 - 0.03)^3 = 1 - 0.97^3 = 1 - 0.912673 = 0.087327
        let prob = params.probability_of_at_least_one_rare();
        assert!((prob - 0.087327).abs() < 0.00001);
    }

    #[test]
    fn test_selection_validity() {
        let params = CardDraftParams::new();
        // Valid selections
        assert!(params.is_selection_valid(0)); // Can skip
        assert!(params.is_selection_valid(1)); // Can pick 1
        
        // Invalid selections
        assert!(!params.is_selection_valid(2)); // Cannot pick 2
        
        let mut no_skip_params = CardDraftParams::new();
        no_skip_params.can_skip = false;
        assert!(!no_skip_params.is_selection_valid(0)); // Cannot skip
    }
}
