#[derive(Debug, Clone, PartialEq)]
pub struct CoopReviveParams {
    pub revive_duration: f32,
    pub bleedout_duration: f32,
    pub revive_range: f32,
    pub health_restored_pct: f32,
    pub pause_bleedout_on_revive: bool,
    pub interrupt_on_damage: bool,
}

impl CoopReviveParams {
    /// Creates a new `CoopReviveParams` with default values based on Apex Legends benchmark.
    pub fn new() -> Self {
        Self {
            revive_duration: 5.0,
            bleedout_duration: 30.0,
            revive_range: 2.0,
            health_restored_pct: 0.2,
            pause_bleedout_on_revive: true,
            interrupt_on_damage: false,
        }
    }

    /// Calculates the remaining bleedout time after a certain amount of time has passed.
    /// If `is_being_revived` is true and `pause_bleedout_on_revive` is true, the timer is paused.
    pub fn calculate_remaining_bleedout(
        &self,
        current_bleedout_time: f32,
        time_passed: f32,
        is_being_revived: bool,
    ) -> f32 {
        if is_being_revived && self.pause_bleedout_on_revive {
            current_bleedout_time
        } else {
            (current_bleedout_time - time_passed).max(0.0)
        }
    }

    /// Checks if a revive attempt is valid based on distance and current state.
    pub fn can_start_revive(&self, distance_to_downed_player: f32, is_downed: bool) -> bool {
        is_downed && distance_to_downed_player <= self.revive_range
    }

    /// Calculates the health restored upon a successful revive.
    pub fn calculate_health_restored(&self, max_health: f32) -> f32 {
        max_health * self.health_restored_pct
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_remaining_bleedout() {
        let params = CoopReviveParams::new();
        
        // Normal bleedout
        let remaining = params.calculate_remaining_bleedout(30.0, 5.0, false);
        assert_eq!(remaining, 25.0);

        // Paused bleedout during revive
        let remaining_paused = params.calculate_remaining_bleedout(25.0, 5.0, true);
        assert_eq!(remaining_paused, 25.0);
        
        // Bleedout reaches 0
        let remaining_zero = params.calculate_remaining_bleedout(5.0, 10.0, false);
        assert_eq!(remaining_zero, 0.0);
    }

    #[test]
    fn test_can_start_revive() {
        let params = CoopReviveParams::new();
        
        // Valid revive
        assert!(params.can_start_revive(1.5, true));
        
        // Out of range
        assert!(!params.can_start_revive(2.5, true));
        
        // Player not downed
        assert!(!params.can_start_revive(1.0, false));
    }

    #[test]
    fn test_calculate_health_restored() {
        let params = CoopReviveParams::new();
        
        let restored = params.calculate_health_restored(100.0);
        assert_eq!(restored, 20.0);
    }
}
