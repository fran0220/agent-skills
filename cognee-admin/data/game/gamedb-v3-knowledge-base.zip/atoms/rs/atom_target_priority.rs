#[derive(Debug, Clone, PartialEq)]
pub struct TargetPriorityParams {
    pub scan_radius: f32,
    pub priority_mode: u32, // 0: Closest, 1: First, 2: Strongest, 3: Weakest
    pub retarget_delay: f32,
    pub sticky_targeting: bool,
}

impl TargetPriorityParams {
    pub fn new() -> Self {
        Self {
            scan_radius: 5.0,
            priority_mode: 0,
            retarget_delay: 0.5,
            sticky_targeting: true,
        }
    }
}

#[derive(Debug, Clone, PartialEq)]
pub struct Target {
    pub id: u32,
    pub distance: f32,
    pub progress: f32,
    pub health: f32,
}

pub fn evaluate_targets(params: &TargetPriorityParams, targets: &[Target], current_target_id: Option<u32>) -> Option<u32> {
    if targets.is_empty() {
        return None;
    }

    let valid_targets: Vec<&Target> = targets.iter()
        .filter(|t| t.distance <= params.scan_radius)
        .collect();

    if valid_targets.is_empty() {
        return None;
    }

    if params.sticky_targeting {
        if let Some(current_id) = current_target_id {
            if valid_targets.iter().any(|t| t.id == current_id) {
                return Some(current_id);
            }
        }
    }

    let mut sorted_targets = valid_targets.clone();
    
    match params.priority_mode {
        0 => {
            // Closest
            sorted_targets.sort_by(|a, b| a.distance.partial_cmp(&b.distance).unwrap_or(std::cmp::Ordering::Equal));
        },
        1 => {
            // First (highest progress)
            sorted_targets.sort_by(|a, b| b.progress.partial_cmp(&a.progress).unwrap_or(std::cmp::Ordering::Equal));
        },
        2 => {
            // Strongest (highest health)
            sorted_targets.sort_by(|a, b| b.health.partial_cmp(&a.health).unwrap_or(std::cmp::Ordering::Equal));
        },
        3 => {
            // Weakest (lowest health)
            sorted_targets.sort_by(|a, b| a.health.partial_cmp(&b.health).unwrap_or(std::cmp::Ordering::Equal));
        },
        _ => {
            // Default to closest
            sorted_targets.sort_by(|a, b| a.distance.partial_cmp(&b.distance).unwrap_or(std::cmp::Ordering::Equal));
        }
    }

    sorted_targets.first().map(|t| t.id)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_closest_priority() {
        let params = TargetPriorityParams {
            scan_radius: 10.0,
            priority_mode: 0,
            retarget_delay: 0.0,
            sticky_targeting: false,
        };

        let targets = vec![
            Target { id: 1, distance: 8.0, progress: 10.0, health: 100.0 },
            Target { id: 2, distance: 3.0, progress: 5.0, health: 200.0 },
            Target { id: 3, distance: 12.0, progress: 15.0, health: 50.0 },
        ];

        let selected = evaluate_targets(&params, &targets, None);
        assert_eq!(selected, Some(2));
    }

    #[test]
    fn test_sticky_targeting() {
        let params = TargetPriorityParams {
            scan_radius: 10.0,
            priority_mode: 0,
            retarget_delay: 0.0,
            sticky_targeting: true,
        };

        let targets = vec![
            Target { id: 1, distance: 8.0, progress: 10.0, health: 100.0 },
            Target { id: 2, distance: 3.0, progress: 5.0, health: 200.0 },
        ];

        // Even though target 2 is closer, target 1 is sticky
        let selected = evaluate_targets(&params, &targets, Some(1));
        assert_eq!(selected, Some(1));
    }
    
    #[test]
    fn test_out_of_range() {
        let params = TargetPriorityParams::new();
        let targets = vec![
            Target { id: 1, distance: 8.0, progress: 10.0, health: 100.0 },
        ];
        
        // scan_radius is 5.0 by default, target is at 8.0
        let selected = evaluate_targets(&params, &targets, None);
        assert_eq!(selected, None);
    }
}
