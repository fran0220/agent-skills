#[derive(Debug, Clone, PartialEq)]
pub struct OneTapParams {
    pub tap_impulse: f32,
    pub gravity: f32,
    pub max_fall_speed: f32,
    pub cooldown: f32,
}

impl OneTapParams {
    pub fn new() -> Self {
        Self {
            tap_impulse: 400.0,
            gravity: 1000.0,
            max_fall_speed: 500.0,
            cooldown: 0.0,
        }
    }
}

pub struct OneTapState {
    pub velocity_y: f32,
    pub cooldown_timer: f32,
}

impl OneTapState {
    pub fn new() -> Self {
        Self {
            velocity_y: 0.0,
            cooldown_timer: 0.0,
        }
    }

    pub fn tap(&mut self, params: &OneTapParams) -> bool {
        if self.cooldown_timer <= 0.0 {
            self.velocity_y = params.tap_impulse;
            self.cooldown_timer = params.cooldown;
            true
        } else {
            false
        }
    }

    pub fn update(&mut self, dt: f32, params: &OneTapParams) {
        if self.cooldown_timer > 0.0 {
            self.cooldown_timer -= dt;
        }

        self.velocity_y -= params.gravity * dt;
        if self.velocity_y < -params.max_fall_speed {
            self.velocity_y = -params.max_fall_speed;
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_tap_applies_impulse() {
        let params = OneTapParams::new();
        let mut state = OneTapState::new();
        
        assert_eq!(state.velocity_y, 0.0);
        let success = state.tap(&params);
        
        assert!(success);
        assert_eq!(state.velocity_y, 400.0);
    }

    #[test]
    fn test_gravity_and_max_fall_speed() {
        let params = OneTapParams::new();
        let mut state = OneTapState::new();
        
        state.update(0.1, &params);
        assert_eq!(state.velocity_y, -100.0); // 0 - 1000 * 0.1
        
        state.update(1.0, &params);
        assert_eq!(state.velocity_y, -500.0); // capped at max_fall_speed
    }

    #[test]
    fn test_cooldown() {
        let mut params = OneTapParams::new();
        params.cooldown = 0.5;
        let mut state = OneTapState::new();
        
        assert!(state.tap(&params));
        assert!(!state.tap(&params)); // Should fail due to cooldown
        
        state.update(0.6, &params);
        assert!(state.tap(&params)); // Should succeed after cooldown
    }
}
