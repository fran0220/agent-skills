#[derive(Debug, Clone, Copy)]
pub struct TouchDragParams {
    pub max_drag_distance: f32,
    pub drag_sensitivity: f32,
    pub snap_back_speed: f32,
    pub cancel_threshold: f32,
}

impl TouchDragParams {
    /// Creates a new TouchDragParams with default values based on benchmark data.
    pub fn new() -> Self {
        Self {
            max_drag_distance: 150.0, // Angry Birds v1.0
            drag_sensitivity: 1.0,    // Cut the Rope v1.0
            snap_back_speed: 20.0,    // Angry Birds v1.0
            cancel_threshold: 10.0,   // Cut the Rope v1.0
        }
    }

    /// Calculates the current drag vector given the start and current touch positions.
    /// Returns the (dx, dy) vector clamped to the max_drag_distance.
    pub fn calculate_drag_vector(&self, start_x: f32, start_y: f32, current_x: f32, current_y: f32) -> (f32, f32) {
        let dx = (current_x - start_x) * self.drag_sensitivity;
        let dy = (current_y - start_y) * self.drag_sensitivity;
        
        let distance_sq = dx * dx + dy * dy;
        let max_dist_sq = self.max_drag_distance * self.max_drag_distance;
        
        if distance_sq > max_dist_sq {
            let distance = distance_sq.sqrt();
            let scale = self.max_drag_distance / distance;
            (dx * scale, dy * scale)
        } else {
            (dx, dy)
        }
    }

    /// Determines if the drag action should be canceled based on the cancel_threshold.
    pub fn should_cancel(&self, start_x: f32, start_y: f32, release_x: f32, release_y: f32) -> bool {
        let dx = release_x - start_x;
        let dy = release_y - start_y;
        let distance_sq = dx * dx + dy * dy;
        
        distance_sq < (self.cancel_threshold * self.cancel_threshold)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_drag_vector_within_limit() {
        let params = TouchDragParams::new();
        let (dx, dy) = params.calculate_drag_vector(0.0, 0.0, 100.0, 0.0);
        assert_eq!(dx, 100.0);
        assert_eq!(dy, 0.0);
    }

    #[test]
    fn test_calculate_drag_vector_exceeds_limit() {
        let params = TouchDragParams::new();
        let (dx, dy) = params.calculate_drag_vector(0.0, 0.0, 200.0, 0.0);
        // Should be clamped to max_drag_distance (150.0)
        assert_eq!(dx, 150.0);
        assert_eq!(dy, 0.0);
    }

    #[test]
    fn test_should_cancel() {
        let params = TouchDragParams::new();
        // Distance is 5.0, which is less than cancel_threshold (10.0)
        assert!(params.should_cancel(0.0, 0.0, 5.0, 0.0));
        
        // Distance is 15.0, which is greater than cancel_threshold (10.0)
        assert!(!params.should_cancel(0.0, 0.0, 15.0, 0.0));
    }
}
