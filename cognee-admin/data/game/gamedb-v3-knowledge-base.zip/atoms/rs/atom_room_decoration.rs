#[derive(Debug, Clone, Copy)]
pub struct RoomDecorationParams {
    pub grid_size: f32,
    pub max_objects: u32,
    pub rotation_steps: u32,
    pub placement_radius: f32,
}

impl RoomDecorationParams {
    /// Creates a new RoomDecorationParams with default values based on Animal Crossing: New Horizons benchmark.
    pub fn new() -> Self {
        Self {
            grid_size: 0.5,
            max_objects: 200,
            rotation_steps: 4,
            placement_radius: 5.0,
        }
    }

    /// Snaps a 1D position coordinate to the nearest grid increment.
    pub fn snap_to_grid(&self, position: f32) -> f32 {
        if self.grid_size <= 0.0 {
            return position;
        }
        (position / self.grid_size).round() * self.grid_size
    }

    /// Snaps an angle (in degrees) to the nearest allowed rotation step.
    pub fn snap_rotation(&self, angle_degrees: f32) -> f32 {
        if self.rotation_steps == 0 {
            return angle_degrees;
        }
        let step_size = 360.0 / (self.rotation_steps as f32);
        let normalized_angle = angle_degrees.rem_euclid(360.0);
        let snapped = (normalized_angle / step_size).round() * step_size;
        if snapped >= 360.0 {
            0.0
        } else {
            snapped
        }
    }

    /// Checks if an object can be placed based on current object count and distance from player.
    pub fn can_place(&self, current_objects: u32, distance: f32) -> bool {
        current_objects < self.max_objects && distance <= self.placement_radius
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_snap_to_grid() {
        let params = RoomDecorationParams::new(); // grid_size = 0.5
        
        assert_eq!(params.snap_to_grid(1.2), 1.0);
        assert_eq!(params.snap_to_grid(1.3), 1.5);
        assert_eq!(params.snap_to_grid(1.75), 2.0);
        assert_eq!(params.snap_to_grid(-0.2), 0.0);
        assert_eq!(params.snap_to_grid(-0.3), -0.5);
    }

    #[test]
    fn test_snap_rotation() {
        let params = RoomDecorationParams::new(); // rotation_steps = 4 (90 degrees)
        
        assert_eq!(params.snap_rotation(44.0), 0.0);
        assert_eq!(params.snap_rotation(46.0), 90.0);
        assert_eq!(params.snap_rotation(100.0), 90.0);
        assert_eq!(params.snap_rotation(350.0), 0.0);
        assert_eq!(params.snap_rotation(-10.0), 0.0);
        assert_eq!(params.snap_rotation(-100.0), 270.0);
    }

    #[test]
    fn test_can_place() {
        let params = RoomDecorationParams::new(); // max_objects = 200, placement_radius = 5.0
        
        assert!(params.can_place(100, 3.0));
        assert!(!params.can_place(200, 3.0)); // Too many objects
        assert!(!params.can_place(100, 6.0)); // Too far
    }
}
