#[derive(Debug, Clone, PartialEq)]
pub struct TowerUpgradePathParams {
    pub base_cost: u32,
    pub upgrade_cost: u32,
    pub damage_multiplier: f32,
    pub range_bonus: f32,
    pub attack_speed_mod: f32,
    pub sell_return_rate: f32,
}

impl TowerUpgradePathParams {
    /// Creates a new TowerUpgradePathParams with default values based on Bloons TD 6 benchmarks.
    pub fn new() -> Self {
        Self {
            base_cost: 200,
            upgrade_cost: 140,
            damage_multiplier: 1.0,
            range_bonus: 0.0,
            attack_speed_mod: 1.0,
            sell_return_rate: 0.7,
        }
    }

    /// Calculates the total cost invested in the tower.
    pub fn calculate_total_investment(&self, upgrades_purchased: u32) -> u32 {
        self.base_cost + (self.upgrade_cost * upgrades_purchased)
    }

    /// Calculates the sell value of the tower based on total investment and sell return rate.
    pub fn calculate_sell_value(&self, upgrades_purchased: u32) -> u32 {
        let total_investment = self.calculate_total_investment(upgrades_purchased) as f32;
        (total_investment * self.sell_return_rate).floor() as u32
    }

    /// Calculates the effective damage after applying the damage multiplier.
    pub fn calculate_effective_damage(&self, base_damage: f32) -> f32 {
        base_damage * self.damage_multiplier
    }
}

impl Default for TowerUpgradePathParams {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_total_investment() {
        let params = TowerUpgradePathParams::new();
        // Base cost 200, 2 upgrades at 140 each = 200 + 280 = 480
        assert_eq!(params.calculate_total_investment(2), 480);
        assert_eq!(params.calculate_total_investment(0), 200);
    }

    #[test]
    fn test_calculate_sell_value() {
        let params = TowerUpgradePathParams::new();
        // Total investment for 1 upgrade = 340. Sell value = 340 * 0.7 = 238
        assert_eq!(params.calculate_sell_value(1), 238);
        
        // Total investment for 0 upgrades = 200. Sell value = 200 * 0.7 = 140
        assert_eq!(params.calculate_sell_value(0), 140);
    }

    #[test]
    fn test_calculate_effective_damage() {
        let mut params = TowerUpgradePathParams::new();
        params.damage_multiplier = 1.5;
        
        // Base damage 10.0 * 1.5 = 15.0
        assert_eq!(params.calculate_effective_damage(10.0), 15.0);
    }
}
