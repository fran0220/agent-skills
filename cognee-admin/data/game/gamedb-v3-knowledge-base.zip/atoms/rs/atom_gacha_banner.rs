pub struct GachaBanner {
    pub base_probability_5_star: f32,
    pub base_probability_4_star: f32,
    pub hard_pity_threshold: u32,
    pub soft_pity_start: u32,
    pub soft_pity_increment: f32,
    pub pull_cost: u32,
}

impl GachaBanner {
    pub fn new() -> Self {
        Self {
            base_probability_5_star: 0.006,
            base_probability_4_star: 0.051,
            hard_pity_threshold: 90,
            soft_pity_start: 74,
            soft_pity_increment: 0.06,
            pull_cost: 160,
        }
    }

    /// Calculates the probability of getting a 5-star item on a given pull number
    /// `pulls_since_last_5_star` is the number of pulls already made without a 5-star.
    /// The current pull is `pulls_since_last_5_star + 1`.
    pub fn calculate_5_star_probability(&self, pulls_since_last_5_star: u32) -> f32 {
        let current_pull = pulls_since_last_5_star + 1;
        
        if current_pull >= self.hard_pity_threshold {
            return 1.0;
        }
        
        if current_pull >= self.soft_pity_start {
            let soft_pity_pulls = current_pull - self.soft_pity_start + 1;
            let increased_prob = self.base_probability_5_star + (soft_pity_pulls as f32 * self.soft_pity_increment);
            return increased_prob.min(1.0);
        }
        
        self.base_probability_5_star
    }

    /// Calculates the cost for a given number of pulls
    pub fn calculate_pull_cost(&self, num_pulls: u32) -> u32 {
        num_pulls * self.pull_cost
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_base_probability() {
        let banner = GachaBanner::new();
        assert_eq!(banner.calculate_5_star_probability(0), 0.006);
        assert_eq!(banner.calculate_5_star_probability(72), 0.006);
    }

    #[test]
    fn test_soft_pity_probability() {
        let banner = GachaBanner::new();
        // At pull 74 (73 pulls since last), prob is base + 1 * increment
        assert_eq!(banner.calculate_5_star_probability(73), 0.006 + 0.06);
        // At pull 75 (74 pulls since last), prob is base + 2 * increment
        assert_eq!(banner.calculate_5_star_probability(74), 0.006 + 0.12);
    }

    #[test]
    fn test_hard_pity_probability() {
        let banner = GachaBanner::new();
        assert_eq!(banner.calculate_5_star_probability(89), 1.0);
        assert_eq!(banner.calculate_5_star_probability(100), 1.0);
    }

    #[test]
    fn test_pull_cost() {
        let banner = GachaBanner::new();
        assert_eq!(banner.calculate_pull_cost(10), 1600);
    }
}
