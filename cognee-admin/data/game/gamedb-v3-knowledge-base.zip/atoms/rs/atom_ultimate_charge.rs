#[derive(Debug, Clone, PartialEq)]
pub struct UltimateChargeParams {
    pub max_charge: f32,
    pub passive_charge_rate: f32,
    pub damage_conversion_rate: f32,
    pub healing_conversion_rate: f32,
    pub charge_loss_on_death: f32,
}

impl UltimateChargeParams {
    pub fn new() -> Self {
        Self {
            max_charge: 2100.0,
            passive_charge_rate: 5.0,
            damage_conversion_rate: 1.0,
            healing_conversion_rate: 1.0,
            charge_loss_on_death: 0.0,
        }
    }
}

#[derive(Debug, Clone, PartialEq)]
pub struct UltimateChargeState {
    pub current_charge: f32,
    pub is_ready: bool,
}

impl UltimateChargeState {
    pub fn new() -> Self {
        Self {
            current_charge: 0.0,
            is_ready: false,
        }
    }

    pub fn add_passive_charge(&mut self, params: &UltimateChargeParams, delta_time: f32) {
        if !self.is_ready {
            self.current_charge += params.passive_charge_rate * delta_time;
            self.check_ready(params);
        }
    }

    pub fn add_active_charge(&mut self, params: &UltimateChargeParams, damage_dealt: f32, healing_done: f32) {
        if !self.is_ready {
            self.current_charge += damage_dealt * params.damage_conversion_rate;
            self.current_charge += healing_done * params.healing_conversion_rate;
            self.check_ready(params);
        }
    }

    pub fn handle_death(&mut self, params: &UltimateChargeParams) {
        if !self.is_ready {
            let loss_factor = params.charge_loss_on_death / 100.0;
            self.current_charge -= self.current_charge * loss_factor;
            if self.current_charge < 0.0 {
                self.current_charge = 0.0;
            }
        }
    }

    pub fn activate_ultimate(&mut self) -> bool {
        if self.is_ready {
            self.current_charge = 0.0;
            self.is_ready = false;
            true
        } else {
            false
        }
    }

    fn check_ready(&mut self, params: &UltimateChargeParams) {
        if self.current_charge >= params.max_charge {
            self.current_charge = params.max_charge;
            self.is_ready = true;
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_passive_charge() {
        let params = UltimateChargeParams::new();
        let mut state = UltimateChargeState::new();
        
        state.add_passive_charge(&params, 10.0);
        assert_eq!(state.current_charge, 50.0);
        assert!(!state.is_ready);
    }

    #[test]
    fn test_active_charge_and_ready() {
        let params = UltimateChargeParams::new();
        let mut state = UltimateChargeState::new();
        
        state.add_active_charge(&params, 1000.0, 1100.0);
        assert_eq!(state.current_charge, 2100.0);
        assert!(state.is_ready);
    }

    #[test]
    fn test_activate_ultimate() {
        let params = UltimateChargeParams::new();
        let mut state = UltimateChargeState::new();
        
        state.add_active_charge(&params, 3000.0, 0.0);
        assert!(state.is_ready);
        
        let activated = state.activate_ultimate();
        assert!(activated);
        assert_eq!(state.current_charge, 0.0);
        assert!(!state.is_ready);
    }
}
