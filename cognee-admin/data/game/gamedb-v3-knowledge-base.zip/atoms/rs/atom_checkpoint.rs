#[derive(Debug, Clone, PartialEq)]
pub struct CheckpointParams {
    pub activation_radius: f32,
    pub heal_amount: f32,
    pub respawn_delay: f32,
    pub enemies_respawn: bool,
}

impl CheckpointParams {
    /// Creates a new CheckpointParams with default values based on Dark Souls benchmark.
    pub fn new() -> Self {
        Self {
            activation_radius: 2.0,
            heal_amount: 100.0,
            respawn_delay: 3.0,
            enemies_respawn: true,
        }
    }
}

impl Default for CheckpointParams {
    fn default() -> Self {
        Self::new()
    }
}

#[derive(Debug, Clone, PartialEq)]
pub enum CheckpointState {
    Unactivated,
    Activated,
    Respawning,
}

pub struct Checkpoint {
    pub params: CheckpointParams,
    pub state: CheckpointState,
    pub current_delay: f32,
}

impl Checkpoint {
    pub fn new(params: CheckpointParams) -> Self {
        Self {
            params,
            state: CheckpointState::Unactivated,
            current_delay: 0.0,
        }
    }

    /// Simulates player interaction or reaching the checkpoint.
    pub fn interact(&mut self, distance: f32) -> bool {
        if self.state == CheckpointState::Unactivated && distance <= self.params.activation_radius {
            self.state = CheckpointState::Activated;
            true
        } else {
            false
        }
    }

    /// Triggers respawn process when player dies.
    pub fn trigger_respawn(&mut self) {
        if self.state == CheckpointState::Activated {
            self.state = CheckpointState::Respawning;
            self.current_delay = self.params.respawn_delay;
        }
    }

    /// Updates the respawn timer. Returns true if respawn is complete.
    pub fn update_respawn(&mut self, delta_time: f32) -> bool {
        if self.state == CheckpointState::Respawning {
            self.current_delay -= delta_time;
            if self.current_delay <= 0.0 {
                self.state = CheckpointState::Activated;
                self.current_delay = 0.0;
                return true;
            }
        }
        false
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_checkpoint_activation() {
        let params = CheckpointParams::new();
        let mut checkpoint = Checkpoint::new(params);
        
        // Too far away
        assert!(!checkpoint.interact(3.0));
        assert_eq!(checkpoint.state, CheckpointState::Unactivated);
        
        // Within radius
        assert!(checkpoint.interact(1.5));
        assert_eq!(checkpoint.state, CheckpointState::Activated);
    }

    #[test]
    fn test_checkpoint_respawn_flow() {
        let params = CheckpointParams::new();
        let mut checkpoint = Checkpoint::new(params);
        
        // Activate first
        checkpoint.interact(1.0);
        assert_eq!(checkpoint.state, CheckpointState::Activated);
        
        // Trigger respawn
        checkpoint.trigger_respawn();
        assert_eq!(checkpoint.state, CheckpointState::Respawning);
        assert_eq!(checkpoint.current_delay, 3.0);
        
        // Update timer
        assert!(!checkpoint.update_respawn(2.0));
        assert_eq!(checkpoint.state, CheckpointState::Respawning);
        
        // Finish respawn
        assert!(checkpoint.update_respawn(1.5));
        assert_eq!(checkpoint.state, CheckpointState::Activated);
    }
}
