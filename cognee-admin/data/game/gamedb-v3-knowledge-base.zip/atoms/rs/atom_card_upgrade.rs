#[derive(Debug, Clone, PartialEq)]
pub struct CardUpgradeParams {
    pub upgrade_cost_reduction: u32,
    pub damage_increase_flat: u32,
    pub block_increase_flat: u32,
    pub magic_number_increase: u32,
    pub max_upgrades_per_card: u32,
}

impl CardUpgradeParams {
    /// Creates a new CardUpgradeParams with default values based on Slay the Spire benchmarks.
    pub fn new() -> Self {
        Self {
            upgrade_cost_reduction: 1,
            damage_increase_flat: 3,
            block_increase_flat: 3,
            magic_number_increase: 1,
            max_upgrades_per_card: 1,
        }
    }

    /// Calculates the new damage of a card after a given number of upgrades.
    /// 
    /// # Arguments
    /// * `base_damage` - The original damage of the card.
    /// * `current_upgrades` - The number of times the card has already been upgraded.
    /// * `times_to_upgrade` - The number of upgrades to apply.
    pub fn calculate_upgraded_damage(&self, base_damage: u32, current_upgrades: u32, times_to_upgrade: u32) -> u32 {
        let total_upgrades = current_upgrades + times_to_upgrade;
        let effective_upgrades = if total_upgrades > self.max_upgrades_per_card {
            self.max_upgrades_per_card
        } else {
            total_upgrades
        };
        
        let actual_new_upgrades = effective_upgrades.saturating_sub(current_upgrades);
        base_damage + (actual_new_upgrades * self.damage_increase_flat)
    }

    /// Calculates the new cost of a card after upgrading.
    /// 
    /// # Arguments
    /// * `base_cost` - The original energy cost of the card.
    /// * `current_upgrades` - The number of times the card has already been upgraded.
    /// * `times_to_upgrade` - The number of upgrades to apply.
    pub fn calculate_upgraded_cost(&self, base_cost: u32, current_upgrades: u32, times_to_upgrade: u32) -> u32 {
        let total_upgrades = current_upgrades + times_to_upgrade;
        let effective_upgrades = if total_upgrades > self.max_upgrades_per_card {
            self.max_upgrades_per_card
        } else {
            total_upgrades
        };
        
        let actual_new_upgrades = effective_upgrades.saturating_sub(current_upgrades);
        base_cost.saturating_sub(actual_new_upgrades * self.upgrade_cost_reduction)
    }
}

impl Default for CardUpgradeParams {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_upgraded_damage() {
        let params = CardUpgradeParams::new();
        
        // Base damage 6, 0 current upgrades, 1 upgrade applied
        let new_damage = params.calculate_upgraded_damage(6, 0, 1);
        assert_eq!(new_damage, 9); // 6 + 3
        
        // Exceeding max upgrades
        let new_damage_exceed = params.calculate_upgraded_damage(6, 0, 2);
        assert_eq!(new_damage_exceed, 9); // Max upgrades is 1, so only 1 applies
    }

    #[test]
    fn test_calculate_upgraded_cost() {
        let params = CardUpgradeParams::new();
        
        // Base cost 2, 0 current upgrades, 1 upgrade applied
        let new_cost = params.calculate_upgraded_cost(2, 0, 1);
        assert_eq!(new_cost, 1); // 2 - 1
        
        // Base cost 0, 0 current upgrades, 1 upgrade applied
        let new_cost_zero = params.calculate_upgraded_cost(0, 0, 1);
        assert_eq!(new_cost_zero, 0); // Cost cannot go below 0
    }
}
