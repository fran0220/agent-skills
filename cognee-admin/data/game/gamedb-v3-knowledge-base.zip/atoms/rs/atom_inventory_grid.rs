#[derive(Debug, Clone)]
pub struct InventoryGridParams {
    pub grid_width: u32,
    pub grid_height: u32,
    pub can_rotate: bool,
    pub auto_sort: bool,
}

impl InventoryGridParams {
    /// Creates a new InventoryGridParams with default values based on Escape from Tarkov benchmarks.
    pub fn new() -> Self {
        Self {
            grid_width: 10,
            grid_height: 28,
            can_rotate: true,
            auto_sort: false,
        }
    }

    /// Calculates the total number of cells in the inventory grid.
    pub fn total_cells(&self) -> u32 {
        self.grid_width * self.grid_height
    }

    /// Checks if an item of given width and height can fit within the grid dimensions.
    /// This does not check for overlaps with other items, only if the item's dimensions
    /// are smaller than or equal to the grid's dimensions.
    pub fn can_fit_dimensions(&self, item_width: u32, item_height: u32) -> bool {
        let fits_normally = item_width <= self.grid_width && item_height <= self.grid_height;
        
        if self.can_rotate {
            let fits_rotated = item_height <= self.grid_width && item_width <= self.grid_height;
            fits_normally || fits_rotated
        } else {
            fits_normally
        }
    }
    
    /// Calculates the utilization percentage of the grid given the number of occupied cells.
    pub fn utilization_percentage(&self, occupied_cells: u32) -> f32 {
        let total = self.total_cells();
        if total == 0 {
            return 0.0;
        }
        (occupied_cells as f32 / total as f32) * 100.0
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_total_cells() {
        let params = InventoryGridParams::new();
        assert_eq!(params.total_cells(), 280);
        
        let small_grid = InventoryGridParams {
            grid_width: 5,
            grid_height: 5,
            can_rotate: true,
            auto_sort: false,
        };
        assert_eq!(small_grid.total_cells(), 25);
    }

    #[test]
    fn test_can_fit_dimensions() {
        let params = InventoryGridParams {
            grid_width: 10,
            grid_height: 10,
            can_rotate: true,
            auto_sort: false,
        };
        
        // Normal fit
        assert!(params.can_fit_dimensions(2, 3));
        
        // Rotated fit
        assert!(params.can_fit_dimensions(12, 5) == false); // Cannot fit even rotated
        
        let narrow_grid = InventoryGridParams {
            grid_width: 2,
            grid_height: 10,
            can_rotate: true,
            auto_sort: false,
        };
        
        // Item is 5x2. Normally doesn't fit width (5 > 2). Rotated it's 2x5, which fits (2 <= 2, 5 <= 10).
        assert!(narrow_grid.can_fit_dimensions(5, 2));
        
        let no_rotate_grid = InventoryGridParams {
            grid_width: 2,
            grid_height: 10,
            can_rotate: false,
            auto_sort: false,
        };
        
        // Without rotation, 5x2 does not fit.
        assert!(!no_rotate_grid.can_fit_dimensions(5, 2));
    }
    
    #[test]
    fn test_utilization_percentage() {
        let params = InventoryGridParams {
            grid_width: 10,
            grid_height: 10,
            can_rotate: true,
            auto_sort: false,
        };
        
        assert_eq!(params.utilization_percentage(50), 50.0);
        assert_eq!(params.utilization_percentage(100), 100.0);
        assert_eq!(params.utilization_percentage(0), 0.0);
    }
}
