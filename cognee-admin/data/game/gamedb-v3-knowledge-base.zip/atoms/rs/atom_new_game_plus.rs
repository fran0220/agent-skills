#[derive(Debug, Clone)]
pub struct NewGamePlusParams {
    pub enemy_health_multiplier: f32,
    pub enemy_damage_multiplier: f32,
    pub soul_drop_multiplier: f32,
    pub max_ng_cycles: u32,
    pub retain_inventory: bool,
    pub retain_key_items: bool,
    pub retain_levels: bool,
}

impl NewGamePlusParams {
    /// Creates a new instance with default values based on Dark Souls Remastered benchmark.
    pub fn new() -> Self {
        Self {
            enemy_health_multiplier: 1.41,
            enemy_damage_multiplier: 1.41,
            soul_drop_multiplier: 3.0,
            max_ng_cycles: 7,
            retain_inventory: true,
            retain_key_items: false,
            retain_levels: true,
        }
    }

    /// Calculates the scaled enemy health for a given NG+ cycle.
    /// Cycle 0 is the first playthrough. Cycle 1 is NG+.
    pub fn calculate_scaled_health(&self, base_health: f32, cycle: u32) -> f32 {
        if cycle == 0 {
            return base_health;
        }
        
        let effective_cycle = std::cmp::min(cycle, self.max_ng_cycles);
        // A simple scaling formula: base * multiplier * (1.0 + 0.1 * (cycle - 1))
        let scaling_factor = self.enemy_health_multiplier * (1.0 + 0.1 * (effective_cycle as f32 - 1.0));
        base_health * scaling_factor
    }

    /// Calculates the scaled enemy damage for a given NG+ cycle.
    pub fn calculate_scaled_damage(&self, base_damage: f32, cycle: u32) -> f32 {
        if cycle == 0 {
            return base_damage;
        }
        
        let effective_cycle = std::cmp::min(cycle, self.max_ng_cycles);
        let scaling_factor = self.enemy_damage_multiplier * (1.0 + 0.1 * (effective_cycle as f32 - 1.0));
        base_damage * scaling_factor
    }

    /// Calculates the scaled soul/currency drop for a given NG+ cycle.
    pub fn calculate_scaled_drops(&self, base_drops: f32, cycle: u32) -> f32 {
        if cycle == 0 {
            return base_drops;
        }
        
        let effective_cycle = std::cmp::min(cycle, self.max_ng_cycles);
        let scaling_factor = self.soul_drop_multiplier * (1.0 + 0.1 * (effective_cycle as f32 - 1.0));
        base_drops * scaling_factor
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_default_params() {
        let params = NewGamePlusParams::new();
        assert_eq!(params.enemy_health_multiplier, 1.41);
        assert_eq!(params.max_ng_cycles, 7);
        assert!(params.retain_inventory);
        assert!(!params.retain_key_items);
    }

    #[test]
    fn test_health_scaling() {
        let params = NewGamePlusParams::new();
        let base_health = 100.0;
        
        // Cycle 0 (First Playthrough)
        assert_eq!(params.calculate_scaled_health(base_health, 0), 100.0);
        
        // Cycle 1 (NG+)
        let ng1_health = params.calculate_scaled_health(base_health, 1);
        assert!((ng1_health - 141.0).abs() < f32::EPSILON);
        
        // Cycle 2 (NG++)
        let ng2_health = params.calculate_scaled_health(base_health, 2);
        assert!((ng2_health - 155.1).abs() < 0.001);
        
        // Cycle 8 (Capped at max_ng_cycles = 7)
        let ng7_health = params.calculate_scaled_health(base_health, 7);
        let ng8_health = params.calculate_scaled_health(base_health, 8);
        assert_eq!(ng7_health, ng8_health);
    }

    #[test]
    fn test_damage_scaling() {
        let params = NewGamePlusParams::new();
        let base_damage = 50.0;
        
        // Cycle 0
        assert_eq!(params.calculate_scaled_damage(base_damage, 0), 50.0);
        
        // Cycle 1
        let ng1_damage = params.calculate_scaled_damage(base_damage, 1);
        assert!((ng1_damage - 70.5).abs() < f32::EPSILON);
    }
}
