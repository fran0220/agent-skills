#[derive(Debug, Clone)]
pub struct MergeUpgradeParams {
    pub required_count: u32,
    pub tier_multiplier: f32,
    pub max_tier: u32,
    pub merge_cost: u32,
    pub success_rate: f32,
}

impl MergeUpgradeParams {
    /// Creates a new MergeUpgradeParams with default values based on Teamfight Tactics benchmarks.
    pub fn new() -> Self {
        Self {
            required_count: 3,
            tier_multiplier: 1.8,
            max_tier: 3,
            merge_cost: 0,
            success_rate: 1.0,
        }
    }

    /// Checks if a merge is possible given the current count of entities and their tier.
    pub fn can_merge(&self, current_count: u32, current_tier: u32) -> bool {
        current_count >= self.required_count && current_tier < self.max_tier
    }

    /// Calculates the stats of the merged entity based on the base stat and the new tier.
    pub fn calculate_merged_stats(&self, base_stat: f32, new_tier: u32) -> f32 {
        if new_tier == 1 {
            return base_stat;
        }
        // Assuming tier 1 is base, tier 2 is base * multiplier, tier 3 is base * multiplier^2
        let power = (new_tier - 1) as f32;
        base_stat * self.tier_multiplier.powf(power)
    }

    /// Attempts to merge entities. Returns the new tier if successful, or an error message.
    pub fn attempt_merge(&self, current_count: u32, current_tier: u32, random_roll: f32) -> Result<u32, &'static str> {
        if !self.can_merge(current_count, current_tier) {
            return Err("Cannot merge: insufficient entities or max tier reached");
        }

        if random_roll <= self.success_rate {
            Ok(current_tier + 1)
        } else {
            Err("Merge failed due to probability")
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_can_merge() {
        let params = MergeUpgradeParams::new();
        
        // Can merge 3 tier-1 entities
        assert!(params.can_merge(3, 1));
        
        // Cannot merge 2 tier-1 entities
        assert!(!params.can_merge(2, 1));
        
        // Cannot merge tier-3 entities (max tier reached)
        assert!(!params.can_merge(3, 3));
    }

    #[test]
    fn test_calculate_merged_stats() {
        let params = MergeUpgradeParams::new();
        let base_health = 100.0;
        
        // Tier 1 health
        assert_eq!(params.calculate_merged_stats(base_health, 1), 100.0);
        
        // Tier 2 health (100 * 1.8)
        assert_eq!(params.calculate_merged_stats(base_health, 2), 180.0);
        
        // Tier 3 health (100 * 1.8^2 = 324)
        let tier_3_health = params.calculate_merged_stats(base_health, 3);
        assert!((tier_3_health - 324.0).abs() < f32::EPSILON);
    }

    #[test]
    fn test_attempt_merge() {
        let mut params = MergeUpgradeParams::new();
        
        // Successful merge (100% success rate)
        assert_eq!(params.attempt_merge(3, 1, 0.5), Ok(2));
        
        // Failed merge due to probability
        params.success_rate = 0.4;
        assert_eq!(params.attempt_merge(3, 1, 0.8), Err("Merge failed due to probability"));
        
        // Failed merge due to insufficient count
        assert_eq!(params.attempt_merge(2, 1, 0.1), Err("Cannot merge: insufficient entities or max tier reached"));
    }
}
