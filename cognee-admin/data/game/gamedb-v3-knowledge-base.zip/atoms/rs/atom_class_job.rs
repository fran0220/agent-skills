#[derive(Debug, Clone)]
pub struct ClassJobParams {
    pub base_hp_multiplier: f32,
    pub base_mp_multiplier: f32,
    pub stat_growth_rate: f32,
    pub max_level: u32,
    pub skill_points_per_level: u32,
}

impl ClassJobParams {
    pub fn new() -> Self {
        Self {
            base_hp_multiplier: 1.2,
            base_mp_multiplier: 1.5,
            stat_growth_rate: 1.1,
            max_level: 90,
            skill_points_per_level: 1,
        }
    }

    pub fn calculate_max_hp(&self, base_hp: f32, level: u32) -> f32 {
        let level_factor = 1.0 + (level as f32 * 0.05);
        base_hp * self.base_hp_multiplier * level_factor
    }

    pub fn calculate_stat_growth(&self, base_stat: f32, level: u32) -> f32 {
        base_stat + (level as f32 * self.stat_growth_rate)
    }

    pub fn calculate_total_skill_points(&self, level: u32) -> u32 {
        if level > self.max_level {
            self.max_level * self.skill_points_per_level
        } else {
            level * self.skill_points_per_level
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_max_hp() {
        let params = ClassJobParams::new();
        let base_hp = 100.0;
        let level = 10;
        // level_factor = 1.0 + (10 * 0.05) = 1.5
        // max_hp = 100.0 * 1.2 * 1.5 = 180.0
        assert_eq!(params.calculate_max_hp(base_hp, level), 180.0);
    }

    #[test]
    fn test_calculate_stat_growth() {
        let params = ClassJobParams::new();
        let base_stat = 10.0;
        let level = 5;
        // stat_growth = 10.0 + (5 * 1.1) = 15.5
        assert_eq!(params.calculate_stat_growth(base_stat, level), 15.5);
    }

    #[test]
    fn test_calculate_total_skill_points() {
        let params = ClassJobParams::new();
        assert_eq!(params.calculate_total_skill_points(10), 10);
        assert_eq!(params.calculate_total_skill_points(100), 90); // Capped at max_level (90)
    }
}
