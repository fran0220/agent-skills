#[derive(Debug, Clone, PartialEq)]
pub struct DisguiseParameters {
    pub detection_time_base: f32,
    pub enforcer_fov: f32,
    pub suspicion_decay_rate: f32,
    pub disguise_equip_time: f32,
    pub movement_penalty: f32,
    pub is_compromised: bool,
}

impl DisguiseParameters {
    /// Creates a new DisguiseParameters instance with default values based on Hitman 3 benchmarks.
    pub fn new() -> Self {
        Self {
            detection_time_base: 2.5,
            enforcer_fov: 90.0,
            suspicion_decay_rate: 0.5,
            disguise_equip_time: 1.5,
            movement_penalty: 0.0,
            is_compromised: false,
        }
    }

    /// Calculates the actual detection time based on the distance to the enforcer.
    /// The closer the player is, the faster they are detected.
    /// Returns the detection time in seconds.
    pub fn calculate_detection_time(&self, distance: f32, min_distance: f32, max_distance: f32) -> f32 {
        if distance <= min_distance {
            return self.detection_time_base * 0.5; // Detected twice as fast at minimum distance
        }
        if distance >= max_distance {
            return self.detection_time_base * 2.0; // Detected twice as slow at maximum distance
        }
        
        // Linear interpolation between min and max distance
        let distance_factor = (distance - min_distance) / (max_distance - min_distance);
        let time_multiplier = 0.5 + (1.5 * distance_factor);
        
        self.detection_time_base * time_multiplier
    }

    /// Calculates the suspicion level decay over a given time delta.
    /// Returns the new suspicion level (clamped to 0.0).
    pub fn calculate_suspicion_decay(&self, current_suspicion: f32, delta_time: f32) -> f32 {
        let decay_amount = self.suspicion_decay_rate * delta_time;
        let new_suspicion = current_suspicion - decay_amount;
        
        if new_suspicion < 0.0 {
            0.0
        } else {
            new_suspicion
        }
    }
    
    /// Checks if an enforcer can see the player based on the angle to the player.
    pub fn can_enforcer_see_player(&self, angle_to_player: f32) -> bool {
        // Angle should be in degrees, absolute value
        angle_to_player.abs() <= (self.enforcer_fov / 2.0)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_detection_time() {
        let params = DisguiseParameters::new();
        
        // Test at minimum distance
        let time_min = params.calculate_detection_time(1.0, 2.0, 10.0);
        assert_eq!(time_min, 1.25); // 2.5 * 0.5
        
        // Test at maximum distance
        let time_max = params.calculate_detection_time(12.0, 2.0, 10.0);
        assert_eq!(time_max, 5.0); // 2.5 * 2.0
        
        // Test at middle distance
        let time_mid = params.calculate_detection_time(6.0, 2.0, 10.0);
        assert_eq!(time_mid, 3.125); // 2.5 * (0.5 + 1.5 * 0.5) = 2.5 * 1.25
    }

    #[test]
    fn test_calculate_suspicion_decay() {
        let params = DisguiseParameters::new();
        
        // Test normal decay
        let new_suspicion = params.calculate_suspicion_decay(5.0, 2.0);
        assert_eq!(new_suspicion, 4.0); // 5.0 - (0.5 * 2.0)
        
        // Test decay clamping to 0
        let clamped_suspicion = params.calculate_suspicion_decay(0.5, 2.0);
        assert_eq!(clamped_suspicion, 0.0); // 0.5 - 1.0 = -0.5 -> 0.0
    }
    
    #[test]
    fn test_can_enforcer_see_player() {
        let params = DisguiseParameters::new(); // fov is 90.0, so +/- 45.0 degrees
        
        assert!(params.can_enforcer_see_player(30.0));
        assert!(params.can_enforcer_see_player(-40.0));
        assert!(!params.can_enforcer_see_player(50.0));
        assert!(!params.can_enforcer_see_player(-60.0));
    }
}
