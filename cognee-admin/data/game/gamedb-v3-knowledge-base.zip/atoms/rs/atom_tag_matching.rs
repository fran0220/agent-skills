#[derive(Debug, Clone)]
pub struct TagMatchingParams {
    pub base_score: f32,
    pub tag_multiplier: f32,
    pub penalty_multiplier: f32,
    pub synergy_bonus: f32,
    pub match_threshold: f32,
}

impl TagMatchingParams {
    /// Creates a new TagMatchingParams with default values based on Love Nikki benchmark.
    pub fn new() -> Self {
        Self {
            base_score: 150.0,
            tag_multiplier: 2.5,
            penalty_multiplier: 0.5,
            synergy_bonus: 100.0,
            match_threshold: 5000.0,
        }
    }
}

/// Represents an item with tags and a base score.
#[derive(Debug, Clone)]
pub struct Item {
    pub base_score: f32,
    pub tags: Vec<String>,
}

pub struct TagMatchingSystem {
    pub params: TagMatchingParams,
}

impl TagMatchingSystem {
    pub fn new(params: TagMatchingParams) -> Self {
        Self { params }
    }

    /// Calculates the score for a single item against a set of target tags.
    pub fn calculate_item_score(&self, item: &Item, target_tags: &[String], penalty_tags: &[String]) -> f32 {
        let mut score = item.base_score;
        let mut match_count = 0;
        let mut penalty_count = 0;

        for tag in &item.tags {
            if target_tags.contains(tag) {
                match_count += 1;
            }
            if penalty_tags.contains(tag) {
                penalty_count += 1;
            }
        }

        if match_count > 0 {
            score *= self.params.tag_multiplier * (match_count as f32);
        }

        if penalty_count > 0 {
            score *= self.params.penalty_multiplier.powi(penalty_count as i32);
        }

        score
    }

    /// Calculates the total score for a loadout of items, including synergy bonuses.
    pub fn calculate_total_score(&self, items: &[Item], target_tags: &[String], penalty_tags: &[String]) -> f32 {
        let mut total_score = 0.0;
        let mut total_matches = 0;

        for item in items {
            total_score += self.calculate_item_score(item, target_tags, penalty_tags);
            
            for tag in &item.tags {
                if target_tags.contains(tag) {
                    total_matches += 1;
                }
            }
        }

        // Apply synergy bonus if multiple items match the target tags
        if total_matches > 1 {
            total_score += self.params.synergy_bonus * ((total_matches - 1) as f32);
        }

        total_score
    }

    /// Checks if the total score meets the match threshold.
    pub fn is_match_successful(&self, total_score: f32) -> bool {
        total_score >= self.params.match_threshold
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_item_score() {
        let params = TagMatchingParams::new();
        let system = TagMatchingSystem::new(params);

        let item = Item {
            base_score: 100.0,
            tags: vec!["Elegant".to_string(), "Simple".to_string()],
        };

        let target_tags = vec!["Elegant".to_string()];
        let penalty_tags = vec!["Gorgeous".to_string()];

        // 1 match: 100.0 * 2.5 * 1 = 250.0
        let score = system.calculate_item_score(&item, &target_tags, &penalty_tags);
        assert_eq!(score, 250.0);

        let target_tags_2 = vec!["Elegant".to_string(), "Simple".to_string()];
        // 2 matches: 100.0 * 2.5 * 2 = 500.0
        let score_2 = system.calculate_item_score(&item, &target_tags_2, &penalty_tags);
        assert_eq!(score_2, 500.0);

        let penalty_tags_2 = vec!["Simple".to_string()];
        // 1 match, 1 penalty: (100.0 * 2.5 * 1) * 0.5 = 125.0
        let score_3 = system.calculate_item_score(&item, &target_tags, &penalty_tags_2);
        assert_eq!(score_3, 125.0);
    }

    #[test]
    fn test_calculate_total_score_and_threshold() {
        let params = TagMatchingParams::new();
        let system = TagMatchingSystem::new(params);

        let item1 = Item {
            base_score: 200.0,
            tags: vec!["Elegant".to_string()],
        };
        let item2 = Item {
            base_score: 300.0,
            tags: vec!["Elegant".to_string(), "Warm".to_string()],
        };

        let items = vec![item1, item2];
        let target_tags = vec!["Elegant".to_string()];
        let penalty_tags = vec![];

        // item1 score: 200.0 * 2.5 * 1 = 500.0
        // item2 score: 300.0 * 2.5 * 1 = 750.0
        // total matches: 2
        // synergy bonus: 100.0 * (2 - 1) = 100.0
        // total score: 500.0 + 750.0 + 100.0 = 1350.0
        let total_score = system.calculate_total_score(&items, &target_tags, &penalty_tags);
        assert_eq!(total_score, 1350.0);

        // Threshold is 5000.0, so this should fail
        assert!(!system.is_match_successful(total_score));
    }
}
