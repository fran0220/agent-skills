#[derive(Debug, Clone, PartialEq)]
pub struct BeltConveyor {
    pub speed: f32, // items per second
    pub capacity_per_tile: u32, // items
    pub length: f32, // tiles
    pub power_consumption: f32, // kW
    pub max_incline: f32, // degrees
}

impl BeltConveyor {
    pub fn new() -> Self {
        // Default values based on Factorio benchmark
        Self {
            speed: 15.0,
            capacity_per_tile: 4,
            length: 1.0,
            power_consumption: 0.0,
            max_incline: 0.0,
        }
    }

    /// Calculates the maximum throughput of the conveyor belt in items per second.
    pub fn max_throughput(&self) -> f32 {
        self.speed
    }

    /// Calculates the time it takes for an item to travel the full length of the conveyor.
    /// Assuming speed is items/sec and capacity_per_tile is items/tile,
    /// the physical speed of the belt is (speed / capacity_per_tile) tiles/sec.
    pub fn travel_time(&self) -> f32 {
        if self.speed <= 0.0 || self.capacity_per_tile == 0 {
            return f32::INFINITY;
        }
        let tiles_per_second = self.speed / (self.capacity_per_tile as f32);
        self.length / tiles_per_second
    }

    /// Calculates the total number of items that can fit on this conveyor segment.
    pub fn total_capacity(&self) -> u32 {
        (self.length * self.capacity_per_tile as f32).floor() as u32
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_travel_time() {
        let mut belt = BeltConveyor::new();
        belt.speed = 15.0;
        belt.capacity_per_tile = 4;
        belt.length = 10.0;
        
        // tiles_per_second = 15.0 / 4.0 = 3.75
        // travel_time = 10.0 / 3.75 = 2.6666667
        assert!((belt.travel_time() - 2.6666667).abs() < 1e-5);
    }

    #[test]
    fn test_total_capacity() {
        let mut belt = BeltConveyor::new();
        belt.capacity_per_tile = 4;
        belt.length = 5.5;
        
        // total_capacity = floor(5.5 * 4) = 22
        assert_eq!(belt.total_capacity(), 22);
    }
}
