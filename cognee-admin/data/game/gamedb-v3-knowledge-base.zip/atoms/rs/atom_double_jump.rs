#[derive(Debug, Clone, PartialEq)]
pub struct DoubleJumpParams {
    pub double_jump_velocity: f32,
    pub gravity_multiplier: f32,
    pub horizontal_boost: f32,
    pub input_buffer_time: f32,
    pub coyote_time_override: bool,
    pub max_jumps: u32,
}

impl DoubleJumpParams {
    /// Creates a new DoubleJumpParams with default values based on Hollow Knight benchmark.
    pub fn new() -> Self {
        Self {
            double_jump_velocity: 16.5,
            gravity_multiplier: 1.0,
            horizontal_boost: 0.0,
            input_buffer_time: 0.1,
            coyote_time_override: false,
            max_jumps: 2,
        }
    }
}

impl Default for DoubleJumpParams {
    fn default() -> Self {
        Self::new()
    }
}

#[derive(Debug, Clone, PartialEq)]
pub struct PlayerState {
    pub velocity_y: f32,
    pub velocity_x: f32,
    pub jumps_performed: u32,
    pub is_grounded: bool,
}

pub struct DoubleJumpAtom {
    pub params: DoubleJumpParams,
}

impl DoubleJumpAtom {
    pub fn new(params: DoubleJumpParams) -> Self {
        Self { params }
    }

    /// Checks if a double jump can be performed.
    pub fn can_double_jump(&self, state: &PlayerState) -> bool {
        !state.is_grounded && state.jumps_performed > 0 && state.jumps_performed < self.params.max_jumps
    }

    /// Applies the double jump logic to the player state.
    /// Returns the new player state after the double jump.
    pub fn apply_double_jump(&self, mut state: PlayerState, input_x: f32) -> PlayerState {
        if self.can_double_jump(&state) {
            // Override vertical velocity
            state.velocity_y = self.params.double_jump_velocity;
            
            // Apply horizontal boost based on input direction
            if input_x > 0.0 {
                state.velocity_x += self.params.horizontal_boost;
            } else if input_x < 0.0 {
                state.velocity_x -= self.params.horizontal_boost;
            }
            
            state.jumps_performed += 1;
        }
        state
    }
    
    /// Resets the jump counter when grounded.
    pub fn update_grounded(&self, mut state: PlayerState, is_grounded: bool) -> PlayerState {
        state.is_grounded = is_grounded;
        if is_grounded {
            state.jumps_performed = 0;
        }
        state
    }
    
    /// Registers an initial jump from the ground.
    pub fn apply_initial_jump(&self, mut state: PlayerState, initial_jump_velocity: f32) -> PlayerState {
        if state.is_grounded {
            state.velocity_y = initial_jump_velocity;
            state.is_grounded = false;
            state.jumps_performed = 1;
        }
        state
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_can_double_jump() {
        let atom = DoubleJumpAtom::new(DoubleJumpParams::new());
        
        // Grounded, shouldn't double jump (it would be a regular jump)
        let state1 = PlayerState { velocity_y: 0.0, velocity_x: 0.0, jumps_performed: 0, is_grounded: true };
        assert_eq!(atom.can_double_jump(&state1), false);
        
        // Airborne, 1 jump performed (initial jump)
        let state2 = PlayerState { velocity_y: -5.0, velocity_x: 0.0, jumps_performed: 1, is_grounded: false };
        assert_eq!(atom.can_double_jump(&state2), true);
        
        // Airborne, 2 jumps performed (max reached)
        let state3 = PlayerState { velocity_y: -5.0, velocity_x: 0.0, jumps_performed: 2, is_grounded: false };
        assert_eq!(atom.can_double_jump(&state3), false);
    }

    #[test]
    fn test_apply_double_jump() {
        let mut params = DoubleJumpParams::new();
        params.horizontal_boost = 2.0; // Add some horizontal boost for testing
        let atom = DoubleJumpAtom::new(params);
        
        let initial_state = PlayerState { 
            velocity_y: -10.0, // Falling
            velocity_x: 5.0,   // Moving right
            jumps_performed: 1, 
            is_grounded: false 
        };
        
        // Apply double jump with right input
        let new_state = atom.apply_double_jump(initial_state, 1.0);
        
        assert_eq!(new_state.velocity_y, 16.5); // Velocity overridden
        assert_eq!(new_state.velocity_x, 7.0);  // 5.0 + 2.0 boost
        assert_eq!(new_state.jumps_performed, 2); // Counter incremented
    }
    
    #[test]
    fn test_ground_reset() {
        let atom = DoubleJumpAtom::new(DoubleJumpParams::new());
        
        let airborne_state = PlayerState { 
            velocity_y: -10.0, 
            velocity_x: 0.0, 
            jumps_performed: 2, 
            is_grounded: false 
        };
        
        let grounded_state = atom.update_grounded(airborne_state, true);
        
        assert_eq!(grounded_state.is_grounded, true);
        assert_eq!(grounded_state.jumps_performed, 0);
    }
}
