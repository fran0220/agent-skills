#[derive(Debug, Clone, PartialEq)]
pub struct MinigameRotationParams {
    pub intro_duration: f32,
    pub minigame_duration: f32,
    pub transition_duration: f32,
    pub speed_multiplier: f32,
    pub games_per_rotation: u32,
}

impl MinigameRotationParams {
    /// Creates a new `MinigameRotationParams` with default values based on WarioWare benchmarks.
    pub fn new() -> Self {
        Self {
            intro_duration: 2.0,
            minigame_duration: 4.0,
            transition_duration: 1.0,
            speed_multiplier: 1.1,
            games_per_rotation: 15,
        }
    }

    /// Calculates the total duration of a single minigame cycle (intro + game + transition)
    /// at a given speed level.
    pub fn calculate_cycle_duration(&self, speed_level: u32) -> f32 {
        let current_multiplier = self.speed_multiplier.powi(speed_level as i32);
        let current_intro = self.intro_duration / current_multiplier;
        let current_game = self.minigame_duration / current_multiplier;
        let current_transition = self.transition_duration / current_multiplier;
        
        current_intro + current_game + current_transition
    }

    /// Calculates the estimated total time for the entire rotation, assuming speed increases
    /// every `speed_increase_interval` games.
    pub fn estimate_total_rotation_time(&self, speed_increase_interval: u32) -> f32 {
        let mut total_time = 0.0;
        for game_index in 0..self.games_per_rotation {
            let speed_level = game_index / speed_increase_interval;
            total_time += self.calculate_cycle_duration(speed_level);
        }
        total_time
    }
}

impl Default for MinigameRotationParams {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_cycle_duration() {
        let params = MinigameRotationParams::new();
        
        // At speed level 0, multiplier is 1.1^0 = 1.0
        // Duration = 2.0 + 4.0 + 1.0 = 7.0
        let duration_lvl0 = params.calculate_cycle_duration(0);
        assert!((duration_lvl0 - 7.0).abs() < f32::EPSILON);

        // At speed level 1, multiplier is 1.1^1 = 1.1
        // Duration = (2.0 + 4.0 + 1.0) / 1.1 = 7.0 / 1.1 ≈ 6.3636
        let duration_lvl1 = params.calculate_cycle_duration(1);
        assert!((duration_lvl1 - 6.363636).abs() < 0.0001);
    }

    #[test]
    fn test_estimate_total_rotation_time() {
        let mut params = MinigameRotationParams::new();
        params.games_per_rotation = 3;
        params.speed_multiplier = 2.0;
        
        // Speed increases every 2 games.
        // Game 0: level 0 (mult 1.0) -> duration 7.0
        // Game 1: level 0 (mult 1.0) -> duration 7.0
        // Game 2: level 1 (mult 2.0) -> duration 3.5
        // Total = 7.0 + 7.0 + 3.5 = 17.5
        let total_time = params.estimate_total_rotation_time(2);
        assert!((total_time - 17.5).abs() < f32::EPSILON);
    }
}
