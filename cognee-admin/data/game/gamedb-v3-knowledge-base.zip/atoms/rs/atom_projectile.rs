#[derive(Debug, Clone)]
pub struct ProjectileParams {
    pub initial_velocity: f32,
    pub gravity_scale: f32,
    pub drag_coefficient: f32,
    pub max_lifespan: f32,
    pub base_damage: f32,
    pub headshot_multiplier: f32,
    pub projectile_radius: f32,
}

impl ProjectileParams {
    /// Creates a new ProjectileParams with default values based on Apex Legends R-301 benchmark.
    pub fn new() -> Self {
        Self {
            initial_velocity: 800.0,
            gravity_scale: 1.0,
            drag_coefficient: 0.01,
            max_lifespan: 3.0,
            base_damage: 14.0,
            headshot_multiplier: 1.75,
            projectile_radius: 0.05,
        }
    }
}

pub struct ProjectileState {
    pub position: (f32, f32, f32),
    pub velocity: (f32, f32, f32),
    pub time_alive: f32,
    pub is_active: bool,
}

impl ProjectileState {
    pub fn new(start_pos: (f32, f32, f32), direction: (f32, f32, f32), params: &ProjectileParams) -> Self {
        // Normalize direction vector
        let mag = (direction.0 * direction.0 + direction.1 * direction.1 + direction.2 * direction.2).sqrt();
        let dir_norm = if mag > 0.0 {
            (direction.0 / mag, direction.1 / mag, direction.2 / mag)
        } else {
            (1.0, 0.0, 0.0)
        };

        Self {
            position: start_pos,
            velocity: (
                dir_norm.0 * params.initial_velocity,
                dir_norm.1 * params.initial_velocity,
                dir_norm.2 * params.initial_velocity,
            ),
            time_alive: 0.0,
            is_active: true,
        }
    }

    /// Updates the projectile's position and velocity over a time step `dt`.
    /// Returns true if the projectile is still active, false if it exceeded max lifespan.
    pub fn update(&mut self, dt: f32, params: &ProjectileParams) -> bool {
        if !self.is_active {
            return false;
        }

        self.time_alive += dt;
        if self.time_alive >= params.max_lifespan {
            self.is_active = false;
            return false;
        }

        // Apply gravity (assuming Z is up, gravity is 9.81 m/s^2)
        let gravity = 9.81 * params.gravity_scale;
        self.velocity.2 -= gravity * dt;

        // Apply drag (simplified linear drag for demonstration)
        let speed = (self.velocity.0 * self.velocity.0 + self.velocity.1 * self.velocity.1 + self.velocity.2 * self.velocity.2).sqrt();
        if speed > 0.0 {
            let drag_force = params.drag_coefficient * speed * speed;
            // Apply drag opposite to velocity
            let drag_accel = drag_force; // Assuming mass = 1 for simplicity
            let drag_factor = 1.0 - (drag_accel * dt / speed).min(1.0);
            
            self.velocity.0 *= drag_factor;
            self.velocity.1 *= drag_factor;
            self.velocity.2 *= drag_factor;
        }

        // Update position
        self.position.0 += self.velocity.0 * dt;
        self.position.1 += self.velocity.1 * dt;
        self.position.2 += self.velocity.2 * dt;

        true
    }

    /// Calculates damage upon impact.
    pub fn calculate_damage(&self, is_headshot: bool, params: &ProjectileParams) -> f32 {
        if is_headshot {
            params.base_damage * params.headshot_multiplier
        } else {
            params.base_damage
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_projectile_initialization() {
        let params = ProjectileParams::new();
        let state = ProjectileState::new((0.0, 0.0, 0.0), (1.0, 0.0, 0.0), &params);
        
        assert_eq!(state.velocity.0, 800.0);
        assert_eq!(state.velocity.1, 0.0);
        assert_eq!(state.velocity.2, 0.0);
        assert!(state.is_active);
    }

    #[test]
    fn test_projectile_update_gravity() {
        let params = ProjectileParams::new();
        let mut state = ProjectileState::new((0.0, 0.0, 0.0), (1.0, 0.0, 0.0), &params);
        
        let dt = 0.1;
        state.update(dt, &params);
        
        // Gravity should reduce Z velocity
        assert!(state.velocity.2 < 0.0);
        // Position should update
        assert!(state.position.0 > 0.0);
    }

    #[test]
    fn test_projectile_lifespan() {
        let params = ProjectileParams::new();
        let mut state = ProjectileState::new((0.0, 0.0, 0.0), (1.0, 0.0, 0.0), &params);
        
        // Update past max lifespan
        state.update(params.max_lifespan + 0.1, &params);
        
        assert!(!state.is_active);
    }

    #[test]
    fn test_damage_calculation() {
        let params = ProjectileParams::new();
        let state = ProjectileState::new((0.0, 0.0, 0.0), (1.0, 0.0, 0.0), &params);
        
        let body_damage = state.calculate_damage(false, &params);
        let head_damage = state.calculate_damage(true, &params);
        
        assert_eq!(body_damage, 14.0);
        assert_eq!(head_damage, 14.0 * 1.75);
    }
}
