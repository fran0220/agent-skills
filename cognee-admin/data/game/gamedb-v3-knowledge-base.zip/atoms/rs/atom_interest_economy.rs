#[derive(Debug, Clone, PartialEq)]
pub struct InterestEconomy {
    pub interest_rate: f32,
    pub min_threshold: u32,
    pub max_threshold: u32,
    pub max_interest: u32,
}

impl InterestEconomy {
    pub fn new() -> Self {
        Self {
            interest_rate: 0.1,
            min_threshold: 10,
            max_threshold: 50,
            max_interest: 5,
        }
    }

    pub fn calculate_interest(&self, current_gold: u32) -> u32 {
        if current_gold < self.min_threshold {
            return 0;
        }

        let effective_gold = std::cmp::min(current_gold, self.max_threshold);
        let interest = (effective_gold as f32 * self.interest_rate).floor() as u32;
        
        std::cmp::min(interest, self.max_interest)
    }

    pub fn apply_interest(&self, current_gold: u32) -> u32 {
        current_gold + self.calculate_interest(current_gold)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_interest() {
        let economy = InterestEconomy::new();
        
        // Below threshold
        assert_eq!(economy.calculate_interest(9), 0);
        
        // At thresholds
        assert_eq!(economy.calculate_interest(10), 1);
        assert_eq!(economy.calculate_interest(25), 2);
        assert_eq!(economy.calculate_interest(30), 3);
        assert_eq!(economy.calculate_interest(49), 4);
        
        // Max threshold
        assert_eq!(economy.calculate_interest(50), 5);
        
        // Above max threshold
        assert_eq!(economy.calculate_interest(100), 5);
    }

    #[test]
    fn test_apply_interest() {
        let economy = InterestEconomy::new();
        
        assert_eq!(economy.apply_interest(9), 9);
        assert_eq!(economy.apply_interest(20), 22);
        assert_eq!(economy.apply_interest(50), 55);
        assert_eq!(economy.apply_interest(100), 105);
    }
}
