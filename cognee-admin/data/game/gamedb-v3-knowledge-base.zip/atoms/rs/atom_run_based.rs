#[derive(Debug, Clone)]
pub struct RunBasedSession {
    pub base_health: u32,
    pub encounters_per_run: u32,
    pub meta_currency_rate: f32,
}

impl RunBasedSession {
    /// Creates a new RunBasedSession with default values based on Hades benchmark.
    pub fn new() -> Self {
        Self {
            base_health: 50,
            encounters_per_run: 69,
            meta_currency_rate: 1.0,
        }
    }

    /// Calculates the expected meta currency earned in a run based on encounters cleared.
    pub fn calculate_meta_currency(&self, encounters_cleared: u32, base_reward_per_encounter: f32) -> f32 {
        let cleared = encounters_cleared.min(self.encounters_per_run);
        (cleared as f32) * base_reward_per_encounter * self.meta_currency_rate
    }

    /// Determines if a run is successful based on encounters cleared.
    pub fn is_run_successful(&self, encounters_cleared: u32) -> bool {
        encounters_cleared >= self.encounters_per_run
    }

    /// Calculates the remaining health after taking damage, ensuring it doesn't drop below 0.
    pub fn take_damage(&self, current_health: u32, damage: u32) -> u32 {
        current_health.saturating_sub(damage)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_meta_currency() {
        let session = RunBasedSession::new();
        // 10 encounters cleared, 5.0 base reward per encounter, 1.0 rate
        let currency = session.calculate_meta_currency(10, 5.0);
        assert_eq!(currency, 50.0);

        // Cap at max encounters
        let currency_capped = session.calculate_meta_currency(100, 5.0);
        assert_eq!(currency_capped, 69.0 * 5.0);
    }

    #[test]
    fn test_is_run_successful() {
        let session = RunBasedSession::new();
        assert!(!session.is_run_successful(50));
        assert!(session.is_run_successful(69));
        assert!(session.is_run_successful(100));
    }

    #[test]
    fn test_take_damage() {
        let session = RunBasedSession::new();
        assert_eq!(session.take_damage(50, 20), 30);
        assert_eq!(session.take_damage(50, 60), 0);
    }
}
