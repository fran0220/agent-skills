#[derive(Debug, Clone, PartialEq)]
pub struct TimedChoiceParams {
    pub time_limit: f32,
    pub num_options: u32,
    pub has_default_action: bool,
    pub timer_visibility: bool,
}

impl TimedChoiceParams {
    pub fn new() -> Self {
        Self {
            time_limit: 5.0, // Default from The Walking Dead
            num_options: 4,
            has_default_action: true,
            timer_visibility: true,
        }
    }
}

#[derive(Debug, Clone, PartialEq)]
pub enum ChoiceState {
    Idle,
    ActiveTimer { time_remaining: f32 },
    ResolvedChosen { chosen_index: u32 },
    ResolvedTimeout,
    End,
}

pub struct TimedChoice {
    pub params: TimedChoiceParams,
    pub state: ChoiceState,
}

impl TimedChoice {
    pub fn new(params: TimedChoiceParams) -> Self {
        Self {
            params,
            state: ChoiceState::Idle,
        }
    }

    pub fn trigger(&mut self) {
        if let ChoiceState::Idle = self.state {
            self.state = ChoiceState::ActiveTimer {
                time_remaining: self.params.time_limit,
            };
        }
    }

    pub fn update(&mut self, delta_time: f32) {
        if let ChoiceState::ActiveTimer { ref mut time_remaining } = self.state {
            *time_remaining -= delta_time;
            if *time_remaining <= 0.0 {
                self.state = ChoiceState::ResolvedTimeout;
            }
        }
    }

    pub fn choose(&mut self, option_index: u32) -> bool {
        if let ChoiceState::ActiveTimer { .. } = self.state {
            if option_index < self.params.num_options {
                self.state = ChoiceState::ResolvedChosen { chosen_index: option_index };
                return true;
            }
        }
        false
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_timeout() {
        let params = TimedChoiceParams::new();
        let mut choice = TimedChoice::new(params);
        
        choice.trigger();
        assert!(matches!(choice.state, ChoiceState::ActiveTimer { .. }));
        
        choice.update(3.0);
        assert!(matches!(choice.state, ChoiceState::ActiveTimer { .. }));
        
        choice.update(2.1);
        assert!(matches!(choice.state, ChoiceState::ResolvedTimeout));
    }

    #[test]
    fn test_choose_valid_option() {
        let params = TimedChoiceParams::new();
        let mut choice = TimedChoice::new(params);
        
        choice.trigger();
        let success = choice.choose(2);
        
        assert!(success);
        assert!(matches!(choice.state, ChoiceState::ResolvedChosen { chosen_index: 2 }));
    }
    
    #[test]
    fn test_choose_invalid_option() {
        let params = TimedChoiceParams::new();
        let mut choice = TimedChoice::new(params);
        
        choice.trigger();
        let success = choice.choose(5); // Out of bounds (num_options is 4)
        
        assert!(!success);
        assert!(matches!(choice.state, ChoiceState::ActiveTimer { .. }));
    }
}
