#[derive(Debug, Clone, PartialEq)]
pub enum EncumbranceState {
    Normal,
    Encumbered,
    OverEncumbered,
}

#[derive(Debug, Clone)]
pub struct InventoryWeightAtom {
    pub base_carry_weight: f32,
    pub weight_per_strength: f32,
    pub encumbered_speed_mult: f32,
    pub over_encumbered_speed_mult: f32,
    pub encumbrance_threshold: f32,
}

impl InventoryWeightAtom {
    pub fn new() -> Self {
        Self {
            base_carry_weight: 300.0,
            weight_per_strength: 5.0,
            encumbered_speed_mult: 0.0,
            over_encumbered_speed_mult: 0.0,
            encumbrance_threshold: 1.0,
        }
    }

    pub fn calculate_max_carry_weight(&self, strength: f32) -> f32 {
        self.base_carry_weight + (strength * self.weight_per_strength)
    }

    pub fn get_encumbrance_state(&self, current_weight: f32, max_carry_weight: f32) -> EncumbranceState {
        let encumbrance_limit = max_carry_weight * self.encumbrance_threshold;
        
        if current_weight > max_carry_weight {
            EncumbranceState::OverEncumbered
        } else if current_weight > encumbrance_limit {
            EncumbranceState::Encumbered
        } else {
            EncumbranceState::Normal
        }
    }

    pub fn get_speed_multiplier(&self, state: &EncumbranceState) -> f32 {
        match state {
            EncumbranceState::Normal => 1.0,
            EncumbranceState::Encumbered => self.encumbered_speed_mult,
            EncumbranceState::OverEncumbered => self.over_encumbered_speed_mult,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_max_carry_weight() {
        let atom = InventoryWeightAtom::new();
        assert_eq!(atom.calculate_max_carry_weight(10.0), 350.0);
        assert_eq!(atom.calculate_max_carry_weight(0.0), 300.0);
    }

    #[test]
    fn test_encumbrance_state() {
        let mut atom = InventoryWeightAtom::new();
        atom.encumbrance_threshold = 0.8; // Set to 80% for testing
        
        let max_weight = 100.0;
        
        assert_eq!(atom.get_encumbrance_state(50.0, max_weight), EncumbranceState::Normal);
        assert_eq!(atom.get_encumbrance_state(85.0, max_weight), EncumbranceState::Encumbered);
        assert_eq!(atom.get_encumbrance_state(110.0, max_weight), EncumbranceState::OverEncumbered);
    }
    
    #[test]
    fn test_speed_multiplier() {
        let mut atom = InventoryWeightAtom::new();
        atom.encumbered_speed_mult = 0.5;
        atom.over_encumbered_speed_mult = 0.0;
        
        assert_eq!(atom.get_speed_multiplier(&EncumbranceState::Normal), 1.0);
        assert_eq!(atom.get_speed_multiplier(&EncumbranceState::Encumbered), 0.5);
        assert_eq!(atom.get_speed_multiplier(&EncumbranceState::OverEncumbered), 0.0);
    }
}
