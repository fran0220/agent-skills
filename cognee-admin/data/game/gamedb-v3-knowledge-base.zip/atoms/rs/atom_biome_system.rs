#[derive(Debug, Clone, PartialEq)]
pub struct BiomeSystem {
    pub temperature: f32,
    pub humidity: f32,
    pub elevation: f32,
    pub spawn_rate_multiplier: f32,
    pub resource_density: f32,
}

impl BiomeSystem {
    pub fn new() -> Self {
        Self {
            temperature: 0.5,
            humidity: 0.5,
            elevation: 64.0,
            spawn_rate_multiplier: 1.0,
            resource_density: 0.1,
        }
    }

    /// Determines the biome type based on temperature and humidity.
    /// Simplified logic for demonstration.
    pub fn determine_biome_type(&self) -> &'static str {
        if self.temperature > 1.5 && self.humidity < 0.2 {
            "Desert"
        } else if self.temperature > 1.0 && self.humidity > 0.7 {
            "Jungle"
        } else if self.temperature < 0.0 {
            "Snowy Taiga"
        } else {
            "Plains"
        }
    }

    /// Calculates the effective spawn rate based on the base multiplier and elevation.
    /// Higher elevation might slightly reduce spawn rates.
    pub fn calculate_effective_spawn_rate(&self) -> f32 {
        let elevation_factor = if self.elevation > 128.0 {
            1.0 - ((self.elevation - 128.0) / 192.0).clamp(0.0, 0.5)
        } else {
            1.0
        };
        self.spawn_rate_multiplier * elevation_factor
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_determine_biome_type() {
        let mut biome = BiomeSystem::new();
        
        biome.temperature = 2.0;
        biome.humidity = 0.0;
        assert_eq!(biome.determine_biome_type(), "Desert");

        biome.temperature = -0.5;
        biome.humidity = 0.5;
        assert_eq!(biome.determine_biome_type(), "Snowy Taiga");
    }

    #[test]
    fn test_calculate_effective_spawn_rate() {
        let mut biome = BiomeSystem::new();
        biome.spawn_rate_multiplier = 2.0;
        biome.elevation = 64.0;
        
        // Elevation <= 128.0, factor is 1.0
        assert_eq!(biome.calculate_effective_spawn_rate(), 2.0);

        biome.elevation = 224.0; // (224 - 128) / 192 = 96 / 192 = 0.5
        // factor is 1.0 - 0.5 = 0.5
        assert_eq!(biome.calculate_effective_spawn_rate(), 1.0);
    }
}
