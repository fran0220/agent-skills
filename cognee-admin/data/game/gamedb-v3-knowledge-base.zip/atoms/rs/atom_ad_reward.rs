#[derive(Debug, Clone)]
pub struct AdRewardParams {
    pub ad_duration: f32,
    pub reward_multiplier: f32,
    pub cooldown_time: f32,
    pub daily_limit: u32,
}

impl AdRewardParams {
    pub fn new() -> Self {
        Self {
            ad_duration: 30.0,
            reward_multiplier: 2.0,
            cooldown_time: 300.0,
            daily_limit: 5,
        }
    }
}

#[derive(Debug, Clone)]
pub struct AdRewardState {
    pub ads_watched_today: u32,
    pub last_ad_time: f32, // in seconds since some epoch
}

impl AdRewardState {
    pub fn new() -> Self {
        Self {
            ads_watched_today: 0,
            last_ad_time: -10000.0, // A long time ago
        }
    }
}

pub struct AdRewardSystem {
    pub params: AdRewardParams,
    pub state: AdRewardState,
}

impl AdRewardSystem {
    pub fn new(params: AdRewardParams) -> Self {
        Self {
            params,
            state: AdRewardState::new(),
        }
    }

    /// Checks if an ad can be offered to the player right now.
    pub fn can_offer_ad(&self, current_time: f32) -> bool {
        if self.state.ads_watched_today >= self.params.daily_limit {
            return false;
        }
        if current_time - self.state.last_ad_time < self.params.cooldown_time {
            return false;
        }
        true
    }

    /// Processes the completion of an ad and returns the multiplier to apply to the reward.
    /// Returns None if the ad could not be watched (e.g., limit reached).
    pub fn watch_ad(&mut self, current_time: f32) -> Option<f32> {
        if !self.can_offer_ad(current_time) {
            return None;
        }

        self.state.ads_watched_today += 1;
        self.state.last_ad_time = current_time;

        Some(self.params.reward_multiplier)
    }
    
    /// Resets the daily limit (e.g., at midnight).
    pub fn reset_daily_limit(&mut self) {
        self.state.ads_watched_today = 0;
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_can_offer_ad() {
        let params = AdRewardParams::new();
        let mut system = AdRewardSystem::new(params);
        
        // Initially, can offer ad
        assert!(system.can_offer_ad(0.0));
        
        // Watch an ad
        let multiplier = system.watch_ad(0.0);
        assert_eq!(multiplier, Some(2.0));
        
        // Cannot offer immediately due to cooldown
        assert!(!system.can_offer_ad(100.0));
        
        // Can offer after cooldown
        assert!(system.can_offer_ad(301.0));
    }

    #[test]
    fn test_daily_limit() {
        let params = AdRewardParams::new();
        let mut system = AdRewardSystem::new(params);
        
        // Watch 5 ads (daily limit)
        for i in 0..5 {
            let time = (i as f32) * 400.0; // Ensure cooldown is passed
            assert!(system.can_offer_ad(time));
            assert!(system.watch_ad(time).is_some());
        }
        
        // 6th ad should be rejected
        let time = 5.0 * 400.0;
        assert!(!system.can_offer_ad(time));
        assert!(system.watch_ad(time).is_none());
        
        // Reset daily limit
        system.reset_daily_limit();
        assert!(system.can_offer_ad(time));
    }
}
