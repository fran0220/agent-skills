#[derive(Debug, Clone, Copy)]
pub struct FlankingBonusParams {
    pub flank_angle_threshold: f32,
    pub accuracy_bonus: f32,
    pub critical_chance_bonus: f32,
    pub damage_multiplier: f32,
    pub ignores_cover: bool,
}

impl FlankingBonusParams {
    /// Creates a new FlankingBonusParams with default values based on benchmark data.
    pub fn new() -> Self {
        Self {
            flank_angle_threshold: 120.0, // Divinity: Original Sin 2 v3.6
            accuracy_bonus: 0.4,          // XCOM 2 v1.0
            critical_chance_bonus: 0.33,  // XCOM: Enemy Unknown v1.0
            damage_multiplier: 1.5,       // Divinity: Original Sin 2 v3.6
            ignores_cover: true,          // XCOM 2 v1.0
        }
    }

    /// Calculates if an attack is considered flanking based on the angle between the attacker and the target's facing direction.
    /// `angle_to_target` is the angle in degrees between the target's facing direction and the attacker's position.
    /// 180 degrees means directly behind the target.
    pub fn is_flanking(&self, angle_to_target: f32) -> bool {
        // If the angle is within the threshold (e.g., 180 +/- (120/2) = 120 to 240 degrees)
        // For simplicity, let's assume angle_to_target is the absolute difference from the target's facing direction.
        // So 180 is directly behind. The threshold defines the arc behind the target.
        let half_threshold = self.flank_angle_threshold / 2.0;
        let angle_diff = (180.0 - angle_to_target).abs();
        angle_diff <= half_threshold
    }

    /// Applies the flanking bonuses to the base attack stats if the attack is flanking.
    pub fn apply_bonuses(
        &self,
        is_flanking: bool,
        base_accuracy: f32,
        base_crit_chance: f32,
        base_damage: f32,
    ) -> (f32, f32, f32) {
        if is_flanking {
            let final_accuracy = (base_accuracy + self.accuracy_bonus).clamp(0.0, 1.0);
            let final_crit_chance = (base_crit_chance + self.critical_chance_bonus).clamp(0.0, 1.0);
            let final_damage = base_damage * self.damage_multiplier;
            (final_accuracy, final_crit_chance, final_damage)
        } else {
            (base_accuracy, base_crit_chance, base_damage)
        }
    }
}

impl Default for FlankingBonusParams {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_is_flanking() {
        let params = FlankingBonusParams::new();
        
        // Directly behind (180 degrees)
        assert!(params.is_flanking(180.0));
        
        // Within threshold (e.g., 130 degrees, diff is 50 <= 60)
        assert!(params.is_flanking(130.0));
        
        // Outside threshold (e.g., 90 degrees, diff is 90 > 60)
        assert!(!params.is_flanking(90.0));
    }

    #[test]
    fn test_apply_bonuses() {
        let params = FlankingBonusParams::new();
        
        let base_acc = 0.5;
        let base_crit = 0.1;
        let base_dmg = 10.0;
        
        // Test with flanking
        let (acc, crit, dmg) = params.apply_bonuses(true, base_acc, base_crit, base_dmg);
        assert_eq!(acc, 0.9); // 0.5 + 0.4
        assert_eq!(crit, 0.43); // 0.1 + 0.33
        assert_eq!(dmg, 15.0); // 10.0 * 1.5
        
        // Test without flanking
        let (acc2, crit2, dmg2) = params.apply_bonuses(false, base_acc, base_crit, base_dmg);
        assert_eq!(acc2, 0.5);
        assert_eq!(crit2, 0.1);
        assert_eq!(dmg2, 10.0);
    }
}
