#[derive(Debug, Clone, Copy)]
pub struct CornerCorrectionParams {
    pub correction_distance_x: f32,
    pub correction_distance_y: f32,
    pub velocity_threshold: f32,
}

impl CornerCorrectionParams {
    /// Creates a new CornerCorrectionParams with default values based on Celeste v1.4 benchmark.
    pub fn new() -> Self {
        Self {
            correction_distance_x: 4.0,
            correction_distance_y: 4.0,
            velocity_threshold: 0.0,
        }
    }
}

impl Default for CornerCorrectionParams {
    fn default() -> Self {
        Self::new()
    }
}

/// Represents a 2D bounding box
#[derive(Debug, Clone, Copy)]
pub struct BoundingBox {
    pub x: f32,
    pub y: f32,
    pub width: f32,
    pub height: f32,
}

impl BoundingBox {
    pub fn intersects(&self, other: &BoundingBox) -> bool {
        self.x < other.x + other.width &&
        self.x + self.width > other.x &&
        self.y < other.y + other.height &&
        self.y + self.height > other.y
    }
}

/// Calculates the corrected position if a corner collision is detected.
/// Returns Some(new_position) if correction is applied, None otherwise.
pub fn calculate_corner_correction(
    player_box: &BoundingBox,
    player_velocity_y: f32,
    obstacle_box: &BoundingBox,
    params: &CornerCorrectionParams,
) -> Option<(f32, f32)> {
    // Only apply correction if moving upwards (e.g., jumping into a ceiling corner)
    if player_velocity_y >= params.velocity_threshold {
        return None;
    }

    if !player_box.intersects(obstacle_box) {
        return None;
    }

    // Calculate overlap
    let overlap_left = (player_box.x + player_box.width) - obstacle_box.x;
    let overlap_right = (obstacle_box.x + obstacle_box.width) - player_box.x;
    
    // Check if it's a left corner or right corner collision
    if overlap_left > 0.0 && overlap_left <= params.correction_distance_x {
        // Shift left to clear the obstacle
        return Some((player_box.x - overlap_left, player_box.y));
    } else if overlap_right > 0.0 && overlap_right <= params.correction_distance_x {
        // Shift right to clear the obstacle
        return Some((player_box.x + overlap_right, player_box.y));
    }

    None
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_corner_correction_left_shift() {
        let params = CornerCorrectionParams::new();
        let player = BoundingBox { x: 10.0, y: 20.0, width: 10.0, height: 10.0 };
        let obstacle = BoundingBox { x: 18.0, y: 15.0, width: 20.0, height: 10.0 };
        
        // Moving up (negative Y velocity in many 2D engines, let's say -10.0)
        let result = calculate_corner_correction(&player, -10.0, &obstacle, &params);
        
        assert!(result.is_some());
        let (new_x, new_y) = result.unwrap();
        // Overlap is (10 + 10) - 18 = 2.0. Shift left by 2.0 -> new x = 8.0
        assert_eq!(new_x, 8.0);
        assert_eq!(new_y, 20.0);
    }

    #[test]
    fn test_corner_correction_no_shift_due_to_large_overlap() {
        let params = CornerCorrectionParams::new();
        let player = BoundingBox { x: 10.0, y: 20.0, width: 10.0, height: 10.0 };
        let obstacle = BoundingBox { x: 12.0, y: 15.0, width: 20.0, height: 10.0 };
        
        // Overlap is (10 + 10) - 12 = 8.0, which is > correction_distance_x (4.0)
        let result = calculate_corner_correction(&player, -10.0, &obstacle, &params);
        
        assert!(result.is_none());
    }
    
    #[test]
    fn test_corner_correction_no_shift_due_to_velocity() {
        let params = CornerCorrectionParams::new();
        let player = BoundingBox { x: 10.0, y: 20.0, width: 10.0, height: 10.0 };
        let obstacle = BoundingBox { x: 18.0, y: 15.0, width: 20.0, height: 10.0 };
        
        // Moving down (positive Y velocity, e.g., 10.0)
        let result = calculate_corner_correction(&player, 10.0, &obstacle, &params);
        
        assert!(result.is_none());
    }
}
