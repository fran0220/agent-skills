#[derive(Debug, Clone, PartialEq)]
pub struct EscapeRoomParams {
    pub time_limit: f32,
    pub puzzle_count: u32,
    pub hint_cooldown: f32,
}

impl EscapeRoomParams {
    /// Creates a new EscapeRoomParams with default values based on benchmark data.
    pub fn new() -> Self {
        Self {
            time_limit: 3600.0, // Default from Zero Escape: Virtue's Last Reward
            puzzle_count: 5,    // Default from The Room
            hint_cooldown: 60.0, // Default from The Room
        }
    }

    /// Calculates the remaining time given the elapsed time.
    /// Returns 0.0 if the time limit has been exceeded.
    pub fn calculate_remaining_time(&self, elapsed_time: f32) -> f32 {
        if elapsed_time >= self.time_limit {
            0.0
        } else {
            self.time_limit - elapsed_time
        }
    }

    /// Checks if a hint is available based on the time since the last hint.
    pub fn is_hint_available(&self, last_hint_time: f32, current_time: f32) -> bool {
        if current_time < last_hint_time {
            return false; // Invalid time progression
        }
        (current_time - last_hint_time) >= self.hint_cooldown
    }

    /// Checks if the escape room is successfully completed.
    pub fn is_escaped(&self, solved_puzzles: u32) -> bool {
        solved_puzzles >= self.puzzle_count
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_remaining_time() {
        let params = EscapeRoomParams::new();
        
        // Normal case
        assert_eq!(params.calculate_remaining_time(600.0), 3000.0);
        
        // Time exceeded
        assert_eq!(params.calculate_remaining_time(4000.0), 0.0);
        
        // Exactly at time limit
        assert_eq!(params.calculate_remaining_time(3600.0), 0.0);
    }

    #[test]
    fn test_is_hint_available() {
        let params = EscapeRoomParams::new();
        
        // Hint available
        assert!(params.is_hint_available(100.0, 160.0));
        assert!(params.is_hint_available(100.0, 200.0));
        
        // Hint not available yet
        assert!(!params.is_hint_available(100.0, 159.9));
        
        // Invalid time
        assert!(!params.is_hint_available(200.0, 100.0));
    }

    #[test]
    fn test_is_escaped() {
        let params = EscapeRoomParams::new();
        
        // Not escaped
        assert!(!params.is_escaped(0));
        assert!(!params.is_escaped(4));
        
        // Escaped
        assert!(params.is_escaped(5));
        assert!(params.is_escaped(6));
    }
}
