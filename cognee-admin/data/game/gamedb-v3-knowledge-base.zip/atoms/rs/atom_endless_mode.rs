#[derive(Debug, Clone, Copy)]
pub struct EndlessModeParams {
    pub base_speed: f32,
    pub speed_multiplier: f32,
    pub max_speed: f32,
    pub spawn_rate_base: f32,
    pub difficulty_curve_exponent: f32,
}

impl EndlessModeParams {
    /// Creates a new EndlessModeParams with default values based on benchmark data.
    pub fn new() -> Self {
        Self {
            base_speed: 10.0,
            speed_multiplier: 1.05,
            max_speed: 50.0,
            spawn_rate_base: 2.0,
            difficulty_curve_exponent: 1.2,
        }
    }

    /// Calculates the current speed based on the elapsed time (in minutes).
    /// The speed increases exponentially but is capped at max_speed.
    pub fn calculate_current_speed(&self, elapsed_minutes: f32) -> f32 {
        let current_speed = self.base_speed * self.speed_multiplier.powf(elapsed_minutes);
        if current_speed > self.max_speed {
            self.max_speed
        } else {
            current_speed
        }
    }

    /// Calculates the current spawn rate based on the elapsed time (in minutes).
    /// The spawn rate increases based on the difficulty curve exponent.
    pub fn calculate_spawn_rate(&self, elapsed_minutes: f32) -> f32 {
        // A simple formula to increase spawn rate over time
        self.spawn_rate_base * (1.0 + elapsed_minutes).powf(self.difficulty_curve_exponent)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_current_speed() {
        let params = EndlessModeParams::new();
        
        // At 0 minutes, speed should be base_speed
        assert_eq!(params.calculate_current_speed(0.0), 10.0);
        
        // At 1 minute, speed should be base_speed * speed_multiplier
        assert_eq!(params.calculate_current_speed(1.0), 10.5);
        
        // At 100 minutes, speed should be capped at max_speed
        assert_eq!(params.calculate_current_speed(100.0), 50.0);
    }

    #[test]
    fn test_calculate_spawn_rate() {
        let params = EndlessModeParams::new();
        
        // At 0 minutes, spawn rate should be spawn_rate_base
        assert_eq!(params.calculate_spawn_rate(0.0), 2.0);
        
        // At 1 minute, spawn rate should be 2.0 * (2.0)^1.2
        let expected_rate = 2.0 * 2.0_f32.powf(1.2);
        assert!((params.calculate_spawn_rate(1.0) - expected_rate).abs() < 1e-5);
    }
}
