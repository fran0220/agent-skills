#[derive(Debug, Clone, PartialEq)]
pub enum VisibilityState {
    Unexplored,
    Revealed,
    Explored,
}

#[derive(Debug, Clone)]
pub struct FogOfWarParams {
    pub vision_radius: f32,
    pub reveal_delay: f32,
    pub fog_fade_time: f32,
    pub high_ground_advantage: bool,
    pub x_ray_vision: bool,
}

impl FogOfWarParams {
    /// Creates a new FogOfWarParams with default values based on StarCraft II benchmarks.
    pub fn new() -> Self {
        Self {
            vision_radius: 9.0,
            reveal_delay: 0.0,
            fog_fade_time: 0.5,
            high_ground_advantage: true,
            x_ray_vision: false,
        }
    }

    /// Calculates if a target point is within vision range of a unit.
    /// Does not account for complex terrain blocking in this simple formula.
    pub fn is_in_vision_range(&self, unit_x: f32, unit_y: f32, target_x: f32, target_y: f32) -> bool {
        let dx = target_x - unit_x;
        let dy = target_y - unit_y;
        let distance_squared = dx * dx + dy * dy;
        distance_squared <= self.vision_radius * self.vision_radius
    }

    /// Determines the new visibility state of a cell based on unit presence and time since last seen.
    pub fn update_visibility_state(
        &self,
        current_state: VisibilityState,
        is_in_vision: bool,
        time_since_seen: f32,
    ) -> VisibilityState {
        if is_in_vision {
            VisibilityState::Revealed
        } else {
            match current_state {
                VisibilityState::Unexplored => VisibilityState::Unexplored,
                VisibilityState::Revealed => {
                    if time_since_seen >= self.fog_fade_time {
                        VisibilityState::Explored
                    } else {
                        VisibilityState::Revealed
                    }
                }
                VisibilityState::Explored => VisibilityState::Explored,
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_is_in_vision_range() {
        let params = FogOfWarParams::new();
        
        // Target exactly at vision radius (9.0)
        assert!(params.is_in_vision_range(0.0, 0.0, 9.0, 0.0));
        
        // Target inside vision radius
        assert!(params.is_in_vision_range(0.0, 0.0, 5.0, 5.0));
        
        // Target outside vision radius
        assert!(!params.is_in_vision_range(0.0, 0.0, 10.0, 0.0));
    }

    #[test]
    fn test_update_visibility_state() {
        let params = FogOfWarParams::new();
        
        // Unexplored -> Revealed
        assert_eq!(
            params.update_visibility_state(VisibilityState::Unexplored, true, 0.0),
            VisibilityState::Revealed
        );
        
        // Revealed -> Revealed (still in vision)
        assert_eq!(
            params.update_visibility_state(VisibilityState::Revealed, true, 0.0),
            VisibilityState::Revealed
        );
        
        // Revealed -> Revealed (out of vision, but fade time not reached)
        assert_eq!(
            params.update_visibility_state(VisibilityState::Revealed, false, 0.2),
            VisibilityState::Revealed
        );
        
        // Revealed -> Explored (out of vision, fade time reached)
        assert_eq!(
            params.update_visibility_state(VisibilityState::Revealed, false, 0.6),
            VisibilityState::Explored
        );
        
        // Explored -> Revealed (back in vision)
        assert_eq!(
            params.update_visibility_state(VisibilityState::Explored, true, 0.0),
            VisibilityState::Revealed
        );
    }
}
