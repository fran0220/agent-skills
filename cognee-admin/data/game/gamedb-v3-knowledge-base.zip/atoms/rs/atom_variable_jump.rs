#[derive(Debug, Clone, Copy)]
pub struct VariableJumpParams {
    pub initial_jump_velocity: f32,
    pub gravity_normal: f32,
    pub gravity_half: f32,
    pub max_jump_hold_time: f32,
    pub early_release_multiplier: f32,
}

impl VariableJumpParams {
    /// Creates a new VariableJumpParams with default values based on Celeste v1.4 benchmark.
    pub fn new() -> Self {
        Self {
            initial_jump_velocity: 105.0,
            gravity_normal: 900.0,
            gravity_half: 450.0,
            max_jump_hold_time: 0.2,
            early_release_multiplier: 0.5,
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub enum JumpState {
    Grounded,
    JumpingRising,
    JumpingFalling,
}

#[derive(Debug, Clone)]
pub struct VariableJumpState {
    pub state: JumpState,
    pub velocity_y: f32,
    pub jump_hold_timer: f32,
}

impl VariableJumpState {
    pub fn new() -> Self {
        Self {
            state: JumpState::Grounded,
            velocity_y: 0.0,
            jump_hold_timer: 0.0,
        }
    }

    /// Initiates a jump, applying the initial velocity.
    pub fn start_jump(&mut self, params: &VariableJumpParams) {
        if self.state == JumpState::Grounded {
            self.state = JumpState::JumpingRising;
            self.velocity_y = params.initial_jump_velocity;
            self.jump_hold_timer = 0.0;
        }
    }

    /// Updates the jump state based on input and delta time.
    /// Returns the new velocity_y.
    pub fn update(&mut self, params: &VariableJumpParams, dt: f32, jump_held: bool) -> f32 {
        match self.state {
            JumpState::Grounded => {
                self.velocity_y = 0.0;
            }
            JumpState::JumpingRising => {
                self.jump_hold_timer += dt;

                if !jump_held {
                    // Early release
                    self.velocity_y *= params.early_release_multiplier;
                    self.state = JumpState::JumpingFalling;
                } else if self.jump_hold_timer >= params.max_jump_hold_time {
                    // Reached max hold time
                    self.state = JumpState::JumpingFalling;
                } else {
                    // Still rising, apply half gravity for floatier jump
                    self.velocity_y -= params.gravity_half * dt;
                    if self.velocity_y <= 0.0 {
                        self.state = JumpState::JumpingFalling;
                    }
                }
            }
            JumpState::JumpingFalling => {
                // Apply normal gravity
                self.velocity_y -= params.gravity_normal * dt;
            }
        }
        self.velocity_y
    }

    /// Simulates landing on the ground.
    pub fn land(&mut self) {
        self.state = JumpState::Grounded;
        self.velocity_y = 0.0;
        self.jump_hold_timer = 0.0;
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_initial_jump() {
        let params = VariableJumpParams::new();
        let mut state = VariableJumpState::new();
        
        state.start_jump(&params);
        
        assert_eq!(state.state, JumpState::JumpingRising);
        assert_eq!(state.velocity_y, params.initial_jump_velocity);
    }

    #[test]
    fn test_early_release() {
        let params = VariableJumpParams::new();
        let mut state = VariableJumpState::new();
        
        state.start_jump(&params);
        
        // Simulate 1 frame of holding jump
        let dt = 0.016;
        state.update(&params, dt, true);
        
        let velocity_before_release = state.velocity_y;
        
        // Simulate early release
        state.update(&params, dt, false);
        
        assert_eq!(state.state, JumpState::JumpingFalling);
        assert_eq!(state.velocity_y, velocity_before_release * params.early_release_multiplier);
    }

    #[test]
    fn test_max_hold_time() {
        let params = VariableJumpParams::new();
        let mut state = VariableJumpState::new();
        
        state.start_jump(&params);
        
        // Simulate holding jump past max time
        let dt = params.max_jump_hold_time + 0.01;
        state.update(&params, dt, true);
        
        assert_eq!(state.state, JumpState::JumpingFalling);
    }
}
