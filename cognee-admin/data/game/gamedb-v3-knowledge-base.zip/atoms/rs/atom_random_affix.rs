#[derive(Debug, Clone)]
pub struct RandomAffixParams {
    pub affix_count: u32,
    pub weight: u32,
    pub value_range: f32,
    pub tier_count: u32,
}

impl RandomAffixParams {
    pub fn new() -> Self {
        Self {
            affix_count: 4,
            weight: 100,
            value_range: 5.0,
            tier_count: 6,
        }
    }

    /// Calculates the probability of rolling a specific tier given its weight and the total weight of all available tiers.
    pub fn calculate_tier_probability(&self, tier_weight: u32, total_weight: u32) -> f32 {
        if total_weight == 0 {
            return 0.0;
        }
        (tier_weight as f32) / (total_weight as f32)
    }

    /// Simulates rolling a value within a specific tier's range.
    /// In a real implementation, this would use a random number generator.
    /// Here we just return a deterministic value based on a normalized 'roll' (0.0 to 1.0).
    pub fn roll_value_in_tier(&self, min_val: f32, max_val: f32, roll: f32) -> f32 {
        let clamped_roll = roll.clamp(0.0, 1.0);
        min_val + (max_val - min_val) * clamped_roll
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_tier_probability() {
        let params = RandomAffixParams::new();
        let prob = params.calculate_tier_probability(100, 1000);
        assert_eq!(prob, 0.1);

        let prob_zero = params.calculate_tier_probability(100, 0);
        assert_eq!(prob_zero, 0.0);
    }

    #[test]
    fn test_roll_value_in_tier() {
        let params = RandomAffixParams::new();
        
        // Min roll
        let val_min = params.roll_value_in_tier(8.0, 10.0, 0.0);
        assert_eq!(val_min, 8.0);

        // Max roll
        let val_max = params.roll_value_in_tier(8.0, 10.0, 1.0);
        assert_eq!(val_max, 10.0);

        // Mid roll
        let val_mid = params.roll_value_in_tier(8.0, 10.0, 0.5);
        assert_eq!(val_mid, 9.0);
        
        // Out of bounds roll (should be clamped)
        let val_out = params.roll_value_in_tier(8.0, 10.0, 1.5);
        assert_eq!(val_out, 10.0);
    }
}
