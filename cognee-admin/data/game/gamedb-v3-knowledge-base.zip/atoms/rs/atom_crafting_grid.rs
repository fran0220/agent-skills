pub struct CraftingGridParams {
    pub grid_width: u32,
    pub grid_height: u32,
    pub shapeless_support: bool,
    pub craft_time: f32,
}

impl CraftingGridParams {
    pub fn new() -> Self {
        Self {
            grid_width: 3,
            grid_height: 3,
            shapeless_support: true,
            craft_time: 0.0,
        }
    }

    pub fn is_valid_grid_size(&self, width: u32, height: u32) -> bool {
        width <= self.grid_width && height <= self.grid_height
    }

    pub fn calculate_total_slots(&self) -> u32 {
        self.grid_width * self.grid_height
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_default_params() {
        let params = CraftingGridParams::new();
        assert_eq!(params.grid_width, 3);
        assert_eq!(params.grid_height, 3);
        assert_eq!(params.shapeless_support, true);
        assert_eq!(params.craft_time, 0.0);
    }

    #[test]
    fn test_is_valid_grid_size() {
        let params = CraftingGridParams::new();
        assert!(params.is_valid_grid_size(2, 2));
        assert!(params.is_valid_grid_size(3, 3));
        assert!(!params.is_valid_grid_size(4, 3));
        assert!(!params.is_valid_grid_size(3, 4));
    }

    #[test]
    fn test_calculate_total_slots() {
        let params = CraftingGridParams::new();
        assert_eq!(params.calculate_total_slots(), 9);
    }
}
