#[derive(Debug, Clone, PartialEq)]
pub enum AffinityState {
    Hostile,
    Neutral,
    Friendly,
    Intimate,
    Rival,
}

#[derive(Debug, Clone)]
pub struct AffinityMeter {
    pub current_affinity: f32,
    pub max_affinity: f32,
    pub min_affinity: f32,
    pub gift_value_loved: f32,
    pub gift_value_liked: f32,
    pub decay_rate: f32,
    pub threshold_friendly: f32,
    pub threshold_intimate: f32,
    pub threshold_hostile: f32,
    pub threshold_rival: f32,
}

impl AffinityMeter {
    /// Creates a new AffinityMeter with default values based on Stardew Valley benchmarks.
    pub fn new() -> Self {
        Self {
            current_affinity: 0.0,
            max_affinity: 2500.0,
            min_affinity: -1000.0,
            gift_value_loved: 80.0,
            gift_value_liked: 45.0,
            decay_rate: 2.0,
            threshold_friendly: 1000.0,
            threshold_intimate: 2000.0,
            threshold_hostile: -500.0,
            threshold_rival: -1000.0,
        }
    }

    /// Adds affinity points, clamping to max_affinity.
    pub fn add_affinity(&mut self, points: f32) {
        self.current_affinity = (self.current_affinity + points).clamp(self.min_affinity, self.max_affinity);
    }

    /// Applies daily decay to the affinity meter.
    pub fn apply_decay(&mut self) {
        // Decay usually only applies to positive affinity or towards neutral
        if self.current_affinity > 0.0 {
            self.current_affinity = (self.current_affinity - self.decay_rate).max(0.0);
        }
    }

    /// Returns the current state based on affinity thresholds.
    pub fn get_state(&self) -> AffinityState {
        if self.current_affinity >= self.threshold_intimate {
            AffinityState::Intimate
        } else if self.current_affinity >= self.threshold_friendly {
            AffinityState::Friendly
        } else if self.current_affinity <= self.threshold_rival {
            AffinityState::Rival
        } else if self.current_affinity <= self.threshold_hostile {
            AffinityState::Hostile
        } else {
            AffinityState::Neutral
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_add_affinity_and_state() {
        let mut meter = AffinityMeter::new();
        assert_eq!(meter.get_state(), AffinityState::Neutral);

        meter.add_affinity(1500.0);
        assert_eq!(meter.current_affinity, 1500.0);
        assert_eq!(meter.get_state(), AffinityState::Friendly);

        meter.add_affinity(2000.0);
        assert_eq!(meter.current_affinity, 2500.0); // Clamped to max
        assert_eq!(meter.get_state(), AffinityState::Intimate);
    }

    #[test]
    fn test_decay_and_negative_affinity() {
        let mut meter = AffinityMeter::new();
        
        meter.add_affinity(10.0);
        meter.apply_decay();
        assert_eq!(meter.current_affinity, 8.0);

        meter.add_affinity(-600.0);
        assert_eq!(meter.current_affinity, -592.0);
        assert_eq!(meter.get_state(), AffinityState::Hostile);
        
        meter.add_affinity(-1000.0);
        assert_eq!(meter.current_affinity, -1000.0); // Clamped to min
        assert_eq!(meter.get_state(), AffinityState::Rival);
    }
}
