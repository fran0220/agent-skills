#[derive(Debug, Clone, PartialEq)]
pub struct ResourceGathering {
    pub gathering_time: f32,
    pub tool_multiplier: f32,
    pub node_health: f32,
    pub yield_amount: u32,
    pub respawn_time: f32,
}

impl ResourceGathering {
    /// Creates a new ResourceGathering instance with default benchmark values.
    pub fn new() -> Self {
        Self {
            gathering_time: 3.0,     // Minecraft 1.20 benchmark
            tool_multiplier: 2.0,    // Stardew Valley 1.5 benchmark
            node_health: 10.0,       // Rust benchmark
            yield_amount: 1,         // Minecraft 1.20 benchmark
            respawn_time: 86400.0,   // Stardew Valley 1.5 benchmark
        }
    }

    /// Calculates the actual time required to gather a resource, factoring in the tool multiplier.
    /// A higher tool multiplier reduces the gathering time.
    pub fn calculate_actual_gathering_time(&self) -> f32 {
        if self.tool_multiplier <= 0.0 {
            return f32::INFINITY;
        }
        self.gathering_time / self.tool_multiplier
    }

    /// Calculates the damage dealt to a resource node per hit.
    /// Assuming base damage is 1.0, multiplied by the tool multiplier.
    pub fn calculate_damage_per_hit(&self) -> f32 {
        1.0 * self.tool_multiplier
    }

    /// Calculates the number of hits required to deplete the resource node.
    pub fn calculate_hits_to_deplete(&self) -> u32 {
        let damage = self.calculate_damage_per_hit();
        if damage <= 0.0 {
            return u32::MAX;
        }
        (self.node_health / damage).ceil() as u32
    }
}

impl Default for ResourceGathering {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_actual_gathering_time() {
        let gathering = ResourceGathering {
            gathering_time: 10.0,
            tool_multiplier: 2.0,
            ..ResourceGathering::new()
        };
        assert_eq!(gathering.calculate_actual_gathering_time(), 5.0);
    }

    #[test]
    fn test_calculate_hits_to_deplete() {
        let gathering = ResourceGathering {
            node_health: 25.0,
            tool_multiplier: 2.0,
            ..ResourceGathering::new()
        };
        // Damage per hit = 2.0. Hits = ceil(25.0 / 2.0) = ceil(12.5) = 13
        assert_eq!(gathering.calculate_hits_to_deplete(), 13);
    }

    #[test]
    fn test_zero_tool_multiplier() {
        let gathering = ResourceGathering {
            gathering_time: 5.0,
            tool_multiplier: 0.0,
            ..ResourceGathering::new()
        };
        assert_eq!(gathering.calculate_actual_gathering_time(), f32::INFINITY);
        assert_eq!(gathering.calculate_hits_to_deplete(), u32::MAX);
    }
}
