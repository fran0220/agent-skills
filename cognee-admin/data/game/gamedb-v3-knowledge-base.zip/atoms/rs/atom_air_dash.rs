#[derive(Debug, Clone, PartialEq)]
pub struct AirDashParams {
    pub dash_speed: f32,
    pub dash_duration: f32,
    pub cooldown: f32,
    pub gravity_multiplier: f32,
    pub i_frames: f32,
}

impl AirDashParams {
    /// Creates a new AirDashParams with default values based on Celeste benchmark.
    pub fn new() -> Self {
        Self {
            dash_speed: 24.0,
            dash_duration: 0.15,
            cooldown: 0.0,
            gravity_multiplier: 0.0,
            i_frames: 0.0,
        }
    }
}

impl Default for AirDashParams {
    fn default() -> Self {
        Self::new()
    }
}

#[derive(Debug, Clone, PartialEq)]
pub struct AirDashState {
    pub is_dashing: bool,
    pub dash_time_remaining: f32,
    pub dashes_available: u32,
}

impl AirDashState {
    pub fn new(max_dashes: u32) -> Self {
        Self {
            is_dashing: false,
            dash_time_remaining: 0.0,
            dashes_available: max_dashes,
        }
    }

    /// Attempts to start a dash. Returns true if successful.
    pub fn start_dash(&mut self, params: &AirDashParams) -> bool {
        if self.dashes_available > 0 && !self.is_dashing {
            self.is_dashing = true;
            self.dash_time_remaining = params.dash_duration;
            self.dashes_available -= 1;
            true
        } else {
            false
        }
    }

    /// Updates the dash state over time. Returns the current velocity multiplier.
    pub fn update(&mut self, delta_time: f32, params: &AirDashParams) -> f32 {
        if !self.is_dashing {
            return 0.0;
        }

        self.dash_time_remaining -= delta_time;
        if self.dash_time_remaining <= 0.0 {
            self.is_dashing = false;
            self.dash_time_remaining = 0.0;
            0.0
        } else {
            params.dash_speed
        }
    }

    /// Resets the number of available dashes (e.g., when touching the ground).
    pub fn reset_dashes(&mut self, max_dashes: u32) {
        self.dashes_available = max_dashes;
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_start_dash() {
        let params = AirDashParams::new();
        let mut state = AirDashState::new(1);

        assert_eq!(state.dashes_available, 1);
        assert!(!state.is_dashing);

        let success = state.start_dash(&params);
        assert!(success);
        assert!(state.is_dashing);
        assert_eq!(state.dashes_available, 0);
        assert_eq!(state.dash_time_remaining, params.dash_duration);

        // Cannot dash again
        let success2 = state.start_dash(&params);
        assert!(!success2);
    }

    #[test]
    fn test_update_dash() {
        let params = AirDashParams::new();
        let mut state = AirDashState::new(1);

        state.start_dash(&params);
        
        // Update halfway through
        let speed = state.update(params.dash_duration / 2.0, &params);
        assert_eq!(speed, params.dash_speed);
        assert!(state.is_dashing);

        // Update past duration
        let speed2 = state.update(params.dash_duration, &params);
        assert_eq!(speed2, 0.0);
        assert!(!state.is_dashing);
    }

    #[test]
    fn test_reset_dashes() {
        let params = AirDashParams::new();
        let mut state = AirDashState::new(1);

        state.start_dash(&params);
        assert_eq!(state.dashes_available, 0);

        state.reset_dashes(1);
        assert_eq!(state.dashes_available, 1);
    }
}
