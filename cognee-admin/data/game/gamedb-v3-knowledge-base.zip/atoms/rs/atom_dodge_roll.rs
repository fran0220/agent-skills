#[derive(Debug, Clone, PartialEq)]
pub struct DodgeRoll {
    pub startup_frames: u32,
    pub active_frames: u32,
    pub recovery_frames: u32,
    pub distance: f32,
    pub stamina_cost: f32,
    pub cooldown: f32,
}

impl DodgeRoll {
    /// Creates a new DodgeRoll with default benchmark values (based on Dark Souls III fast roll).
    pub fn new() -> Self {
        Self {
            startup_frames: 0,
            active_frames: 13,
            recovery_frames: 21,
            distance: 4.5,
            stamina_cost: 15.0,
            cooldown: 0.0,
        }
    }

    /// Determines if the character is currently invulnerable based on the frame of the dodge animation.
    pub fn is_invulnerable(&self, current_frame: u32) -> bool {
        current_frame >= self.startup_frames 
            && current_frame < (self.startup_frames + self.active_frames)
    }

    /// Calculates the average velocity during the active frames of the dodge.
    /// Assumes the distance is covered entirely during the active frames.
    pub fn calculate_velocity(&self, fps: f32) -> f32 {
        if self.active_frames == 0 {
            return 0.0;
        }
        let active_duration_seconds = self.active_frames as f32 / fps;
        self.distance / active_duration_seconds
    }

    /// Checks if the character has enough stamina and the cooldown has elapsed to perform a dodge.
    pub fn can_dodge(&self, current_stamina: f32, time_since_last_dodge: f32) -> bool {
        current_stamina >= self.stamina_cost && time_since_last_dodge >= self.cooldown
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_invulnerability() {
        let dodge = DodgeRoll::new();
        
        // Startup frames (0 in default)
        // Active frames (0 to 12)
        assert!(dodge.is_invulnerable(0));
        assert!(dodge.is_invulnerable(5));
        assert!(dodge.is_invulnerable(12));
        
        // Recovery frames (13 onwards)
        assert!(!dodge.is_invulnerable(13));
        assert!(!dodge.is_invulnerable(20));
    }

    #[test]
    fn test_can_dodge() {
        let dodge = DodgeRoll::new();
        
        // Enough stamina, cooldown elapsed
        assert!(dodge.can_dodge(20.0, 1.0));
        
        // Not enough stamina
        assert!(!dodge.can_dodge(10.0, 1.0));
        
        // Cooldown not elapsed (if we had a cooldown)
        let mut dodge_with_cooldown = DodgeRoll::new();
        dodge_with_cooldown.cooldown = 2.0;
        assert!(!dodge_with_cooldown.can_dodge(20.0, 1.0));
        assert!(dodge_with_cooldown.can_dodge(20.0, 2.5));
    }

    #[test]
    fn test_calculate_velocity() {
        let dodge = DodgeRoll::new();
        let fps = 60.0;
        
        // distance = 4.5, active_frames = 13
        // duration = 13 / 60 = 0.2166...
        // velocity = 4.5 / 0.2166... = 20.769...
        let velocity = dodge.calculate_velocity(fps);
        assert!((velocity - 20.769).abs() < 0.01);
    }
}
