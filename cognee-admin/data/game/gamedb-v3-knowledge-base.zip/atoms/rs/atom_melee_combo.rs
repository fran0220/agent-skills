#[derive(Debug, Clone, PartialEq)]
pub struct MeleeComboParams {
    pub startup_frames: u32,
    pub active_frames: u32,
    pub recovery_frames: u32,
    pub combo_window_start: u32,
    pub combo_window_end: u32,
    pub damage_multiplier: f32,
}

impl MeleeComboParams {
    /// Creates a new MeleeComboParams with default values based on Devil May Cry 5 benchmark.
    pub fn new() -> Self {
        Self {
            startup_frames: 5,
            active_frames: 3,
            recovery_frames: 15,
            combo_window_start: 10,
            combo_window_end: 25,
            damage_multiplier: 1.2,
        }
    }

    /// Checks if an input received at a specific frame (relative to the start of recovery)
    /// falls within the valid combo window.
    pub fn is_input_in_combo_window(&self, frames_since_recovery_start: u32) -> bool {
        frames_since_recovery_start >= self.combo_window_start
            && frames_since_recovery_start <= self.combo_window_end
    }

    /// Calculates the damage for a specific hit in the combo chain.
    /// `base_damage` is the damage of the first hit.
    /// `combo_step` is the 0-indexed step in the combo (0 for first hit, 1 for second, etc.).
    pub fn calculate_combo_damage(&self, base_damage: f32, combo_step: u32) -> f32 {
        if combo_step == 0 {
            base_damage
        } else {
            base_damage * self.damage_multiplier.powi(combo_step as i32)
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_combo_window() {
        let params = MeleeComboParams::new();
        
        // Before window
        assert!(!params.is_input_in_combo_window(5));
        
        // Inside window
        assert!(params.is_input_in_combo_window(10));
        assert!(params.is_input_in_combo_window(15));
        assert!(params.is_input_in_combo_window(25));
        
        // After window
        assert!(!params.is_input_in_combo_window(26));
    }

    #[test]
    fn test_combo_damage_calculation() {
        let params = MeleeComboParams::new();
        let base_damage = 10.0;
        
        // First hit (step 0)
        assert_eq!(params.calculate_combo_damage(base_damage, 0), 10.0);
        
        // Second hit (step 1)
        assert_eq!(params.calculate_combo_damage(base_damage, 1), 12.0);
        
        // Third hit (step 2)
        assert_eq!(params.calculate_combo_damage(base_damage, 2), 14.4);
    }
}
