#[derive(Debug, Clone)]
pub struct AuctionHouseParams {
    pub listing_fee_percent: f32,
    pub transaction_tax_percent: f32,
    pub max_duration_hours: u32,
    pub max_listings_per_player: u32,
    pub bid_increment_percent: f32,
}

impl AuctionHouseParams {
    /// Creates a new AuctionHouseParams with default values based on WoW Classic benchmarks.
    pub fn new() -> Self {
        Self {
            listing_fee_percent: 0.05,
            transaction_tax_percent: 0.05,
            max_duration_hours: 48,
            max_listings_per_player: 50,
            bid_increment_percent: 0.05,
        }
    }

    /// Calculates the listing fee based on the item's vendor price.
    pub fn calculate_listing_fee(&self, vendor_price: f32) -> f32 {
        vendor_price * self.listing_fee_percent
    }

    /// Calculates the transaction tax taken from the final sale price.
    pub fn calculate_transaction_tax(&self, final_sale_price: f32) -> f32 {
        final_sale_price * self.transaction_tax_percent
    }

    /// Calculates the net payout to the seller after a successful auction.
    pub fn calculate_seller_payout(&self, final_sale_price: f32) -> f32 {
        let tax = self.calculate_transaction_tax(final_sale_price);
        final_sale_price - tax
    }

    /// Calculates the minimum required next bid given the current bid.
    pub fn calculate_min_next_bid(&self, current_bid: f32) -> f32 {
        current_bid * (1.0 + self.bid_increment_percent)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_listing_fee() {
        let params = AuctionHouseParams::new();
        let vendor_price = 100.0;
        let fee = params.calculate_listing_fee(vendor_price);
        assert_eq!(fee, 5.0);
    }

    #[test]
    fn test_calculate_seller_payout() {
        let params = AuctionHouseParams::new();
        let final_price = 1000.0;
        let payout = params.calculate_seller_payout(final_price);
        // 1000 - (1000 * 0.05) = 950
        assert_eq!(payout, 950.0);
    }

    #[test]
    fn test_calculate_min_next_bid() {
        let params = AuctionHouseParams::new();
        let current_bid = 100.0;
        let next_bid = params.calculate_min_next_bid(current_bid);
        // 100 * 1.05 = 105
        assert_eq!(next_bid, 105.0);
    }
}
