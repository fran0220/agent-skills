#[derive(Debug, Clone, PartialEq)]
pub struct NpcTradeParams {
    pub buy_price_multiplier: f32,
    pub sell_price_multiplier: f32,
    pub restock_time: u32,
    pub max_stock: u32,
    pub discount_rate: f32,
}

impl NpcTradeParams {
    /// Creates a new NpcTradeParams with default values based on Stardew Valley benchmarks.
    pub fn new() -> Self {
        Self {
            buy_price_multiplier: 2.0,
            sell_price_multiplier: 0.5,
            restock_time: 24,
            max_stock: 99,
            discount_rate: 0.0,
        }
    }

    /// Calculates the final buy price for an item given its base value.
    pub fn calculate_buy_price(&self, base_value: f32) -> f32 {
        let discounted_multiplier = self.buy_price_multiplier * (1.0 - self.discount_rate);
        (base_value * discounted_multiplier).max(0.0)
    }

    /// Calculates the final sell price for an item given its base value.
    pub fn calculate_sell_price(&self, base_value: f32) -> f32 {
        (base_value * self.sell_price_multiplier).max(0.0)
    }

    /// Checks if a transaction is valid based on player funds and item stock.
    pub fn can_afford(&self, player_funds: f32, base_value: f32, quantity: u32) -> bool {
        if quantity > self.max_stock {
            return false;
        }
        let total_cost = self.calculate_buy_price(base_value) * (quantity as f32);
        player_funds >= total_cost
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_buy_price() {
        let mut params = NpcTradeParams::new();
        // Default buy multiplier is 2.0, discount is 0.0
        assert_eq!(params.calculate_buy_price(100.0), 200.0);

        // Apply a 10% discount
        params.discount_rate = 0.1;
        assert_eq!(params.calculate_buy_price(100.0), 180.0);
    }

    #[test]
    fn test_calculate_sell_price() {
        let params = NpcTradeParams::new();
        // Default sell multiplier is 0.5
        assert_eq!(params.calculate_sell_price(100.0), 50.0);
    }

    #[test]
    fn test_can_afford() {
        let params = NpcTradeParams::new();
        // Base value 100, buy price 200. Quantity 2 costs 400.
        assert!(params.can_afford(500.0, 100.0, 2));
        assert!(!params.can_afford(300.0, 100.0, 2));
        
        // Exceeds max stock
        assert!(!params.can_afford(100000.0, 100.0, 100));
    }
}
