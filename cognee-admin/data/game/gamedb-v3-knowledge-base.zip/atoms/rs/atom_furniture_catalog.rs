#[derive(Debug, Clone)]
pub struct FurnitureCatalogParams {
    pub total_items: u32,
    pub order_limit_per_day: u32,
    pub delivery_delay: f32,
    pub completion_reward_threshold: f32,
}

impl FurnitureCatalogParams {
    /// Creates a new FurnitureCatalogParams with default values based on Animal Crossing: New Horizons benchmark.
    pub fn new() -> Self {
        Self {
            total_items: 1700,
            order_limit_per_day: 5,
            delivery_delay: 24.0,
            completion_reward_threshold: 1.0,
        }
    }

    /// Calculates the completion percentage of the catalog.
    pub fn calculate_completion_percentage(&self, collected_items: u32) -> f32 {
        if self.total_items == 0 {
            return 0.0;
        }
        let collected = collected_items.min(self.total_items);
        (collected as f32 / self.total_items as f32) * 100.0
    }

    /// Checks if the player can order another item today.
    pub fn can_order_item(&self, orders_today: u32) -> bool {
        orders_today < self.order_limit_per_day
    }

    /// Checks if the player is eligible for the completion reward.
    pub fn is_eligible_for_completion_reward(&self, collected_items: u32) -> bool {
        if self.total_items == 0 {
            return false;
        }
        let ratio = collected_items as f32 / self.total_items as f32;
        ratio >= self.completion_reward_threshold
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_completion_percentage() {
        let params = FurnitureCatalogParams::new();
        
        // 0 items collected
        assert_eq!(params.calculate_completion_percentage(0), 0.0);
        
        // Half items collected
        assert_eq!(params.calculate_completion_percentage(850), 50.0);
        
        // All items collected
        assert_eq!(params.calculate_completion_percentage(1700), 100.0);
        
        // More than total items collected (should cap at 100%)
        assert_eq!(params.calculate_completion_percentage(2000), 100.0);
    }

    #[test]
    fn test_can_order_item() {
        let params = FurnitureCatalogParams::new();
        
        // 0 orders today
        assert!(params.can_order_item(0));
        
        // 4 orders today
        assert!(params.can_order_item(4));
        
        // 5 orders today (limit reached)
        assert!(!params.can_order_item(5));
        
        // 6 orders today (over limit)
        assert!(!params.can_order_item(6));
    }

    #[test]
    fn test_is_eligible_for_completion_reward() {
        let mut params = FurnitureCatalogParams::new();
        
        // Default threshold is 1.0 (100%)
        assert!(!params.is_eligible_for_completion_reward(1699));
        assert!(params.is_eligible_for_completion_reward(1700));
        
        // Change threshold to 0.8 (80%)
        params.completion_reward_threshold = 0.8;
        assert!(!params.is_eligible_for_completion_reward(1359)); // 1359 / 1700 = 0.7994
        assert!(params.is_eligible_for_completion_reward(1360)); // 1360 / 1700 = 0.8
    }
}
