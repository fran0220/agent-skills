#[derive(Debug, Clone, Copy)]
pub struct ParryRiposteParams {
    pub startup_frames: u32,
    pub active_frames: u32,
    pub recovery_frames: u32,
    pub vulnerability_duration: f32,
    pub damage_multiplier: f32,
}

impl ParryRiposteParams {
    /// Creates a new ParryRiposteParams with default values based on Dark Souls III and Sekiro benchmarks.
    pub fn new() -> Self {
        Self {
            startup_frames: 4,
            active_frames: 6,
            recovery_frames: 20,
            vulnerability_duration: 2.5,
            damage_multiplier: 2.0,
        }
    }
}

impl Default for ParryRiposteParams {
    fn default() -> Self {
        Self::new()
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ParryState {
    Idle,
    Startup,
    Active,
    Recovery,
    Success,
    Riposte,
}

pub struct ParryRiposteSystem {
    pub params: ParryRiposteParams,
    pub current_state: ParryState,
    pub frame_counter: u32,
    pub vulnerability_timer: f32,
}

impl ParryRiposteSystem {
    pub fn new(params: ParryRiposteParams) -> Self {
        Self {
            params,
            current_state: ParryState::Idle,
            frame_counter: 0,
            vulnerability_timer: 0.0,
        }
    }

    /// Initiates a parry attempt.
    pub fn initiate_parry(&mut self) -> bool {
        if self.current_state == ParryState::Idle {
            self.current_state = ParryState::Startup;
            self.frame_counter = 0;
            true
        } else {
            false
        }
    }

    /// Updates the parry state machine by one frame.
    pub fn update(&mut self, delta_time: f32) {
        match self.current_state {
            ParryState::Startup => {
                self.frame_counter += 1;
                if self.frame_counter >= self.params.startup_frames {
                    self.current_state = ParryState::Active;
                    self.frame_counter = 0;
                }
            }
            ParryState::Active => {
                self.frame_counter += 1;
                if self.frame_counter >= self.params.active_frames {
                    self.current_state = ParryState::Recovery;
                    self.frame_counter = 0;
                }
            }
            ParryState::Recovery => {
                self.frame_counter += 1;
                if self.frame_counter >= self.params.recovery_frames {
                    self.current_state = ParryState::Idle;
                    self.frame_counter = 0;
                }
            }
            ParryState::Success => {
                self.vulnerability_timer -= delta_time;
                if self.vulnerability_timer <= 0.0 {
                    self.current_state = ParryState::Idle;
                }
            }
            ParryState::Riposte => {
                // Riposte animation logic would go here.
                // For simplicity, we just return to Idle after a set time or event.
                self.current_state = ParryState::Idle;
            }
            ParryState::Idle => {}
        }
    }

    /// Attempts to deflect an incoming attack.
    pub fn try_deflect(&mut self) -> bool {
        if self.current_state == ParryState::Active {
            self.current_state = ParryState::Success;
            self.vulnerability_timer = self.params.vulnerability_duration;
            true
        } else {
            false
        }
    }

    /// Calculates the damage of a riposte based on base damage.
    pub fn calculate_riposte_damage(&self, base_damage: f32) -> f32 {
        base_damage * self.params.damage_multiplier
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_parry_state_machine() {
        let params = ParryRiposteParams::new();
        let mut system = ParryRiposteSystem::new(params);

        assert_eq!(system.current_state, ParryState::Idle);

        // Initiate parry
        assert!(system.initiate_parry());
        assert_eq!(system.current_state, ParryState::Startup);

        // Update through startup frames
        for _ in 0..params.startup_frames {
            system.update(0.016);
        }
        assert_eq!(system.current_state, ParryState::Active);

        // Update through active frames
        for _ in 0..params.active_frames {
            system.update(0.016);
        }
        assert_eq!(system.current_state, ParryState::Recovery);

        // Update through recovery frames
        for _ in 0..params.recovery_frames {
            system.update(0.016);
        }
        assert_eq!(system.current_state, ParryState::Idle);
    }

    #[test]
    fn test_successful_deflect() {
        let params = ParryRiposteParams::new();
        let mut system = ParryRiposteSystem::new(params);

        system.initiate_parry();
        
        // Fast forward to active state
        for _ in 0..params.startup_frames {
            system.update(0.016);
        }
        assert_eq!(system.current_state, ParryState::Active);

        // Try deflect
        assert!(system.try_deflect());
        assert_eq!(system.current_state, ParryState::Success);
        assert_eq!(system.vulnerability_timer, params.vulnerability_duration);
    }

    #[test]
    fn test_riposte_damage() {
        let params = ParryRiposteParams::new();
        let system = ParryRiposteSystem::new(params);

        let base_damage = 100.0;
        let expected_damage = base_damage * params.damage_multiplier;
        assert_eq!(system.calculate_riposte_damage(base_damage), expected_damage);
    }
}
