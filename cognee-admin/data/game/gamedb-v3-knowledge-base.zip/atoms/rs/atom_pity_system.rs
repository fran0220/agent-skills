#[derive(Debug, Clone, Copy)]
pub struct PitySystem {
    pub base_probability: f32,
    pub hard_pity_threshold: u32,
    pub soft_pity_threshold: u32,
    pub soft_pity_increment: f32,
    pub fifty_fifty_chance: bool,
}

impl PitySystem {
    /// Creates a new PitySystem with default values based on Genshin Impact benchmark.
    pub fn new() -> Self {
        Self {
            base_probability: 0.006,
            hard_pity_threshold: 90,
            soft_pity_threshold: 74,
            soft_pity_increment: 0.06,
            fifty_fifty_chance: true,
        }
    }

    /// Calculates the probability of success for a given pull count.
    /// `pulls_since_last_success` is the number of pulls already made without success.
    /// The next pull will be `pulls_since_last_success + 1`.
    pub fn calculate_probability(&self, pulls_since_last_success: u32) -> f32 {
        let next_pull = pulls_since_last_success + 1;

        if next_pull >= self.hard_pity_threshold {
            return 1.0;
        }

        if next_pull >= self.soft_pity_threshold {
            let pulls_in_soft_pity = next_pull - self.soft_pity_threshold + 1;
            let boosted_prob = self.base_probability + (pulls_in_soft_pity as f32 * self.soft_pity_increment);
            return boosted_prob.min(1.0);
        }

        self.base_probability
    }

    /// Simulates a pull outcome given a random value between 0.0 and 1.0.
    /// Returns true if the pull is successful.
    pub fn simulate_pull(&self, pulls_since_last_success: u32, random_value: f32) -> bool {
        let probability = self.calculate_probability(pulls_since_last_success);
        random_value < probability
    }
}

impl Default for PitySystem {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_base_probability() {
        let pity = PitySystem::new();
        // Pulls 1 to 73 should have base probability
        assert_eq!(pity.calculate_probability(0), 0.006);
        assert_eq!(pity.calculate_probability(72), 0.006);
    }

    #[test]
    fn test_soft_pity_probability() {
        let pity = PitySystem::new();
        // Pull 74 (73 pulls since last success)
        let prob_74 = pity.calculate_probability(73);
        assert!((prob_74 - (0.006 + 0.06)).abs() < f32::EPSILON);

        // Pull 75
        let prob_75 = pity.calculate_probability(74);
        assert!((prob_75 - (0.006 + 0.12)).abs() < f32::EPSILON);
    }

    #[test]
    fn test_hard_pity_probability() {
        let pity = PitySystem::new();
        // Pull 90 should be 100%
        assert_eq!(pity.calculate_probability(89), 1.0);
        // Pull 91 should also be 100%
        assert_eq!(pity.calculate_probability(90), 1.0);
    }
}
