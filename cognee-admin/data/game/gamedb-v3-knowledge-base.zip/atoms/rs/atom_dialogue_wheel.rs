#[derive(Debug, Clone, PartialEq)]
pub struct DialogueWheelParams {
    pub options_count: u32,
    pub time_limit: f32,
    pub interrupt_window: f32,
}

impl DialogueWheelParams {
    /// Creates a new DialogueWheelParams with default values based on Mass Effect benchmark.
    pub fn new() -> Self {
        Self {
            options_count: 6,
            time_limit: 0.0,
            interrupt_window: 0.0,
        }
    }

    /// Calculates the angle (in degrees) for a given option index.
    /// Assumes options are evenly distributed around the wheel starting from the top (0 degrees).
    pub fn calculate_option_angle(&self, option_index: u32) -> Option<f32> {
        if option_index >= self.options_count || self.options_count == 0 {
            return None;
        }
        let angle_per_option = 360.0 / self.options_count as f32;
        Some(option_index as f32 * angle_per_option)
    }

    /// Checks if an interrupt is currently available based on the elapsed time in the listening state.
    pub fn is_interrupt_available(&self, elapsed_listening_time: f32) -> bool {
        if self.interrupt_window <= 0.0 {
            return false;
        }
        elapsed_listening_time <= self.interrupt_window
    }
    
    /// Checks if the dialogue wheel has timed out.
    pub fn has_timed_out(&self, elapsed_wheel_time: f32) -> bool {
        if self.time_limit <= 0.0 {
            return false; // No time limit
        }
        elapsed_wheel_time >= self.time_limit
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_option_angle() {
        let params = DialogueWheelParams::new(); // 6 options
        assert_eq!(params.calculate_option_angle(0), Some(0.0));
        assert_eq!(params.calculate_option_angle(1), Some(60.0));
        assert_eq!(params.calculate_option_angle(3), Some(180.0));
        assert_eq!(params.calculate_option_angle(6), None); // Out of bounds
    }

    #[test]
    fn test_is_interrupt_available() {
        let mut params = DialogueWheelParams::new();
        assert_eq!(params.is_interrupt_available(1.0), false); // Default interrupt_window is 0.0
        
        params.interrupt_window = 2.0;
        assert_eq!(params.is_interrupt_available(1.0), true);
        assert_eq!(params.is_interrupt_available(2.0), true);
        assert_eq!(params.is_interrupt_available(2.1), false);
    }
    
    #[test]
    fn test_has_timed_out() {
        let mut params = DialogueWheelParams::new();
        assert_eq!(params.has_timed_out(10.0), false); // Default time_limit is 0.0
        
        params.time_limit = 5.0;
        assert_eq!(params.has_timed_out(4.9), false);
        assert_eq!(params.has_timed_out(5.0), true);
        assert_eq!(params.has_timed_out(6.0), true);
    }
}
