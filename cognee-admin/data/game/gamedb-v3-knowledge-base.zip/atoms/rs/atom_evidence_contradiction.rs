#[derive(Debug, Clone)]
pub struct EvidenceContradiction {
    pub penalty_damage: u32,
    pub max_health: u32,
    pub time_limit: f32,
}

impl EvidenceContradiction {
    pub fn new() -> Self {
        Self {
            penalty_damage: 20,
            max_health: 100,
            time_limit: 0.0,
        }
    }

    pub fn evaluate_evidence(&self, presented_evidence_id: &str, expected_evidence_id: &str, current_health: u32) -> Result<u32, u32> {
        if presented_evidence_id == expected_evidence_id {
            Ok(current_health)
        } else {
            Err(current_health.saturating_sub(self.penalty_damage))
        }
    }

    pub fn check_time_limit(&self, elapsed_time: f32) -> bool {
        if self.time_limit <= 0.0 {
            true // No time limit
        } else {
            elapsed_time <= self.time_limit
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_evaluate_evidence_match() {
        let atom = EvidenceContradiction::new();
        let result = atom.evaluate_evidence("autopsy_report", "autopsy_report", 100);
        assert_eq!(result, Ok(100));
    }

    #[test]
    fn test_evaluate_evidence_mismatch() {
        let atom = EvidenceContradiction::new();
        let result = atom.evaluate_evidence("attorney_badge", "autopsy_report", 100);
        assert_eq!(result, Err(80));
    }

    #[test]
    fn test_evaluate_evidence_mismatch_fatal() {
        let atom = EvidenceContradiction::new();
        let result = atom.evaluate_evidence("attorney_badge", "autopsy_report", 10);
        assert_eq!(result, Err(0));
    }

    #[test]
    fn test_check_time_limit() {
        let mut atom = EvidenceContradiction::new();
        assert_eq!(atom.check_time_limit(100.0), true); // No time limit

        atom.time_limit = 300.0;
        assert_eq!(atom.check_time_limit(150.0), true);
        assert_eq!(atom.check_time_limit(350.0), false);
    }
}
