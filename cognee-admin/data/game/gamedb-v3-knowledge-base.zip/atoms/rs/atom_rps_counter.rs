#[derive(Debug, Clone, PartialEq)]
pub enum MatchupType {
    Advantageous,
    Disadvantageous,
    Neutral,
}

#[derive(Debug, Clone)]
pub struct RpsCounterParams {
    pub bonus_damage_multiplier: f32,
    pub penalty_damage_multiplier: f32,
    pub armor_type_reduction: f32,
    pub movement_speed_modifier: f32,
}

impl RpsCounterParams {
    /// Creates a new RpsCounterParams with default values based on StarCraft II benchmarks.
    pub fn new() -> Self {
        Self {
            bonus_damage_multiplier: 1.5,
            penalty_damage_multiplier: 1.0,
            armor_type_reduction: 0.0,
            movement_speed_modifier: 1.0,
        }
    }

    /// Calculates the final damage based on the base damage and the matchup type.
    pub fn calculate_damage(&self, base_damage: f32, matchup: MatchupType) -> f32 {
        let multiplier = match matchup {
            MatchupType::Advantageous => self.bonus_damage_multiplier,
            MatchupType::Disadvantageous => self.penalty_damage_multiplier,
            MatchupType::Neutral => 1.0,
        };
        
        let damage_after_multiplier = base_damage * multiplier;
        let final_damage = damage_after_multiplier * (1.0 - self.armor_type_reduction);
        
        final_damage.max(0.0)
    }

    /// Calculates the effective movement speed based on the matchup type.
    pub fn calculate_movement_speed(&self, base_speed: f32, matchup: MatchupType) -> f32 {
        let modifier = match matchup {
            MatchupType::Advantageous => self.movement_speed_modifier,
            MatchupType::Disadvantageous => 1.0 / self.movement_speed_modifier,
            MatchupType::Neutral => 1.0,
        };
        
        base_speed * modifier
    }
}

impl Default for RpsCounterParams {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_damage_advantageous() {
        let params = RpsCounterParams {
            bonus_damage_multiplier: 2.5,
            penalty_damage_multiplier: 0.5,
            armor_type_reduction: 0.0,
            movement_speed_modifier: 1.2,
        };
        
        let base_damage = 20.0;
        let final_damage = params.calculate_damage(base_damage, MatchupType::Advantageous);
        
        assert_eq!(final_damage, 50.0);
    }

    #[test]
    fn test_calculate_damage_disadvantageous() {
        let params = RpsCounterParams {
            bonus_damage_multiplier: 2.5,
            penalty_damage_multiplier: 0.5,
            armor_type_reduction: 0.0,
            movement_speed_modifier: 1.2,
        };
        
        let base_damage = 20.0;
        let final_damage = params.calculate_damage(base_damage, MatchupType::Disadvantageous);
        
        assert_eq!(final_damage, 10.0);
    }

    #[test]
    fn test_calculate_damage_neutral_with_armor() {
        let params = RpsCounterParams {
            bonus_damage_multiplier: 2.5,
            penalty_damage_multiplier: 0.5,
            armor_type_reduction: 0.2,
            movement_speed_modifier: 1.2,
        };
        
        let base_damage = 20.0;
        let final_damage = params.calculate_damage(base_damage, MatchupType::Neutral);
        
        assert_eq!(final_damage, 16.0);
    }
    
    #[test]
    fn test_calculate_movement_speed() {
        let params = RpsCounterParams {
            bonus_damage_multiplier: 2.5,
            penalty_damage_multiplier: 0.5,
            armor_type_reduction: 0.0,
            movement_speed_modifier: 1.25,
        };
        
        let base_speed = 4.0;
        
        let adv_speed = params.calculate_movement_speed(base_speed, MatchupType::Advantageous);
        assert_eq!(adv_speed, 5.0);
        
        let dis_speed = params.calculate_movement_speed(base_speed, MatchupType::Disadvantageous);
        assert_eq!(dis_speed, 3.2);
    }
}
