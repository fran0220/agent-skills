#[derive(Debug, Clone, PartialEq)]
pub struct PvpArena {
    pub time_limit: u32,
    pub arena_radius: f32,
    pub max_players: u32,
    pub preparation_time: u32,
    pub healing_reduction: f32,
}

impl PvpArena {
    /// Creates a new PvpArena with default values based on World of Warcraft (v10.0) benchmarks.
    pub fn new() -> Self {
        Self {
            time_limit: 1200,
            arena_radius: 30.0,
            max_players: 6,
            preparation_time: 45,
            healing_reduction: 0.1, // 10% per minute
        }
    }

    /// Calculates the current healing reduction multiplier based on elapsed combat time.
    /// The reduction increases linearly over time.
    pub fn calculate_dampening(&self, elapsed_time_seconds: u32) -> f32 {
        let elapsed_minutes = elapsed_time_seconds as f32 / 60.0;
        let current_reduction = elapsed_minutes * self.healing_reduction;
        
        // Cap the reduction at 1.0 (100%)
        if current_reduction > 1.0 {
            1.0
        } else {
            current_reduction
        }
    }

    /// Checks if the match should end based on elapsed time or remaining players.
    pub fn is_match_over(&self, elapsed_time_seconds: u32, players_alive: u32) -> bool {
        if elapsed_time_seconds >= self.time_limit {
            return true;
        }
        
        // Match is over if 1 or 0 players are alive (assuming free-for-all or last team standing logic simplified)
        if players_alive <= 1 {
            return true;
        }
        
        false
    }
    
    /// Calculates the distance from the center and checks if a player is out of bounds.
    pub fn is_out_of_bounds(&self, player_x: f32, player_y: f32) -> bool {
        let distance_squared = player_x * player_x + player_y * player_y;
        distance_squared > self.arena_radius * self.arena_radius
    }
}

impl Default for PvpArena {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_dampening() {
        let arena = PvpArena::new();
        
        // At 0 seconds, dampening should be 0.0
        assert_eq!(arena.calculate_dampening(0), 0.0);
        
        // At 60 seconds (1 minute), dampening should be 0.1 (10%)
        assert_eq!(arena.calculate_dampening(60), 0.1);
        
        // At 300 seconds (5 minutes), dampening should be 0.5 (50%)
        assert_eq!(arena.calculate_dampening(300), 0.5);
        
        // At 600 seconds (10 minutes), dampening should be 1.0 (100%)
        assert_eq!(arena.calculate_dampening(600), 1.0);
        
        // At 1200 seconds (20 minutes), dampening should be capped at 1.0 (100%)
        assert_eq!(arena.calculate_dampening(1200), 1.0);
    }

    #[test]
    fn test_is_match_over() {
        let arena = PvpArena::new();
        
        // Match not over: time not reached, multiple players alive
        assert_eq!(arena.is_match_over(600, 4), false);
        
        // Match over: time limit reached
        assert_eq!(arena.is_match_over(1200, 4), true);
        assert_eq!(arena.is_match_over(1300, 4), true);
        
        // Match over: only 1 player alive
        assert_eq!(arena.is_match_over(600, 1), true);
        
        // Match over: 0 players alive
        assert_eq!(arena.is_match_over(600, 0), true);
    }
    
    #[test]
    fn test_is_out_of_bounds() {
        let arena = PvpArena::new(); // radius is 30.0
        
        // Inside bounds
        assert_eq!(arena.is_out_of_bounds(0.0, 0.0), false);
        assert_eq!(arena.is_out_of_bounds(20.0, 20.0), false); // distance is ~28.28
        
        // Outside bounds
        assert_eq!(arena.is_out_of_bounds(30.0, 30.0), true); // distance is ~42.42
        assert_eq!(arena.is_out_of_bounds(0.0, 31.0), true);
    }
}
