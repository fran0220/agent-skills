use std::collections::{HashMap, HashSet};

/// Parameters for the Control Group atom.
#[derive(Debug, Clone)]
pub struct ControlGroupParams {
    pub max_groups: u32,
    pub max_units_per_group: u32,
    pub double_tap_camera_snap: bool,
    pub steal_action_enabled: bool,
}

impl ControlGroupParams {
    /// Creates a new `ControlGroupParams` with default values based on StarCraft II (v5.0) benchmarks.
    pub fn new() -> Self {
        Self {
            max_groups: 10,
            max_units_per_group: 255,
            double_tap_camera_snap: true,
            steal_action_enabled: true,
        }
    }
}

/// Represents the Control Group system for a player.
pub struct ControlGroupSystem {
    params: ControlGroupParams,
    groups: HashMap<u32, HashSet<u32>>, // Maps group index to a set of entity IDs
}

impl ControlGroupSystem {
    pub fn new(params: ControlGroupParams) -> Self {
        Self {
            params,
            groups: HashMap::new(),
        }
    }

    /// Assigns a list of entity IDs to a specific control group index.
    /// If `steal_action_enabled` is true, removes these entities from all other groups.
    pub fn assign_group(&mut self, group_index: u32, entity_ids: Vec<u32>) -> Result<(), String> {
        if group_index >= self.params.max_groups {
            return Err(format!("Group index {} exceeds max_groups {}", group_index, self.params.max_groups));
        }

        let mut limited_entities = entity_ids;
        if limited_entities.len() > self.params.max_units_per_group as usize {
            limited_entities.truncate(self.params.max_units_per_group as usize);
        }

        if self.params.steal_action_enabled {
            for entity_id in &limited_entities {
                for (idx, group) in self.groups.iter_mut() {
                    if *idx != group_index {
                        group.remove(entity_id);
                    }
                }
            }
        }

        let entity_set: HashSet<u32> = limited_entities.into_iter().collect();
        self.groups.insert(group_index, entity_set);

        Ok(())
    }

    /// Recalls the entities assigned to a specific control group index.
    pub fn recall_group(&self, group_index: u32) -> Option<Vec<u32>> {
        self.groups.get(&group_index).map(|group| group.iter().cloned().collect())
    }

    /// Adds entities to an existing control group.
    pub fn add_to_group(&mut self, group_index: u32, entity_ids: Vec<u32>) -> Result<(), String> {
        if group_index >= self.params.max_groups {
            return Err(format!("Group index {} exceeds max_groups {}", group_index, self.params.max_groups));
        }

        if self.params.steal_action_enabled {
            for entity_id in &entity_ids {
                for (idx, group) in self.groups.iter_mut() {
                    if *idx != group_index {
                        group.remove(entity_id);
                    }
                }
            }
        }

        let group = self.groups.entry(group_index).or_insert_with(HashSet::new);
        
        for entity_id in entity_ids {
            if group.len() < self.params.max_units_per_group as usize {
                group.insert(entity_id);
            }
        }

        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_assign_and_recall() {
        let params = ControlGroupParams::new();
        let mut system = ControlGroupSystem::new(params);

        let entities = vec![1, 2, 3, 4, 5];
        assert!(system.assign_group(1, entities.clone()).is_ok());

        let recalled = system.recall_group(1).unwrap();
        assert_eq!(recalled.len(), 5);
        for id in entities {
            assert!(recalled.contains(&id));
        }
    }

    #[test]
    fn test_steal_action() {
        let mut params = ControlGroupParams::new();
        params.steal_action_enabled = true;
        let mut system = ControlGroupSystem::new(params);

        system.assign_group(1, vec![1, 2, 3]).unwrap();
        system.assign_group(2, vec![3, 4, 5]).unwrap(); // Entity 3 should be stolen from group 1

        let group1 = system.recall_group(1).unwrap();
        assert_eq!(group1.len(), 2);
        assert!(!group1.contains(&3));

        let group2 = system.recall_group(2).unwrap();
        assert_eq!(group2.len(), 3);
        assert!(group2.contains(&3));
    }

    #[test]
    fn test_max_units_limit() {
        let mut params = ControlGroupParams::new();
        params.max_units_per_group = 3;
        let mut system = ControlGroupSystem::new(params);

        system.assign_group(1, vec![1, 2, 3, 4, 5]).unwrap();

        let group1 = system.recall_group(1).unwrap();
        assert_eq!(group1.len(), 3);
    }
}
