#[derive(Debug, Clone, Copy, PartialEq)]
pub enum WeaponType {
    Sword,
    Lance,
    Axe,
    None,
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub enum MatchupResult {
    Advantage,
    Disadvantage,
    Neutral,
}

#[derive(Debug, Clone)]
pub struct WeaponTriangleParams {
    pub advantage_damage_mod: f32,
    pub advantage_hit_mod: f32,
    pub disadvantage_damage_mod: f32,
    pub disadvantage_hit_mod: f32,
}

impl WeaponTriangleParams {
    pub fn new() -> Self {
        Self {
            advantage_damage_mod: 1.0,
            advantage_hit_mod: 0.15,
            disadvantage_damage_mod: -1.0,
            disadvantage_hit_mod: -0.15,
        }
    }

    pub fn evaluate_matchup(&self, attacker: WeaponType, defender: WeaponType) -> MatchupResult {
        match (attacker, defender) {
            (WeaponType::Sword, WeaponType::Axe) => MatchupResult::Advantage,
            (WeaponType::Axe, WeaponType::Lance) => MatchupResult::Advantage,
            (WeaponType::Lance, WeaponType::Sword) => MatchupResult::Advantage,
            (WeaponType::Axe, WeaponType::Sword) => MatchupResult::Disadvantage,
            (WeaponType::Lance, WeaponType::Axe) => MatchupResult::Disadvantage,
            (WeaponType::Sword, WeaponType::Lance) => MatchupResult::Disadvantage,
            _ => MatchupResult::Neutral,
        }
    }

    pub fn apply_modifiers(&self, matchup: MatchupResult, base_damage: f32, base_hit: f32) -> (f32, f32) {
        match matchup {
            MatchupResult::Advantage => (
                base_damage + self.advantage_damage_mod,
                base_hit + self.advantage_hit_mod,
            ),
            MatchupResult::Disadvantage => (
                base_damage + self.disadvantage_damage_mod,
                base_hit + self.disadvantage_hit_mod,
            ),
            MatchupResult::Neutral => (base_damage, base_hit),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_matchup_evaluation() {
        let params = WeaponTriangleParams::new();
        
        assert_eq!(params.evaluate_matchup(WeaponType::Sword, WeaponType::Axe), MatchupResult::Advantage);
        assert_eq!(params.evaluate_matchup(WeaponType::Sword, WeaponType::Lance), MatchupResult::Disadvantage);
        assert_eq!(params.evaluate_matchup(WeaponType::Sword, WeaponType::Sword), MatchupResult::Neutral);
        assert_eq!(params.evaluate_matchup(WeaponType::Sword, WeaponType::None), MatchupResult::Neutral);
    }

    #[test]
    fn test_apply_modifiers() {
        let params = WeaponTriangleParams::new();
        
        let (adv_dmg, adv_hit) = params.apply_modifiers(MatchupResult::Advantage, 10.0, 0.80);
        assert_eq!(adv_dmg, 11.0);
        assert_eq!(adv_hit, 0.95);

        let (dis_dmg, dis_hit) = params.apply_modifiers(MatchupResult::Disadvantage, 10.0, 0.80);
        assert_eq!(dis_dmg, 9.0);
        assert_eq!(dis_hit, 0.65);

        let (neu_dmg, neu_hit) = params.apply_modifiers(MatchupResult::Neutral, 10.0, 0.80);
        assert_eq!(neu_dmg, 10.0);
        assert_eq!(neu_hit, 0.80);
    }
}
