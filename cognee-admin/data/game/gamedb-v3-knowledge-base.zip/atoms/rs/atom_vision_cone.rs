#[derive(Debug, Clone, PartialEq)]
pub struct VisionConeParams {
    pub fov_angle: f32,
    pub view_distance: f32,
    pub peripheral_fov: f32,
    pub peripheral_distance: f32,
    pub detection_speed: f32,
}

impl VisionConeParams {
    /// Creates a new VisionConeParams with default values based on Metal Gear Solid V benchmarks.
    pub fn new() -> Self {
        Self {
            fov_angle: 90.0,
            view_distance: 60.0,
            peripheral_fov: 160.0,
            peripheral_distance: 10.0,
            detection_speed: 1.5,
        }
    }

    /// Checks if a target is within the primary vision cone.
    /// `distance` is the distance to the target.
    /// `angle` is the absolute angle difference between the detector's forward vector and the direction to the target (in degrees).
    pub fn is_in_primary_cone(&self, distance: f32, angle: f32) -> bool {
        distance <= self.view_distance && angle <= (self.fov_angle / 2.0)
    }

    /// Checks if a target is within the peripheral vision cone.
    pub fn is_in_peripheral_cone(&self, distance: f32, angle: f32) -> bool {
        distance <= self.peripheral_distance && angle <= (self.peripheral_fov / 2.0)
    }

    /// Calculates the detection increment based on distance and angle.
    /// Returns a value to add to the detection meter.
    pub fn calculate_detection_increment(&self, distance: f32, angle: f32, delta_time: f32) -> f32 {
        if self.is_in_primary_cone(distance, angle) {
            // Closer targets are detected faster
            let distance_factor = 1.0 - (distance / self.view_distance).clamp(0.0, 1.0);
            return self.detection_speed * (0.5 + 0.5 * distance_factor) * delta_time;
        } else if self.is_in_peripheral_cone(distance, angle) {
            // Peripheral detection is slower
            let distance_factor = 1.0 - (distance / self.peripheral_distance).clamp(0.0, 1.0);
            return (self.detection_speed * 0.2) * (0.5 + 0.5 * distance_factor) * delta_time;
        }
        0.0
    }
}

impl Default for VisionConeParams {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_primary_cone_detection() {
        let params = VisionConeParams::new();
        
        // Inside primary cone: distance 30 < 60, angle 30 < 45
        assert!(params.is_in_primary_cone(30.0, 30.0));
        
        // Outside primary cone (too far): distance 70 > 60, angle 30 < 45
        assert!(!params.is_in_primary_cone(70.0, 30.0));
        
        // Outside primary cone (too wide): distance 30 < 60, angle 60 > 45
        assert!(!params.is_in_primary_cone(30.0, 60.0));
    }

    #[test]
    fn test_peripheral_cone_detection() {
        let params = VisionConeParams::new();
        
        // Inside peripheral cone: distance 5 < 10, angle 70 < 80
        assert!(params.is_in_peripheral_cone(5.0, 70.0));
        
        // Outside peripheral cone (too far): distance 15 > 10, angle 70 < 80
        assert!(!params.is_in_peripheral_cone(15.0, 70.0));
        
        // Outside peripheral cone (too wide): distance 5 < 10, angle 90 > 80
        assert!(!params.is_in_peripheral_cone(5.0, 90.0));
    }

    #[test]
    fn test_detection_increment() {
        let params = VisionConeParams::new();
        
        // Primary cone increment
        let inc_primary = params.calculate_detection_increment(30.0, 0.0, 1.0);
        assert!(inc_primary > 0.0);
        
        // Peripheral cone increment
        let inc_peripheral = params.calculate_detection_increment(5.0, 60.0, 1.0);
        assert!(inc_peripheral > 0.0);
        
        // Primary should be faster than peripheral (assuming similar relative distance)
        let inc_primary_close = params.calculate_detection_increment(5.0, 0.0, 1.0);
        assert!(inc_primary_close > inc_peripheral);
        
        // Outside both cones
        let inc_outside = params.calculate_detection_increment(100.0, 180.0, 1.0);
        assert_eq!(inc_outside, 0.0);
    }
}
