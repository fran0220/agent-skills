#[derive(Debug, Clone, PartialEq)]
pub struct FastTravelParams {
    pub cost_amount: u32,
    pub cast_time: f32,
    pub cooldown: f32,
    pub combat_lockout: bool,
}

impl FastTravelParams {
    /// Creates a new FastTravelParams with default values based on benchmark data (e.g., Breath of the Wild).
    pub fn new() -> Self {
        Self {
            cost_amount: 0,
            cast_time: 3.0,
            cooldown: 0.0,
            combat_lockout: false,
        }
    }

    /// Checks if fast travel can be initiated.
    /// Returns true if the player has enough currency/items, is not in combat (if lockout is active),
    /// and the cooldown has expired.
    pub fn can_fast_travel(&self, current_currency: u32, in_combat: bool, time_since_last_travel: f32) -> bool {
        if self.combat_lockout && in_combat {
            return false;
        }
        if current_currency < self.cost_amount {
            return false;
        }
        if time_since_last_travel < self.cooldown {
            return false;
        }
        true
    }

    /// Calculates the total time taken to fast travel, including cast time and an estimated loading time.
    pub fn calculate_total_travel_time(&self, estimated_load_time: f32) -> f32 {
        self.cast_time + estimated_load_time
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_can_fast_travel() {
        let mut params = FastTravelParams::new();
        
        // Default BotW style: no cost, 3s cast, no cooldown, no combat lockout
        assert!(params.can_fast_travel(0, true, 10.0));
        
        // Skyrim style: combat lockout
        params.combat_lockout = true;
        assert!(!params.can_fast_travel(0, true, 10.0));
        assert!(params.can_fast_travel(0, false, 10.0));
        
        // Hollow Knight style: cost required
        params.cost_amount = 100;
        params.combat_lockout = false;
        assert!(!params.can_fast_travel(50, false, 10.0));
        assert!(params.can_fast_travel(150, false, 10.0));
        
        // Cooldown check
        params.cooldown = 60.0;
        assert!(!params.can_fast_travel(150, false, 30.0));
        assert!(params.can_fast_travel(150, false, 70.0));
    }

    #[test]
    fn test_calculate_total_travel_time() {
        let params = FastTravelParams::new(); // cast_time = 3.0
        let load_time = 5.5;
        let total_time = params.calculate_total_travel_time(load_time);
        assert_eq!(total_time, 8.5);
    }
}
