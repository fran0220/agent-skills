#[derive(Debug, Clone)]
pub struct ConstellationDupeSystem {
    pub max_dupes: u32,
    pub stat_boost_multiplier: f32,
    pub skill_level_bonus: u32,
    pub overflow_currency_amount: u32,
    pub dupe_requirement_per_node: u32,
}

impl ConstellationDupeSystem {
    /// Creates a new ConstellationDupeSystem with default benchmark values (Genshin Impact v4.0).
    pub fn new() -> Self {
        Self {
            max_dupes: 6,
            stat_boost_multiplier: 1.15,
            skill_level_bonus: 3,
            overflow_currency_amount: 25,
            dupe_requirement_per_node: 1,
        }
    }

    /// Calculates the number of unlocked nodes based on the total number of duplicates acquired.
    pub fn calculate_unlocked_nodes(&self, total_dupes: u32) -> u32 {
        let nodes = total_dupes / self.dupe_requirement_per_node;
        if nodes > self.max_dupes {
            self.max_dupes
        } else {
            nodes
        }
    }

    /// Calculates the overflow currency generated from excess duplicates.
    pub fn calculate_overflow_currency(&self, total_dupes: u32) -> u32 {
        let max_usable_dupes = self.max_dupes * self.dupe_requirement_per_node;
        if total_dupes > max_usable_dupes {
            let excess_dupes = total_dupes - max_usable_dupes;
            excess_dupes * self.overflow_currency_amount
        } else {
            0
        }
    }

    /// Calculates the stat multiplier based on the current constellation level.
    /// Assuming a linear increase for simplicity in this model.
    pub fn calculate_stat_multiplier(&self, current_node: u32) -> f32 {
        let node = if current_node > self.max_dupes {
            self.max_dupes
        } else {
            current_node
        };
        
        1.0 + (self.stat_boost_multiplier - 1.0) * (node as f32 / self.max_dupes as f32)
    }
}

impl Default for ConstellationDupeSystem {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_unlocked_nodes() {
        let system = ConstellationDupeSystem::new();
        
        assert_eq!(system.calculate_unlocked_nodes(0), 0);
        assert_eq!(system.calculate_unlocked_nodes(3), 3);
        assert_eq!(system.calculate_unlocked_nodes(6), 6);
        assert_eq!(system.calculate_unlocked_nodes(10), 6); // Capped at max_dupes
    }

    #[test]
    fn test_calculate_overflow_currency() {
        let system = ConstellationDupeSystem::new();
        
        assert_eq!(system.calculate_overflow_currency(0), 0);
        assert_eq!(system.calculate_overflow_currency(6), 0);
        assert_eq!(system.calculate_overflow_currency(7), 25);
        assert_eq!(system.calculate_overflow_currency(10), 100);
    }

    #[test]
    fn test_calculate_stat_multiplier() {
        let system = ConstellationDupeSystem::new();
        
        assert_eq!(system.calculate_stat_multiplier(0), 1.0);
        // At max node (6), multiplier should be 1.15
        assert!((system.calculate_stat_multiplier(6) - 1.15).abs() < f32::EPSILON);
        // At node 3, multiplier should be halfway between 1.0 and 1.15 (1.075)
        assert!((system.calculate_stat_multiplier(3) - 1.075).abs() < f32::EPSILON);
    }
}
