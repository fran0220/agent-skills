#[derive(Debug, Clone, PartialEq)]
pub struct VictoryConditionsParams {
    pub victory_types_count: u32,
    pub progress_threshold: f32,
    pub pivot_penalty_factor: f32,
    pub global_turn_limit: u32,
}

impl VictoryConditionsParams {
    /// Creates a new instance with default values based on benchmark data.
    pub fn new() -> Self {
        Self {
            victory_types_count: 5,
            progress_threshold: 15000.0,
            pivot_penalty_factor: 0.2,
            global_turn_limit: 500,
        }
    }

    /// Calculates the percentage of progress towards a victory condition.
    /// Returns a value between 0.0 and 1.0.
    pub fn calculate_progress_percentage(&self, current_progress: f32) -> f32 {
        if self.progress_threshold <= 0.0 {
            return 1.0;
        }
        (current_progress / self.progress_threshold).clamp(0.0, 1.0)
    }

    /// Calculates the cost of pivoting to a different victory condition.
    /// The cost is a percentage of the current progress based on the pivot penalty factor.
    pub fn calculate_pivot_cost(&self, current_progress: f32) -> f32 {
        current_progress * self.pivot_penalty_factor
    }

    /// Checks if a victory condition has been met based on progress and turn limit.
    pub fn check_victory(&self, current_progress: f32, current_turn: u32) -> bool {
        if current_turn > self.global_turn_limit {
            return false; // Game over by turn limit
        }
        current_progress >= self.progress_threshold
    }
}

impl Default for VictoryConditionsParams {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_progress_percentage() {
        let params = VictoryConditionsParams::new();
        
        assert_eq!(params.calculate_progress_percentage(0.0), 0.0);
        assert_eq!(params.calculate_progress_percentage(7500.0), 0.5);
        assert_eq!(params.calculate_progress_percentage(15000.0), 1.0);
        assert_eq!(params.calculate_progress_percentage(20000.0), 1.0); // Clamped
    }

    #[test]
    fn test_calculate_pivot_cost() {
        let params = VictoryConditionsParams::new();
        
        assert_eq!(params.calculate_pivot_cost(10000.0), 2000.0);
        assert_eq!(params.calculate_pivot_cost(0.0), 0.0);
    }

    #[test]
    fn test_check_victory() {
        let params = VictoryConditionsParams::new();
        
        // Not enough progress
        assert!(!params.check_victory(14999.0, 100));
        
        // Enough progress, within turn limit
        assert!(params.check_victory(15000.0, 100));
        assert!(params.check_victory(20000.0, 500));
        
        // Past turn limit
        assert!(!params.check_victory(15000.0, 501));
    }
}
