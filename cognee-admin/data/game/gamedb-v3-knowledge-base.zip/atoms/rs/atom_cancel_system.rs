#[derive(Debug, Clone, PartialEq)]
pub struct CancelSystemParams {
    pub cancel_window_start: f32,
    pub cancel_window_end: f32,
    pub cost: f32,
    pub hit_stop_duration: f32,
}

impl CancelSystemParams {
    /// Creates a new CancelSystemParams with default values based on Devil May Cry 5 benchmark.
    pub fn new() -> Self {
        Self {
            cancel_window_start: 0.4,
            cancel_window_end: 0.9,
            cost: 0.0,
            hit_stop_duration: 0.1,
        }
    }

    /// Checks if a cancel is currently allowed based on the animation progress.
    /// `animation_progress` should be a normalized value between 0.0 and 1.0.
    pub fn is_cancel_allowed(&self, animation_progress: f32) -> bool {
        animation_progress >= self.cancel_window_start && animation_progress <= self.cancel_window_end
    }

    /// Attempts to perform a cancel, checking both the window and the resource cost.
    /// Returns true if successful, false otherwise.
    pub fn try_cancel(&self, animation_progress: f32, current_resource: &mut f32) -> bool {
        if self.is_cancel_allowed(animation_progress) && *current_resource >= self.cost {
            *current_resource -= self.cost;
            true
        } else {
            false
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_is_cancel_allowed() {
        let params = CancelSystemParams::new();
        
        // Before window
        assert!(!params.is_cancel_allowed(0.3));
        
        // Inside window
        assert!(params.is_cancel_allowed(0.5));
        assert!(params.is_cancel_allowed(0.4));
        assert!(params.is_cancel_allowed(0.9));
        
        // After window
        assert!(!params.is_cancel_allowed(0.95));
    }

    #[test]
    fn test_try_cancel_with_cost() {
        let mut params = CancelSystemParams::new();
        params.cost = 50.0; // E.g., Roman Cancel cost
        
        let mut resource = 100.0;
        
        // Successful cancel
        assert!(params.try_cancel(0.5, &mut resource));
        assert_eq!(resource, 50.0);
        
        // Failed cancel due to insufficient resource
        let mut low_resource = 40.0;
        assert!(!params.try_cancel(0.5, &mut low_resource));
        assert_eq!(low_resource, 40.0);
        
        // Failed cancel due to being outside window
        let mut resource2 = 100.0;
        assert!(!params.try_cancel(0.2, &mut resource2));
        assert_eq!(resource2, 100.0);
    }
}
