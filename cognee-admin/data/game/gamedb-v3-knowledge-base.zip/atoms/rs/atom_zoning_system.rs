#[derive(Debug, Clone, PartialEq)]
pub enum ZoneState {
    Unzoned,
    ZonedEmpty,
    Developing(f32), // Tracks construction progress
    Developed(u32),  // Tracks level
    Abandoned(f32),  // Tracks abandonment time
}

#[derive(Debug, Clone)]
pub struct ZoningSystemParams {
    pub zone_desirability_threshold: f32,
    pub construction_time: f32,
    pub abandonment_time_limit: f32,
    pub density_upgrade_threshold: f32,
    pub pollution_tolerance: f32,
}

impl ZoningSystemParams {
    pub fn new() -> Self {
        Self {
            zone_desirability_threshold: 45.0,
            construction_time: 15.0,
            abandonment_time_limit: 120.0,
            density_upgrade_threshold: 75.0,
            pollution_tolerance: 20.0,
        }
    }
}

pub struct ZoneCell {
    pub state: ZoneState,
    pub desirability: f32,
    pub land_value: f32,
    pub pollution: f32,
    pub has_services: bool,
}

impl ZoneCell {
    pub fn new() -> Self {
        Self {
            state: ZoneState::Unzoned,
            desirability: 0.0,
            land_value: 0.0,
            pollution: 0.0,
            has_services: false,
        }
    }

    pub fn update(&mut self, dt: f32, params: &ZoningSystemParams, demand: f32) {
        match self.state {
            ZoneState::Unzoned => {}
            ZoneState::ZonedEmpty => {
                if demand > 0.0 && self.desirability >= params.zone_desirability_threshold && self.pollution <= params.pollution_tolerance {
                    self.state = ZoneState::Developing(0.0);
                }
            }
            ZoneState::Developing(progress) => {
                let new_progress = progress + dt;
                if new_progress >= params.construction_time {
                    self.state = ZoneState::Developed(1);
                } else {
                    self.state = ZoneState::Developing(new_progress);
                }
            }
            ZoneState::Developed(level) => {
                if !self.has_services || self.pollution > params.pollution_tolerance {
                    self.state = ZoneState::Abandoned(0.0);
                } else if self.land_value >= params.density_upgrade_threshold * (level as f32) {
                    self.state = ZoneState::Developed(level + 1);
                }
            }
            ZoneState::Abandoned(time) => {
                let new_time = time + dt;
                if new_time >= params.abandonment_time_limit {
                    self.state = ZoneState::ZonedEmpty;
                } else {
                    self.state = ZoneState::Abandoned(new_time);
                }
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_development_trigger() {
        let params = ZoningSystemParams::new();
        let mut cell = ZoneCell::new();
        cell.state = ZoneState::ZonedEmpty;
        cell.desirability = 50.0; // Above threshold of 45.0
        cell.pollution = 10.0;    // Below tolerance of 20.0
        
        cell.update(1.0, &params, 10.0); // Demand is 10.0
        
        assert_eq!(cell.state, ZoneState::Developing(0.0));
    }

    #[test]
    fn test_construction_completion() {
        let params = ZoningSystemParams::new();
        let mut cell = ZoneCell::new();
        cell.state = ZoneState::Developing(14.0);
        
        cell.update(2.0, &params, 10.0); // dt = 2.0, total progress = 16.0 > 15.0
        
        assert_eq!(cell.state, ZoneState::Developed(1));
    }

    #[test]
    fn test_abandonment_due_to_pollution() {
        let params = ZoningSystemParams::new();
        let mut cell = ZoneCell::new();
        cell.state = ZoneState::Developed(1);
        cell.has_services = true;
        cell.pollution = 30.0; // Above tolerance of 20.0
        
        cell.update(1.0, &params, 10.0);
        
        assert_eq!(cell.state, ZoneState::Abandoned(0.0));
    }
}
