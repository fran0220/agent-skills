#[derive(Debug, Clone)]
pub struct GiftGivingParams {
    pub loved_gift_points: f32,
    pub liked_gift_points: f32,
    pub neutral_gift_points: f32,
    pub disliked_gift_points: f32,
    pub hated_gift_points: f32,
    pub daily_gift_limit: u32,
    pub weekly_gift_limit: u32,
    pub birthday_multiplier: f32,
}

impl GiftGivingParams {
    pub fn new() -> Self {
        Self {
            loved_gift_points: 80.0,
            liked_gift_points: 45.0,
            neutral_gift_points: 20.0,
            disliked_gift_points: -20.0,
            hated_gift_points: -40.0,
            daily_gift_limit: 1,
            weekly_gift_limit: 2,
            birthday_multiplier: 8.0,
        }
    }
}

pub enum GiftPreference {
    Loved,
    Liked,
    Neutral,
    Disliked,
    Hated,
}

pub struct NpcGiftState {
    pub current_friendship: f32,
    pub gifts_given_today: u32,
    pub gifts_given_this_week: u32,
}

impl NpcGiftState {
    pub fn new(initial_friendship: f32) -> Self {
        Self {
            current_friendship: initial_friendship,
            gifts_given_today: 0,
            gifts_given_this_week: 0,
        }
    }

    /// Attempts to give a gift to the NPC. Returns true if successful, false if limits are reached.
    pub fn give_gift(
        &mut self,
        params: &GiftGivingParams,
        preference: GiftPreference,
        is_birthday: bool,
    ) -> bool {
        if self.gifts_given_today >= params.daily_gift_limit
            || self.gifts_given_this_week >= params.weekly_gift_limit
        {
            return false;
        }

        let base_points = match preference {
            GiftPreference::Loved => params.loved_gift_points,
            GiftPreference::Liked => params.liked_gift_points,
            GiftPreference::Neutral => params.neutral_gift_points,
            GiftPreference::Disliked => params.disliked_gift_points,
            GiftPreference::Hated => params.hated_gift_points,
        };

        let multiplier = if is_birthday {
            params.birthday_multiplier
        } else {
            1.0
        };

        self.current_friendship += base_points * multiplier;
        self.gifts_given_today += 1;
        self.gifts_given_this_week += 1;

        true
    }

    pub fn reset_daily(&mut self) {
        self.gifts_given_today = 0;
    }

    pub fn reset_weekly(&mut self) {
        self.gifts_given_today = 0;
        self.gifts_given_this_week = 0;
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_give_gift_success_and_limits() {
        let params = GiftGivingParams::new();
        let mut state = NpcGiftState::new(0.0);

        // First gift (Loved, not birthday)
        let success = state.give_gift(&params, GiftPreference::Loved, false);
        assert!(success);
        assert_eq!(state.current_friendship, 80.0);
        assert_eq!(state.gifts_given_today, 1);

        // Second gift today (should fail due to daily limit)
        let success2 = state.give_gift(&params, GiftPreference::Liked, false);
        assert!(!success2);
        assert_eq!(state.current_friendship, 80.0); // No change
    }

    #[test]
    fn test_birthday_multiplier() {
        let params = GiftGivingParams::new();
        let mut state = NpcGiftState::new(100.0);

        // Gift on birthday (Liked)
        let success = state.give_gift(&params, GiftPreference::Liked, true);
        assert!(success);
        // 100.0 + (45.0 * 8.0) = 100.0 + 360.0 = 460.0
        assert_eq!(state.current_friendship, 460.0);
    }
}
