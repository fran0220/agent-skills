#[derive(Debug, Clone)]
pub struct CascadeChain {
    pub base_score: u32,
    pub multiplier_step: f32,
    pub max_multiplier: f32,
    pub animation_delay: f32,
    pub gravity_speed: f32,
}

impl CascadeChain {
    pub fn new() -> Self {
        Self {
            base_score: 60,
            multiplier_step: 0.5,
            max_multiplier: 5.0,
            animation_delay: 0.25,
            gravity_speed: 9.8,
        }
    }

    /// Calculates the score for a specific chain step.
    /// The step is 0-indexed (0 is the initial match, 1 is the first cascade, etc.)
    pub fn calculate_score(&self, step: u32, elements_cleared: u32) -> u32 {
        let multiplier = 1.0 + (step as f32 * self.multiplier_step);
        let clamped_multiplier = multiplier.min(self.max_multiplier);
        
        // Base score is per element cleared, or a flat rate? Let's say base_score is for a standard 3-match,
        // so per element it's base_score / 3.
        let score_per_element = self.base_score as f32 / 3.0;
        
        let total_score = score_per_element * elements_cleared as f32 * clamped_multiplier;
        total_score.round() as u32
    }

    /// Calculates the total time taken for a sequence of cascades to animate
    pub fn calculate_animation_time(&self, steps: u32) -> f32 {
        if steps == 0 {
            return 0.0;
        }
        steps as f32 * self.animation_delay
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_score() {
        let cascade = CascadeChain::new();
        
        // Step 0 (initial match), 3 elements
        // multiplier = 1.0
        // score = (60 / 3) * 3 * 1.0 = 60
        assert_eq!(cascade.calculate_score(0, 3), 60);

        // Step 1 (first cascade), 3 elements
        // multiplier = 1.5
        // score = (60 / 3) * 3 * 1.5 = 90
        assert_eq!(cascade.calculate_score(1, 3), 90);

        // Step 10 (max multiplier reached), 4 elements
        // multiplier = 1.0 + 10 * 0.5 = 6.0 -> clamped to 5.0
        // score = (60 / 3) * 4 * 5.0 = 400
        assert_eq!(cascade.calculate_score(10, 4), 400);
    }

    #[test]
    fn test_calculate_animation_time() {
        let cascade = CascadeChain::new();
        
        assert_eq!(cascade.calculate_animation_time(0), 0.0);
        assert_eq!(cascade.calculate_animation_time(1), 0.25);
        assert_eq!(cascade.calculate_animation_time(4), 1.0);
    }
}
