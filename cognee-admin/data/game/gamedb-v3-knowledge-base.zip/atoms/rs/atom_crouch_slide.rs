#[derive(Debug, Clone, PartialEq)]
pub struct CrouchSlideParams {
    pub initial_velocity_boost: f32,
    pub friction_coefficient: f32,
    pub slope_acceleration: f32,
    pub min_sprint_time_to_slide: f32,
    pub hitbox_height_multiplier: f32,
    pub slide_cooldown: f32,
}

impl CrouchSlideParams {
    pub fn new() -> Self {
        Self {
            initial_velocity_boost: 2.0,
            friction_coefficient: 0.2,
            slope_acceleration: 5.0,
            min_sprint_time_to_slide: 0.1,
            hitbox_height_multiplier: 0.5,
            slide_cooldown: 1.5,
        }
    }

    /// Calculates the initial slide velocity given the current sprint velocity.
    pub fn calculate_initial_slide_velocity(&self, current_velocity: f32) -> f32 {
        current_velocity + self.initial_velocity_boost
    }

    /// Calculates the velocity after applying friction and slope acceleration over a time delta.
    /// slope_angle is in radians. Positive angle means downhill.
    pub fn calculate_velocity_update(&self, current_velocity: f32, slope_angle: f32, delta_time: f32) -> f32 {
        let gravity = 9.81;
        let friction_deceleration = gravity * self.friction_coefficient;
        let slope_effect = slope_angle.sin() * self.slope_acceleration;
        
        let new_velocity = current_velocity - (friction_deceleration * delta_time) + (slope_effect * delta_time);
        
        if new_velocity < 0.0 {
            0.0
        } else {
            new_velocity
        }
    }
    
    /// Calculates the new hitbox height based on the original height.
    pub fn calculate_slide_hitbox_height(&self, original_height: f32) -> f32 {
        original_height * self.hitbox_height_multiplier
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_initial_slide_velocity() {
        let params = CrouchSlideParams::new();
        let sprint_velocity = 8.0;
        let slide_velocity = params.calculate_initial_slide_velocity(sprint_velocity);
        assert_eq!(slide_velocity, 10.0);
    }

    #[test]
    fn test_velocity_update_flat_ground() {
        let params = CrouchSlideParams::new();
        let current_velocity = 10.0;
        let slope_angle = 0.0; // Flat ground
        let delta_time = 1.0; // 1 second
        
        let new_velocity = params.calculate_velocity_update(current_velocity, slope_angle, delta_time);
        // friction = 9.81 * 0.2 = 1.962
        // new_velocity = 10.0 - 1.962 = 8.038
        assert!((new_velocity - 8.038).abs() < 0.001);
    }

    #[test]
    fn test_velocity_update_downhill() {
        let params = CrouchSlideParams::new();
        let current_velocity = 10.0;
        let slope_angle = 0.5; // Downhill
        let delta_time = 1.0;
        
        let new_velocity = params.calculate_velocity_update(current_velocity, slope_angle, delta_time);
        // friction = 1.962
        // slope_effect = sin(0.5) * 5.0 ≈ 0.4794 * 5.0 = 2.397
        // new_velocity = 10.0 - 1.962 + 2.397 = 10.435
        assert!(new_velocity > 10.0);
    }
    
    #[test]
    fn test_slide_hitbox_height() {
        let params = CrouchSlideParams::new();
        let original_height = 2.0;
        let new_height = params.calculate_slide_hitbox_height(original_height);
        assert_eq!(new_height, 1.0);
    }
}
