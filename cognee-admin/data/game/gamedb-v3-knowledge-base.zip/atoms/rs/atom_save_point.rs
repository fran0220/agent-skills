#[derive(Debug, Clone, PartialEq)]
pub struct SavePointParams {
    pub activation_radius: f32,
    pub heal_amount: f32,
    pub requires_item: bool,
    pub cooldown_time: f32,
    pub enemy_respawn: bool,
}

impl SavePointParams {
    /// Creates a new SavePointParams with default values based on Metroid Dread benchmark
    pub fn new() -> Self {
        Self {
            activation_radius: 2.0,
            heal_amount: 100.0,
            requires_item: false,
            cooldown_time: 0.0,
            enemy_respawn: false,
        }
    }
}

pub struct SavePointState {
    pub is_available: bool,
    pub last_save_time: f32,
}

impl SavePointState {
    pub fn new() -> Self {
        Self {
            is_available: true,
            last_save_time: 0.0,
        }
    }

    /// Checks if the player is within the activation radius to discover/interact with the save point
    pub fn is_in_range(&self, player_distance: f32, params: &SavePointParams) -> bool {
        player_distance <= params.activation_radius
    }

    /// Attempts to save the game. Returns true if successful, false otherwise.
    pub fn attempt_save(
        &mut self,
        current_time: f32,
        has_required_item: bool,
        params: &SavePointParams,
    ) -> bool {
        if !self.is_available {
            return false;
        }

        if params.requires_item && !has_required_item {
            return false;
        }

        if current_time - self.last_save_time < params.cooldown_time {
            return false;
        }

        // Perform save logic here...
        self.last_save_time = current_time;
        
        // If there's a cooldown, it becomes unavailable temporarily
        if params.cooldown_time > 0.0 {
            self.is_available = false;
        }

        true
    }

    /// Updates the save point state, potentially making it available again after cooldown
    pub fn update(&mut self, current_time: f32, params: &SavePointParams) {
        if !self.is_available && current_time - self.last_save_time >= params.cooldown_time {
            self.is_available = true;
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_is_in_range() {
        let params = SavePointParams::new();
        let state = SavePointState::new();

        // Inside radius
        assert!(state.is_in_range(1.5, &params));
        // Exactly on radius
        assert!(state.is_in_range(2.0, &params));
        // Outside radius
        assert!(!state.is_in_range(2.5, &params));
    }

    #[test]
    fn test_attempt_save_with_cooldown() {
        let mut params = SavePointParams::new();
        params.cooldown_time = 10.0;
        let mut state = SavePointState::new();

        // First save should succeed
        assert!(state.attempt_save(5.0, true, &params));
        assert_eq!(state.last_save_time, 5.0);
        assert!(!state.is_available);

        // Second save immediately after should fail due to cooldown
        assert!(!state.attempt_save(10.0, true, &params));

        // Update state after cooldown period
        state.update(16.0, &params);
        assert!(state.is_available);

        // Save should succeed again
        assert!(state.attempt_save(16.0, true, &params));
    }

    #[test]
    fn test_attempt_save_requires_item() {
        let mut params = SavePointParams::new();
        params.requires_item = true;
        let mut state = SavePointState::new();

        // Fails without item
        assert!(!state.attempt_save(0.0, false, &params));
        
        // Succeeds with item
        assert!(state.attempt_save(0.0, true, &params));
    }
}
