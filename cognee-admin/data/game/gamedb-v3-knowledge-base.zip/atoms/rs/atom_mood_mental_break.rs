#[derive(Debug, Clone, PartialEq)]
pub enum MentalState {
    Content,
    Stressed,
    MinorBreakRisk,
    MajorBreakRisk,
    ExtremeBreakRisk,
    MentalBreak,
    Catharsis,
}

#[derive(Debug, Clone)]
pub struct MoodMentalBreakParams {
    pub base_mood: f32,
    pub minor_break_threshold: f32,
    pub major_break_threshold: f32,
    pub extreme_break_threshold: f32,
    pub catharsis_buff: f32,
    pub catharsis_duration: f32,
    pub mtb_minor_break: f32,
}

impl MoodMentalBreakParams {
    pub fn new() -> Self {
        Self {
            base_mood: 50.0,
            minor_break_threshold: 35.0,
            major_break_threshold: 20.0,
            extreme_break_threshold: 5.0,
            catharsis_buff: 40.0,
            catharsis_duration: 3.0,
            mtb_minor_break: 3.0,
        }
    }
}

pub struct CharacterMood {
    pub params: MoodMentalBreakParams,
    pub current_mood: f32,
    pub state: MentalState,
    pub catharsis_time_remaining: f32,
}

impl CharacterMood {
    pub fn new(params: MoodMentalBreakParams) -> Self {
        let base_mood = params.base_mood;
        Self {
            params,
            current_mood: base_mood,
            state: MentalState::Content,
            catharsis_time_remaining: 0.0,
        }
    }

    /// Updates the mental state based on current mood and catharsis status.
    pub fn update_state(&mut self, delta_time: f32) {
        if self.state == MentalState::MentalBreak {
            // In a mental break, state doesn't change until it's resolved externally or via a timer.
            // For simplicity, we assume an external trigger ends the break and starts catharsis.
            return;
        }

        if self.state == MentalState::Catharsis {
            self.catharsis_time_remaining -= delta_time;
            if self.catharsis_time_remaining <= 0.0 {
                self.catharsis_time_remaining = 0.0;
                self.state = MentalState::Content;
            } else {
                return; // Still in catharsis
            }
        }

        // Determine state based on mood thresholds
        if self.current_mood <= self.params.extreme_break_threshold {
            self.state = MentalState::ExtremeBreakRisk;
        } else if self.current_mood <= self.params.major_break_threshold {
            self.state = MentalState::MajorBreakRisk;
        } else if self.current_mood <= self.params.minor_break_threshold {
            self.state = MentalState::MinorBreakRisk;
        } else if self.current_mood < 80.0 {
            self.state = MentalState::Stressed;
        } else {
            self.state = MentalState::Content;
        }
    }

    /// Modifies the current mood by a given amount, clamping it between 0 and 100.
    pub fn modify_mood(&mut self, amount: f32) {
        self.current_mood = (self.current_mood + amount).clamp(0.0, 100.0);
    }

    /// Triggers a mental break, transitioning the state.
    pub fn trigger_mental_break(&mut self) {
        if matches!(
            self.state,
            MentalState::MinorBreakRisk | MentalState::MajorBreakRisk | MentalState::ExtremeBreakRisk
        ) {
            self.state = MentalState::MentalBreak;
        }
    }

    /// Ends a mental break and applies catharsis.
    pub fn end_mental_break(&mut self) {
        if self.state == MentalState::MentalBreak {
            self.state = MentalState::Catharsis;
            self.catharsis_time_remaining = self.params.catharsis_duration;
            self.modify_mood(self.params.catharsis_buff);
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_mood_thresholds_and_state_update() {
        let params = MoodMentalBreakParams::new();
        let mut char_mood = CharacterMood::new(params);

        // Initial state should be Content or Stressed depending on base_mood (50.0 < 80.0 -> Stressed)
        char_mood.update_state(0.0);
        assert_eq!(char_mood.state, MentalState::Stressed);

        // Drop mood to Minor Break Risk
        char_mood.modify_mood(-20.0); // Mood = 30.0
        char_mood.update_state(0.0);
        assert_eq!(char_mood.state, MentalState::MinorBreakRisk);

        // Drop mood to Extreme Break Risk
        char_mood.modify_mood(-28.0); // Mood = 2.0
        char_mood.update_state(0.0);
        assert_eq!(char_mood.state, MentalState::ExtremeBreakRisk);
    }

    #[test]
    fn test_mental_break_and_catharsis() {
        let params = MoodMentalBreakParams::new();
        let mut char_mood = CharacterMood::new(params);

        // Force into a risk state
        char_mood.current_mood = 10.0;
        char_mood.update_state(0.0);
        assert_eq!(char_mood.state, MentalState::MajorBreakRisk);

        // Trigger break
        char_mood.trigger_mental_break();
        assert_eq!(char_mood.state, MentalState::MentalBreak);

        // End break, should enter catharsis and get mood buff
        char_mood.end_mental_break();
        assert_eq!(char_mood.state, MentalState::Catharsis);
        assert_eq!(char_mood.current_mood, 50.0); // 10.0 + 40.0 buff

        // Update state with time passing, catharsis should expire
        char_mood.update_state(3.1); // Duration is 3.0
        assert_eq!(char_mood.state, MentalState::Stressed); // Mood is 50.0, so Stressed
    }
}
