#[derive(Debug, Clone, PartialEq)]
pub struct SpatialPortalParams {
    pub portal_width: f32,
    pub portal_height: f32,
    pub momentum_retention: f32,
    pub teleport_cooldown: f32,
}

impl SpatialPortalParams {
    pub fn new() -> Self {
        Self {
            portal_width: 2.0,
            portal_height: 3.0,
            momentum_retention: 1.0,
            teleport_cooldown: 0.1,
        }
    }

    /// Calculates the exit velocity of an entity after passing through the portal.
    /// 
    /// # Arguments
    /// * `entry_velocity` - The velocity vector of the entity entering the portal.
    /// * `entry_normal` - The normal vector of the entry portal surface.
    /// * `exit_normal` - The normal vector of the exit portal surface.
    /// 
    /// # Returns
    /// The new velocity vector of the entity exiting the portal.
    pub fn calculate_exit_velocity(
        &self,
        entry_velocity: (f32, f32, f32),
        entry_normal: (f32, f32, f32),
        exit_normal: (f32, f32, f32),
    ) -> (f32, f32, f32) {
        // A simplified calculation for momentum redirection.
        // In a real engine, this involves quaternion rotation from entry to exit normal.
        // Here we just scale the entry velocity by momentum retention and flip it based on normals.
        
        // Dot product to find the speed along the entry normal
        let speed_along_normal = entry_velocity.0 * entry_normal.0 
                               + entry_velocity.1 * entry_normal.1 
                               + entry_velocity.2 * entry_normal.2;
                               
        // For simplicity in this atom, we assume the exit velocity is redirected along the exit normal
        // while retaining the original magnitude scaled by momentum_retention.
        let magnitude = (entry_velocity.0.powi(2) + entry_velocity.1.powi(2) + entry_velocity.2.powi(2)).sqrt();
        let retained_magnitude = magnitude * self.momentum_retention;
        
        (
            exit_normal.0 * retained_magnitude,
            exit_normal.1 * retained_magnitude,
            exit_normal.2 * retained_magnitude,
        )
    }

    /// Checks if an entity can teleport based on the cooldown.
    /// 
    /// # Arguments
    /// * `time_since_last_teleport` - Time in seconds since the entity last teleported.
    /// 
    /// # Returns
    /// `true` if the entity can teleport, `false` otherwise.
    pub fn can_teleport(&self, time_since_last_teleport: f32) -> bool {
        time_since_last_teleport >= self.teleport_cooldown
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_exit_velocity() {
        let params = SpatialPortalParams::new();
        let entry_velocity = (0.0, -10.0, 0.0); // Falling straight down
        let entry_normal = (0.0, 1.0, 0.0); // Floor portal pointing up
        let exit_normal = (1.0, 0.0, 0.0); // Wall portal pointing right
        
        let exit_velocity = params.calculate_exit_velocity(entry_velocity, entry_normal, exit_normal);
        
        // Magnitude should be 10.0, directed along exit_normal (1.0, 0.0, 0.0)
        assert!((exit_velocity.0 - 10.0).abs() < 0.001);
        assert!((exit_velocity.1 - 0.0).abs() < 0.001);
        assert!((exit_velocity.2 - 0.0).abs() < 0.001);
    }

    #[test]
    fn test_can_teleport() {
        let params = SpatialPortalParams::new();
        
        assert_eq!(params.can_teleport(0.05), false); // Less than cooldown (0.1)
        assert_eq!(params.can_teleport(0.15), true);  // Greater than cooldown (0.1)
    }
}
