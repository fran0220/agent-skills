#[derive(Debug, Clone, PartialEq)]
pub struct SwerveDodgeParams {
    pub forward_speed_base: f32,
    pub forward_speed_max: f32,
    pub lane_width: f32,
    pub swerve_duration: f32,
    pub jump_height: f32,
    pub jump_duration: f32,
    pub roll_duration: f32,
    pub obstacle_spawn_rate: f32,
}

impl SwerveDodgeParams {
    /// Creates a new SwerveDodgeParams with default values based on Subway Surfers benchmark.
    pub fn new() -> Self {
        Self {
            forward_speed_base: 15.0,
            forward_speed_max: 45.0,
            lane_width: 3.0,
            swerve_duration: 0.15,
            jump_height: 3.5,
            jump_duration: 0.6,
            roll_duration: 0.6,
            obstacle_spawn_rate: 1.2,
        }
    }

    /// Calculates the current forward speed based on time elapsed and a speed increase factor.
    pub fn calculate_current_speed(&self, time_elapsed: f32, speed_increase_per_sec: f32) -> f32 {
        let current_speed = self.forward_speed_base + (time_elapsed * speed_increase_per_sec);
        current_speed.min(self.forward_speed_max)
    }

    /// Calculates the lateral position during a swerve transition.
    /// `progress` is a value between 0.0 and 1.0 representing the completion of the swerve.
    /// `start_lane` and `target_lane` are integer indices (e.g., -1, 0, 1).
    pub fn calculate_lateral_position(&self, start_lane: i32, target_lane: i32, progress: f32) -> f32 {
        let start_pos = start_lane as f32 * self.lane_width;
        let target_pos = target_lane as f32 * self.lane_width;
        
        // Simple linear interpolation for lateral movement
        start_pos + (target_pos - start_pos) * progress.clamp(0.0, 1.0)
    }
    
    /// Calculates the vertical position during a jump.
    /// `progress` is a value between 0.0 and 1.0 representing the completion of the jump.
    pub fn calculate_jump_height(&self, progress: f32) -> f32 {
        let p = progress.clamp(0.0, 1.0);
        // Parabolic jump curve: 4 * h * p * (1 - p)
        4.0 * self.jump_height * p * (1.0 - p)
    }
}

impl Default for SwerveDodgeParams {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_current_speed() {
        let params = SwerveDodgeParams::new();
        
        // Initial speed
        assert_eq!(params.calculate_current_speed(0.0, 1.0), 15.0);
        
        // Speed after 10 seconds
        assert_eq!(params.calculate_current_speed(10.0, 1.0), 25.0);
        
        // Max speed cap
        assert_eq!(params.calculate_current_speed(100.0, 1.0), 45.0);
    }

    #[test]
    fn test_calculate_lateral_position() {
        let params = SwerveDodgeParams::new();
        
        // Start of swerve from lane 0 to lane 1
        assert_eq!(params.calculate_lateral_position(0, 1, 0.0), 0.0);
        
        // Middle of swerve from lane 0 to lane 1
        assert_eq!(params.calculate_lateral_position(0, 1, 0.5), 1.5);
        
        // End of swerve from lane 0 to lane 1
        assert_eq!(params.calculate_lateral_position(0, 1, 1.0), 3.0);
        
        // Swerve from lane 1 to lane -1
        assert_eq!(params.calculate_lateral_position(1, -1, 0.5), 0.0);
    }
    
    #[test]
    fn test_calculate_jump_height() {
        let params = SwerveDodgeParams::new();
        
        // Start of jump
        assert_eq!(params.calculate_jump_height(0.0), 0.0);
        
        // Peak of jump
        assert_eq!(params.calculate_jump_height(0.5), 3.5);
        
        // End of jump
        assert_eq!(params.calculate_jump_height(1.0), 0.0);
    }
}
