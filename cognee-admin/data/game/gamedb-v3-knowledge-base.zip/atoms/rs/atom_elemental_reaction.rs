#[derive(Debug, Clone, PartialEq)]
pub enum Element {
    Pyro,
    Hydro,
    Cryo,
    Electro,
    Dendro,
    Anemo,
    Geo,
}

#[derive(Debug, Clone)]
pub struct ElementalReactionParams {
    pub base_reaction_multiplier: f32,
    pub elemental_mastery_bonus: f32,
    pub gauge_units: f32,
    pub aura_duration: f32,
}

impl ElementalReactionParams {
    pub fn new() -> Self {
        Self {
            base_reaction_multiplier: 2.0,
            elemental_mastery_bonus: 0.0,
            gauge_units: 1.0,
            aura_duration: 9.5,
        }
    }

    pub fn calculate_reaction_damage(&self, base_damage: f32, em: f32) -> f32 {
        let em_bonus = 2.78 * em / (em + 1400.0);
        base_damage * self.base_reaction_multiplier * (1.0 + em_bonus + self.elemental_mastery_bonus)
    }

    pub fn calculate_remaining_gauge(&self, applied_gauge: f32) -> f32 {
        let remaining = self.gauge_units - applied_gauge;
        if remaining > 0.0 {
            remaining
        } else {
            0.0
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_reaction_damage() {
        let params = ElementalReactionParams::new();
        let damage = params.calculate_reaction_damage(1000.0, 0.0);
        assert_eq!(damage, 2000.0);
    }

    #[test]
    fn test_remaining_gauge() {
        let params = ElementalReactionParams::new();
        let remaining = params.calculate_remaining_gauge(0.5);
        assert_eq!(remaining, 0.5);
        
        let depleted = params.calculate_remaining_gauge(1.5);
        assert_eq!(depleted, 0.0);
    }
}
