#[derive(Debug, Clone, Copy)]
pub struct HalvedGravityPeakParams {
    pub gravity_normal: f32,
    pub gravity_mult: f32,
    pub apex_threshold: f32,
}

impl HalvedGravityPeakParams {
    /// Creates a new `HalvedGravityPeakParams` with default values based on Celeste benchmark.
    pub fn new() -> Self {
        Self {
            gravity_normal: 900.0,
            gravity_mult: 0.5,
            apex_threshold: 40.0,
        }
    }

    /// Calculates the current gravity to apply based on the vertical velocity.
    /// 
    /// # Arguments
    /// * `v_y` - The current vertical velocity.
    /// 
    /// # Returns
    /// The gravity value to apply for the current frame.
    pub fn calculate_gravity(&self, v_y: f32) -> f32 {
        if v_y.abs() < self.apex_threshold {
            self.gravity_normal * self.gravity_mult
        } else {
            self.gravity_normal
        }
    }

    /// Updates the vertical velocity for a single frame given a delta time.
    /// 
    /// # Arguments
    /// * `v_y` - The current vertical velocity.
    /// * `dt` - The delta time for the frame.
    /// 
    /// # Returns
    /// The new vertical velocity after applying gravity.
    pub fn update_velocity(&self, v_y: f32, dt: f32) -> f32 {
        let current_gravity = self.calculate_gravity(v_y);
        // Assuming positive v_y is downwards, gravity increases v_y.
        // If positive v_y is upwards, gravity should decrease v_y.
        // We'll assume standard game math where gravity is added to velocity downwards.
        v_y + current_gravity * dt
    }
}

impl Default for HalvedGravityPeakParams {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_gravity_outside_apex() {
        let params = HalvedGravityPeakParams::new();
        
        // Velocity well above threshold (falling fast)
        assert_eq!(params.calculate_gravity(100.0), 900.0);
        
        // Velocity well below threshold (rising fast)
        assert_eq!(params.calculate_gravity(-100.0), 900.0);
    }

    #[test]
    fn test_calculate_gravity_inside_apex() {
        let params = HalvedGravityPeakParams::new();
        
        // Velocity exactly at 0
        assert_eq!(params.calculate_gravity(0.0), 450.0);
        
        // Velocity slightly positive but within threshold
        assert_eq!(params.calculate_gravity(20.0), 450.0);
        
        // Velocity slightly negative but within threshold
        assert_eq!(params.calculate_gravity(-20.0), 450.0);
    }

    #[test]
    fn test_update_velocity() {
        let params = HalvedGravityPeakParams::new();
        let dt = 0.016; // ~60fps
        
        // Outside apex: normal gravity applied
        let v_y_fast = 100.0;
        let new_v_y_fast = params.update_velocity(v_y_fast, dt);
        assert_eq!(new_v_y_fast, 100.0 + 900.0 * dt);
        
        // Inside apex: halved gravity applied
        let v_y_slow = 10.0;
        let new_v_y_slow = params.update_velocity(v_y_slow, dt);
        assert_eq!(new_v_y_slow, 10.0 + 450.0 * dt);
    }
}
