#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Season {
    Spring,
    Summer,
    Autumn,
    Winter,
}

impl Season {
    pub fn next(&self) -> Self {
        match self {
            Season::Spring => Season::Summer,
            Season::Summer => Season::Autumn,
            Season::Autumn => Season::Winter,
            Season::Winter => Season::Spring,
        }
    }
}

#[derive(Debug, Clone)]
pub struct SeasonalCalendar {
    pub days_per_season: u32,
    pub seasons_per_year: u32,
    pub day_duration_real_seconds: f32,
    pub weather_change_probability: f32,
    
    pub current_day: u32,
    pub current_season: Season,
    pub current_year: u32,
}

impl SeasonalCalendar {
    /// Creates a new SeasonalCalendar with default values based on Stardew Valley benchmarks.
    pub fn new() -> Self {
        Self {
            days_per_season: 28,
            seasons_per_year: 4,
            day_duration_real_seconds: 860.0,
            weather_change_probability: 0.25,
            current_day: 1,
            current_season: Season::Spring,
            current_year: 1,
        }
    }

    /// Advances the calendar by one day, handling season and year transitions.
    pub fn advance_day(&mut self) {
        self.current_day += 1;
        if self.current_day > self.days_per_season {
            self.current_day = 1;
            self.current_season = self.current_season.next();
            
            if self.current_season == Season::Spring {
                self.current_year += 1;
            }
        }
    }

    /// Calculates the total number of days elapsed since the start of the game.
    pub fn total_days_elapsed(&self) -> u32 {
        let season_index = match self.current_season {
            Season::Spring => 0,
            Season::Summer => 1,
            Season::Autumn => 2,
            Season::Winter => 3,
        };
        
        let days_from_years = (self.current_year - 1) * self.seasons_per_year * self.days_per_season;
        let days_from_seasons = season_index * self.days_per_season;
        let days_from_current_season = self.current_day - 1;
        
        days_from_years + days_from_seasons + days_from_current_season
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_advance_day_and_season_transition() {
        let mut calendar = SeasonalCalendar::new();
        assert_eq!(calendar.current_day, 1);
        assert_eq!(calendar.current_season, Season::Spring);
        assert_eq!(calendar.current_year, 1);

        // Advance to the last day of Spring
        for _ in 0..27 {
            calendar.advance_day();
        }
        assert_eq!(calendar.current_day, 28);
        assert_eq!(calendar.current_season, Season::Spring);

        // Advance to the first day of Summer
        calendar.advance_day();
        assert_eq!(calendar.current_day, 1);
        assert_eq!(calendar.current_season, Season::Summer);
        assert_eq!(calendar.current_year, 1);
    }

    #[test]
    fn test_year_transition() {
        let mut calendar = SeasonalCalendar::new();
        
        // Advance through all 4 seasons (4 * 28 = 112 days)
        for _ in 0..112 {
            calendar.advance_day();
        }
        
        assert_eq!(calendar.current_day, 1);
        assert_eq!(calendar.current_season, Season::Spring);
        assert_eq!(calendar.current_year, 2);
    }

    #[test]
    fn test_total_days_elapsed() {
        let mut calendar = SeasonalCalendar::new();
        assert_eq!(calendar.total_days_elapsed(), 0);

        calendar.advance_day();
        assert_eq!(calendar.total_days_elapsed(), 1);

        // Advance to Summer day 1
        for _ in 0..27 {
            calendar.advance_day();
        }
        assert_eq!(calendar.total_days_elapsed(), 28);
    }
}
