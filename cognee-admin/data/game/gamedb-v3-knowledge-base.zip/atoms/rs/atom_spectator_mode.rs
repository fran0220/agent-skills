#[derive(Debug, Clone, PartialEq)]
pub struct SpectatorMode {
    pub broadcast_delay: u32,
    pub camera_move_speed: f32,
    pub fov_spectator: f32,
    pub xray_enabled: bool,
    pub auto_director_enabled: bool,
}

impl SpectatorMode {
    /// Creates a new SpectatorMode with default values based on CS:GO benchmarks.
    pub fn new() -> Self {
        Self {
            broadcast_delay: 180,
            camera_move_speed: 5.0,
            fov_spectator: 90.0,
            xray_enabled: true,
            auto_director_enabled: true,
        }
    }

    /// Calculates the effective broadcast time given the current server time.
    /// Ensures that the spectator sees the game with the configured delay.
    pub fn get_broadcast_time(&self, current_server_time: u32) -> u32 {
        if current_server_time < self.broadcast_delay {
            0
        } else {
            current_server_time - self.broadcast_delay
        }
    }

    /// Determines if a specific entity should be visible through walls.
    /// This depends on whether X-Ray is enabled.
    pub fn can_see_through_walls(&self) -> bool {
        self.xray_enabled
    }

    /// Calculates the new camera position based on input direction and delta time.
    pub fn calculate_camera_movement(&self, current_pos: f32, direction: f32, delta_time: f32) -> f32 {
        // direction should be normalized between -1.0 and 1.0
        let clamped_dir = direction.clamp(-1.0, 1.0);
        current_pos + (clamped_dir * self.camera_move_speed * delta_time)
    }
}

impl Default for SpectatorMode {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_get_broadcast_time() {
        let spectator = SpectatorMode::new();
        
        // Server time is less than delay
        assert_eq!(spectator.get_broadcast_time(100), 0);
        
        // Server time is exactly delay
        assert_eq!(spectator.get_broadcast_time(180), 0);
        
        // Server time is greater than delay
        assert_eq!(spectator.get_broadcast_time(200), 20);
    }

    #[test]
    fn test_calculate_camera_movement() {
        let spectator = SpectatorMode::new();
        
        let current_pos = 10.0;
        let delta_time = 0.5; // half a second
        
        // Move positive direction
        let new_pos = spectator.calculate_camera_movement(current_pos, 1.0, delta_time);
        assert_eq!(new_pos, 10.0 + (1.0 * 5.0 * 0.5)); // 12.5
        
        // Move negative direction
        let new_pos_neg = spectator.calculate_camera_movement(current_pos, -1.0, delta_time);
        assert_eq!(new_pos_neg, 10.0 + (-1.0 * 5.0 * 0.5)); // 7.5
        
        // Move with clamped direction
        let new_pos_clamp = spectator.calculate_camera_movement(current_pos, 2.0, delta_time);
        assert_eq!(new_pos_clamp, 10.0 + (1.0 * 5.0 * 0.5)); // 12.5
    }

    #[test]
    fn test_can_see_through_walls() {
        let mut spectator = SpectatorMode::new();
        assert_eq!(spectator.can_see_through_walls(), true);
        
        spectator.xray_enabled = false;
        assert_eq!(spectator.can_see_through_walls(), false);
    }
}
