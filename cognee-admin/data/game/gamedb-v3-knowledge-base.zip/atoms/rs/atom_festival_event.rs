#[derive(Debug, Clone, PartialEq)]
pub struct FestivalEventParams {
    pub duration_days: u32,
    pub preparation_time: u32,
    pub exclusive_currency_rate: f32,
    pub participation_reward_multiplier: f32,
    pub minigame_difficulty_scaling: f32,
}

impl FestivalEventParams {
    /// Creates a new FestivalEventParams with default values based on benchmark data.
    pub fn new() -> Self {
        Self {
            duration_days: 14, // Genshin Impact v4.0
            preparation_time: 3, // Stardew Valley v1.5
            exclusive_currency_rate: 1.5, // Animal Crossing: NH v2.0
            participation_reward_multiplier: 2.0, // Genshin Impact v4.0
            minigame_difficulty_scaling: 1.0, // Stardew Valley v1.5
        }
    }

    /// Calculates the total exclusive currency earned based on participation time.
    pub fn calculate_total_currency(&self, days_participated: u32, hours_per_day: f32) -> f32 {
        let effective_days = days_participated.min(self.duration_days);
        let total_minutes = effective_days as f32 * hours_per_day * 60.0;
        total_minutes * self.exclusive_currency_rate
    }

    /// Calculates the final reward amount after applying the participation multiplier.
    pub fn calculate_reward(&self, base_reward: f32) -> f32 {
        base_reward * self.participation_reward_multiplier
    }

    /// Checks if the festival is currently active given the current day and the start day.
    pub fn is_festival_active(&self, current_day: u32, start_day: u32) -> bool {
        if current_day < start_day {
            return false;
        }
        let end_day = start_day + self.duration_days - 1;
        current_day <= end_day
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_total_currency() {
        let params = FestivalEventParams::new();
        // 2 days, 2 hours per day = 240 minutes. 240 * 1.5 = 360.0
        let currency = params.calculate_total_currency(2, 2.0);
        assert_eq!(currency, 360.0);

        // Cap at duration_days (14)
        let currency_capped = params.calculate_total_currency(20, 1.0);
        // 14 days * 1 hour * 60 mins = 840 mins. 840 * 1.5 = 1260.0
        assert_eq!(currency_capped, 1260.0);
    }

    #[test]
    fn test_calculate_reward() {
        let params = FestivalEventParams::new();
        let reward = params.calculate_reward(100.0);
        assert_eq!(reward, 200.0);
    }

    #[test]
    fn test_is_festival_active() {
        let params = FestivalEventParams::new();
        // Starts on day 10, duration is 14 days (ends on day 23)
        assert_eq!(params.is_festival_active(9, 10), false);
        assert_eq!(params.is_festival_active(10, 10), true);
        assert_eq!(params.is_festival_active(15, 10), true);
        assert_eq!(params.is_festival_active(23, 10), true);
        assert_eq!(params.is_festival_active(24, 10), false);
    }
}
