#[derive(Debug, Clone)]
pub struct OfflineProgressParams {
    pub max_offline_time_hours: u32,
    pub base_gold_rate_per_minute: f32,
    pub base_exp_rate_per_minute: f32,
    pub vip_time_multiplier: f32,
    pub min_offline_time_minutes: u32,
}

impl OfflineProgressParams {
    /// Creates a new OfflineProgressParams with default values based on AFK Arena v1.100 benchmarks.
    pub fn new() -> Self {
        Self {
            max_offline_time_hours: 12,
            base_gold_rate_per_minute: 50.0,
            base_exp_rate_per_minute: 25.0,
            vip_time_multiplier: 1.0,
            min_offline_time_minutes: 1,
        }
    }

    /// Calculates the effective maximum offline time in minutes, factoring in the VIP multiplier.
    pub fn effective_max_time_minutes(&self) -> f32 {
        (self.max_offline_time_hours as f32) * 60.0 * self.vip_time_multiplier
    }

    /// Calculates the offline rewards (gold, exp) given the time away in minutes.
    /// Returns (0.0, 0.0) if the time away is less than the minimum required time.
    pub fn calculate_rewards(&self, time_away_minutes: f32) -> (f32, f32) {
        if time_away_minutes < (self.min_offline_time_minutes as f32) {
            return (0.0, 0.0);
        }

        let max_time = self.effective_max_time_minutes();
        let effective_time = if time_away_minutes > max_time {
            max_time
        } else {
            time_away_minutes
        };

        let gold_reward = effective_time * self.base_gold_rate_per_minute;
        let exp_reward = effective_time * self.base_exp_rate_per_minute;

        (gold_reward, exp_reward)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_rewards_below_minimum() {
        let params = OfflineProgressParams::new();
        // 0.5 minutes is below the 1 minute minimum
        let (gold, exp) = params.calculate_rewards(0.5);
        assert_eq!(gold, 0.0);
        assert_eq!(exp, 0.0);
    }

    #[test]
    fn test_calculate_rewards_normal() {
        let params = OfflineProgressParams::new();
        // 60 minutes of offline time
        let (gold, exp) = params.calculate_rewards(60.0);
        assert_eq!(gold, 3000.0); // 60 * 50.0
        assert_eq!(exp, 1500.0);  // 60 * 25.0
    }

    #[test]
    fn test_calculate_rewards_capped() {
        let mut params = OfflineProgressParams::new();
        params.max_offline_time_hours = 12;
        params.vip_time_multiplier = 1.0;
        
        // 12 hours = 720 minutes. Let's simulate 20 hours (1200 minutes)
        let (gold, exp) = params.calculate_rewards(1200.0);
        
        // Should be capped at 720 minutes
        assert_eq!(gold, 720.0 * 50.0);
        assert_eq!(exp, 720.0 * 25.0);
    }

    #[test]
    fn test_calculate_rewards_with_vip() {
        let mut params = OfflineProgressParams::new();
        params.max_offline_time_hours = 12;
        params.vip_time_multiplier = 1.5; // Increases cap to 18 hours (1080 minutes)
        
        // Simulate 20 hours (1200 minutes)
        let (gold, exp) = params.calculate_rewards(1200.0);
        
        // Should be capped at 1080 minutes
        assert_eq!(gold, 1080.0 * 50.0);
        assert_eq!(exp, 1080.0 * 25.0);
    }
}
