#[derive(Debug, Clone, Copy)]
pub struct HeadshotMultiParams {
    pub base_multiplier: f32,
    pub helmet_reduction: f32,
    pub distance_falloff: f32,
    pub hitbox_scale: f32,
}

impl HeadshotMultiParams {
    /// Creates a new HeadshotMultiParams with default values based on CS:GO benchmark.
    pub fn new() -> Self {
        Self {
            base_multiplier: 4.0,
            helmet_reduction: 0.5,
            distance_falloff: 0.98,
            hitbox_scale: 1.0,
        }
    }

    /// Calculates the final damage multiplier based on whether the target has a helmet.
    pub fn calculate_multiplier(&self, has_helmet: bool) -> f32 {
        if has_helmet {
            self.base_multiplier * (1.0 - self.helmet_reduction)
        } else {
            self.base_multiplier
        }
    }

    /// Calculates the final damage applied to the target.
    pub fn calculate_damage(&self, base_damage: f32, has_helmet: bool, distance: f32) -> f32 {
        let multiplier = self.calculate_multiplier(has_helmet);
        let falloff_factor = self.distance_falloff.powf(distance / 10.0); // Assuming falloff applies every 10 units
        base_damage * multiplier * falloff_factor
    }
}

impl Default for HeadshotMultiParams {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_multiplier() {
        let params = HeadshotMultiParams::new();
        
        // Without helmet: multiplier should be 4.0
        assert_eq!(params.calculate_multiplier(false), 4.0);
        
        // With helmet: multiplier should be 4.0 * (1.0 - 0.5) = 2.0
        assert_eq!(params.calculate_multiplier(true), 2.0);
    }

    #[test]
    fn test_calculate_damage() {
        let params = HeadshotMultiParams::new();
        let base_damage = 36.0; // AK-47 base damage
        
        // Point blank, no helmet
        let damage_no_helmet = params.calculate_damage(base_damage, false, 0.0);
        assert_eq!(damage_no_helmet, 144.0);
        
        // Point blank, with helmet
        let damage_with_helmet = params.calculate_damage(base_damage, true, 0.0);
        assert_eq!(damage_with_helmet, 72.0);
        
        // At distance (10 units), no helmet
        let damage_distance = params.calculate_damage(base_damage, false, 10.0);
        assert_eq!(damage_distance, 144.0 * 0.98);
    }
}
