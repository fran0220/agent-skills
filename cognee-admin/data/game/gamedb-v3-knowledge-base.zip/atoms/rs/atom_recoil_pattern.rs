#[derive(Debug, Clone)]
pub struct RecoilPattern {
    pub vertical_recoil_base: f32,
    pub horizontal_recoil_base: f32,
    pub recoil_variance: f32,
    pub recovery_time: f32,
    pub pattern_length: u32,
}

impl RecoilPattern {
    /// Creates a new RecoilPattern with default benchmark values (CS:GO AK-47)
    pub fn new() -> Self {
        Self {
            vertical_recoil_base: 2.1,
            horizontal_recoil_base: 0.8,
            recoil_variance: 0.4,
            recovery_time: 0.45,
            pattern_length: 30,
        }
    }

    /// Calculates the deterministic recoil offset for a given shot index.
    /// Returns a tuple of (pitch_offset, yaw_offset).
    pub fn calculate_recoil_offset(&self, shot_index: u32) -> (f32, f32) {
        if shot_index == 0 {
            return (0.0, 0.0);
        }

        let clamped_index = shot_index.min(self.pattern_length);
        
        // Simple simulated pattern:
        // Vertical recoil increases linearly up to a point, then plateaus.
        let vertical_multiplier = (clamped_index as f32).min(10.0);
        let pitch_offset = self.vertical_recoil_base * vertical_multiplier;

        // Horizontal recoil sways left and right based on sine wave.
        let sway = (clamped_index as f32 * 0.5).sin();
        let yaw_offset = self.horizontal_recoil_base * sway * (clamped_index as f32).min(15.0) / 15.0;

        (pitch_offset, yaw_offset)
    }

    /// Calculates the recovery progress based on time since firing stopped.
    /// Returns a value between 0.0 (no recovery) and 1.0 (fully recovered).
    pub fn calculate_recovery_progress(&self, time_since_stop: f32) -> f32 {
        if time_since_stop <= 0.0 {
            return 0.0;
        }
        if time_since_stop >= self.recovery_time {
            return 1.0;
        }
        
        // Linear recovery for simplicity
        time_since_stop / self.recovery_time
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_recoil_offset_first_shot() {
        let recoil = RecoilPattern::new();
        let (pitch, yaw) = recoil.calculate_recoil_offset(0);
        assert_eq!(pitch, 0.0);
        assert_eq!(yaw, 0.0);
    }

    #[test]
    fn test_recoil_offset_progression() {
        let recoil = RecoilPattern::new();
        let (pitch_1, _) = recoil.calculate_recoil_offset(1);
        let (pitch_5, _) = recoil.calculate_recoil_offset(5);
        let (pitch_15, _) = recoil.calculate_recoil_offset(15);
        
        assert!(pitch_5 > pitch_1);
        // Pitch should plateau after 10 shots based on our formula
        assert_eq!(pitch_15, recoil.vertical_recoil_base * 10.0);
    }

    #[test]
    fn test_recovery_progress() {
        let recoil = RecoilPattern::new();
        
        assert_eq!(recoil.calculate_recovery_progress(0.0), 0.0);
        assert_eq!(recoil.calculate_recovery_progress(recoil.recovery_time / 2.0), 0.5);
        assert_eq!(recoil.calculate_recovery_progress(recoil.recovery_time), 1.0);
        assert_eq!(recoil.calculate_recovery_progress(recoil.recovery_time + 1.0), 1.0);
    }
}
