#[derive(Debug, Clone)]
pub struct TrafficSimParams {
    pub max_speed: f32,
    pub acceleration: f32,
    pub braking_deceleration: f32,
    pub vehicle_length: f32,
    pub safe_following_distance: f32,
    pub pathfinding_weight_distance: f32,
    pub pathfinding_weight_traffic: f32,
}

impl TrafficSimParams {
    /// Creates a new TrafficSimParams with default values based on Cities: Skylines benchmarks.
    pub fn new() -> Self {
        Self {
            max_speed: 50.0,
            acceleration: 3.0,
            braking_deceleration: 5.0,
            vehicle_length: 4.5,
            safe_following_distance: 2.0,
            pathfinding_weight_distance: 0.5,
            pathfinding_weight_traffic: 0.5,
        }
    }

    /// Calculates the safe speed for a vehicle based on the distance to the vehicle ahead.
    /// Uses a simplified car-following model.
    pub fn calculate_safe_speed(&self, current_speed: f32, distance_to_leader: f32, leader_speed: f32) -> f32 {
        let gap = distance_to_leader - self.vehicle_length;
        if gap <= self.safe_following_distance {
            return 0.0; // Stop if too close
        }

        // Time to reach the leader if both maintain current speeds
        let relative_speed = current_speed - leader_speed;
        
        if relative_speed <= 0.0 {
            // Leader is faster or same speed, can accelerate up to max speed
            return (current_speed + self.acceleration).min(self.max_speed);
        }

        // Calculate required braking distance
        let braking_distance = (current_speed * current_speed) / (2.0 * self.braking_deceleration);
        
        if gap < braking_distance + self.safe_following_distance {
            // Need to brake
            return (current_speed - self.braking_deceleration).max(0.0);
        }

        // Safe to accelerate
        (current_speed + self.acceleration).min(self.max_speed)
    }

    /// Calculates the cost of a path segment for routing.
    pub fn calculate_path_cost(&self, distance: f32, traffic_density: f32) -> f32 {
        let distance_cost = distance * self.pathfinding_weight_distance;
        let traffic_cost = traffic_density * self.pathfinding_weight_traffic * distance; // Traffic cost scales with distance
        distance_cost + traffic_cost
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_safe_speed() {
        let params = TrafficSimParams::new();
        
        // Test stopping when too close
        let speed = params.calculate_safe_speed(30.0, 5.0, 0.0);
        assert_eq!(speed, 0.0);

        // Test accelerating when leader is faster and far away
        let speed2 = params.calculate_safe_speed(20.0, 100.0, 30.0);
        assert_eq!(speed2, 23.0); // 20.0 + 3.0 (acceleration)

        // Test braking when approaching a slower leader
        let speed3 = params.calculate_safe_speed(40.0, 30.0, 10.0);
        assert_eq!(speed3, 35.0); // 40.0 - 5.0 (braking_deceleration)
    }

    #[test]
    fn test_calculate_path_cost() {
        let params = TrafficSimParams::new();
        
        // Low traffic
        let cost1 = params.calculate_path_cost(100.0, 0.1);
        assert_eq!(cost1, 50.0 + 5.0); // 100 * 0.5 + 0.1 * 0.5 * 100

        // High traffic
        let cost2 = params.calculate_path_cost(100.0, 1.0);
        assert_eq!(cost2, 50.0 + 50.0); // 100 * 0.5 + 1.0 * 0.5 * 100
        
        assert!(cost2 > cost1);
    }
}
