pub struct SwapMatch3Params {
    pub grid_width: u32,
    pub grid_height: u32,
    pub element_types: u32,
    pub swap_duration: f32,
    pub fall_speed: f32,
    pub match_score: u32,
}

impl SwapMatch3Params {
    pub fn new() -> Self {
        Self {
            grid_width: 9,
            grid_height: 9,
            element_types: 6,
            swap_duration: 0.3,
            fall_speed: 10.0,
            match_score: 60,
        }
    }

    /// Calculates the base score for a match of a given length.
    /// Formula: match_score * (match_length - 2)
    pub fn calculate_match_score(&self, match_length: u32) -> u32 {
        if match_length < 3 {
            return 0;
        }
        self.match_score * (match_length - 2)
    }

    /// Calculates the time it takes for an element to fall a given number of cells.
    /// Formula: cells / fall_speed
    pub fn calculate_fall_time(&self, cells: u32) -> f32 {
        if self.fall_speed <= 0.0 {
            return 0.0;
        }
        (cells as f32) / self.fall_speed
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_match_score() {
        let params = SwapMatch3Params::new();
        assert_eq!(params.calculate_match_score(2), 0);
        assert_eq!(params.calculate_match_score(3), 60);
        assert_eq!(params.calculate_match_score(4), 120);
        assert_eq!(params.calculate_match_score(5), 180);
    }

    #[test]
    fn test_calculate_fall_time() {
        let params = SwapMatch3Params::new();
        assert_eq!(params.calculate_fall_time(0), 0.0);
        assert_eq!(params.calculate_fall_time(5), 0.5);
        assert_eq!(params.calculate_fall_time(10), 1.0);
    }
}
