#[derive(Debug, Clone, PartialEq)]
pub struct PhysicsPuzzleParams {
    pub gravity_scale: f32,
    pub object_mass: f32,
    pub friction_coeff: f32,
    pub bounciness: f32,
    pub solve_tolerance: f32,
}

impl PhysicsPuzzleParams {
    /// Creates a new PhysicsPuzzleParams with default values based on benchmark data.
    pub fn new() -> Self {
        Self {
            gravity_scale: 1.0,
            object_mass: 50.0,
            friction_coeff: 0.6,
            bounciness: 0.2,
            solve_tolerance: 0.1,
        }
    }

    /// Calculates the gravitational force applied to an object.
    /// F = m * g * gravity_scale
    pub fn calculate_gravity_force(&self, base_gravity: f32) -> f32 {
        self.object_mass * base_gravity * self.gravity_scale
    }

    /// Checks if the object's position is within the solve tolerance of the target position.
    pub fn is_solved(&self, current_pos: f32, target_pos: f32) -> bool {
        (current_pos - target_pos).abs() <= self.solve_tolerance
    }

    /// Calculates the friction force based on the normal force.
    /// F_friction = friction_coeff * F_normal
    pub fn calculate_friction_force(&self, normal_force: f32) -> f32 {
        self.friction_coeff * normal_force
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_gravity_force() {
        let params = PhysicsPuzzleParams::new();
        let base_gravity = 9.81;
        let expected_force = 50.0 * 9.81 * 1.0;
        assert_eq!(params.calculate_gravity_force(base_gravity), expected_force);
    }

    #[test]
    fn test_is_solved() {
        let params = PhysicsPuzzleParams::new();
        
        // Within tolerance
        assert!(params.is_solved(10.05, 10.0));
        assert!(params.is_solved(9.95, 10.0));
        
        // Outside tolerance
        assert!(!params.is_solved(10.2, 10.0));
        assert!(!params.is_solved(9.8, 10.0));
    }

    #[test]
    fn test_calculate_friction_force() {
        let params = PhysicsPuzzleParams::new();
        let normal_force = 100.0;
        let expected_friction = 0.6 * 100.0;
        assert_eq!(params.calculate_friction_force(normal_force), expected_friction);
    }
}
