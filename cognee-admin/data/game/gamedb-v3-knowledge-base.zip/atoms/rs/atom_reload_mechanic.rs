pub struct ReloadMechanic {
    pub reload_time: f32,
    pub magazine_size: u32,
    pub reserve_ammo: u32,
    pub active_reload_window_start: f32,
    pub active_reload_window_end: f32,
    pub can_interrupt: bool,
    
    // State variables
    pub current_magazine: u32,
    pub is_reloading: bool,
    pub reload_progress: f32,
}

impl ReloadMechanic {
    pub fn new() -> Self {
        Self {
            reload_time: 1.5,
            magazine_size: 30,
            reserve_ammo: 90,
            active_reload_window_start: 0.5,
            active_reload_window_end: 0.6,
            can_interrupt: true,
            current_magazine: 30,
            is_reloading: false,
            reload_progress: 0.0,
        }
    }

    pub fn start_reload(&mut self) -> bool {
        if self.current_magazine < self.magazine_size && self.reserve_ammo > 0 && !self.is_reloading {
            self.is_reloading = true;
            self.reload_progress = 0.0;
            true
        } else {
            false
        }
    }

    pub fn update(&mut self, delta_time: f32) -> bool {
        if !self.is_reloading {
            return false;
        }

        self.reload_progress += delta_time;

        if self.reload_progress >= self.reload_time {
            self.finish_reload();
            true
        } else {
            false
        }
    }

    pub fn attempt_active_reload(&mut self) -> Option<bool> {
        if !self.is_reloading {
            return None;
        }

        let progress_ratio = self.reload_progress / self.reload_time;
        
        if progress_ratio >= self.active_reload_window_start && progress_ratio <= self.active_reload_window_end {
            // Success
            self.finish_reload();
            Some(true)
        } else {
            // Failure
            self.is_reloading = false;
            self.reload_progress = 0.0;
            Some(false)
        }
    }

    fn finish_reload(&mut self) {
        let needed = self.magazine_size - self.current_magazine;
        let to_load = std::cmp::min(needed, self.reserve_ammo);
        
        self.current_magazine += to_load;
        self.reserve_ammo -= to_load;
        
        self.is_reloading = false;
        self.reload_progress = 0.0;
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_normal_reload() {
        let mut mechanic = ReloadMechanic::new();
        mechanic.current_magazine = 10;
        
        assert!(mechanic.start_reload());
        assert!(mechanic.is_reloading);
        
        // Update halfway
        assert!(!mechanic.update(0.75));
        assert_eq!(mechanic.current_magazine, 10);
        
        // Finish reload
        assert!(mechanic.update(0.75));
        assert!(!mechanic.is_reloading);
        assert_eq!(mechanic.current_magazine, 30);
        assert_eq!(mechanic.reserve_ammo, 70);
    }

    #[test]
    fn test_active_reload_success() {
        let mut mechanic = ReloadMechanic::new();
        mechanic.current_magazine = 0;
        
        mechanic.start_reload();
        
        // Update to 55% (within 0.5 - 0.6 window)
        mechanic.update(1.5 * 0.55);
        
        let result = mechanic.attempt_active_reload();
        assert_eq!(result, Some(true));
        assert!(!mechanic.is_reloading);
        assert_eq!(mechanic.current_magazine, 30);
    }
    
    #[test]
    fn test_active_reload_failure() {
        let mut mechanic = ReloadMechanic::new();
        mechanic.current_magazine = 0;
        
        mechanic.start_reload();
        
        // Update to 20% (outside window)
        mechanic.update(1.5 * 0.2);
        
        let result = mechanic.attempt_active_reload();
        assert_eq!(result, Some(false));
        assert!(!mechanic.is_reloading);
        assert_eq!(mechanic.current_magazine, 0); // Reload failed, mag still empty
    }
}
