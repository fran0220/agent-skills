#[derive(Debug, Clone, PartialEq)]
pub struct GlideFloatParams {
    pub glide_fall_speed: f32,
    pub horizontal_speed: f32,
    pub stamina_drain_rate: f32,
    pub deploy_delay: f32,
    pub updraft_lift: f32,
}

impl GlideFloatParams {
    /// Creates a new GlideFloatParams with default values based on Breath of the Wild benchmark.
    pub fn new() -> Self {
        Self {
            glide_fall_speed: 5.0,
            horizontal_speed: 12.0,
            stamina_drain_rate: 10.0,
            deploy_delay: 0.1,
            updraft_lift: 15.0,
        }
    }
}

impl Default for GlideFloatParams {
    fn default() -> Self {
        Self::new()
    }
}

pub struct GlideFloatState {
    pub is_gliding: bool,
    pub current_stamina: f32,
    pub vertical_velocity: f32,
    pub horizontal_velocity: f32,
    pub time_since_deploy: f32,
}

impl GlideFloatState {
    pub fn new(initial_stamina: f32) -> Self {
        Self {
            is_gliding: false,
            current_stamina: initial_stamina,
            vertical_velocity: 0.0,
            horizontal_velocity: 0.0,
            time_since_deploy: 0.0,
        }
    }

    /// Attempts to deploy the glider. Returns true if successful.
    pub fn deploy_glider(&mut self, params: &GlideFloatParams) -> bool {
        if self.current_stamina > 0.0 && !self.is_gliding {
            self.is_gliding = true;
            self.time_since_deploy = 0.0;
            return true;
        }
        false
    }

    /// Updates the glide state over a given time delta (dt).
    pub fn update(&mut self, dt: f32, params: &GlideFloatParams, in_updraft: bool) {
        if !self.is_gliding {
            return;
        }

        self.time_since_deploy += dt;

        // Check if deploy delay has passed
        if self.time_since_deploy >= params.deploy_delay {
            // Drain stamina
            self.current_stamina -= params.stamina_drain_rate * dt;
            if self.current_stamina <= 0.0 {
                self.current_stamina = 0.0;
                self.is_gliding = false; // Force cancel glide if stamina depleted
                return;
            }

            // Apply vertical velocity
            if in_updraft {
                self.vertical_velocity = params.updraft_lift;
            } else {
                // Gradually approach glide fall speed (simplified as immediate cap here)
                self.vertical_velocity = -params.glide_fall_speed;
            }

            // Apply horizontal velocity (simplified as constant speed)
            self.horizontal_velocity = params.horizontal_speed;
        }
    }

    /// Cancels the glide state.
    pub fn cancel_glider(&mut self) {
        self.is_gliding = false;
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_glider_deployment_and_stamina_drain() {
        let params = GlideFloatParams::new();
        let mut state = GlideFloatState::new(100.0);

        // Deploy glider
        assert!(state.deploy_glider(&params));
        assert!(state.is_gliding);

        // Update before deploy delay finishes
        state.update(0.05, &params, false);
        assert_eq!(state.current_stamina, 100.0); // Stamina shouldn't drain yet
        assert_eq!(state.vertical_velocity, 0.0);

        // Update after deploy delay
        state.update(0.1, &params, false);
        // Total time is 0.15, which is > 0.1 (deploy_delay).
        // The second update() call adds 0.1 to time_since_deploy, making it 0.15.
        // Stamina drains by 10.0 * 0.1 = 1.0
        assert_eq!(state.current_stamina, 99.0);
        assert_eq!(state.vertical_velocity, -5.0);
        assert_eq!(state.horizontal_velocity, 12.0);
    }

    #[test]
    fn test_glider_updraft() {
        let params = GlideFloatParams::new();
        let mut state = GlideFloatState::new(50.0);

        state.deploy_glider(&params);
        
        // Fast forward past deploy delay
        state.update(0.2, &params, true); // in_updraft = true

        assert_eq!(state.vertical_velocity, 15.0); // Updraft lift
        assert_eq!(state.current_stamina, 48.0); // 50.0 - (10.0 * 0.2)
    }

    #[test]
    fn test_glider_stamina_depletion() {
        let params = GlideFloatParams::new();
        let mut state = GlideFloatState::new(1.0); // Only 1 stamina

        state.deploy_glider(&params);
        
        // Update past deploy delay and drain all stamina
        state.update(0.2, &params, false); // Drains 2.0 stamina, but we only have 1.0

        assert_eq!(state.current_stamina, 0.0);
        assert!(!state.is_gliding); // Should be forced out of glide
    }
}
