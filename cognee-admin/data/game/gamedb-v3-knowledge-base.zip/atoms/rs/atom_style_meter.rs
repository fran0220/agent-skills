#[derive(Debug, Clone)]
pub struct StyleMeterParams {
    pub base_decay_rate: f32,
    pub decay_delay: f32,
    pub damage_penalty: f32,
    pub stale_move_penalty: f32,
    pub max_rank_threshold: u32,
}

impl StyleMeterParams {
    /// Creates a new StyleMeterParams with default values based on Devil May Cry 5 benchmark.
    pub fn new() -> Self {
        Self {
            base_decay_rate: 5.0,
            decay_delay: 3.0,
            damage_penalty: 0.5,
            stale_move_penalty: 0.5,
            max_rank_threshold: 10000,
        }
    }
}

impl Default for StyleMeterParams {
    fn default() -> Self {
        Self::new()
    }
}

#[derive(Debug, Clone)]
pub struct StyleMeterState {
    pub current_points: f32,
    pub time_since_last_hit: f32,
}

impl StyleMeterState {
    pub fn new() -> Self {
        Self {
            current_points: 0.0,
            time_since_last_hit: 0.0,
        }
    }

    /// Calculates the points gained from an attack, applying the stale move penalty if applicable.
    pub fn calculate_hit_points(
        &mut self,
        base_points: f32,
        is_stale: bool,
        params: &StyleMeterParams,
    ) -> f32 {
        let multiplier = if is_stale {
            params.stale_move_penalty
        } else {
            1.0
        };
        
        let points_gained = base_points * multiplier;
        self.current_points += points_gained;
        
        if self.current_points > params.max_rank_threshold as f32 {
            self.current_points = params.max_rank_threshold as f32;
        }
        
        self.time_since_last_hit = 0.0;
        points_gained
    }

    /// Updates the style meter over time, applying decay if the delay has passed.
    pub fn update_decay(&mut self, delta_time: f32, params: &StyleMeterParams) {
        self.time_since_last_hit += delta_time;
        
        if self.time_since_last_hit > params.decay_delay {
            let decay_amount = params.base_decay_rate * delta_time;
            self.current_points -= decay_amount;
            
            if self.current_points < 0.0 {
                self.current_points = 0.0;
            }
        }
    }

    /// Applies the penalty for taking damage.
    pub fn apply_damage_penalty(&mut self, params: &StyleMeterParams) {
        self.current_points *= params.damage_penalty;
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_hit_points() {
        let params = StyleMeterParams::new();
        let mut state = StyleMeterState::new();

        // Fresh move
        let gained = state.calculate_hit_points(100.0, false, &params);
        assert_eq!(gained, 100.0);
        assert_eq!(state.current_points, 100.0);

        // Stale move
        let gained_stale = state.calculate_hit_points(100.0, true, &params);
        assert_eq!(gained_stale, 50.0); // 100.0 * 0.5
        assert_eq!(state.current_points, 150.0);
    }

    #[test]
    fn test_update_decay() {
        let params = StyleMeterParams::new();
        let mut state = StyleMeterState::new();
        
        state.current_points = 100.0;

        // Before decay delay
        state.update_decay(2.0, &params);
        assert_eq!(state.current_points, 100.0);

        // After decay delay
        state.update_decay(2.0, &params); // Total time = 4.0 > 3.0
        // Decay applied for the delta_time of 2.0
        // Decay amount = 5.0 * 2.0 = 10.0
        assert_eq!(state.current_points, 90.0);
    }

    #[test]
    fn test_apply_damage_penalty() {
        let params = StyleMeterParams::new();
        let mut state = StyleMeterState::new();
        
        state.current_points = 1000.0;
        state.apply_damage_penalty(&params);
        
        assert_eq!(state.current_points, 500.0); // 1000.0 * 0.5
    }
}
