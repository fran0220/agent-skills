#[derive(Debug, Clone, PartialEq)]
pub struct PoiseHyperArmor {
    pub base_poise: f32,
    pub poise_damage: f32,
    pub hyper_armor_multiplier: f32,
    pub poise_reset_time: f32,
    pub stagger_duration: f32,
    pub current_poise: f32,
    pub is_hyper_armor_active: bool,
}

impl PoiseHyperArmor {
    /// Creates a new PoiseHyperArmor instance with default benchmark values.
    pub fn new() -> Self {
        Self {
            base_poise: 50.0,
            poise_damage: 30.0,
            hyper_armor_multiplier: 0.5,
            poise_reset_time: 5.0,
            stagger_duration: 0.8,
            current_poise: 50.0,
            is_hyper_armor_active: false,
        }
    }

    /// Calculates the effective poise damage taken based on hyper armor state.
    pub fn calculate_effective_damage(&self, incoming_damage: f32) -> f32 {
        if self.is_hyper_armor_active {
            incoming_damage * self.hyper_armor_multiplier
        } else {
            incoming_damage
        }
    }

    /// Processes an incoming attack and returns true if the character is staggered.
    pub fn take_hit(&mut self, incoming_damage: f32) -> bool {
        let effective_damage = self.calculate_effective_damage(incoming_damage);
        self.current_poise -= effective_damage;
        
        if self.current_poise <= 0.0 {
            self.current_poise = 0.0;
            true // Staggered
        } else {
            false // Endured
        }
    }

    /// Resets the current poise to the base poise value.
    pub fn reset_poise(&mut self) {
        self.current_poise = self.base_poise;
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_hyper_armor_active_endures_hit() {
        let mut poise_system = PoiseHyperArmor::new();
        poise_system.base_poise = 30.0;
        poise_system.current_poise = 30.0;
        poise_system.hyper_armor_multiplier = 0.5;
        poise_system.is_hyper_armor_active = true;

        // Incoming damage is 40. With 0.5 multiplier, effective damage is 20.
        // Current poise (30) - 20 = 10. Should not stagger.
        let is_staggered = poise_system.take_hit(40.0);
        
        assert_eq!(is_staggered, false);
        assert_eq!(poise_system.current_poise, 10.0);
    }

    #[test]
    fn test_no_hyper_armor_staggers() {
        let mut poise_system = PoiseHyperArmor::new();
        poise_system.base_poise = 30.0;
        poise_system.current_poise = 30.0;
        poise_system.is_hyper_armor_active = false;

        // Incoming damage is 40. No multiplier, effective damage is 40.
        // Current poise (30) - 40 = -10 (clamped to 0). Should stagger.
        let is_staggered = poise_system.take_hit(40.0);
        
        assert_eq!(is_staggered, true);
        assert_eq!(poise_system.current_poise, 0.0);
    }
}
