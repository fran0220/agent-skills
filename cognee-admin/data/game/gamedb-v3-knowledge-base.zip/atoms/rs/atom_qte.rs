#[derive(Debug, Clone, PartialEq)]
pub enum QteResult {
    InProgress,
    Success,
    Failure,
}

#[derive(Debug, Clone)]
pub struct QteParameters {
    pub time_limit: f32,
    pub mash_target: u32,
    pub mash_decay: f32,
    pub hold_duration: f32,
    pub wrong_input_penalty: bool,
}

impl QteParameters {
    /// Creates a new QteParameters instance with default values based on benchmark data (God of War 2018).
    pub fn new() -> Self {
        Self {
            time_limit: 1.5,
            mash_target: 15,
            mash_decay: 0.5,
            hold_duration: 2.0,
            wrong_input_penalty: true,
        }
    }

    /// Processes a single button press QTE.
    /// Returns the current state of the QTE.
    pub fn process_single_input(&self, time_elapsed: f32, is_correct: bool, has_input: bool) -> QteResult {
        if time_elapsed > self.time_limit {
            return QteResult::Failure;
        }

        if has_input {
            if is_correct {
                return QteResult::Success;
            } else if self.wrong_input_penalty {
                return QteResult::Failure;
            }
        }

        QteResult::InProgress
    }

    /// Processes a button mashing QTE.
    /// Calculates the effective presses considering decay over time.
    pub fn process_mash_input(&self, total_presses: u32, time_elapsed: f32) -> QteResult {
        if time_elapsed > self.time_limit {
            return QteResult::Failure;
        }

        let decayed_presses = (total_presses as f32 - (self.mash_decay * time_elapsed)).max(0.0);

        if decayed_presses >= self.mash_target as f32 {
            return QteResult::Success;
        }

        QteResult::InProgress
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_single_input_success() {
        let qte = QteParameters::new();
        let result = qte.process_single_input(1.0, true, true);
        assert_eq!(result, QteResult::Success);
    }

    #[test]
    fn test_single_input_timeout() {
        let qte = QteParameters::new();
        let result = qte.process_single_input(2.0, false, false);
        assert_eq!(result, QteResult::Failure);
    }

    #[test]
    fn test_single_input_wrong_penalty() {
        let qte = QteParameters::new();
        let result = qte.process_single_input(0.5, false, true);
        assert_eq!(result, QteResult::Failure);
    }

    #[test]
    fn test_mash_input_success() {
        let qte = QteParameters::new();
        // 16 presses in 1 second. Decay is 0.5 * 1.0 = 0.5. Effective = 15.5 >= 15
        let result = qte.process_mash_input(16, 1.0);
        assert_eq!(result, QteResult::Success);
    }

    #[test]
    fn test_mash_input_in_progress() {
        let qte = QteParameters::new();
        // 10 presses in 1 second. Decay is 0.5. Effective = 9.5 < 15
        let result = qte.process_mash_input(10, 1.0);
        assert_eq!(result, QteResult::InProgress);
    }
}
