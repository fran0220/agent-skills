#[derive(Debug, Clone)]
pub struct GuildClanParams {
    pub max_members: u32,
    pub creation_cost: u32,
    pub min_level_to_create: u32,
    pub inactivity_kick_days: u32,
    pub max_roles: u32,
}

impl GuildClanParams {
    pub fn new() -> Self {
        Self {
            max_members: 50,
            creation_cost: 10000,
            min_level_to_create: 10,
            inactivity_kick_days: 30,
            max_roles: 4,
        }
    }

    pub fn can_create_guild(&self, player_level: u32, player_gold: u32) -> bool {
        player_level >= self.min_level_to_create && player_gold >= self.creation_cost
    }

    pub fn can_invite_member(&self, current_members: u32) -> bool {
        current_members < self.max_members
    }

    pub fn should_kick_inactive(&self, days_inactive: u32) -> bool {
        days_inactive >= self.inactivity_kick_days
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_can_create_guild() {
        let params = GuildClanParams::new();
        assert!(params.can_create_guild(15, 15000));
        assert!(!params.can_create_guild(5, 15000));
        assert!(!params.can_create_guild(15, 5000));
    }

    #[test]
    fn test_can_invite_member() {
        let params = GuildClanParams::new();
        assert!(params.can_invite_member(49));
        assert!(!params.can_invite_member(50));
    }

    #[test]
    fn test_should_kick_inactive() {
        let params = GuildClanParams::new();
        assert!(params.should_kick_inactive(30));
        assert!(params.should_kick_inactive(45));
        assert!(!params.should_kick_inactive(29));
    }
}
