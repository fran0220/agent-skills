#[derive(Debug, Clone, PartialEq)]
pub struct SpacedRepetitionParams {
    pub initial_interval: f32,
    pub interval_modifier: f32,
    pub easy_bonus: f32,
    pub hard_penalty: f32,
    pub max_interval: f32,
}

impl SpacedRepetitionParams {
    /// Creates a new SpacedRepetitionParams with default values based on Anki v2.1 benchmarks.
    pub fn new() -> Self {
        Self {
            initial_interval: 24.0, // Hours
            interval_modifier: 2.5,
            easy_bonus: 1.3,
            hard_penalty: 0.5,
            max_interval: 36500.0, // Days
        }
    }

    /// Calculates the next interval based on the current interval and the quality of the review.
    /// Quality is represented as an enum or integer, but here we use specific functions for clarity.
    pub fn calculate_next_interval_normal(&self, current_interval: f32) -> f32 {
        let next_interval = current_interval * self.interval_modifier;
        next_interval.min(self.max_interval * 24.0) // Convert max_interval to hours for comparison
    }

    pub fn calculate_next_interval_easy(&self, current_interval: f32) -> f32 {
        let next_interval = current_interval * self.interval_modifier * self.easy_bonus;
        next_interval.min(self.max_interval * 24.0)
    }

    pub fn calculate_next_interval_hard(&self, current_interval: f32) -> f32 {
        let next_interval = current_interval * self.hard_penalty;
        next_interval.max(self.initial_interval) // Should not drop below initial interval
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_next_interval_normal() {
        let params = SpacedRepetitionParams::new();
        let current_interval = 24.0;
        let next_interval = params.calculate_next_interval_normal(current_interval);
        assert_eq!(next_interval, 60.0); // 24.0 * 2.5
    }

    #[test]
    fn test_calculate_next_interval_easy() {
        let params = SpacedRepetitionParams::new();
        let current_interval = 24.0;
        let next_interval = params.calculate_next_interval_easy(current_interval);
        assert_eq!(next_interval, 78.0); // 24.0 * 2.5 * 1.3
    }

    #[test]
    fn test_calculate_next_interval_hard() {
        let params = SpacedRepetitionParams::new();
        let current_interval = 100.0;
        let next_interval = params.calculate_next_interval_hard(current_interval);
        assert_eq!(next_interval, 50.0); // 100.0 * 0.5
    }

    #[test]
    fn test_calculate_next_interval_hard_minimum() {
        let params = SpacedRepetitionParams::new();
        let current_interval = 30.0;
        let next_interval = params.calculate_next_interval_hard(current_interval);
        assert_eq!(next_interval, 24.0); // 30.0 * 0.5 = 15.0, but min is 24.0
    }
}
