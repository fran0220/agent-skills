#[derive(Debug, Clone, PartialEq)]
pub struct LogicDeduction {
    pub clue_count: u32,
    pub grid_size: u32,
    pub complexity_level: f32,
    pub penalty_on_fail: bool,
}

impl LogicDeduction {
    /// Creates a new LogicDeduction atom with default values based on Return of the Obra Dinn benchmark.
    pub fn new() -> Self {
        Self {
            clue_count: 60,
            grid_size: 1,
            complexity_level: 0.9,
            penalty_on_fail: true,
        }
    }

    /// Calculates the estimated time to solve based on complexity and clue count.
    /// Returns the estimated time in minutes.
    pub fn calculate_estimated_solve_time(&self) -> f32 {
        let base_time = (self.clue_count as f32) * 0.5;
        let complexity_multiplier = 1.0 + (self.complexity_level * 2.0);
        base_time * complexity_multiplier
    }

    /// Determines if a deduction attempt is successful based on the provided accuracy.
    /// If penalty_on_fail is true, requires higher accuracy to succeed.
    pub fn attempt_deduction(&self, player_accuracy: f32) -> bool {
        let required_accuracy = if self.penalty_on_fail {
            0.95 // Strict requirement if there's a penalty
        } else {
            0.75 // More lenient if no penalty
        };
        
        player_accuracy >= required_accuracy
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_estimated_solve_time() {
        let atom = LogicDeduction {
            clue_count: 25,
            grid_size: 9,
            complexity_level: 0.5,
            penalty_on_fail: false,
        };
        
        // base_time = 25 * 0.5 = 12.5
        // complexity_multiplier = 1.0 + (0.5 * 2.0) = 2.0
        // expected = 12.5 * 2.0 = 25.0
        assert_eq!(atom.calculate_estimated_solve_time(), 25.0);
    }

    #[test]
    fn test_attempt_deduction() {
        let mut atom = LogicDeduction::new();
        
        // With penalty_on_fail = true, requires 0.95
        atom.penalty_on_fail = true;
        assert_eq!(atom.attempt_deduction(0.90), false);
        assert_eq!(atom.attempt_deduction(0.96), true);
        
        // With penalty_on_fail = false, requires 0.75
        atom.penalty_on_fail = false;
        assert_eq!(atom.attempt_deduction(0.70), false);
        assert_eq!(atom.attempt_deduction(0.80), true);
    }
}
