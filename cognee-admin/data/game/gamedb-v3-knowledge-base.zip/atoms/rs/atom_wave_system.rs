#[derive(Debug, Clone, PartialEq)]
pub enum WaveState {
    Preparation,
    Spawning,
    Combat,
    Completed,
}

#[derive(Debug, Clone)]
pub struct WaveSystemParams {
    pub wave_count: u32,
    pub prep_time: f32,
    pub spawn_interval: f32,
    pub difficulty_multiplier: f32,
    pub max_active_enemies: u32,
}

impl Default for WaveSystemParams {
    fn default() -> Self {
        Self {
            wave_count: 20,
            prep_time: 15.0,
            spawn_interval: 1.0,
            difficulty_multiplier: 1.15,
            max_active_enemies: 300,
        }
    }
}

pub struct WaveSystem {
    pub params: WaveSystemParams,
    pub current_wave: u32,
    pub state: WaveState,
    pub timer: f32,
    pub active_enemies: u32,
    pub enemies_to_spawn: u32,
}

impl WaveSystem {
    pub fn new(params: Option<WaveSystemParams>) -> Self {
        Self {
            params: params.unwrap_or_default(),
            current_wave: 0,
            state: WaveState::Preparation,
            timer: 0.0,
            active_enemies: 0,
            enemies_to_spawn: 0,
        }
    }

    pub fn update(&mut self, delta_time: f32) {
        match self.state {
            WaveState::Preparation => {
                self.timer += delta_time;
                if self.timer >= self.params.prep_time {
                    self.start_next_wave();
                }
            }
            WaveState::Spawning => {
                self.timer += delta_time;
                if self.timer >= self.params.spawn_interval {
                    self.spawn_enemy();
                    self.timer = 0.0;
                }
                if self.enemies_to_spawn == 0 {
                    self.state = WaveState::Combat;
                }
            }
            WaveState::Combat => {
                if self.active_enemies == 0 {
                    if self.current_wave >= self.params.wave_count {
                        self.state = WaveState::Completed;
                    } else {
                        self.state = WaveState::Preparation;
                        self.timer = 0.0;
                    }
                }
            }
            WaveState::Completed => {}
        }
    }

    pub fn start_next_wave(&mut self) {
        self.current_wave += 1;
        self.state = WaveState::Spawning;
        self.timer = 0.0;
        // Calculate enemies to spawn based on wave number and difficulty multiplier
        let base_enemies = 10;
        self.enemies_to_spawn = (base_enemies as f32 * self.params.difficulty_multiplier.powi(self.current_wave as i32 - 1)) as u32;
    }

    pub fn spawn_enemy(&mut self) {
        if self.enemies_to_spawn > 0 && self.active_enemies < self.params.max_active_enemies {
            self.enemies_to_spawn -= 1;
            self.active_enemies += 1;
        }
    }

    pub fn enemy_defeated(&mut self) {
        if self.active_enemies > 0 {
            self.active_enemies -= 1;
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_wave_system_initialization() {
        let system = WaveSystem::new(None);
        assert_eq!(system.state, WaveState::Preparation);
        assert_eq!(system.current_wave, 0);
        assert_eq!(system.params.wave_count, 20);
    }

    #[test]
    fn test_wave_progression() {
        let mut params = WaveSystemParams::default();
        params.prep_time = 5.0;
        params.spawn_interval = 1.0;
        let mut system = WaveSystem::new(Some(params));

        // Advance prep time
        system.update(5.0);
        assert_eq!(system.state, WaveState::Spawning);
        assert_eq!(system.current_wave, 1);
        assert!(system.enemies_to_spawn > 0);

        // Spawn all enemies
        let enemies_to_spawn = system.enemies_to_spawn;
        for _ in 0..enemies_to_spawn {
            system.update(1.0);
        }
        assert_eq!(system.state, WaveState::Combat);
        assert_eq!(system.active_enemies, enemies_to_spawn);

        // Defeat all enemies
        for _ in 0..enemies_to_spawn {
            system.enemy_defeated();
        }
        system.update(0.1); // Trigger state transition
        assert_eq!(system.state, WaveState::Preparation);
    }
}
