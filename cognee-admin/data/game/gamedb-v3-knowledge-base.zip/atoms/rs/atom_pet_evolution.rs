#[derive(Debug, Clone)]
pub struct PetEvolutionParams {
    pub hatch_steps: u32,
    pub evolution_level: u32,
    pub hunger_decay_rate: f32,
    pub happiness_threshold: u32,
}

impl PetEvolutionParams {
    pub fn new() -> Self {
        Self {
            hatch_steps: 5120,
            evolution_level: 16,
            hunger_decay_rate: 1.0,
            happiness_threshold: 220,
        }
    }
}

#[derive(Debug, Clone, PartialEq)]
pub enum PetState {
    Egg,
    Baby,
    Child,
    Adult,
    Evolved,
}

pub struct Pet {
    pub state: PetState,
    pub steps_taken: u32,
    pub level: u32,
    pub hunger: f32,
    pub happiness: u32,
    pub params: PetEvolutionParams,
}

impl Pet {
    pub fn new(params: PetEvolutionParams) -> Self {
        Self {
            state: PetState::Egg,
            steps_taken: 0,
            level: 1,
            hunger: 100.0,
            happiness: 50,
            params,
        }
    }

    pub fn take_steps(&mut self, steps: u32) -> bool {
        if self.state == PetState::Egg {
            self.steps_taken += steps;
            if self.steps_taken >= self.params.hatch_steps {
                self.state = PetState::Baby;
                return true; // Hatched
            }
        }
        false
    }

    pub fn level_up(&mut self) -> bool {
        if self.state == PetState::Adult || self.state == PetState::Child || self.state == PetState::Baby {
            self.level += 1;
            if self.level >= self.params.evolution_level && self.state == PetState::Adult {
                self.state = PetState::Evolved;
                return true; // Evolved
            } else if self.level >= 5 && self.state == PetState::Baby {
                self.state = PetState::Child;
            } else if self.level >= 10 && self.state == PetState::Child {
                self.state = PetState::Adult;
            }
        }
        false
    }

    pub fn update_hunger(&mut self, hours_passed: f32) {
        if self.state != PetState::Egg {
            self.hunger -= self.params.hunger_decay_rate * hours_passed;
            if self.hunger < 0.0 {
                self.hunger = 0.0;
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_hatching() {
        let params = PetEvolutionParams::new();
        let mut pet = Pet::new(params);
        
        assert_eq!(pet.state, PetState::Egg);
        
        let hatched = pet.take_steps(5000);
        assert!(!hatched);
        assert_eq!(pet.state, PetState::Egg);
        
        let hatched = pet.take_steps(200);
        assert!(hatched);
        assert_eq!(pet.state, PetState::Baby);
    }

    #[test]
    fn test_evolution() {
        let params = PetEvolutionParams::new();
        let mut pet = Pet::new(params);
        
        pet.state = PetState::Adult;
        pet.level = 15;
        
        let evolved = pet.level_up();
        assert!(evolved);
        assert_eq!(pet.state, PetState::Evolved);
        assert_eq!(pet.level, 16);
    }

    #[test]
    fn test_hunger_decay() {
        let params = PetEvolutionParams::new();
        let mut pet = Pet::new(params);
        
        pet.state = PetState::Baby;
        pet.hunger = 100.0;
        
        pet.update_hunger(2.5);
        assert_eq!(pet.hunger, 97.5);
    }
}
