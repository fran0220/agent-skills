#[derive(Debug, Clone, PartialEq)]
pub enum EntityState {
    Satisfied,
    Needy,
    Sick,
    Dead,
}

#[derive(Debug, Clone)]
pub struct FeedingCareParams {
    pub max_hunger: f32,
    pub hunger_decay_rate: f32, // Points per hour
    pub feed_amount: f32,
    pub sick_threshold: f32,
    pub death_timer: f32, // Hours
}

impl FeedingCareParams {
    /// Creates a new set of parameters based on Tamagotchi Classic benchmarks.
    pub fn new() -> Self {
        Self {
            max_hunger: 100.0,
            hunger_decay_rate: 1.0,
            feed_amount: 25.0,
            sick_threshold: 0.0,
            death_timer: 24.0,
        }
    }
}

#[derive(Debug, Clone)]
pub struct Entity {
    pub state: EntityState,
    pub current_hunger: f32,
    pub time_sick: f32, // Hours spent in sick state
    pub params: FeedingCareParams,
}

impl Entity {
    pub fn new(params: FeedingCareParams) -> Self {
        Self {
            state: EntityState::Satisfied,
            current_hunger: params.max_hunger,
            time_sick: 0.0,
            params,
        }
    }

    /// Simulates the passage of time, updating hunger and state.
    /// `hours_passed` is the amount of time elapsed since the last update.
    pub fn pass_time(&mut self, hours_passed: f32) {
        if self.state == EntityState::Dead {
            return;
        }

        // Decay hunger
        self.current_hunger -= self.params.hunger_decay_rate * hours_passed;
        if self.current_hunger < 0.0 {
            self.current_hunger = 0.0;
        }

        // Update state based on hunger
        if self.current_hunger <= self.params.sick_threshold {
            if self.state != EntityState::Sick {
                self.state = EntityState::Sick;
                self.time_sick = 0.0; // Reset sick timer when entering sick state
            }
        } else if self.current_hunger < self.params.max_hunger * 0.5 {
            self.state = EntityState::Needy;
        } else {
            self.state = EntityState::Satisfied;
        }

        // Handle sickness progression
        if self.state == EntityState::Sick {
            self.time_sick += hours_passed;
            if self.time_sick >= self.params.death_timer {
                self.state = EntityState::Dead;
            }
        }
    }

    /// Feeds the entity, increasing its hunger level.
    pub fn feed(&mut self) {
        if self.state == EntityState::Dead {
            return;
        }

        self.current_hunger += self.params.feed_amount;
        if self.current_hunger > self.params.max_hunger {
            self.current_hunger = self.params.max_hunger;
        }

        // Feeding might cure sickness if it pushes hunger above threshold,
        // but typically medicine is needed. For simplicity, if hunger is high enough, it's no longer sick.
        if self.current_hunger > self.params.sick_threshold {
            self.time_sick = 0.0;
            if self.current_hunger < self.params.max_hunger * 0.5 {
                self.state = EntityState::Needy;
            } else {
                self.state = EntityState::Satisfied;
            }
        }
    }
    
    /// Heals the entity if it is sick.
    pub fn heal(&mut self) {
        if self.state == EntityState::Sick {
            self.time_sick = 0.0;
            self.state = EntityState::Needy;
            // Optionally give a small hunger boost so it doesn't immediately fall back to sick
            self.current_hunger = self.params.sick_threshold + 10.0; 
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_hunger_decay_and_state_transition() {
        let params = FeedingCareParams::new();
        let mut entity = Entity::new(params);

        assert_eq!(entity.state, EntityState::Satisfied);
        assert_eq!(entity.current_hunger, 100.0);

        // Pass 60 hours. Decay is 1.0 per hour.
        entity.pass_time(60.0);
        assert_eq!(entity.current_hunger, 40.0);
        assert_eq!(entity.state, EntityState::Needy);

        // Pass another 50 hours. Hunger should hit 0.
        entity.pass_time(50.0);
        assert_eq!(entity.current_hunger, 0.0);
        assert_eq!(entity.state, EntityState::Sick);
    }

    #[test]
    fn test_feeding_restores_hunger() {
        let params = FeedingCareParams::new();
        let mut entity = Entity::new(params);

        entity.pass_time(50.0); // Hunger drops to 50
        assert_eq!(entity.current_hunger, 50.0);

        entity.feed(); // Restores 25
        assert_eq!(entity.current_hunger, 75.0);
        assert_eq!(entity.state, EntityState::Satisfied);
    }

    #[test]
    fn test_death_from_neglect() {
        let params = FeedingCareParams::new();
        let mut entity = Entity::new(params);

        // Drop hunger to 0 to make it sick
        entity.pass_time(100.0);
        assert_eq!(entity.state, EntityState::Sick);

        // Pass time equal to death timer
        entity.pass_time(24.0);
        assert_eq!(entity.state, EntityState::Dead);
        
        // Feeding a dead entity does nothing
        entity.feed();
        assert_eq!(entity.state, EntityState::Dead);
    }
}
