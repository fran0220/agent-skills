#[derive(Debug, Clone, PartialEq)]
pub struct TeleportBlink {
    pub max_distance: f32,
    pub cooldown: f32,
    pub requires_los: bool,
    pub charges: u32,
    pub current_charges: u32,
    pub current_cooldown: f32,
}

impl TeleportBlink {
    pub fn new() -> Self {
        Self {
            max_distance: 15.0,
            cooldown: 3.0,
            requires_los: true,
            charges: 3,
            current_charges: 3,
            current_cooldown: 0.0,
        }
    }

    pub fn can_blink(&self) -> bool {
        self.current_charges > 0
    }

    pub fn execute_blink(&mut self, distance: f32) -> Result<f32, &'static str> {
        if !self.can_blink() {
            return Err("No charges available");
        }

        let actual_distance = if distance > self.max_distance {
            self.max_distance
        } else {
            distance
        };

        self.current_charges -= 1;
        if self.current_charges < self.charges && self.current_cooldown <= 0.0 {
            self.current_cooldown = self.cooldown;
        }

        Ok(actual_distance)
    }

    pub fn update(&mut self, delta_time: f32) {
        if self.current_charges < self.charges {
            self.current_cooldown -= delta_time;
            if self.current_cooldown <= 0.0 {
                self.current_charges += 1;
                if self.current_charges < self.charges {
                    self.current_cooldown += self.cooldown;
                } else {
                    self.current_cooldown = 0.0;
                }
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_initial_state() {
        let blink = TeleportBlink::new();
        assert_eq!(blink.max_distance, 15.0);
        assert_eq!(blink.charges, 3);
        assert_eq!(blink.current_charges, 3);
        assert!(blink.can_blink());
    }

    #[test]
    fn test_execute_blink() {
        let mut blink = TeleportBlink::new();
        
        // Blink within max distance
        let dist = blink.execute_blink(10.0).unwrap();
        assert_eq!(dist, 10.0);
        assert_eq!(blink.current_charges, 2);
        assert_eq!(blink.current_cooldown, 3.0);

        // Blink beyond max distance
        let dist2 = blink.execute_blink(20.0).unwrap();
        assert_eq!(dist2, 15.0);
        assert_eq!(blink.current_charges, 1);
    }

    #[test]
    fn test_cooldown_update() {
        let mut blink = TeleportBlink::new();
        blink.execute_blink(5.0).unwrap();
        assert_eq!(blink.current_charges, 2);

        blink.update(1.0);
        assert_eq!(blink.current_cooldown, 2.0);
        assert_eq!(blink.current_charges, 2);

        blink.update(2.0);
        assert_eq!(blink.current_cooldown, 0.0);
        assert_eq!(blink.current_charges, 3);
    }
}
