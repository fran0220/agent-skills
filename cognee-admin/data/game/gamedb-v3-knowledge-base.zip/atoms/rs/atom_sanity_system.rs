#[derive(Debug, Clone, PartialEq)]
pub enum SanityState {
    Normal,
    Stressed,
    Afflicted,
    Insane,
    Dead,
}

#[derive(Debug, Clone)]
pub struct SanitySystem {
    pub current_sanity: f32,
    pub max_sanity: f32,
    pub drain_rate_darkness: f32,
    pub drain_rate_monster: f32,
    pub restore_rate_light: f32,
    pub hallucination_threshold: f32,
}

impl SanitySystem {
    /// Creates a new SanitySystem with default values based on Don't Starve benchmarks.
    pub fn new() -> Self {
        Self {
            current_sanity: 200.0,
            max_sanity: 200.0,
            drain_rate_darkness: 1.0,
            drain_rate_monster: 10.0,
            restore_rate_light: 0.5,
            hallucination_threshold: 30.0,
        }
    }

    /// Updates the sanity based on environmental factors over a given delta time.
    pub fn update(&mut self, delta_time: f32, in_darkness: bool, in_light: bool) {
        if in_darkness {
            self.current_sanity -= self.drain_rate_darkness * delta_time;
        } else if in_light {
            self.current_sanity += self.restore_rate_light * delta_time;
        }
        
        self.current_sanity = self.current_sanity.clamp(0.0, self.max_sanity);
    }

    /// Applies a sudden sanity drain from a monster encounter.
    pub fn encounter_monster(&mut self) {
        self.current_sanity -= self.drain_rate_monster;
        self.current_sanity = self.current_sanity.max(0.0);
    }

    /// Returns the current state of the character based on their sanity level.
    pub fn get_state(&self) -> SanityState {
        let percentage = self.current_sanity / self.max_sanity;
        
        if self.current_sanity <= 0.0 {
            SanityState::Dead
        } else if percentage < 0.25 {
            SanityState::Insane
        } else if percentage < 0.50 {
            SanityState::Afflicted
        } else if percentage < 0.75 {
            SanityState::Stressed
        } else {
            SanityState::Normal
        }
    }

    /// Checks if the character is currently experiencing hallucinations.
    pub fn is_hallucinating(&self) -> bool {
        self.current_sanity <= self.hallucination_threshold
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_sanity_drain_and_restore() {
        let mut system = SanitySystem::new();
        
        // Initial state
        assert_eq!(system.current_sanity, 200.0);
        assert_eq!(system.get_state(), SanityState::Normal);
        
        // Drain in darkness for 10 seconds
        system.update(10.0, true, false);
        assert_eq!(system.current_sanity, 190.0);
        
        // Restore in light for 10 seconds
        system.update(10.0, false, true);
        assert_eq!(system.current_sanity, 195.0);
    }

    #[test]
    fn test_monster_encounter_and_states() {
        let mut system = SanitySystem::new();
        
        // Encounter monsters until state changes
        for _ in 0..6 {
            system.encounter_monster(); // -60 sanity
        }
        assert_eq!(system.current_sanity, 140.0);
        assert_eq!(system.get_state(), SanityState::Stressed); // 140/200 = 0.7
        
        // Encounter more monsters
        for _ in 0..5 {
            system.encounter_monster(); // -50 sanity
        }
        assert_eq!(system.current_sanity, 90.0);
        assert_eq!(system.get_state(), SanityState::Afflicted); // 90/200 = 0.45
        
        // Drop below hallucination threshold
        for _ in 0..7 {
            system.encounter_monster(); // -70 sanity
        }
        assert_eq!(system.current_sanity, 20.0);
        assert_eq!(system.get_state(), SanityState::Insane); // 20/200 = 0.1
        assert!(system.is_hallucinating());
        
        // Death
        for _ in 0..2 {
            system.encounter_monster(); // -20 sanity
        }
        assert_eq!(system.current_sanity, 0.0);
        assert_eq!(system.get_state(), SanityState::Dead);
    }
}
