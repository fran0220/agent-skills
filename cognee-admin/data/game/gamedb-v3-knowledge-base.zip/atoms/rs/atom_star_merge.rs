#[derive(Debug, Clone)]
pub struct StarMergeParams {
    pub merge_requirement: u32,
    pub stat_multiplier: f32,
    pub max_star_level: u32,
    pub sell_value_penalty: f32,
}

impl StarMergeParams {
    /// Creates a new StarMergeParams with default values based on TFT Set 10 benchmarks.
    pub fn new() -> Self {
        Self {
            merge_requirement: 3,
            stat_multiplier: 1.8,
            max_star_level: 3,
            sell_value_penalty: 0.0,
        }
    }

    /// Calculates the required number of 1-star base units to reach a target star level.
    /// Returns None if the target level is invalid (e.g., 0 or greater than max_star_level).
    pub fn base_units_required(&self, target_star_level: u32) -> Option<u32> {
        if target_star_level == 0 || target_star_level > self.max_star_level {
            return None;
        }
        
        // Formula: requirement ^ (target_level - 1)
        Some(self.merge_requirement.pow(target_star_level - 1))
    }

    /// Calculates the stat value of a unit at a given star level, given its base stat.
    /// Returns None if the target level is invalid.
    pub fn calculate_stat(&self, base_stat: f32, target_star_level: u32) -> Option<f32> {
        if target_star_level == 0 || target_star_level > self.max_star_level {
            return None;
        }

        // Formula: base_stat * (multiplier ^ (target_level - 1))
        let multiplier = self.stat_multiplier.powi((target_star_level - 1) as i32);
        Some(base_stat * multiplier)
    }
    
    /// Calculates the sell value of a unit at a given star level, given its base cost.
    /// Returns None if the target level is invalid.
    pub fn calculate_sell_value(&self, base_cost: f32, target_star_level: u32) -> Option<f32> {
        if target_star_level == 0 || target_star_level > self.max_star_level {
            return None;
        }
        
        let total_cost = base_cost * self.base_units_required(target_star_level)? as f32;
        
        // Apply penalty if it's an upgraded unit (level > 1)
        if target_star_level > 1 {
            Some(total_cost * (1.0 - self.sell_value_penalty))
        } else {
            Some(total_cost)
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_base_units_required() {
        let params = StarMergeParams::new();
        
        assert_eq!(params.base_units_required(1), Some(1));
        assert_eq!(params.base_units_required(2), Some(3));
        assert_eq!(params.base_units_required(3), Some(9));
        assert_eq!(params.base_units_required(4), None); // Exceeds max_star_level
    }

    #[test]
    fn test_calculate_stat() {
        let params = StarMergeParams::new();
        let base_hp = 500.0;
        
        assert_eq!(params.calculate_stat(base_hp, 1), Some(500.0));
        assert_eq!(params.calculate_stat(base_hp, 2), Some(900.0)); // 500 * 1.8
        assert_eq!(params.calculate_stat(base_hp, 3), Some(1620.0)); // 500 * 1.8 * 1.8
    }
    
    #[test]
    fn test_calculate_sell_value() {
        let mut params = StarMergeParams::new();
        let base_cost = 2.0;
        
        // No penalty
        assert_eq!(params.calculate_sell_value(base_cost, 1), Some(2.0));
        assert_eq!(params.calculate_sell_value(base_cost, 2), Some(6.0));
        assert_eq!(params.calculate_sell_value(base_cost, 3), Some(18.0));
        
        // With penalty
        params.sell_value_penalty = 0.1; // 10% penalty
        assert_eq!(params.calculate_sell_value(base_cost, 1), Some(2.0)); // No penalty for 1-star
        assert_eq!(params.calculate_sell_value(base_cost, 2), Some(5.4)); // 6.0 * 0.9
    }
}
