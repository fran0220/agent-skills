#[derive(Debug, Clone, PartialEq)]
pub struct DriftBoostParams {
    pub charge_time_tier1: f32,
    pub charge_time_tier2: f32,
    pub charge_time_tier3: f32,
    pub boost_duration_tier1: f32,
    pub boost_duration_tier2: f32,
    pub boost_duration_tier3: f32,
    pub boost_speed_multiplier: f32,
    pub min_drift_angle: f32,
}

impl DriftBoostParams {
    pub fn new() -> Self {
        Self {
            charge_time_tier1: 1.0,
            charge_time_tier2: 2.5,
            charge_time_tier3: 4.5,
            boost_duration_tier1: 0.6,
            boost_duration_tier2: 1.2,
            boost_duration_tier3: 2.0,
            boost_speed_multiplier: 1.25,
            min_drift_angle: 15.0,
        }
    }
}

impl Default for DriftBoostParams {
    fn default() -> Self {
        Self::new()
    }
}

#[derive(Debug, Clone, PartialEq)]
pub enum BoostTier {
    None,
    Tier1,
    Tier2,
    Tier3,
}

pub struct DriftState {
    pub is_drifting: bool,
    pub drift_time: f32,
    pub current_angle: f32,
}

impl DriftState {
    pub fn new() -> Self {
        Self {
            is_drifting: false,
            drift_time: 0.0,
            current_angle: 0.0,
        }
    }

    /// Updates the drift state based on current inputs and time delta.
    pub fn update(&mut self, is_drifting_input: bool, angle: f32, dt: f32, params: &DriftBoostParams) {
        if is_drifting_input && angle.abs() >= params.min_drift_angle {
            self.is_drifting = true;
            self.current_angle = angle;
            self.drift_time += dt;
        } else {
            self.is_drifting = false;
            self.drift_time = 0.0;
            self.current_angle = 0.0;
        }
    }

    /// Determines the current boost tier based on accumulated drift time.
    pub fn get_boost_tier(&self, params: &DriftBoostParams) -> BoostTier {
        if !self.is_drifting {
            return BoostTier::None;
        }

        if self.drift_time >= params.charge_time_tier3 {
            BoostTier::Tier3
        } else if self.drift_time >= params.charge_time_tier2 {
            BoostTier::Tier2
        } else if self.drift_time >= params.charge_time_tier1 {
            BoostTier::Tier1
        } else {
            BoostTier::None
        }
    }

    /// Calculates the boost duration and multiplier upon releasing the drift.
    /// Returns (duration, multiplier). If no boost, returns (0.0, 1.0).
    pub fn release_drift(&mut self, params: &DriftBoostParams) -> (f32, f32) {
        let tier = self.get_boost_tier(params);
        
        let result = match tier {
            BoostTier::Tier3 => (params.boost_duration_tier3, params.boost_speed_multiplier),
            BoostTier::Tier2 => (params.boost_duration_tier2, params.boost_speed_multiplier),
            BoostTier::Tier1 => (params.boost_duration_tier1, params.boost_speed_multiplier),
            BoostTier::None => (0.0, 1.0),
        };

        // Reset state after release
        self.is_drifting = false;
        self.drift_time = 0.0;
        self.current_angle = 0.0;

        result
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_drift_accumulation_and_tier() {
        let params = DriftBoostParams::new();
        let mut state = DriftState::new();

        // Not drifting
        state.update(false, 0.0, 0.5, &params);
        assert_eq!(state.get_boost_tier(&params), BoostTier::None);

        // Drifting but angle too small
        state.update(true, 10.0, 1.0, &params);
        assert_eq!(state.get_boost_tier(&params), BoostTier::None);

        // Drifting, tier 1
        state.update(true, 20.0, 1.2, &params);
        assert_eq!(state.get_boost_tier(&params), BoostTier::Tier1);

        // Drifting, tier 2
        state.update(true, 20.0, 1.5, &params); // Total time: 2.7
        assert_eq!(state.get_boost_tier(&params), BoostTier::Tier2);

        // Drifting, tier 3
        state.update(true, 20.0, 2.0, &params); // Total time: 4.7
        assert_eq!(state.get_boost_tier(&params), BoostTier::Tier3);
    }

    #[test]
    fn test_drift_release() {
        let params = DriftBoostParams::new();
        let mut state = DriftState::new();

        // Accumulate to tier 2
        state.update(true, 20.0, 3.0, &params);
        
        // Release
        let (duration, multiplier) = state.release_drift(&params);
        
        assert_eq!(duration, params.boost_duration_tier2);
        assert_eq!(multiplier, params.boost_speed_multiplier);
        
        // State should be reset
        assert_eq!(state.is_drifting, false);
        assert_eq!(state.drift_time, 0.0);
    }
}
