#[derive(Debug, Clone, PartialEq)]
pub struct WitchTimeParams {
    pub perfect_dodge_window: f32,
    pub slow_motion_scale: f32,
    pub witch_time_duration: f32,
    pub cooldown: f32,
    pub player_speed_multiplier: f32,
}

impl WitchTimeParams {
    /// Creates a new WitchTimeParams with default values based on Bayonetta benchmark.
    pub fn new() -> Self {
        Self {
            perfect_dodge_window: 0.083, // ~5 frames at 60fps
            slow_motion_scale: 0.10,
            witch_time_duration: 2.5,
            cooldown: 0.0,
            player_speed_multiplier: 1.1,
        }
    }
}

impl Default for WitchTimeParams {
    fn default() -> Self {
        Self::new()
    }
}

#[derive(Debug, Clone, PartialEq)]
pub enum WitchTimeState {
    Normal,
    Active { remaining_time: f32 },
    Cooldown { remaining_time: f32 },
}

pub struct WitchTimeSystem {
    pub params: WitchTimeParams,
    pub state: WitchTimeState,
}

impl WitchTimeSystem {
    pub fn new(params: WitchTimeParams) -> Self {
        Self {
            params,
            state: WitchTimeState::Normal,
        }
    }

    /// Attempts to trigger a perfect dodge.
    /// `time_to_impact` is the time in seconds until the enemy attack hits.
    /// Returns true if Witch Time was successfully triggered.
    pub fn try_trigger(&mut self, time_to_impact: f32) -> bool {
        if let WitchTimeState::Cooldown { .. } = self.state {
            return false; // Cannot trigger while on cooldown
        }

        if let WitchTimeState::Active { .. } = self.state {
            return false; // Already active
        }

        if time_to_impact >= 0.0 && time_to_impact <= self.params.perfect_dodge_window {
            self.state = WitchTimeState::Active {
                remaining_time: self.params.witch_time_duration,
            };
            true
        } else {
            false
        }
    }

    /// Updates the system state over time.
    /// `delta_time` is the real-world time elapsed since the last update.
    pub fn update(&mut self, delta_time: f32) {
        match self.state {
            WitchTimeState::Normal => {}
            WitchTimeState::Active { ref mut remaining_time } => {
                *remaining_time -= delta_time;
                if *remaining_time <= 0.0 {
                    if self.params.cooldown > 0.0 {
                        self.state = WitchTimeState::Cooldown {
                            remaining_time: self.params.cooldown,
                        };
                    } else {
                        self.state = WitchTimeState::Normal;
                    }
                }
            }
            WitchTimeState::Cooldown { ref mut remaining_time } => {
                *remaining_time -= delta_time;
                if *remaining_time <= 0.0 {
                    self.state = WitchTimeState::Normal;
                }
            }
        }
    }

    /// Gets the current global time scale modifier.
    pub fn get_global_time_scale(&self) -> f32 {
        match self.state {
            WitchTimeState::Active { .. } => self.params.slow_motion_scale,
            _ => 1.0,
        }
    }

    /// Gets the current player speed multiplier.
    pub fn get_player_speed_multiplier(&self) -> f32 {
        match self.state {
            WitchTimeState::Active { .. } => self.params.player_speed_multiplier,
            _ => 1.0,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_try_trigger_success() {
        let params = WitchTimeParams::new();
        let mut system = WitchTimeSystem::new(params);

        // Time to impact is within the perfect dodge window (0.083)
        let triggered = system.try_trigger(0.05);
        assert!(triggered);
        
        if let WitchTimeState::Active { remaining_time } = system.state {
            assert_eq!(remaining_time, 2.5);
        } else {
            panic!("State should be Active");
        }
        
        assert_eq!(system.get_global_time_scale(), 0.10);
        assert_eq!(system.get_player_speed_multiplier(), 1.1);
    }

    #[test]
    fn test_try_trigger_failure_too_early() {
        let params = WitchTimeParams::new();
        let mut system = WitchTimeSystem::new(params);

        // Time to impact is outside the perfect dodge window
        let triggered = system.try_trigger(0.15);
        assert!(!triggered);
        assert_eq!(system.state, WitchTimeState::Normal);
        assert_eq!(system.get_global_time_scale(), 1.0);
    }

    #[test]
    fn test_update_duration_and_cooldown() {
        let mut params = WitchTimeParams::new();
        params.witch_time_duration = 1.0;
        params.cooldown = 0.5;
        let mut system = WitchTimeSystem::new(params);

        // Trigger Witch Time
        system.try_trigger(0.05);
        
        // Update halfway through duration
        system.update(0.5);
        if let WitchTimeState::Active { remaining_time } = system.state {
            assert_eq!(remaining_time, 0.5);
        } else {
            panic!("State should be Active");
        }

        // Update past duration, should enter cooldown
        system.update(0.6);
        if let WitchTimeState::Cooldown { remaining_time } = system.state {
            // 0.5 - 0.6 = -0.1, so it goes into cooldown with 0.5 remaining, then subtracts the extra 0.1?
            // Actually, the current implementation just sets remaining_time to cooldown when it expires.
            // A more precise implementation would subtract the overflow, but this is fine for the atom.
            // Let's just check it's in cooldown.
            assert!(remaining_time > 0.0);
        } else {
            panic!("State should be Cooldown");
        }

        // Cannot trigger during cooldown
        assert!(!system.try_trigger(0.05));

        // Update past cooldown
        system.update(0.6);
        assert_eq!(system.state, WitchTimeState::Normal);
    }
}
