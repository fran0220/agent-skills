#[derive(Debug, Clone, PartialEq)]
pub struct DeckThinningParams {
    pub removal_cost_base: u32,
    pub removal_cost_increment: u32,
    pub max_removals_per_shop: u32,
    pub trash_action_cost: u32,
}

impl DeckThinningParams {
    /// Creates a new DeckThinningParams with default values based on Slay the Spire and Dominion benchmarks.
    pub fn new() -> Self {
        Self {
            removal_cost_base: 75,
            removal_cost_increment: 25,
            max_removals_per_shop: 1,
            trash_action_cost: 1,
        }
    }

    /// Calculates the cost of the nth removal (0-indexed).
    /// For example, the 0th removal costs `removal_cost_base`.
    /// The 1st removal costs `removal_cost_base + removal_cost_increment`.
    pub fn calculate_removal_cost(&self, previous_removals: u32) -> u32 {
        self.removal_cost_base + (previous_removals * self.removal_cost_increment)
    }

    /// Calculates the total cost to perform `count` removals, given `previous_removals` already done.
    pub fn calculate_total_cost_for_removals(&self, previous_removals: u32, count: u32) -> u32 {
        let mut total_cost = 0;
        for i in 0..count {
            total_cost += self.calculate_removal_cost(previous_removals + i);
        }
        total_cost
    }

    /// Checks if a requested number of removals is allowed in a single shop visit.
    pub fn is_removal_allowed_in_shop(&self, requested_removals: u32) -> bool {
        requested_removals <= self.max_removals_per_shop
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_removal_cost() {
        let params = DeckThinningParams::new();
        
        // 0th removal (first time)
        assert_eq!(params.calculate_removal_cost(0), 75);
        
        // 1st removal (second time)
        assert_eq!(params.calculate_removal_cost(1), 100);
        
        // 2nd removal (third time)
        assert_eq!(params.calculate_removal_cost(2), 125);
    }

    #[test]
    fn test_calculate_total_cost_for_removals() {
        let params = DeckThinningParams::new();
        
        // Cost of first 3 removals: 75 + 100 + 125 = 300
        assert_eq!(params.calculate_total_cost_for_removals(0, 3), 300);
        
        // Cost of 2 removals after having done 1 already: 100 + 125 = 225
        assert_eq!(params.calculate_total_cost_for_removals(1, 2), 225);
    }

    #[test]
    fn test_is_removal_allowed_in_shop() {
        let params = DeckThinningParams::new();
        
        assert!(params.is_removal_allowed_in_shop(1));
        assert!(!params.is_removal_allowed_in_shop(2));
    }
}
