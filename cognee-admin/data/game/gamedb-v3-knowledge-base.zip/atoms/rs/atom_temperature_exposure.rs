#[derive(Debug, Clone, PartialEq)]
pub enum TemperatureState {
    Comfortable,
    Chilly,
    Warm,
    Freezing,
    Overheating,
    TakingDamage,
    Death,
}

#[derive(Debug, Clone)]
pub struct TemperatureExposure {
    pub ambient_temp: f32,
    pub body_temp: f32,
    pub insulation_value: f32,
    pub temp_change_rate: f32,
    pub damage_tick_rate: f32,
    pub wind_chill_factor: f32,
    pub health: f32,
}

impl TemperatureExposure {
    /// Creates a new TemperatureExposure instance with default benchmark values.
    pub fn new() -> Self {
        Self {
            ambient_temp: -15.0,
            body_temp: 37.0,
            insulation_value: 12.5,
            temp_change_rate: 1.2,
            damage_tick_rate: 5.0,
            wind_chill_factor: 5.0,
            health: 100.0,
        }
    }

    /// Calculates the "feels like" temperature based on ambient temp, wind chill, and insulation.
    pub fn calculate_feels_like_temp(&self) -> f32 {
        self.ambient_temp - self.wind_chill_factor + self.insulation_value
    }

    /// Updates the body temperature and health based on the current environment over a given delta time (in minutes).
    pub fn update(&mut self, delta_time_minutes: f32) -> TemperatureState {
        let feels_like = self.calculate_feels_like_temp();
        
        // Target body temp tends towards feels_like, but is clamped by biological limits in a real game.
        // For simplicity, if feels_like is below 0, body temp drops. If above 30, it rises.
        if feels_like < 0.0 {
            self.body_temp -= self.temp_change_rate * delta_time_minutes;
        } else if feels_like > 30.0 {
            self.body_temp += self.temp_change_rate * delta_time_minutes;
        } else {
            // Slowly return to normal
            if self.body_temp < 37.0 {
                self.body_temp += self.temp_change_rate * delta_time_minutes;
                if self.body_temp > 37.0 { self.body_temp = 37.0; }
            } else if self.body_temp > 37.0 {
                self.body_temp -= self.temp_change_rate * delta_time_minutes;
                if self.body_temp < 37.0 { self.body_temp = 37.0; }
            }
        }

        self.determine_state(delta_time_minutes)
    }

    fn determine_state(&mut self, delta_time_minutes: f32) -> TemperatureState {
        if self.health <= 0.0 {
            return TemperatureState::Death;
        }

        if self.body_temp <= 30.0 || self.body_temp >= 42.0 {
            // Taking damage state
            self.health -= self.damage_tick_rate * delta_time_minutes; // Simplified: damage per minute here
            if self.health <= 0.0 {
                return TemperatureState::Death;
            }
            return TemperatureState::TakingDamage;
        } else if self.body_temp <= 34.0 {
            return TemperatureState::Freezing;
        } else if self.body_temp >= 39.0 {
            return TemperatureState::Overheating;
        } else if self.body_temp <= 36.0 {
            return TemperatureState::Chilly;
        } else if self.body_temp >= 38.0 {
            return TemperatureState::Warm;
        }

        TemperatureState::Comfortable
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_feels_like_temp() {
        let mut exposure = TemperatureExposure::new();
        exposure.ambient_temp = -10.0;
        exposure.wind_chill_factor = 5.0;
        exposure.insulation_value = 10.0;
        
        // -10 - 5 + 10 = -5
        assert_eq!(exposure.calculate_feels_like_temp(), -5.0);
    }

    #[test]
    fn test_body_temp_drop_and_damage() {
        let mut exposure = TemperatureExposure::new();
        exposure.ambient_temp = -50.0; // Very cold
        exposure.wind_chill_factor = 10.0;
        exposure.insulation_value = 0.0; // No clothes
        exposure.body_temp = 37.0;
        exposure.temp_change_rate = 2.0;
        
        // Feels like -60.
        // Update for 4 minutes -> body temp drops by 8 degrees to 29.0
        let state = exposure.update(4.0);
        
        assert_eq!(exposure.body_temp, 29.0);
        assert_eq!(state, TemperatureState::TakingDamage);
        assert!(exposure.health < 100.0);
    }
}
