pub struct InterconnectedMapParams {
    pub nodes_count: u32,
    pub shortcuts_per_zone: f32,
    pub loop_length_avg: f32,
    pub hub_connectivity: u32,
}

impl InterconnectedMapParams {
    pub fn new() -> Self {
        Self {
            nodes_count: 42,
            shortcuts_per_zone: 1.5,
            loop_length_avg: 12.5,
            hub_connectivity: 5,
        }
    }

    /// Calculates the estimated total number of shortcuts in the map.
    pub fn total_shortcuts(&self) -> f32 {
        self.nodes_count as f32 * self.shortcuts_per_zone
    }

    /// Calculates the estimated total exploration time before finding all shortcuts,
    /// assuming each loop takes `loop_length_avg` minutes.
    pub fn estimated_exploration_time(&self) -> f32 {
        self.total_shortcuts() * self.loop_length_avg
    }
    
    /// Calculates the connectivity density of the map.
    pub fn connectivity_density(&self) -> f32 {
        if self.nodes_count == 0 {
            return 0.0;
        }
        (self.hub_connectivity as f32 + self.total_shortcuts()) / self.nodes_count as f32
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_total_shortcuts() {
        let params = InterconnectedMapParams::new();
        assert_eq!(params.total_shortcuts(), 42.0 * 1.5);
    }

    #[test]
    fn test_estimated_exploration_time() {
        let params = InterconnectedMapParams::new();
        let expected_time = (42.0 * 1.5) * 12.5;
        assert_eq!(params.estimated_exploration_time(), expected_time);
    }
    
    #[test]
    fn test_connectivity_density() {
        let params = InterconnectedMapParams::new();
        let expected_density = (5.0 + (42.0 * 1.5)) / 42.0;
        assert_eq!(params.connectivity_density(), expected_density);
    }
}
