#[derive(Debug, Clone)]
pub struct ShelterBuildingParams {
    pub health: f32,
    pub build_cost: u32,
    pub stability_loss: f32,
    pub decay_rate: f32,
}

impl ShelterBuildingParams {
    /// Creates a new ShelterBuildingParams with default values based on Rust (v1.0) benchmark.
    pub fn new() -> Self {
        Self {
            health: 500.0,
            build_cost: 300,
            stability_loss: 0.1,
            decay_rate: 1.0,
        }
    }

    /// Calculates the remaining stability of a structure block given its vertical distance from the foundation.
    pub fn calculate_stability(&self, vertical_distance: u32) -> f32 {
        let loss = self.stability_loss * (vertical_distance as f32);
        let stability = 1.0 - loss;
        if stability < 0.0 {
            0.0
        } else {
            stability
        }
    }

    /// Calculates the remaining health of a structure after a certain number of hours of decay.
    pub fn calculate_decay(&self, hours: f32) -> f32 {
        let total_decay = self.decay_rate * hours;
        let remaining_health = self.health - total_decay;
        if remaining_health < 0.0 {
            0.0
        } else {
            remaining_health
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_stability() {
        let params = ShelterBuildingParams::new();
        
        // Foundation (distance 0) should have 1.0 stability
        assert_eq!(params.calculate_stability(0), 1.0);
        
        // Distance 5 with 0.1 loss per block should have 0.5 stability
        assert_eq!(params.calculate_stability(5), 0.5);
        
        // Distance 15 with 0.1 loss per block should be 0.0 (not negative)
        assert_eq!(params.calculate_stability(15), 0.0);
    }

    #[test]
    fn test_calculate_decay() {
        let params = ShelterBuildingParams::new();
        
        // 0 hours decay
        assert_eq!(params.calculate_decay(0.0), 500.0);
        
        // 100 hours decay at 1.0 HP/hour
        assert_eq!(params.calculate_decay(100.0), 400.0);
        
        // 600 hours decay should result in 0 HP (not negative)
        assert_eq!(params.calculate_decay(600.0), 0.0);
    }
}
