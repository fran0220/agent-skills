#[derive(Debug, Clone, PartialEq)]
pub struct CoverSystemParams {
    pub snap_radius: f32,
    pub snap_speed: f32,
    pub damage_reduction: f32,
    pub peek_exposure: f32,
    pub blind_fire_accuracy: f32,
    pub exit_delay: f32,
}

impl CoverSystemParams {
    /// Creates a new CoverSystemParams with default values based on benchmark data.
    pub fn new() -> Self {
        Self {
            snap_radius: 1.2,
            snap_speed: 5.0,
            damage_reduction: 1.0,
            peek_exposure: 0.3,
            blind_fire_accuracy: 0.1,
            exit_delay: 0.15,
        }
    }

    /// Calculates the effective damage taken while in cover.
    /// `incoming_damage` is the raw damage value.
    /// `is_peeking` indicates if the character is currently peeking (exposing themselves).
    pub fn calculate_damage_taken(&self, incoming_damage: f32, is_peeking: bool) -> f32 {
        if is_peeking {
            // When peeking, damage reduction is less effective, proportional to exposure
            let effective_reduction = self.damage_reduction * (1.0 - self.peek_exposure);
            incoming_damage * (1.0 - effective_reduction).max(0.0)
        } else {
            // Full cover
            incoming_damage * (1.0 - self.damage_reduction).max(0.0)
        }
    }

    /// Calculates the accuracy multiplier when firing from cover.
    /// `is_aiming` indicates if the character is aiming (peeking).
    pub fn calculate_accuracy(&self, is_aiming: bool) -> f32 {
        if is_aiming {
            1.0 // Full accuracy when aiming/peeking
        } else {
            self.blind_fire_accuracy // Reduced accuracy when blind firing
        }
    }
    
    /// Checks if a cover object is within snap radius.
    pub fn can_snap_to_cover(&self, distance_to_cover: f32) -> bool {
        distance_to_cover <= self.snap_radius
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_damage_taken() {
        let params = CoverSystemParams::new();
        let incoming_damage = 100.0;

        // Full cover with 1.0 damage reduction should take 0 damage
        let damage_in_cover = params.calculate_damage_taken(incoming_damage, false);
        assert_eq!(damage_in_cover, 0.0);

        // Peeking with 0.3 exposure and 1.0 damage reduction
        // effective_reduction = 1.0 * (1.0 - 0.3) = 0.7
        // damage taken = 100.0 * (1.0 - 0.7) = 30.0
        let damage_peeking = params.calculate_damage_taken(incoming_damage, true);
        assert!((damage_peeking - 30.0).abs() < f32::EPSILON);
    }

    #[test]
    fn test_calculate_accuracy() {
        let params = CoverSystemParams::new();

        // Aiming should give 1.0 accuracy
        assert_eq!(params.calculate_accuracy(true), 1.0);

        // Blind firing should give blind_fire_accuracy (0.1)
        assert_eq!(params.calculate_accuracy(false), 0.1);
    }
    
    #[test]
    fn test_can_snap_to_cover() {
        let params = CoverSystemParams::new();
        
        assert!(params.can_snap_to_cover(1.0));
        assert!(params.can_snap_to_cover(1.2));
        assert!(!params.can_snap_to_cover(1.3));
    }
}
