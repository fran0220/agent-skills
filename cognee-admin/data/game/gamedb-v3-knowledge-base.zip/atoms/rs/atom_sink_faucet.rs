#[derive(Debug, Clone, PartialEq)]
pub struct SinkFaucetEconomy {
    pub faucet_rate: f32,
    pub sink_rate: f32,
    pub tax_rate: f32,
    pub repair_cost_ratio: f32,
}

impl SinkFaucetEconomy {
    /// Creates a new SinkFaucetEconomy with default values based on WoW Classic benchmarks.
    pub fn new() -> Self {
        Self {
            faucet_rate: 50.0,
            sink_rate: 30.0,
            tax_rate: 0.05,
            repair_cost_ratio: 0.10,
        }
    }

    /// Calculates the net income over a given number of hours, accounting for both faucets and sinks.
    pub fn calculate_net_income(&self, hours: f32) -> f32 {
        (self.faucet_rate - self.sink_rate) * hours
    }

    /// Calculates the final amount received after applying the transaction tax.
    pub fn calculate_taxed_transaction(&self, amount: f32) -> f32 {
        amount * (1.0 - self.tax_rate)
    }

    /// Calculates the repair cost for an item based on its base value.
    pub fn calculate_repair_cost(&self, item_value: f32) -> f32 {
        item_value * self.repair_cost_ratio
    }
}

impl Default for SinkFaucetEconomy {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_net_income() {
        let economy = SinkFaucetEconomy::new();
        // 50.0 faucet - 30.0 sink = 20.0 net per hour
        // Over 5 hours: 20.0 * 5.0 = 100.0
        assert_eq!(economy.calculate_net_income(5.0), 100.0);
    }

    #[test]
    fn test_calculate_taxed_transaction() {
        let economy = SinkFaucetEconomy::new();
        // 100.0 amount with 0.05 tax rate = 95.0
        assert_eq!(economy.calculate_taxed_transaction(100.0), 95.0);
    }

    #[test]
    fn test_calculate_repair_cost() {
        let economy = SinkFaucetEconomy::new();
        // 500.0 item value with 0.10 repair cost ratio = 50.0
        assert_eq!(economy.calculate_repair_cost(500.0), 50.0);
    }
}
