pub struct RubberBandingAiParams {
    pub base_speed: f32,
    pub catch_up_distance: f32,
    pub slow_down_distance: f32,
    pub max_boost_multiplier: f32,
    pub min_handicap_multiplier: f32,
    pub adjustment_rate: f32,
}

impl RubberBandingAiParams {
    /// Creates a new instance with default values based on Mario Kart 8 Deluxe benchmark.
    pub fn new() -> Self {
        Self {
            base_speed: 100.0,
            catch_up_distance: 300.0,
            slow_down_distance: 250.0,
            max_boost_multiplier: 1.35,
            min_handicap_multiplier: 0.75,
            adjustment_rate: 1.5,
        }
    }

    /// Calculates the target speed multiplier based on the distance to the player.
    /// Positive distance means the AI is behind the player.
    /// Negative distance means the AI is ahead of the player.
    pub fn calculate_target_multiplier(&self, distance_to_player: f32) -> f32 {
        if distance_to_player > self.catch_up_distance {
            // AI is far behind, needs a boost
            let excess_distance = distance_to_player - self.catch_up_distance;
            // Simple linear scaling up to max_boost_multiplier
            let boost = 1.0 + (excess_distance / 1000.0);
            boost.min(self.max_boost_multiplier)
        } else if distance_to_player < -self.slow_down_distance {
            // AI is far ahead, needs a handicap
            let excess_distance = (-distance_to_player) - self.slow_down_distance;
            // Simple linear scaling down to min_handicap_multiplier
            let handicap = 1.0 - (excess_distance / 1000.0);
            handicap.max(self.min_handicap_multiplier)
        } else {
            // AI is within normal tracking range
            1.0
        }
    }

    /// Updates the current speed multiplier towards the target multiplier.
    pub fn update_multiplier(&self, current_multiplier: f32, target_multiplier: f32, delta_time: f32) -> f32 {
        let adjustment = self.adjustment_rate * delta_time;
        if current_multiplier < target_multiplier {
            (current_multiplier + adjustment).min(target_multiplier)
        } else if current_multiplier > target_multiplier {
            (current_multiplier - adjustment).max(target_multiplier)
        } else {
            current_multiplier
        }
    }

    /// Calculates the final speed of the AI.
    pub fn calculate_speed(&self, current_multiplier: f32) -> f32 {
        self.base_speed * current_multiplier
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_target_multiplier_behind() {
        let params = RubberBandingAiParams::new();
        // Distance 400 is > catch_up_distance (300)
        let target = params.calculate_target_multiplier(400.0);
        assert!(target > 1.0);
        assert!(target <= params.max_boost_multiplier);
        
        // Distance 2000 is way behind, should cap at max_boost_multiplier
        let target_max = params.calculate_target_multiplier(2000.0);
        assert_eq!(target_max, params.max_boost_multiplier);
    }

    #[test]
    fn test_calculate_target_multiplier_ahead() {
        let params = RubberBandingAiParams::new();
        // Distance -350 is < -slow_down_distance (-250)
        let target = params.calculate_target_multiplier(-350.0);
        assert!(target < 1.0);
        assert!(target >= params.min_handicap_multiplier);
        
        // Distance -2000 is way ahead, should cap at min_handicap_multiplier
        let target_min = params.calculate_target_multiplier(-2000.0);
        assert_eq!(target_min, params.min_handicap_multiplier);
    }

    #[test]
    fn test_update_multiplier() {
        let params = RubberBandingAiParams::new();
        let current = 1.0;
        let target = 1.35;
        let delta_time = 0.1; // 0.1 seconds
        
        let new_multiplier = params.update_multiplier(current, target, delta_time);
        // adjustment = 1.5 * 0.1 = 0.15
        // new = 1.0 + 0.15 = 1.15
        assert!((new_multiplier - 1.15).abs() < f32::EPSILON);
    }
}
