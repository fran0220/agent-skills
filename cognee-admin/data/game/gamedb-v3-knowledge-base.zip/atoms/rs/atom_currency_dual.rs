#[derive(Debug, Clone)]
pub struct DualCurrencySystem {
    pub soft_currency_earn_rate: f32,
    pub hard_currency_earn_rate: f32,
    pub hard_to_soft_exchange_rate: f32,
    pub premium_item_cost: u32,
    pub basic_item_cost: u32,
    
    pub soft_currency_balance: u32,
    pub hard_currency_balance: u32,
}

impl DualCurrencySystem {
    /// Creates a new DualCurrencySystem with default benchmark values (Genshin Impact / Clash Royale mix)
    pub fn new() -> Self {
        Self {
            soft_currency_earn_rate: 100.0,
            hard_currency_earn_rate: 10.0,
            hard_to_soft_exchange_rate: 100.0,
            premium_item_cost: 160,
            basic_item_cost: 1000,
            soft_currency_balance: 0,
            hard_currency_balance: 0,
        }
    }

    /// Simulates earning currency over a given number of hours
    pub fn earn_currency_over_time(&mut self, hours: f32) {
        let soft_earned = (self.soft_currency_earn_rate * hours) as u32;
        // Hard currency is earned per week in benchmarks, so convert hours to weeks
        let weeks = hours / (24.0 * 7.0);
        let hard_earned = (self.hard_currency_earn_rate * weeks) as u32;

        self.soft_currency_balance += soft_earned;
        self.hard_currency_balance += hard_earned;
    }

    /// Converts a specified amount of hard currency to soft currency
    pub fn convert_hard_to_soft(&mut self, hard_amount: u32) -> Result<(), &'static str> {
        if self.hard_currency_balance >= hard_amount {
            self.hard_currency_balance -= hard_amount;
            let soft_gained = (hard_amount as f32 * self.hard_to_soft_exchange_rate) as u32;
            self.soft_currency_balance += soft_gained;
            Ok(())
        } else {
            Err("Insufficient hard currency")
        }
    }

    /// Attempts to purchase a basic item using soft currency
    pub fn purchase_basic_item(&mut self) -> Result<(), &'static str> {
        if self.soft_currency_balance >= self.basic_item_cost {
            self.soft_currency_balance -= self.basic_item_cost;
            Ok(())
        } else {
            Err("Insufficient soft currency")
        }
    }

    /// Attempts to purchase a premium item using hard currency
    pub fn purchase_premium_item(&mut self) -> Result<(), &'static str> {
        if self.hard_currency_balance >= self.premium_item_cost {
            self.hard_currency_balance -= self.premium_item_cost;
            Ok(())
        } else {
            Err("Insufficient hard currency")
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_earn_currency_over_time() {
        let mut system = DualCurrencySystem::new();
        // Earn for 1 week (168 hours)
        system.earn_currency_over_time(168.0);
        
        assert_eq!(system.soft_currency_balance, 16800);
        assert_eq!(system.hard_currency_balance, 10);
    }

    #[test]
    fn test_convert_hard_to_soft() {
        let mut system = DualCurrencySystem::new();
        system.hard_currency_balance = 10;
        
        assert!(system.convert_hard_to_soft(5).is_ok());
        assert_eq!(system.hard_currency_balance, 5);
        assert_eq!(system.soft_currency_balance, 500); // 5 * 100.0
        
        assert!(system.convert_hard_to_soft(10).is_err());
    }

    #[test]
    fn test_purchases() {
        let mut system = DualCurrencySystem::new();
        system.soft_currency_balance = 1500;
        system.hard_currency_balance = 200;

        assert!(system.purchase_basic_item().is_ok());
        assert_eq!(system.soft_currency_balance, 500);
        assert!(system.purchase_basic_item().is_err());

        assert!(system.purchase_premium_item().is_ok());
        assert_eq!(system.hard_currency_balance, 40);
        assert!(system.purchase_premium_item().is_err());
    }
}
