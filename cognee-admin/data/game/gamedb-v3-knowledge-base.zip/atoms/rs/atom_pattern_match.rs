#[derive(Debug, Clone, PartialEq)]
pub struct PatternMatchParams {
    pub grid_width: u32,
    pub grid_height: u32,
    pub match_threshold: f32,
    pub time_limit: f32,
    pub element_types: u32,
}

impl PatternMatchParams {
    /// Creates a new PatternMatchParams with default values based on Tetris benchmarks.
    pub fn new() -> Self {
        Self {
            grid_width: 10,
            grid_height: 20,
            match_threshold: 1.0,
            time_limit: 0.0,
            element_types: 7,
        }
    }

    /// Calculates the match ratio between a current pattern and a target pattern.
    /// Returns a value between 0.0 and 1.0.
    pub fn calculate_match_ratio(&self, matched_elements: u32, total_target_elements: u32) -> f32 {
        if total_target_elements == 0 {
            return 0.0;
        }
        let ratio = (matched_elements as f32) / (total_target_elements as f32);
        ratio.clamp(0.0, 1.0)
    }

    /// Checks if the current match ratio meets or exceeds the required threshold.
    pub fn is_match_successful(&self, current_ratio: f32) -> bool {
        current_ratio >= self.match_threshold
    }
    
    /// Calculates the remaining time given the elapsed time.
    /// Returns 0.0 if time_limit is 0.0 (untimed).
    pub fn remaining_time(&self, elapsed_time: f32) -> f32 {
        if self.time_limit <= 0.0 {
            return 0.0;
        }
        (self.time_limit - elapsed_time).max(0.0)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_match_ratio() {
        let params = PatternMatchParams::new();
        
        // Half match
        assert_eq!(params.calculate_match_ratio(5, 10), 0.5);
        
        // Full match
        assert_eq!(params.calculate_match_ratio(10, 10), 1.0);
        
        // Over match (should clamp to 1.0)
        assert_eq!(params.calculate_match_ratio(12, 10), 1.0);
        
        // Zero target elements
        assert_eq!(params.calculate_match_ratio(5, 0), 0.0);
    }

    #[test]
    fn test_is_match_successful() {
        let mut params = PatternMatchParams::new();
        params.match_threshold = 0.8;
        
        assert!(params.is_match_successful(0.8));
        assert!(params.is_match_successful(0.9));
        assert!(!params.is_match_successful(0.7));
    }
    
    #[test]
    fn test_remaining_time() {
        let mut params = PatternMatchParams::new();
        params.time_limit = 60.0;
        
        assert_eq!(params.remaining_time(20.0), 40.0);
        assert_eq!(params.remaining_time(60.0), 0.0);
        assert_eq!(params.remaining_time(70.0), 0.0); // Should not go below 0
        
        // Untimed
        params.time_limit = 0.0;
        assert_eq!(params.remaining_time(20.0), 0.0);
    }
}
