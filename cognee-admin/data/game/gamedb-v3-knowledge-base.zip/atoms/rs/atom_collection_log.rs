#[derive(Debug, Clone)]
pub struct CollectionLogParams {
    pub total_entries: u32,
    pub milestone_intervals: u32,
    pub reward_multiplier: f32,
    pub mastery_threshold: u32,
    pub completion_bonus: u32,
}

impl CollectionLogParams {
    pub fn new() -> Self {
        Self {
            total_entries: 151,
            milestone_intervals: 10,
            reward_multiplier: 1.5,
            mastery_threshold: 10,
            completion_bonus: 1000,
        }
    }
}

#[derive(Debug, Clone, PartialEq)]
pub enum EntryState {
    Undiscovered,
    Discovered(u32), // tracks encounter count
    Mastered,
}

pub struct CollectionLog {
    pub params: CollectionLogParams,
    pub entries: std::collections::HashMap<u32, EntryState>,
    pub total_discovered: u32,
    pub total_mastered: u32,
}

impl CollectionLog {
    pub fn new(params: CollectionLogParams) -> Self {
        Self {
            params,
            entries: std::collections::HashMap::new(),
            total_discovered: 0,
            total_mastered: 0,
        }
    }

    pub fn encounter_entity(&mut self, entity_id: u32) -> EntryState {
        let state = self.entries.entry(entity_id).or_insert(EntryState::Undiscovered);
        
        match state {
            EntryState::Undiscovered => {
                *state = EntryState::Discovered(1);
                self.total_discovered += 1;
                
                if self.params.mastery_threshold <= 1 {
                    *state = EntryState::Mastered;
                    self.total_mastered += 1;
                }
            }
            EntryState::Discovered(count) => {
                *count += 1;
                if *count >= self.params.mastery_threshold {
                    *state = EntryState::Mastered;
                    self.total_mastered += 1;
                }
            }
            EntryState::Mastered => {}
        }
        
        state.clone()
    }

    pub fn calculate_completion_percentage(&self) -> f32 {
        if self.params.total_entries == 0 {
            return 0.0;
        }
        (self.total_discovered as f32 / self.params.total_entries as f32) * 100.0
    }

    pub fn check_milestone_reward(&self) -> Option<u32> {
        if self.total_discovered > 0 && self.total_discovered % self.params.milestone_intervals == 0 {
            let base_reward = 100; // Arbitrary base reward
            Some((base_reward as f32 * self.params.reward_multiplier) as u32)
        } else {
            None
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_encounter_progression() {
        let mut params = CollectionLogParams::new();
        params.mastery_threshold = 3;
        let mut log = CollectionLog::new(params);

        // First encounter
        assert_eq!(log.encounter_entity(1), EntryState::Discovered(1));
        assert_eq!(log.total_discovered, 1);
        assert_eq!(log.total_mastered, 0);

        // Second encounter
        assert_eq!(log.encounter_entity(1), EntryState::Discovered(2));
        
        // Third encounter (Mastery)
        assert_eq!(log.encounter_entity(1), EntryState::Mastered);
        assert_eq!(log.total_mastered, 1);
    }

    #[test]
    fn test_completion_percentage() {
        let mut params = CollectionLogParams::new();
        params.total_entries = 100;
        let mut log = CollectionLog::new(params);

        log.encounter_entity(1);
        log.encounter_entity(2);
        log.encounter_entity(3);

        assert_eq!(log.calculate_completion_percentage(), 3.0);
    }
    
    #[test]
    fn test_milestone_reward() {
        let mut params = CollectionLogParams::new();
        params.milestone_intervals = 2;
        params.reward_multiplier = 2.0;
        let mut log = CollectionLog::new(params);

        log.encounter_entity(1);
        assert_eq!(log.check_milestone_reward(), None);
        
        log.encounter_entity(2);
        assert_eq!(log.check_milestone_reward(), Some(200)); // 100 * 2.0
    }
}
