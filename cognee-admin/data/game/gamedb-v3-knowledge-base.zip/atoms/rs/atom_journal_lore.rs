#[derive(Debug, Clone, PartialEq)]
pub struct JournalLoreParams {
    pub interaction_radius: f32,
    pub read_xp_reward: u32,
    pub word_count_limit: u32,
    pub auto_pause_game: bool,
}

impl JournalLoreParams {
    /// Creates a new JournalLoreParams with default values based on benchmark data (Skyrim v1.5).
    pub fn new() -> Self {
        Self {
            interaction_radius: 2.5,
            read_xp_reward: 10, // Using Witcher 3 benchmark for a non-zero default
            word_count_limit: 300,
            auto_pause_game: true,
        }
    }

    /// Checks if the player is close enough to interact with the lore entry.
    pub fn can_interact(&self, player_distance: f32) -> bool {
        player_distance <= self.interaction_radius
    }

    /// Simulates reading the entry and returns the new total XP.
    pub fn read_entry(&self, current_xp: u32) -> u32 {
        current_xp + self.read_xp_reward
    }

    /// Validates if a given lore entry's word count is within the allowed limit.
    pub fn is_valid_entry(&self, word_count: u32) -> bool {
        word_count <= self.word_count_limit
    }
}

impl Default for JournalLoreParams {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_can_interact() {
        let params = JournalLoreParams::new();
        
        // Player is within radius
        assert!(params.can_interact(1.5));
        assert!(params.can_interact(2.5));
        
        // Player is outside radius
        assert!(!params.can_interact(2.6));
        assert!(!params.can_interact(5.0));
    }

    #[test]
    fn test_read_entry_xp_reward() {
        let params = JournalLoreParams::new();
        let initial_xp = 100;
        
        let new_xp = params.read_entry(initial_xp);
        assert_eq!(new_xp, 110);
    }

    #[test]
    fn test_is_valid_entry() {
        let params = JournalLoreParams::new();
        
        // Valid word count
        assert!(params.is_valid_entry(150));
        assert!(params.is_valid_entry(300));
        
        // Invalid word count
        assert!(!params.is_valid_entry(301));
        assert!(!params.is_valid_entry(500));
    }
}
