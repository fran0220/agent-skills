pub struct RespecParams {
    pub base_cost: f32,
    pub cost_multiplier: f32,
    pub max_cost: f32,
    pub refund_points_per_use: u32,
}

impl RespecParams {
    pub fn new() -> Self {
        Self {
            base_cost: 100.0,
            cost_multiplier: 5.0,
            max_cost: 50000.0,
            refund_points_per_use: 1,
        }
    }

    /// Calculates the cost of the next respec based on how many times the player has already respecced.
    pub fn calculate_respec_cost(&self, previous_respecs: u32) -> f32 {
        if previous_respecs == 0 {
            return self.base_cost;
        }
        
        let cost = self.base_cost + (previous_respecs as f32 * self.cost_multiplier * self.base_cost);
        cost.min(self.max_cost)
    }

    /// Calculates the total number of points refunded given a number of consumed respec items.
    pub fn calculate_refunded_points(&self, items_consumed: u32) -> u32 {
        items_consumed * self.refund_points_per_use
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_respec_cost() {
        let params = RespecParams::new();
        
        // First respec should be base cost
        assert_eq!(params.calculate_respec_cost(0), 100.0);
        
        // Second respec (1 previous)
        assert_eq!(params.calculate_respec_cost(1), 600.0);
        
        // Third respec (2 previous)
        assert_eq!(params.calculate_respec_cost(2), 1100.0);
        
        // Cap at max_cost
        assert_eq!(params.calculate_respec_cost(1000), 50000.0);
    }

    #[test]
    fn test_calculate_refunded_points() {
        let params = RespecParams::new();
        
        assert_eq!(params.calculate_refunded_points(1), 1);
        assert_eq!(params.calculate_refunded_points(5), 5);
        assert_eq!(params.calculate_refunded_points(0), 0);
    }
}
