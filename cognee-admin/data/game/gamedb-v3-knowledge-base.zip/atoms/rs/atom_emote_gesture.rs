#[derive(Debug, Clone, PartialEq)]
pub struct EmoteGesture {
    pub startup_time: f32,
    pub duration: f32,
    pub cooldown: f32,
    pub is_cancellable: bool,
    pub cancel_delay: f32,
    pub looping: bool,
}

impl EmoteGesture {
    /// Creates a new EmoteGesture with default values based on Fortnite benchmark data.
    pub fn new() -> Self {
        Self {
            startup_time: 0.1,
            duration: 9999.0, // Represents infinite/looping
            cooldown: 0.0,
            is_cancellable: true,
            cancel_delay: 0.0,
            looping: true,
        }
    }

    /// Determines if the emote can be cancelled at the given elapsed time.
    pub fn can_cancel(&self, elapsed_time: f32) -> bool {
        if !self.is_cancellable {
            return false;
        }
        // Can only cancel after the cancel delay has passed
        elapsed_time >= self.cancel_delay
    }

    /// Checks if the emote has finished playing naturally.
    pub fn is_finished(&self, elapsed_time: f32) -> bool {
        if self.looping {
            return false; // Looping emotes never finish naturally
        }
        elapsed_time >= (self.startup_time + self.duration)
    }

    /// Calculates the time remaining before the emote can be used again, given the time since it ended.
    pub fn remaining_cooldown(&self, time_since_end: f32) -> f32 {
        if time_since_end >= self.cooldown {
            0.0
        } else {
            self.cooldown - time_since_end
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_can_cancel() {
        let mut emote = EmoteGesture::new();
        emote.is_cancellable = true;
        emote.cancel_delay = 0.5;

        assert_eq!(emote.can_cancel(0.2), false);
        assert_eq!(emote.can_cancel(0.5), true);
        assert_eq!(emote.can_cancel(1.0), true);

        emote.is_cancellable = false;
        assert_eq!(emote.can_cancel(1.0), false);
    }

    #[test]
    fn test_is_finished() {
        let mut emote = EmoteGesture::new();
        emote.looping = false;
        emote.startup_time = 0.2;
        emote.duration = 3.0;

        assert_eq!(emote.is_finished(1.0), false);
        assert_eq!(emote.is_finished(3.1), false);
        assert_eq!(emote.is_finished(3.2), true);
        assert_eq!(emote.is_finished(4.0), true);

        emote.looping = true;
        assert_eq!(emote.is_finished(100.0), false);
    }

    #[test]
    fn test_remaining_cooldown() {
        let mut emote = EmoteGesture::new();
        emote.cooldown = 2.0;

        assert_eq!(emote.remaining_cooldown(0.5), 1.5);
        assert_eq!(emote.remaining_cooldown(2.0), 0.0);
        assert_eq!(emote.remaining_cooldown(3.0), 0.0);
    }
}
