#[derive(Debug, Clone, PartialEq)]
pub struct HitProbabilityParams {
    pub base_accuracy: f32,
    pub weapon_bonus: f32,
    pub target_evasion: f32,
    pub cover_penalty: f32,
    pub distance_modifier: f32,
}

impl HitProbabilityParams {
    /// Creates a new HitProbabilityParams with default values based on XCOM benchmark data.
    pub fn new() -> Self {
        Self {
            base_accuracy: 0.65,
            weapon_bonus: 0.10,
            target_evasion: 0.20,
            cover_penalty: 0.40,
            distance_modifier: -0.15,
        }
    }

    /// Calculates the final hit probability based on the parameters.
    /// The result is clamped between 0.0 and 1.0.
    pub fn calculate_hit_chance(&self, is_in_cover: bool, is_long_range: bool) -> f32 {
        let mut chance = self.base_accuracy + self.weapon_bonus - self.target_evasion;
        
        if is_in_cover {
            chance -= self.cover_penalty;
        }
        
        if is_long_range {
            chance += self.distance_modifier; // distance_modifier is typically negative for long range
        }
        
        chance.clamp(0.0, 1.0)
    }

    /// Determines if an attack hits based on a given random roll (0.0 to 1.0).
    pub fn is_hit(&self, roll: f32, is_in_cover: bool, is_long_range: bool) -> bool {
        let hit_chance = self.calculate_hit_chance(is_in_cover, is_long_range);
        roll <= hit_chance
    }
}

impl Default for HitProbabilityParams {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_hit_chance_no_cover_short_range() {
        let params = HitProbabilityParams::new();
        // 0.65 + 0.10 - 0.20 = 0.55
        let chance = params.calculate_hit_chance(false, false);
        assert!((chance - 0.55).abs() < f32::EPSILON);
    }

    #[test]
    fn test_calculate_hit_chance_with_cover_and_range() {
        let params = HitProbabilityParams::new();
        // 0.65 + 0.10 - 0.20 - 0.40 - 0.15 = 0.0
        let chance = params.calculate_hit_chance(true, true);
        assert!((chance - 0.0).abs() < f32::EPSILON);
    }

    #[test]
    fn test_is_hit_success() {
        let params = HitProbabilityParams::new();
        // Chance is 0.55
        assert!(params.is_hit(0.50, false, false));
    }

    #[test]
    fn test_is_hit_miss() {
        let params = HitProbabilityParams::new();
        // Chance is 0.55
        assert!(!params.is_hit(0.60, false, false));
    }
}
