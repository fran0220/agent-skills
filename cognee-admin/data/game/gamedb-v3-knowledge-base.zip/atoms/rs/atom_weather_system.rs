#[derive(Debug, Clone, PartialEq)]
pub struct WeatherSystemParams {
    pub transition_duration: f32,
    pub rain_slip_chance: f32,
    pub temperature_modifier: f32,
    pub wind_force: f32,
    pub lightning_strike_rate: f32,
}

impl WeatherSystemParams {
    pub fn new() -> Self {
        Self {
            transition_duration: 30.0,
            rain_slip_chance: 0.8,
            temperature_modifier: -10.0,
            wind_force: 15.0,
            lightning_strike_rate: 0.02,
        }
    }

    /// Calculates the effective slip chance based on the current rain intensity (0.0 to 1.0)
    pub fn calculate_slip_chance(&self, rain_intensity: f32) -> f32 {
        (self.rain_slip_chance * rain_intensity).clamp(0.0, 1.0)
    }

    /// Calculates the effective temperature given a base temperature and weather intensity
    pub fn calculate_effective_temperature(&self, base_temp: f32, weather_intensity: f32) -> f32 {
        base_temp + (self.temperature_modifier * weather_intensity)
    }
    
    /// Calculates the probability of a lightning strike in a given time delta
    pub fn calculate_lightning_probability(&self, delta_time: f32) -> f32 {
        (self.lightning_strike_rate * delta_time).clamp(0.0, 1.0)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_slip_chance() {
        let params = WeatherSystemParams::new();
        assert_eq!(params.calculate_slip_chance(0.0), 0.0);
        assert_eq!(params.calculate_slip_chance(0.5), 0.4);
        assert_eq!(params.calculate_slip_chance(1.0), 0.8);
    }

    #[test]
    fn test_calculate_effective_temperature() {
        let params = WeatherSystemParams::new();
        assert_eq!(params.calculate_effective_temperature(20.0, 0.0), 20.0);
        assert_eq!(params.calculate_effective_temperature(20.0, 0.5), 15.0);
        assert_eq!(params.calculate_effective_temperature(20.0, 1.0), 10.0);
    }
    
    #[test]
    fn test_calculate_lightning_probability() {
        let params = WeatherSystemParams::new();
        assert_eq!(params.calculate_lightning_probability(10.0), 0.2);
        assert_eq!(params.calculate_lightning_probability(100.0), 1.0); // Clamped
    }
}
