#[derive(Debug, Clone, PartialEq)]
pub struct ExhaustBanishParams {
    pub exhaust_on_play: bool,
    pub exhaust_on_discard: bool,
    pub exhaust_on_turn_end: bool,
    pub exhaust_damage_multiplier: f32,
    pub exhaust_energy_gain: u32,
}

impl ExhaustBanishParams {
    pub fn new() -> Self {
        Self {
            exhaust_on_play: true,
            exhaust_on_discard: false,
            exhaust_on_turn_end: false,
            exhaust_damage_multiplier: 1.0,
            exhaust_energy_gain: 0,
        }
    }

    /// Calculates the damage dealt when an exhaust card is played.
    pub fn calculate_exhaust_damage(&self, base_damage: f32) -> f32 {
        if self.exhaust_on_play {
            base_damage * self.exhaust_damage_multiplier
        } else {
            base_damage
        }
    }

    /// Determines if a card should be exhausted at the end of the turn.
    pub fn should_exhaust_at_turn_end(&self, is_ethereal: bool) -> bool {
        self.exhaust_on_turn_end || is_ethereal
    }
    
    /// Calculates energy gained from exhausting a card.
    pub fn calculate_energy_gain(&self) -> u32 {
        self.exhaust_energy_gain
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_exhaust_damage() {
        let mut params = ExhaustBanishParams::new();
        params.exhaust_damage_multiplier = 1.5;
        
        // When exhaust_on_play is true
        assert_eq!(params.calculate_exhaust_damage(10.0), 15.0);
        
        // When exhaust_on_play is false
        params.exhaust_on_play = false;
        assert_eq!(params.calculate_exhaust_damage(10.0), 10.0);
    }

    #[test]
    fn test_should_exhaust_at_turn_end() {
        let mut params = ExhaustBanishParams::new();
        
        // Default is false, not ethereal
        assert_eq!(params.should_exhaust_at_turn_end(false), false);
        
        // Ethereal card
        assert_eq!(params.should_exhaust_at_turn_end(true), true);
        
        // Global turn end exhaust
        params.exhaust_on_turn_end = true;
        assert_eq!(params.should_exhaust_at_turn_end(false), true);
    }
}
