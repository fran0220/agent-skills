#[derive(Debug, Clone, PartialEq)]
pub struct TiltGyroParams {
    pub sensitivity_x: f32,
    pub sensitivity_y: f32,
    pub deadzone: f32,
    pub smoothing_factor: f32,
    pub max_angle: f32,
}

impl TiltGyroParams {
    /// Creates a new TiltGyroParams with default values based on Splatoon 3 benchmark
    pub fn new() -> Self {
        Self {
            sensitivity_x: 1.5,
            sensitivity_y: 1.5,
            deadzone: 0.05,
            smoothing_factor: 0.8,
            max_angle: 45.0,
        }
    }

    /// Applies deadzone to the raw tilt input (in radians)
    pub fn apply_deadzone(&self, raw_tilt: f32) -> f32 {
        if raw_tilt.abs() < self.deadzone {
            0.0
        } else {
            let sign = raw_tilt.signum();
            (raw_tilt.abs() - self.deadzone) * sign
        }
    }

    /// Calculates the final output rotation based on raw tilt input, sensitivity, and max angle
    pub fn calculate_output(&self, raw_tilt_x: f32, raw_tilt_y: f32) -> (f32, f32) {
        let deadzoned_x = self.apply_deadzone(raw_tilt_x);
        let deadzoned_y = self.apply_deadzone(raw_tilt_y);

        let mut output_x = deadzoned_x * self.sensitivity_x;
        let mut output_y = deadzoned_y * self.sensitivity_y;

        // Clamp to max angle (assuming max_angle is in degrees, convert to radians for comparison if needed, 
        // but here we just treat output as an abstract value that can be clamped)
        let max_val = self.max_angle.to_radians();
        
        output_x = output_x.clamp(-max_val, max_val);
        output_y = output_y.clamp(-max_val, max_val);

        (output_x, output_y)
    }

    /// Applies exponential smoothing to the output
    pub fn apply_smoothing(&self, current_output: f32, previous_output: f32) -> f32 {
        self.smoothing_factor * previous_output + (1.0 - self.smoothing_factor) * current_output
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_apply_deadzone() {
        let params = TiltGyroParams::new();
        
        // Inside deadzone
        assert_eq!(params.apply_deadzone(0.02), 0.0);
        assert_eq!(params.apply_deadzone(-0.04), 0.0);
        
        // Outside deadzone
        assert_eq!(params.apply_deadzone(0.1), 0.05);
        assert_eq!(params.apply_deadzone(-0.1), -0.05);
    }

    #[test]
    fn test_calculate_output() {
        let params = TiltGyroParams::new();
        
        // Test with values outside deadzone
        let (out_x, out_y) = params.calculate_output(0.1, -0.1);
        
        // (0.1 - 0.05) * 1.5 = 0.075
        assert!((out_x - 0.075).abs() < f32::EPSILON);
        assert!((out_y - (-0.075)).abs() < f32::EPSILON);
    }

    #[test]
    fn test_apply_smoothing() {
        let params = TiltGyroParams::new();
        
        let current = 1.0;
        let previous = 0.5;
        
        // 0.8 * 0.5 + 0.2 * 1.0 = 0.4 + 0.2 = 0.6
        let smoothed = params.apply_smoothing(current, previous);
        assert!((smoothed - 0.6).abs() < f32::EPSILON);
    }
}
