#[derive(Debug, Clone, PartialEq)]
pub struct FmvChoiceParams {
    pub choice_timeout: f32,
    pub num_options: u32,
    pub transition_delay: f32,
    pub seamless_audio: bool,
}

impl FmvChoiceParams {
    /// Creates a new FmvChoiceParams with default values based on Late Shift benchmark.
    pub fn new() -> Self {
        Self {
            choice_timeout: 5.0,
            num_options: 2,
            transition_delay: 0.1,
            seamless_audio: true,
        }
    }

    /// Calculates the total time allowed for a choice, including transition delay.
    pub fn total_interaction_time(&self) -> f32 {
        self.choice_timeout + self.transition_delay
    }

    /// Determines if a choice was made within the allowed time.
    pub fn is_choice_valid(&self, time_taken: f32) -> bool {
        if self.choice_timeout <= 0.0 {
            return true; // Infinite time
        }
        time_taken <= self.choice_timeout
    }

    /// Calculates the score multiplier based on how quickly the choice was made.
    /// Faster choices yield higher multipliers (up to 2.0x), slower choices approach 1.0x.
    pub fn speed_multiplier(&self, time_taken: f32) -> f32 {
        if self.choice_timeout <= 0.0 || time_taken >= self.choice_timeout {
            return 1.0;
        }
        let ratio = time_taken / self.choice_timeout;
        1.0 + (1.0 - ratio)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_total_interaction_time() {
        let params = FmvChoiceParams::new();
        assert_eq!(params.total_interaction_time(), 5.1);
    }

    #[test]
    fn test_is_choice_valid() {
        let params = FmvChoiceParams::new();
        assert!(params.is_choice_valid(3.0));
        assert!(params.is_choice_valid(5.0));
        assert!(!params.is_choice_valid(5.1));
        
        let mut infinite_params = FmvChoiceParams::new();
        infinite_params.choice_timeout = 0.0;
        assert!(infinite_params.is_choice_valid(100.0));
    }

    #[test]
    fn test_speed_multiplier() {
        let params = FmvChoiceParams::new();
        // time_taken = 0.0 -> ratio = 0.0 -> multiplier = 2.0
        assert_eq!(params.speed_multiplier(0.0), 2.0);
        // time_taken = 2.5 -> ratio = 0.5 -> multiplier = 1.5
        assert_eq!(params.speed_multiplier(2.5), 1.5);
        // time_taken = 5.0 -> ratio = 1.0 -> multiplier = 1.0
        assert_eq!(params.speed_multiplier(5.0), 1.0);
        // time_taken > 5.0 -> multiplier = 1.0
        assert_eq!(params.speed_multiplier(6.0), 1.0);
    }
}
