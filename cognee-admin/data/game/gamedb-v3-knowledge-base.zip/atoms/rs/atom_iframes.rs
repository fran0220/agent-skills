#[derive(Debug, Clone, PartialEq)]
pub struct IFramesParams {
    pub startup_frames: u32,
    pub active_iframes: u32,
    pub recovery_frames: u32,
    pub stamina_cost: f32,
}

impl IFramesParams {
    /// Creates a new IFramesParams with default values based on Dark Souls III benchmark.
    pub fn new() -> Self {
        Self {
            startup_frames: 0,
            active_iframes: 13,
            recovery_frames: 12,
            stamina_cost: 15.0,
        }
    }

    /// Checks if a given frame is within the active invincibility window.
    pub fn is_invincible(&self, current_frame: u32) -> bool {
        current_frame >= self.startup_frames 
            && current_frame < (self.startup_frames + self.active_iframes)
    }

    /// Calculates the total duration of the dodge animation in frames.
    pub fn total_duration(&self) -> u32 {
        self.startup_frames + self.active_iframes + self.recovery_frames
    }

    /// Checks if the player has enough stamina to perform the dodge.
    pub fn can_dodge(&self, current_stamina: f32) -> bool {
        current_stamina >= self.stamina_cost
    }
}

impl Default for IFramesParams {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_is_invincible() {
        let params = IFramesParams::new();
        
        // Startup frames: 0
        // Active frames: 13 (frames 0 to 12)
        // Recovery frames: 12 (frames 13 to 24)
        
        assert!(params.is_invincible(0));
        assert!(params.is_invincible(5));
        assert!(params.is_invincible(12));
        assert!(!params.is_invincible(13));
        assert!(!params.is_invincible(20));
    }

    #[test]
    fn test_total_duration() {
        let params = IFramesParams::new();
        assert_eq!(params.total_duration(), 25);
    }

    #[test]
    fn test_can_dodge() {
        let params = IFramesParams::new();
        assert!(params.can_dodge(20.0));
        assert!(params.can_dodge(15.0));
        assert!(!params.can_dodge(10.0));
    }
}
