#[derive(Debug, Clone)]
pub struct SharedDraftParams {
    pub carousel_radius: f32,
    pub rotation_speed: f32,
    pub entity_count: u32,
    pub release_interval: f32,
    pub selection_timeout: f32,
    pub player_move_speed: f32,
    pub collision_radius: f32,
}

impl SharedDraftParams {
    pub fn new() -> Self {
        Self {
            carousel_radius: 10.0,
            rotation_speed: 30.0,
            entity_count: 9,
            release_interval: 3.5,
            selection_timeout: 15.0,
            player_move_speed: 6.0,
            collision_radius: 1.2,
        }
    }

    /// Calculates the angular position of an entity at a given time.
    /// `entity_index` is the index of the entity (0 to entity_count - 1).
    /// `time_elapsed` is the time in seconds since the draft started.
    pub fn calculate_entity_angle(&self, entity_index: u32, time_elapsed: f32) -> f32 {
        let initial_angle = (360.0 / self.entity_count as f32) * entity_index as f32;
        let current_angle = initial_angle + (self.rotation_speed * time_elapsed);
        current_angle % 360.0
    }

    /// Checks if a player has collided with an entity.
    /// `player_pos` is the (x, y) coordinates of the player.
    /// `entity_angle` is the current angle of the entity in degrees.
    pub fn check_collision(&self, player_pos: (f32, f32), entity_angle: f32) -> bool {
        let angle_rad = entity_angle.to_radians();
        let entity_x = self.carousel_radius * angle_rad.cos();
        let entity_y = self.carousel_radius * angle_rad.sin();

        let dx = player_pos.0 - entity_x;
        let dy = player_pos.1 - entity_y;
        let distance_squared = dx * dx + dy * dy;

        distance_squared <= self.collision_radius * self.collision_radius
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_entity_angle() {
        let params = SharedDraftParams::new();
        
        // Entity 0 at time 0 should be at 0 degrees
        assert_eq!(params.calculate_entity_angle(0, 0.0), 0.0);
        
        // Entity 0 after 1 second should be at 30 degrees
        assert_eq!(params.calculate_entity_angle(0, 1.0), 30.0);
        
        // Entity 1 at time 0 should be at 40 degrees (360 / 9)
        assert_eq!(params.calculate_entity_angle(1, 0.0), 40.0);
        
        // Entity 0 after 12 seconds should be at 360 -> 0 degrees
        assert_eq!(params.calculate_entity_angle(0, 12.0), 0.0);
    }

    #[test]
    fn test_check_collision() {
        let params = SharedDraftParams::new();
        
        // Entity at 0 degrees is at (10.0, 0.0)
        let entity_angle = 0.0;
        
        // Player exactly at entity position
        assert!(params.check_collision((10.0, 0.0), entity_angle));
        
        // Player within collision radius (1.2)
        assert!(params.check_collision((11.0, 0.0), entity_angle));
        
        // Player outside collision radius
        assert!(!params.check_collision((12.0, 0.0), entity_angle));
    }
}
