#[derive(Debug, Clone, PartialEq)]
pub struct DiplomacyParams {
    pub base_relation: f32,
    pub trust_decay_rate: f32,
    pub gift_impact_multiplier: f32,
    pub war_exhaustion_rate: f32,
    pub alliance_threshold: f32,
}

impl DiplomacyParams {
    pub fn new() -> Self {
        Self {
            base_relation: 0.0,
            trust_decay_rate: 1.0,
            gift_impact_multiplier: 0.5,
            war_exhaustion_rate: 0.1,
            alliance_threshold: 80.0,
        }
    }

    /// Calculates the new relation score after receiving a gift.
    pub fn calculate_gift_impact(&self, current_relation: f32, gift_value: f32) -> f32 {
        let impact = gift_value * self.gift_impact_multiplier;
        (current_relation + impact).clamp(-100.0, 100.0)
    }

    /// Calculates the trust decay over a given number of turns.
    pub fn calculate_trust_decay(&self, current_trust: f32, turns: u32) -> f32 {
        let decay = self.trust_decay_rate * (turns as f32);
        (current_trust - decay).max(0.0)
    }

    /// Checks if the current relation is high enough to form an alliance.
    pub fn can_form_alliance(&self, current_relation: f32) -> bool {
        current_relation >= self.alliance_threshold
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_gift_impact() {
        let params = DiplomacyParams::new();
        let new_relation = params.calculate_gift_impact(10.0, 50.0);
        // 10.0 + (50.0 * 0.5) = 35.0
        assert_eq!(new_relation, 35.0);
        
        // Test clamping
        let max_relation = params.calculate_gift_impact(90.0, 100.0);
        assert_eq!(max_relation, 100.0);
    }

    #[test]
    fn test_trust_decay() {
        let params = DiplomacyParams::new();
        let new_trust = params.calculate_trust_decay(50.0, 10);
        // 50.0 - (1.0 * 10) = 40.0
        assert_eq!(new_trust, 40.0);
        
        // Test min bound
        let min_trust = params.calculate_trust_decay(5.0, 10);
        assert_eq!(min_trust, 0.0);
    }

    #[test]
    fn test_alliance_formation() {
        let params = DiplomacyParams::new();
        assert!(params.can_form_alliance(85.0));
        assert!(!params.can_form_alliance(75.0));
    }
}
