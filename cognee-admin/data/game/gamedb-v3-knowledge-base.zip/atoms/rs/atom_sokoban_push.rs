#[derive(Debug, Clone, PartialEq)]
pub struct SokobanPushParams {
    pub push_speed: f32,
    pub max_push_count: u32,
    pub undo_limit: u32,
    pub grid_size: f32,
}

impl SokobanPushParams {
    pub fn new() -> Self {
        Self {
            push_speed: 5.0,
            max_push_count: 1,
            undo_limit: 999,
            grid_size: 32.0,
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub enum CellState {
    Empty,
    Wall,
    Box,
}

pub struct SokobanGrid {
    pub width: usize,
    pub height: usize,
    pub cells: Vec<CellState>,
}

impl SokobanGrid {
    pub fn new(width: usize, height: usize, cells: Vec<CellState>) -> Self {
        Self { width, height, cells }
    }

    pub fn get_cell(&self, x: i32, y: i32) -> Option<CellState> {
        if x < 0 || y < 0 || x >= self.width as i32 || y >= self.height as i32 {
            return None;
        }
        Some(self.cells[(y as usize) * self.width + (x as usize)])
    }

    pub fn set_cell(&mut self, x: i32, y: i32, state: CellState) {
        if x >= 0 && y >= 0 && x < self.width as i32 && y < self.height as i32 {
            self.cells[(y as usize) * self.width + (x as usize)] = state;
        }
    }
}

/// Core logic to check if a push is valid and perform it.
/// Returns true if the push was successful, false otherwise.
pub fn try_push(
    grid: &mut SokobanGrid,
    player_x: i32,
    player_y: i32,
    dx: i32,
    dy: i32,
    params: &SokobanPushParams,
) -> bool {
    let mut push_count = 0;
    let mut check_x = player_x + dx;
    let mut check_y = player_y + dy;

    // Count how many boxes are in a row
    while let Some(CellState::Box) = grid.get_cell(check_x, check_y) {
        push_count += 1;
        check_x += dx;
        check_y += dy;
    }

    if push_count == 0 {
        // No box to push
        return false;
    }

    if push_count > params.max_push_count {
        // Too many boxes to push
        return false;
    }

    // Check what is after the boxes
    match grid.get_cell(check_x, check_y) {
        Some(CellState::Empty) => {
            // We can push!
            // Move the boxes: the first box becomes empty, and the space after the last box becomes a box.
            grid.set_cell(player_x + dx, player_y + dy, CellState::Empty);
            grid.set_cell(check_x, check_y, CellState::Box);
            true
        }
        _ => {
            // Blocked by wall or out of bounds
            false
        }
    }
}

/// Calculate the time required to push a box across one grid cell.
pub fn calculate_push_time(params: &SokobanPushParams) -> f32 {
    if params.push_speed <= 0.0 {
        return f32::INFINITY;
    }
    1.0 / params.push_speed
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_try_push_success() {
        let params = SokobanPushParams::new();
        // Grid: P B E
        let mut grid = SokobanGrid::new(3, 1, vec![CellState::Empty, CellState::Box, CellState::Empty]);
        
        let success = try_push(&mut grid, 0, 0, 1, 0, &params);
        assert!(success);
        assert_eq!(grid.get_cell(1, 0), Some(CellState::Empty));
        assert_eq!(grid.get_cell(2, 0), Some(CellState::Box));
    }

    #[test]
    fn test_try_push_blocked_by_wall() {
        let params = SokobanPushParams::new();
        // Grid: P B W
        let mut grid = SokobanGrid::new(3, 1, vec![CellState::Empty, CellState::Box, CellState::Wall]);
        
        let success = try_push(&mut grid, 0, 0, 1, 0, &params);
        assert!(!success);
        assert_eq!(grid.get_cell(1, 0), Some(CellState::Box));
    }

    #[test]
    fn test_try_push_too_many_boxes() {
        let params = SokobanPushParams::new(); // max_push_count is 1
        // Grid: P B B E
        let mut grid = SokobanGrid::new(4, 1, vec![CellState::Empty, CellState::Box, CellState::Box, CellState::Empty]);
        
        let success = try_push(&mut grid, 0, 0, 1, 0, &params);
        assert!(!success);
        assert_eq!(grid.get_cell(1, 0), Some(CellState::Box));
        assert_eq!(grid.get_cell(2, 0), Some(CellState::Box));
    }

    #[test]
    fn test_calculate_push_time() {
        let params = SokobanPushParams {
            push_speed: 5.0,
            max_push_count: 1,
            undo_limit: 999,
            grid_size: 32.0,
        };
        assert_eq!(calculate_push_time(&params), 0.2);
    }
}
