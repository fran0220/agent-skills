#[derive(Debug, Clone)]
pub struct CraftingRecipeParams {
    pub input_quantities: Vec<u32>,
    pub output_quantity: u32,
    pub crafting_time: f32,
    pub success_chance: f32,
}

impl CraftingRecipeParams {
    pub fn new() -> Self {
        Self {
            input_quantities: vec![5],
            output_quantity: 1,
            crafting_time: 0.5,
            success_chance: 1.0,
        }
    }

    pub fn can_craft(&self, available_inputs: &[u32]) -> bool {
        if available_inputs.len() < self.input_quantities.len() {
            return false;
        }
        for (required, available) in self.input_quantities.iter().zip(available_inputs.iter()) {
            if available < required {
                return false;
            }
        }
        true
    }

    pub fn calculate_crafting_time(&self, speed_multiplier: f32) -> f32 {
        if speed_multiplier <= 0.0 {
            return f32::INFINITY;
        }
        self.crafting_time / speed_multiplier
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_can_craft() {
        let params = CraftingRecipeParams::new();
        assert!(params.can_craft(&[5]));
        assert!(params.can_craft(&[10]));
        assert!(!params.can_craft(&[4]));
        assert!(!params.can_craft(&[]));
    }

    #[test]
    fn test_calculate_crafting_time() {
        let params = CraftingRecipeParams::new();
        assert_eq!(params.calculate_crafting_time(1.0), 0.5);
        assert_eq!(params.calculate_crafting_time(2.0), 0.25);
        assert_eq!(params.calculate_crafting_time(0.5), 1.0);
    }
}
