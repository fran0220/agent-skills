#[derive(Debug, Clone, PartialEq)]
pub struct PrestigeResetParams {
    pub base_requirement: f32,
    pub scaling_exponent: f32,
    pub reward_multiplier: f32,
    pub min_time_between_resets: f32,
}

impl PrestigeResetParams {
    /// Creates a new PrestigeResetParams with default values based on AdVenture Capitalist benchmark.
    pub fn new() -> Self {
        Self {
            base_requirement: 1_000_000_000_000_000.0, // 1e15
            scaling_exponent: 0.5,
            reward_multiplier: 0.02,
            min_time_between_resets: 0.0,
        }
    }

    /// Calculates the total prestige currency earned based on lifetime primary currency.
    /// Formula: (lifetime_currency / base_requirement) ^ scaling_exponent
    pub fn calculate_total_prestige_currency(&self, lifetime_currency: f32) -> f32 {
        if lifetime_currency < self.base_requirement {
            return 0.0;
        }
        
        let ratio = lifetime_currency / self.base_requirement;
        ratio.powf(self.scaling_exponent).floor()
    }

    /// Calculates the prestige currency to be gained upon reset.
    /// This is the difference between the total prestige currency earned and the currently owned prestige currency.
    pub fn calculate_pending_prestige_currency(&self, lifetime_currency: f32, current_prestige_currency: f32) -> f32 {
        let total_earned = self.calculate_total_prestige_currency(lifetime_currency);
        if total_earned > current_prestige_currency {
            total_earned - current_prestige_currency
        } else {
            0.0
        }
    }

    /// Calculates the total production multiplier provided by the current prestige currency.
    /// Formula: 1.0 + (current_prestige_currency * reward_multiplier)
    pub fn calculate_production_multiplier(&self, current_prestige_currency: f32) -> f32 {
        1.0 + (current_prestige_currency * self.reward_multiplier)
    }
}

impl Default for PrestigeResetParams {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_calculate_total_prestige_currency() {
        let params = PrestigeResetParams {
            base_requirement: 1_000_000.0,
            scaling_exponent: 0.5,
            reward_multiplier: 0.02,
            min_time_between_resets: 0.0,
        };

        // Below requirement
        assert_eq!(params.calculate_total_prestige_currency(500_000.0), 0.0);

        // Exactly at requirement
        assert_eq!(params.calculate_total_prestige_currency(1_000_000.0), 1.0);

        // Above requirement
        assert_eq!(params.calculate_total_prestige_currency(4_000_000.0), 2.0);
        assert_eq!(params.calculate_total_prestige_currency(9_000_000.0), 3.0);
    }

    #[test]
    fn test_calculate_pending_prestige_currency() {
        let params = PrestigeResetParams {
            base_requirement: 1_000_000.0,
            scaling_exponent: 0.5,
            reward_multiplier: 0.02,
            min_time_between_resets: 0.0,
        };

        // 4M lifetime currency means 2 total prestige currency.
        // If we already have 1, pending is 1.
        assert_eq!(params.calculate_pending_prestige_currency(4_000_000.0, 1.0), 1.0);

        // If we already have 2, pending is 0.
        assert_eq!(params.calculate_pending_prestige_currency(4_000_000.0, 2.0), 0.0);

        // If we already have 3 (somehow), pending is 0.
        assert_eq!(params.calculate_pending_prestige_currency(4_000_000.0, 3.0), 0.0);
    }

    #[test]
    fn test_calculate_production_multiplier() {
        let params = PrestigeResetParams::new();

        // 0 prestige currency -> 1.0x multiplier
        assert_eq!(params.calculate_production_multiplier(0.0), 1.0);

        // 100 prestige currency -> 1.0 + (100 * 0.02) = 3.0x multiplier
        assert_eq!(params.calculate_production_multiplier(100.0), 3.0);
    }
}
