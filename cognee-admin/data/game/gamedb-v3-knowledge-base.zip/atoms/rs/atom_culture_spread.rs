#[derive(Debug, Clone, PartialEq)]
pub struct CultureSpreadParams {
    pub base_spread_rate: f32,
    pub distance_penalty: f32,
    pub conversion_threshold: f32,
    pub missionary_strength: f32,
    pub resistance_factor: f32,
}

impl CultureSpreadParams {
    /// Creates a new `CultureSpreadParams` with default values based on benchmark data.
    pub fn new() -> Self {
        Self {
            base_spread_rate: 1.0,
            distance_penalty: 0.5,
            conversion_threshold: 50.0,
            missionary_strength: 200.0,
            resistance_factor: 0.2,
        }
    }

    /// Calculates the passive influence spread to a target node based on distance.
    /// Formula: base_spread_rate * (1.0 - (distance * distance_penalty)).max(0.0)
    pub fn calculate_passive_spread(&self, distance: f32) -> f32 {
        let penalty = distance * self.distance_penalty;
        let multiplier = (1.0 - penalty).max(0.0);
        self.base_spread_rate * multiplier
    }

    /// Calculates the active influence applied by a missionary, accounting for local resistance.
    /// Formula: missionary_strength * (1.0 - resistance_factor)
    pub fn calculate_active_spread(&self) -> f32 {
        self.missionary_strength * (1.0 - self.resistance_factor).max(0.0)
    }

    /// Checks if the accumulated influence has reached the conversion threshold.
    pub fn is_converted(&self, current_influence: f32) -> bool {
        current_influence >= self.conversion_threshold
    }
}

impl Default for CultureSpreadParams {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_passive_spread() {
        let params = CultureSpreadParams::new();
        
        // Distance 0: full spread
        assert_eq!(params.calculate_passive_spread(0.0), 1.0);
        
        // Distance 1: half spread (1.0 - 1.0 * 0.5) = 0.5
        assert_eq!(params.calculate_passive_spread(1.0), 0.5);
        
        // Distance 2: zero spread (1.0 - 2.0 * 0.5) = 0.0
        assert_eq!(params.calculate_passive_spread(2.0), 0.0);
        
        // Distance 3: zero spread (clamped to 0.0)
        assert_eq!(params.calculate_passive_spread(3.0), 0.0);
    }

    #[test]
    fn test_active_spread() {
        let params = CultureSpreadParams::new();
        
        // Active spread with 0.2 resistance: 200.0 * (1.0 - 0.2) = 160.0
        assert_eq!(params.calculate_active_spread(), 160.0);
    }

    #[test]
    fn test_conversion_threshold() {
        let params = CultureSpreadParams::new();
        
        // Threshold is 50.0
        assert!(!params.is_converted(49.9));
        assert!(params.is_converted(50.0));
        assert!(params.is_converted(100.0));
    }
}
