#[derive(Debug, Clone)]
pub struct NotificationReminder {
    pub trigger_delay: u32,
    pub expiration_time: u32,
    pub max_queued_notifications: u32,
    pub is_push_enabled: bool,
    pub cooldown_between_alerts: u32,
    
    // Internal state
    pub queued_count: u32,
    pub last_alert_time: u32,
}

impl NotificationReminder {
    /// Creates a new NotificationReminder with default benchmark values.
    pub fn new() -> Self {
        Self {
            trigger_delay: 3600,
            expiration_time: 86400,
            max_queued_notifications: 10,
            is_push_enabled: true,
            cooldown_between_alerts: 14400,
            queued_count: 0,
            last_alert_time: 0,
        }
    }

    /// Attempts to queue a new notification.
    /// Returns true if successfully queued, false if max queue reached.
    pub fn queue_notification(&mut self) -> bool {
        if self.queued_count < self.max_queued_notifications {
            self.queued_count += 1;
            true
        } else {
            false
        }
    }

    /// Checks if an alert can be sent based on cooldown and queue status.
    /// If an alert is sent, updates the last_alert_time and decrements the queue.
    pub fn try_send_alert(&mut self, current_time: u32) -> bool {
        if self.queued_count == 0 {
            return false;
        }

        if current_time >= self.last_alert_time + self.cooldown_between_alerts {
            self.last_alert_time = current_time;
            self.queued_count -= 1;
            true
        } else {
            false
        }
    }

    /// Clears expired notifications from the queue.
    /// For simplicity in this atom, we just clear all if a certain time has passed.
    pub fn clear_expired(&mut self, current_time: u32, notification_time: u32) {
        if current_time >= notification_time + self.expiration_time {
            self.queued_count = 0;
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_queue_notification() {
        let mut reminder = NotificationReminder::new();
        reminder.max_queued_notifications = 2;
        
        assert_eq!(reminder.queue_notification(), true);
        assert_eq!(reminder.queued_count, 1);
        
        assert_eq!(reminder.queue_notification(), true);
        assert_eq!(reminder.queued_count, 2);
        
        // Should fail because max is 2
        assert_eq!(reminder.queue_notification(), false);
        assert_eq!(reminder.queued_count, 2);
    }

    #[test]
    fn test_try_send_alert() {
        let mut reminder = NotificationReminder::new();
        reminder.cooldown_between_alerts = 100;
        reminder.last_alert_time = 0;
        
        // Queue a notification
        reminder.queue_notification();
        
        // Try to send at time 50 (too early)
        assert_eq!(reminder.try_send_alert(50), false);
        assert_eq!(reminder.queued_count, 1);
        
        // Try to send at time 100 (just enough cooldown)
        assert_eq!(reminder.try_send_alert(100), true);
        assert_eq!(reminder.queued_count, 0);
        assert_eq!(reminder.last_alert_time, 100);
    }
}
