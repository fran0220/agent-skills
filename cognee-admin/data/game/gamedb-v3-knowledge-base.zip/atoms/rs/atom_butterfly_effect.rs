#[derive(Debug, Clone, PartialEq)]
pub struct ButterflyEffectParams {
    pub decision_timer: f32,
    pub impact_delay: u32,
    pub visibility_flag: bool,
    pub relationship_change: f32,
}

impl ButterflyEffectParams {
    /// Creates a new ButterflyEffectParams with default values based on benchmark data.
    pub fn new() -> Self {
        Self {
            decision_timer: 5.0,
            impact_delay: 10,
            visibility_flag: true,
            relationship_change: 0.1,
        }
    }

    /// Calculates the new relationship value after a choice is made.
    /// If the time taken exceeds the decision timer, a penalty might be applied or a default choice is forced.
    pub fn make_choice(&self, time_taken: f32, current_relationship: f32, is_positive_choice: bool) -> f32 {
        if time_taken > self.decision_timer {
            // Penalty for not deciding in time
            current_relationship - self.relationship_change
        } else if is_positive_choice {
            current_relationship + self.relationship_change
        } else {
            current_relationship - self.relationship_change
        }
    }

    /// Checks if the consequence of a past choice should be triggered based on the current chapter.
    pub fn check_consequence(&self, choice_chapter: u32, current_chapter: u32) -> bool {
        current_chapter >= choice_chapter + self.impact_delay
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_make_choice_within_time() {
        let params = ButterflyEffectParams::new();
        let initial_relationship = 0.5;
        
        // Positive choice within time
        let new_rel_pos = params.make_choice(3.0, initial_relationship, true);
        assert_eq!(new_rel_pos, 0.6);

        // Negative choice within time
        let new_rel_neg = params.make_choice(4.0, initial_relationship, false);
        assert_eq!(new_rel_neg, 0.4);
    }

    #[test]
    fn test_make_choice_timeout() {
        let params = ButterflyEffectParams::new();
        let initial_relationship = 0.5;
        
        // Timeout choice (time_taken > decision_timer)
        let new_rel_timeout = params.make_choice(6.0, initial_relationship, true);
        assert_eq!(new_rel_timeout, 0.4); // Penalty applied regardless of choice intent
    }

    #[test]
    fn test_check_consequence() {
        let params = ButterflyEffectParams::new();
        let choice_chapter = 2;
        
        // Consequence not yet triggered
        assert!(!params.check_consequence(choice_chapter, 10));
        
        // Consequence triggered exactly at delay
        assert!(params.check_consequence(choice_chapter, 12));
        
        // Consequence triggered after delay
        assert!(params.check_consequence(choice_chapter, 15));
    }
}
