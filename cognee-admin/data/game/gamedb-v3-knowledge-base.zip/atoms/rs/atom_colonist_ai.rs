#[derive(Debug, Clone)]
pub struct ColonistNeedsParams {
    pub hunger_decay_rate: f32,
    pub max_energy: f32,
    pub sleep_restore_rate: f32,
    pub mental_break_threshold: f32,
}

impl ColonistNeedsParams {
    /// Creates a new `ColonistNeedsParams` with default values based on RimWorld v1.4 benchmarks.
    pub fn new() -> Self {
        Self {
            hunger_decay_rate: 1.5,
            max_energy: 100.0,
            sleep_restore_rate: 12.0,
            mental_break_threshold: 0.35,
        }
    }
}

#[derive(Debug, Clone)]
pub struct ColonistState {
    pub hunger: f32,
    pub energy: f32,
    pub mood: f32,
}

impl ColonistState {
    pub fn new(max_energy: f32) -> Self {
        Self {
            hunger: 100.0, // 100 is full, 0 is starving
            energy: max_energy,
            mood: 1.0, // 1.0 is perfectly happy, 0.0 is miserable
        }
    }

    /// Simulates the passage of time (in hours) and updates the colonist's needs.
    /// Returns true if a mental break is triggered.
    pub fn update_needs(&mut self, hours: f32, params: &ColonistNeedsParams) -> bool {
        // Decay hunger
        self.hunger -= params.hunger_decay_rate * hours;
        if self.hunger < 0.0 {
            self.hunger = 0.0;
        }

        // Decay energy (assuming active)
        // Let's say energy decays at a base rate of 5.0 per hour when awake
        self.energy -= 5.0 * hours;
        if self.energy < 0.0 {
            self.energy = 0.0;
        }

        // Update mood based on needs
        // Simple formula: average of hunger and energy percentages
        let hunger_pct = self.hunger / 100.0;
        let energy_pct = self.energy / params.max_energy;
        self.mood = (hunger_pct + energy_pct) / 2.0;

        // Check for mental break
        self.mood < params.mental_break_threshold
    }

    /// Simulates the colonist sleeping to restore energy.
    pub fn sleep(&mut self, hours: f32, params: &ColonistNeedsParams) {
        self.energy += params.sleep_restore_rate * hours;
        if self.energy > params.max_energy {
            self.energy = params.max_energy;
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_need_decay_and_mental_break() {
        let params = ColonistNeedsParams::new();
        let mut state = ColonistState::new(params.max_energy);

        // Simulate 10 hours of activity
        let break_triggered = state.update_needs(10.0, &params);
        
        assert_eq!(state.hunger, 85.0); // 100 - (1.5 * 10)
        assert_eq!(state.energy, 50.0); // 100 - (5.0 * 10)
        assert_eq!(state.mood, 0.675); // (0.85 + 0.5) / 2
        assert!(!break_triggered);

        // Simulate another 20 hours of activity (total 30 hours without food/sleep)
        let break_triggered = state.update_needs(20.0, &params);
        
        assert_eq!(state.hunger, 55.0); // 85 - (1.5 * 20)
        assert_eq!(state.energy, 0.0); // 50 - (5.0 * 20) -> clamped to 0
        assert_eq!(state.mood, 0.275); // (0.55 + 0.0) / 2
        assert!(break_triggered); // Mood 0.275 < 0.35 threshold
    }

    #[test]
    fn test_sleep_restoration() {
        let params = ColonistNeedsParams::new();
        let mut state = ColonistState::new(params.max_energy);

        // Deplete energy
        state.energy = 20.0;

        // Sleep for 5 hours
        state.sleep(5.0, &params);
        
        assert_eq!(state.energy, 80.0); // 20 + (12.0 * 5)

        // Sleep for another 5 hours (should cap at max_energy)
        state.sleep(5.0, &params);
        
        assert_eq!(state.energy, 100.0); // Capped at 100.0
    }
}
