# Gameplay Atom: Light & Shadow Stealth

## 1. Identity
- **Atom ID:** `atom_light_shadow`
- **English Name:** Light & Shadow Stealth
- **Chinese Name:** 光影潜行
- **Category:** A
- **Definition:** A stealth mechanic where the player's visibility to enemies is dynamically determined by the ambient light level of their current position. Players must navigate through shadows to remain undetected while avoiding illuminated areas.

## 2. Core Verb & State Machine
- **Core Verb:** Hide / Sneak
- **State Diagram:**
  [Hidden] <--(Enter Shadow/Leave Light)--> [Exposed]
  [Exposed] --(Spotted by Enemy)--> [Detected]
  [Detected] --(Break Line of Sight & Hide)--> [Searching]
  [Searching] --(Time Expires)--> [Hidden]

- **States:**
  - `Hidden`: Player is in darkness, significantly reducing enemy detection range.
  - `Exposed`: Player is in a lit area, normal or increased enemy detection range.
  - `Detected`: Enemy has spotted the player and is actively engaging.
  - `Searching`: Enemy has lost sight of the player and is looking for them.

- **Transitions:**
  - `Hidden` -> `Exposed`: Player moves into a light source.
  - `Exposed` -> `Hidden`: Player moves into a shadow.
  - `Exposed` -> `Detected`: Enemy line of sight intersects player for a duration exceeding the detection threshold.
  - `Detected` -> `Searching`: Player breaks line of sight and enters a hidden state.
  - `Searching` -> `Hidden`: Enemy search timer expires without finding the player.

## 3. MDA Analysis
- **Mechanics:** The game calculates a visibility score based on the player's position relative to light sources. This score modifies the vision cones and detection speed of AI enemies.
- **Dynamics:** Players actively seek out and create shadows (e.g., by shooting out lights). They time their movements between cover and shadows to avoid enemy patrols.
- **Aesthetics:** Tension, suspense, and the thrill of outsmarting enemies. A feeling of empowerment when successfully navigating a dangerous area unseen.

## 4. Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value (Thief: The Dark Project v1.33) | Unit |
|---|---|---|---|---|
| `light_level` | f32 | 0.0 - 1.0 | 0.0 | N/A |
| `detection_multiplier` | f32 | 0.1 - 2.0 | 0.2 | Multiplier |
| `detection_speed` | f32 | 0.5 - 5.0 | 2.0 | Seconds |
| `shadow_threshold` | f32 | 0.0 - 0.5 | 0.3 | N/A |

## 5. Benchmark Data
- **Thief: The Dark Project (v1.33):**
  - `light_level` ranges from 0 (completely hidden) to 15 (fully visible). Normalized to 0.0 - 1.0.
  - `detection_speed` in full light is almost instantaneous (0.5s), while in deep shadow it can take up to 3.0s for an enemy to fully detect the player at close range.
- **Tom Clancy's Splinter Cell (v1.0):**
  - Uses a discrete light meter with 5 stages.
  - `shadow_threshold` is clearly defined; dropping below stage 2 makes the player virtually invisible beyond 5 meters.

## 6. Common Variants
1. **Binary Light/Dark:** The player is either completely hidden in shadows or completely visible in light (e.g., Mark of the Ninja).
2. **Analog Light Meter:** A continuous scale of visibility based on exact light intensity (e.g., Splinter Cell).
3. **Dynamic Shadows:** Shadows cast by moving objects or enemies can be used for cover.
4. **Sound Integration:** Light level affects visual detection, while movement speed affects auditory detection, requiring balancing both.

## 7. Compatibility Notes
- **Commonly Pairs With:** `atom_line_of_sight`, `atom_noise_generation`, `atom_takedown`, `atom_distraction`.
- **Conflicts:** Can conflict with `atom_fast_paced_combat` if not balanced correctly, as stealth encourages slow, methodical gameplay.

## 8. Anti-Patterns
1. **Unclear Light Boundaries:** Players cannot easily tell if they are in shadow or light, leading to frustrating, unpredictable detections.
2. **Binary Detection:** Enemies instantly detect the player the moment they step into the light, without a grace period or warning indicator.
3. **Useless Shadows:** Shadows are placed in areas where enemies never patrol, making the mechanic irrelevant.
