# Gameplay Atom: Offline Progress

## 1. Identity
- **Atom ID:** `atom_offline_progress`
- **English Name:** Offline Progress
- **Chinese Name:** 离线进度
- **Category:** E (Economy) / F (Flow)
- **Definition:** Offline Progress is a core gameplay mechanic where the game state continues to advance and accumulate resources or progress even when the player is not actively playing or logged into the game. This mechanic is foundational to idle games and modern RPGs, ensuring that players feel rewarded for returning to the game after a period of absence, thereby increasing long-term retention and reducing the grind associated with active play.

## 2. Core Verb & State Machine
- **Core Verb:** "Claim" (The player logs in to claim accumulated offline rewards).

**State Diagram:**
```text
[Active Play] --(Player logs out)--> [Offline Accumulation]
[Offline Accumulation] --(Time passes)--> [Offline Accumulation (Updating)]
[Offline Accumulation] --(Max time reached)--> [Capped Accumulation]
[Offline Accumulation] --(Player logs in)--> [Reward Pending]
[Capped Accumulation] --(Player logs in)--> [Reward Pending]
[Reward Pending] --(Player claims)--> [Active Play]
```

**States and Transitions:**
- **Active Play:** The player is currently engaged with the game.
- **Offline Accumulation:** The game calculates resources generated over time while the player is away.
- **Capped Accumulation:** The maximum allowable offline time has been reached; no further resources are generated.
- **Reward Pending:** The player has logged in and is presented with the accumulated rewards, waiting for the player to claim them.

## 3. MDA Analysis
- **Mechanics:** The system records the timestamp when the player logs out and compares it to the timestamp when they log back in. The time difference (delta time) is multiplied by the player's current resource generation rates to calculate the total offline rewards. A hard cap is usually applied to the maximum offline time (e.g., 12 hours) to encourage regular logins.
- **Dynamics:** Players optimize their resource generation rates before logging off to maximize their offline gains. They also develop a habit of logging in at specific intervals (e.g., twice a day) to ensure they do not hit the offline time cap and waste potential progress.
- **Aesthetics:** Players experience a sense of continuous growth and anticipation. Returning to the game feels highly rewarding, as they are immediately greeted with a burst of resources, creating a positive feedback loop that respects their real-world time constraints.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Game) | Unit |
|---|---|---|---|---|
| `max_offline_time` | `u32` | 4 - 24 | 12 (AFK Arena v1.100) | Hours |
| `base_gold_rate` | `f32` | 10 - 1000 | 50.0 (AFK Arena v1.100) | Gold/Minute |
| `base_exp_rate` | `f32` | 5 - 500 | 25.0 (AFK Arena v1.100) | EXP/Minute |
| `vip_time_multiplier` | `f32` | 1.0 - 2.0 | 1.5 (Idle Heroes v1.30) | Multiplier |
| `min_offline_time` | `u32` | 1 - 5 | 1 (AFK Arena v1.100) | Minutes |

## 5. Benchmark Data
- **AFK Arena (v1.100):** The base maximum offline time is set to 12 hours. Players generate Gold, Hero EXP, and Player EXP continuously. The minimum time required to trigger the offline reward screen is 1 minute. VIP levels can extend the maximum offline time up to 24 hours or more.
- **Idle Heroes (v1.30):** The standard offline limit is 8 hours. However, players can purchase monthly cards or achieve higher VIP statuses to increase this limit to 12 hours and boost the overall resource generation rate by 20-50%.
- **Cookie Clicker (v2.048):** Offline progress is unlocked via specific upgrades (e.g., "Twin Gates of Transcendence"). It typically generates a fraction of the active CPS (Cookies Per Second), starting at 5% and scaling up based on further upgrades, with a soft cap on time that reduces efficiency after a certain period.

## 6. Common Variants
1. **Fractional Offline Progress:** The game generates resources at a reduced rate compared to active play (e.g., 50% efficiency) to still incentivize keeping the game open.
2. **Stepped Efficiency Drop:** Offline progress is 100% efficient for the first 4 hours, drops to 50% for the next 4 hours, and then stops completely.
3. **Simulated Battles:** Instead of a simple math formula, the game simulates actual battles in the background to determine exact loot drops, including rare items.
4. **Offline Energy Refill:** Instead of direct resources, offline time is used to refill an energy or stamina bar, which the player then spends actively upon returning.
5. **Catch-up Mechanics:** If a player is offline for an extended period (e.g., weeks), the game offers a massive, one-time "welcome back" bonus that exceeds the normal cap.

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_vip_system` (VIP levels often boost offline caps), `atom_idle_combat` (provides the base rates for offline calculations), `atom_push_notifications` (reminds players when their offline cap is reached).
- **Incompatible Atoms:** `atom_permadeath` (offline progress contradicts the high-stakes, active survival nature of permadeath), `atom_real_time_pvp` (offline progress cannot simulate complex real-time player interactions).

## 8. Anti-Patterns
1. **Punishingly Short Caps:** Setting the maximum offline time too low (e.g., 2 hours) forces players to disrupt their sleep or work schedules, leading to burnout and churn.
2. **Overpowered Offline Gains:** Making offline progress significantly more rewarding than active play discourages players from actually engaging with the game's core mechanics.
3. **Lack of Transparency:** Failing to clearly show players how their offline rewards are calculated or what their current generation rates are, leading to confusion and mistrust in the system.
