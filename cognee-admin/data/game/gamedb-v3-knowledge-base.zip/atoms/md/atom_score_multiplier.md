# Gameplay Atom: Score Multiplier

## 1. Identity
- **Atom ID:** `atom_score_multiplier`
- **English Name:** Score Multiplier
- **Chinese Name:** 分数乘数
- **Category:** G
- **Definition:** A scoring mechanic where the base points earned from an action are multiplied by a variable factor (the multiplier). This factor typically increases as the player successfully performs consecutive actions or maintains a combo, and resets or decreases upon failure, taking damage, or dropping the combo.

## 2. Core Verb & State Machine
- **Core Verb:** "Chain" or "Maintain" (actions to keep the multiplier active and growing).
- **State Diagram:**
  ```text
  [Idle] --(Perform Action)--> [Active Multiplier]
  [Active Multiplier] --(Perform Action within Time Window)--> [Increased Multiplier]
  [Increased Multiplier] --(Perform Action within Time Window)--> [Max Multiplier]
  [Active/Increased/Max Multiplier] --(Fail/Timeout)--> [Idle]
  ```
- **States:**
  - `Idle`: Multiplier is at base value (usually 1x).
  - `Active Multiplier`: Multiplier is > 1x.
  - `Max Multiplier`: Multiplier has reached its cap.
- **Transitions:**
  - `Idle` -> `Active Multiplier`: Triggered by a successful scoring action.
  - `Active Multiplier` -> `Increased Multiplier`: Triggered by consecutive successful actions.
  - `Any Active State` -> `Idle`: Triggered by a mistake, taking damage, or a timeout.

## 3. MDA Analysis
- **Mechanics:** The system tracks consecutive successful actions or specific triggers to increment a multiplier value. All base scores earned are multiplied by this value before being added to the total score. A timer or error state resets the multiplier.
- **Dynamics:** Players are incentivized to play riskier or faster to maintain the multiplier. It creates a "flow" state where the player focuses on not breaking the chain. It can lead to snowballing scores for skilled players.
- **Aesthetics:** Tension, excitement, and flow. The fear of losing a high multiplier creates high stakes, while reaching the maximum multiplier provides a sense of mastery and euphoria.

## 4. Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value (Game) | Unit |
|---|---|---|---|---|
| `base_multiplier` | f32 | 1.0 | 1.0 (Osu! v2023) | x |
| `max_multiplier` | f32 | 2.0 - 100.0 | 8.0 (Guitar Hero III) | x |
| `increment_step` | f32 | 0.1 - 1.0 | 1.0 (Tony Hawk's Pro Skater 1+2) | x |
| `actions_to_increment` | u32 | 1 - 10 | 10 (Guitar Hero III) | actions |
| `timeout_duration` | f32 | 1.0 - 10.0 | 3.0 (Devil May Cry 5) | seconds |

## 5. Benchmark Data
- **Guitar Hero III (v1.0):**
  - `max_multiplier`: 4.0 (8.0 with Star Power)
  - `actions_to_increment`: 10 consecutive notes
  - `timeout_duration`: N/A (resets on missed note)
- **Tony Hawk's Pro Skater 1+2 (v1.0):**
  - `max_multiplier`: Uncapped (practically limited by balance meter)
  - `increment_step`: 1.0 per trick in a combo
  - `timeout_duration`: N/A (resets when landing or bailing)
- **Osu! (v2023):**
  - `max_multiplier`: Uncapped (combo count directly acts as multiplier)
  - `increment_step`: 1.0 per hit
  - `timeout_duration`: N/A (resets on miss)

## 6. Common Variants
1. **Time-Based Multiplier:** Multiplier increases over time as long as the player survives or stays in a specific zone.
2. **Resource-Based Multiplier:** Players spend a resource (e.g., Star Power) to temporarily double their current multiplier.
3. **Risk-Based Multiplier:** Multiplier increases based on proximity to danger (e.g., grazing bullets in bullet hell games).
4. **Combo-as-Multiplier:** The combo count itself is the multiplier (e.g., 100 combo = 100x multiplier).

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_combo_system`, `atom_scoring_event`, `atom_time_limit`, `atom_risk_reward`.
- **Incompatible Atoms:** `atom_fixed_score_cap` (conflicts with the exponential nature of multipliers).

## 8. Anti-Patterns
1. **Snowballing out of control:** If the multiplier has no cap and scales too quickly, skilled players will achieve scores orders of magnitude higher than average players, breaking leaderboards.
2. **Punishing resets:** Resetting a hard-earned 100x multiplier to 1x for a minor mistake can be overly frustrating and discourage players from continuing the level.
3. **Hidden mechanics:** If the rules for increasing or maintaining the multiplier are not clearly communicated visually or audibly, players will feel cheated when it resets.
