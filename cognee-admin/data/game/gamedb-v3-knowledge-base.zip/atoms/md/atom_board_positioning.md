# Gameplay Atom: Board Positioning

## 1. Identity
- **Atom ID:** atom_board_positioning
- **English Name:** Board Positioning
- **Chinese Name:** 棋盘站位
- **Category:** G/H (Tactical/Spatial)
- **Definition:** Board Positioning is a spatial and tactical gameplay atom where players place units on a discrete grid or board before a combat phase begins. The initial placement determines targeting, movement paths, and ability interactions during the subsequent automated or semi-automated resolution phase, making spatial arrangement the primary vector for strategic expression.

## 2. Core Verb & State Machine
- **Core Verb:** Place / Position

**State Diagram:**
[Idle] -> (Select Unit) -> [Holding Unit]
[Holding Unit] -> (Place on Valid Tile) -> [Unit Placed]
[Holding Unit] -> (Place on Invalid Tile/Cancel) -> [Idle]
[Unit Placed] -> (Combat Start) -> [Locked]
[Locked] -> (Combat End) -> [Idle]

**States:**
- `Idle`: Player is observing the board, no unit selected.
- `Holding Unit`: Player has selected a unit and is dragging/moving it over the board.
- `Unit Placed`: Unit is successfully assigned to a specific coordinate.
- `Locked`: Combat has begun; positions cannot be altered by the player.

**Transitions:**
- `Idle` to `Holding Unit`: Triggered by clicking/tapping a unit.
- `Holding Unit` to `Unit Placed`: Triggered by releasing the unit over a valid, unoccupied (or swappable) tile.
- `Holding Unit` to `Idle`: Triggered by releasing the unit off-board or canceling the action.
- `Unit Placed` to `Locked`: Triggered by the combat phase timer reaching zero.
- `Locked` to `Idle`: Triggered by the combat phase concluding.

## 3. MDA Analysis
- **Mechanics:** The system provides a grid (e.g., hex or square) and a set of units. Players assign units to grid coordinates. The system calculates distances, line of sight, and initial aggro based on these coordinates when combat starts.
- **Dynamics:** Players attempt to protect fragile high-damage units by placing them behind durable units. Opponents attempt to bypass these defenses using "assassin" units that jump to the backline. This creates a dynamic rock-paper-scissors positioning meta (e.g., clumping vs. spreading out).
- **Aesthetics:** Players experience a sense of intellectual satisfaction and anticipation ("galaxy brain" moments) when their positioning perfectly counters the opponent's setup, followed by tension as they watch the automated combat unfold.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (TFT v13) | Unit |
| --- | --- | --- | --- | --- |
| `board_width` | u32 | 7-10 | 7 | hexes |
| `board_height` | u32 | 3-5 | 4 | hexes |
| `max_units` | u32 | 1-15 | 9 | units |
| `placement_time` | f32 | 15.0-45.0 | 30.0 | seconds |
| `hex_size` | f32 | 1.0-2.0 | 1.0 | meters |

## 5. Benchmark Data
- **Teamfight Tactics (TFT) (Set 13):**
  - `board_width`: 7 hexes
  - `board_height`: 4 hexes (player half)
  - `placement_time`: 30 seconds (standard PvP round)
- **Dota Underlords (v1.0):**
  - `board_width`: 8 squares
  - `board_height`: 4 squares (player half)
  - `placement_time`: 25 seconds

## 6. Common Variants
1. **Hexagonal vs. Square Grid:** TFT uses hexes (6 neighbors, staggered distances), while Underlords uses squares (8 neighbors with diagonals).
2. **Symmetric vs. Asymmetric Boards:** Most auto-battlers mirror the board exactly, but some PvE modes feature asymmetric boss arenas.
3. **Pre-combat vs. Mid-combat Positioning:** Traditional auto-battlers lock positions at combat start. Tactical RPGs (like Fire Emblem) allow repositioning every turn.
4. **Elevation/Terrain Modifiers:** Games like Baldur's Gate 3 add height advantages and elemental surfaces to the positioning grid.

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_auto_combat` (Auto Combat), `atom_unit_synergy` (Unit Synergies), `atom_aggro_management` (Aggro Management).
- **Incompatible Atoms:** `atom_twitch_movement` (Real-time WASD movement conflicts with discrete grid placement).

## 8. Anti-Patterns
1. **Meaningless Positioning:** If unit stats overwhelmingly dictate the outcome regardless of placement, the positioning phase feels like a waste of time.
2. **Unclear Targeting Rules:** If players cannot predict who a unit will attack based on its starting position, they cannot make strategic decisions.
3. **Overly Complex Grids:** Boards that are too large or have too many obstacles can cause pathing AI to break, leading to frustrating, unpredictable unit behavior.
