# Gameplay Atom: Aggro / Threat (仇恨值)

## 1. Identity
- **Atom ID:** `atom_aggro_threat`
- **English Name:** Aggro / Threat
- **Chinese Name:** 仇恨值
- **Category:** A
- **Definition:** The Aggro or Threat system is a foundational AI targeting mechanism used primarily in role-playing games (RPGs) and massively multiplayer online games (MMOs). It quantifies the level of hostility an NPC (non-player character) or enemy holds toward various player characters based on their actions, such as dealing damage, healing allies, or using specific taunt abilities. The entity with the highest threat value typically becomes the primary target of the enemy's attacks, allowing players to strategically manage enemy focus and protect vulnerable team members.

## 2. Core Verb & State Machine
- **Core Verb:** Generate Threat / Taunt / Manage Aggro

**State Diagram:**
```text
[Idle] --(Detect Player)--> [Engaged]
[Engaged] --(Highest Threat Changes)--> [Switch Target]
[Switch Target] --(Attack)--> [Engaged]
[Engaged] --(Target Dies/Out of Range)--> [Evaluate Next Target]
[Evaluate Next Target] --(Threat > 0)--> [Switch Target]
[Evaluate Next Target] --(Threat == 0)--> [Reset/Evade]
[Reset/Evade] --(Return to Spawn)--> [Idle]
```

**States and Transitions:**
- **Idle:** The enemy is not in combat.
- **Engaged:** The enemy is actively attacking the target with the highest threat.
- **Switch Target:** The enemy changes its focus when another player surpasses the current target's threat by a specific threshold (often 110% for melee, 130% for ranged).
- **Evaluate Next Target:** The enemy checks the threat table after the current target becomes invalid.
- **Reset/Evade:** The enemy drops combat and heals to full if no valid targets remain on the threat table.

## 3. MDA Analysis
- **Mechanics:** The system maintains a "threat table" for each enemy, tracking a numerical value for every player involved in the combat. Actions like dealing damage (usually 1 damage = 1 threat), healing (often 1 healing = 0.5 threat, divided among active enemies), and using specific abilities (taunts force the enemy to attack the user for a duration and match the highest threat) modify these values.
- **Dynamics:** Players must balance their output. Tanks actively generate disproportionate threat to keep the enemy's attention. Damage dealers (DPS) must maximize damage without exceeding the tank's threat. Healers must manage their healing output to avoid drawing aggro, especially when multiple enemies are present. This creates a cooperative dance of output management.
- **Aesthetics:** The system fosters a sense of teamwork, role fulfillment, and tension. Tanks feel protective and in control, DPS feel the thrill of pushing limits without crossing the line, and healers experience the pressure of keeping the team alive while remaining unnoticed by the enemy.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (WoW Classic) | Unit |
| :--- | :--- | :--- | :--- | :--- |
| `damage_threat_multiplier` | f32 | 0.5 - 3.0 | 1.0 | Threat per Damage |
| `healing_threat_multiplier` | f32 | 0.1 - 1.0 | 0.5 | Threat per Healing |
| `melee_pull_threshold` | f32 | 1.0 - 1.2 | 1.1 | Multiplier |
| `ranged_pull_threshold` | f32 | 1.0 - 1.5 | 1.3 | Multiplier |
| `taunt_duration` | f32 | 1.0 - 5.0 | 3.0 | Seconds |
| `threat_decay_rate` | f32 | 0.0 - 0.1 | 0.0 | % per Second |

## 5. Benchmark Data
- **World of Warcraft (Patch 1.12):**
  - Damage generates 1 threat per point of damage.
  - Healing generates 0.5 threat per point of healing, divided among all enemies in combat.
  - Melee characters must exceed the current target's threat by 110% to pull aggro.
  - Ranged characters must exceed the current target's threat by 130% to pull aggro.
  - Taunt forces the target to attack the caster for 3 seconds and sets the caster's threat to equal the highest threat on the table.
- **Final Fantasy XIV (Patch 6.0):**
  - Tank stance provides a massive multiplier to threat generation (typically 10x or more), trivializing threat management for DPS and focusing the tank's role on positioning and mitigation rather than pure threat generation.
  - Provoke (Taunt) places the caster at the top of the aggro list with a slight lead.

## 6. Common Variants
- **Proximity-Based Aggro:** Enemies target the closest player regardless of threat values, common in action games or specific boss mechanics.
- **Action-Specific Aggro:** Enemies target players performing specific actions (e.g., using an item, interacting with an object) regardless of damage or healing.
- **Random Targeting:** Enemies occasionally ignore the threat table to attack a random player, forcing the group to adapt quickly.
- **Linked Aggro (Social Aggro):** Attacking one enemy causes nearby enemies of the same faction to also enter combat and add the attacker to their threat tables.
- **Decaying Threat:** Threat values naturally decrease over time, requiring constant action to maintain aggro.

## 7. Compatibility Notes
- **Commonly Pairs With:** `atom_health_points` (HP), `atom_damage_mitigation` (Armor/Resistances), `atom_healing`, `atom_cooldowns`.
- **Known Conflicts:** Can conflict with `atom_stealth` or `atom_invisibility` if threat is not properly cleared upon entering stealth. May also clash with highly mobile boss designs where positioning is more critical than threat.

## 8. Anti-Patterns
- **Opaque Threat Mechanics:** Hiding threat values or thresholds from players, leading to frustration when aggro shifts unpredictably without clear feedback.
- **Trivialized Threat:** Making threat generation so easy (e.g., massive passive multipliers) that the mechanic becomes irrelevant, removing a layer of depth from combat.
- **Punishing Healers Excessively:** Assigning too much threat to healing, making it impossible for healers to keep the group alive without constantly dying to enemy attacks.
