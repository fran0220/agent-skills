# Weather System (天气系统)

## 1. Identity
- **Atom ID:** atom_weather_system
- **English Name:** Weather System
- **Chinese Name:** 天气系统
- **Category:** G
- **Definition:** A dynamic environmental system that simulates meteorological conditions (such as rain, snow, wind, and fog) over time, affecting gameplay mechanics like visibility, movement, temperature, and NPC behaviors.

## 2. Core Verb & State Machine
- **Core Verb:** Adapt (Player adapts to changing weather conditions)
- **State Diagram:**
  [Clear] <--> [Cloudy]
  [Cloudy] <--> [Rain]
  [Cloudy] <--> [Snow]
  [Rain] <--> [Storm]
- **States:** Clear, Cloudy, Rain, Snow, Storm, Fog
- **Transitions:**
  - Clear -> Cloudy: Humidity increases, temperature drops slightly.
  - Cloudy -> Rain: Humidity reaches threshold, temperature > 0°C.
  - Cloudy -> Snow: Humidity reaches threshold, temperature <= 0°C.
  - Rain -> Storm: Wind speed increases, atmospheric pressure drops.
  - Any -> Clear: Time passes, humidity drops.

## 3. MDA Analysis
- **Mechanics:** The system continuously updates environmental variables (temperature, humidity, wind speed) based on a global timer or noise function. These variables determine the current weather state, which applies modifiers to player stats (e.g., stamina drain, slipping on surfaces) and world elements (e.g., fires extinguishing, lightning strikes).
- **Dynamics:** Players must plan their journeys according to weather forecasts or current conditions. They might seek shelter during a storm, change equipment to resist cold, or use rain to mask their footsteps for stealth.
- **Aesthetics:** Immersion, Challenge, Discovery. The weather creates a living, breathing world that feels unpredictable and atmospheric, enhancing the emotional tone of the environment.

## 4. Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value (BotW v1.5.0) | Unit |
| --- | --- | --- | --- | --- |
| transition_duration | f32 | 10.0 - 120.0 | 30.0 | seconds |
| rain_slip_chance | f32 | 0.0 - 1.0 | 0.8 | probability |
| temperature_modifier | f32 | -20.0 - 20.0 | -10.0 | Celsius |
| wind_force | f32 | 0.0 - 50.0 | 15.0 | m/s |
| lightning_strike_rate | f32 | 0.0 - 0.1 | 0.02 | strikes/sec |

## 5. Benchmark Data
- **The Legend of Zelda: Breath of the Wild (v1.5.0):**
  - `rain_slip_chance`: 0.8 (Makes climbing extremely difficult)
  - `transition_duration`: 30.0s (Smooth blending between skyboxes)
  - `lightning_strike_rate`: 0.02 (High danger when wearing metal)
- **Red Dead Redemption 2 (v1.31):**
  - `temperature_modifier`: -15.0°C in blizzards (Requires winter clothing)
  - `wind_force`: 25.0 m/s (Affects projectile trajectories and horse stamina)
  - `transition_duration`: 120.0s (Slow, realistic weather shifts)

## 6. Common Variants
1. **Cosmetic Weather:** Weather changes visually but has no mechanical impact on gameplay (e.g., many older MMOs).
2. **Zone-Locked Weather:** Specific regions have permanent weather states (e.g., a perpetually snowy mountain or rainy swamp).
3. **Player-Controlled Weather:** The player possesses an item or ability to change the weather at will (e.g., Song of Storms in Ocarina of Time).
4. **Disaster Weather:** Extreme weather events that act as hazards or boss mechanics (e.g., Sandstorms in survival games).

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_temperature_system`, `atom_stealth_mechanics`, `atom_survival_needs`, `atom_dynamic_lighting`.
- **Incompatible Atoms:** `atom_fixed_lighting` (Static lighting clashes with dynamic weather shadows), `atom_indoor_only_environments` (Weather is irrelevant without outdoor spaces).

## 8. Anti-Patterns
1. **Overly Punishing Weather:** Making weather effects so severe (e.g., constant slipping in rain) that players simply put the controller down and wait it out rather than engaging with the system.
2. **Abrupt Transitions:** Instantly snapping from clear skies to a thunderstorm breaks immersion; lack of transition blending.
3. **Irrelevant Weather:** Implementing a complex weather simulation that has no meaningful impact on player decisions or world state, wasting development resources.
