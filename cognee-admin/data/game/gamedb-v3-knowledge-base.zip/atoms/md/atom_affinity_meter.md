# Affinity / Relationship Meter (好感度计量)

## 1. Identity
- **Atom ID**: atom_affinity_meter
- **English Name**: Affinity / Relationship Meter
- **Chinese Name**: 好感度计量
- **Category**: E/F (Social/Progression)
- **Definition**: A quantifiable metric representing the relationship status or emotional bond between the player character and an NPC, faction, or entity, which unlocks new interactions, narrative branches, or mechanical benefits as it increases or decreases.

## 2. Core Verb & State Machine
- **Core Verb**: Interact (Gift, Talk, Complete Quest)
- **State Diagram**:
  [Neutral] <--> [Friendly] <--> [Intimate]
      |              |
      v              v
  [Hostile] <--> [Rival]
- **States**:
  - `Neutral`: Baseline state, standard interactions.
  - `Friendly`: Positive interactions, minor perks.
  - `Intimate`: Maximum positive state, romance or major perks.
  - `Hostile`: Negative interactions, combat or refusal of service.
  - `Rival`: High engagement but negative alignment.
- **Transitions**:
  - `Neutral` -> `Friendly`: Gain positive affinity points.
  - `Friendly` -> `Intimate`: Reach max positive threshold, complete specific event.
  - `Neutral` -> `Hostile`: Gain negative affinity points.
  - `Hostile` -> `Rival`: Reach max negative threshold.
  - `Friendly` -> `Neutral`: Decay over time or negative action.

## 3. MDA Analysis
- **Mechanics**: The system tracks a numerical value for each relationship. Actions like giving gifts, choosing dialogue options, or completing quests modify this value. Thresholds trigger state changes.
- **Dynamics**: Players optimize their actions (e.g., hoarding specific gifts) to maximize affinity with chosen NPCs. They may avoid certain quests to prevent negative affinity with factions.
- **Aesthetics**: Players feel a sense of connection, progression, and emotional investment in the characters. It satisfies the desire for social simulation and completionism.

## 4. Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value | Unit |
|---|---|---|---|---|
| `max_affinity` | u32 | 100 - 10000 | 2500 (Stardew Valley 1.5) | Points |
| `min_affinity` | i32 | -1000 - 0 | 0 (Persona 5 Royal) | Points |
| `gift_value_loved` | u32 | 10 - 500 | 80 (Stardew Valley 1.5) | Points |
| `gift_value_liked` | u32 | 5 - 250 | 45 (Stardew Valley 1.5) | Points |
| `decay_rate` | u32 | 0 - 20 | 2 (Stardew Valley 1.5) | Points/Day |
| `threshold_friendly` | u32 | 20% - 50% | 1000 (Stardew Valley 1.5) | Points |

## 5. Benchmark Data
- **Stardew Valley (v1.5)**:
  - `max_affinity`: 2500 (10 hearts, 250 points per heart)
  - `gift_value_loved`: 80
  - `decay_rate`: 2 points per day (if not talked to)
- **Persona 5 Royal (v1.0)**:
  - `max_affinity`: 10 (Ranks)
  - `gift_value_loved`: 3 (Musical Notes)
- **Fire Emblem: Three Houses (v1.2.0)**:
  - `max_affinity`: 4 (C, B, A, S support levels)
  - `gift_value_loved`: 200 (Support points)

## 6. Common Variants
1. **Faction Reputation**: Instead of individuals, affinity is tracked for entire groups (e.g., World of Warcraft).
2. **Decaying Relationships**: Affinity drops over time if not maintained (e.g., Animal Crossing).
3. **Mutual Affinity**: Both parties have independent meters for each other.
4. **Hidden Meters**: The exact numerical value is hidden, only showing vague states (e.g., Undertale).

## 7. Compatibility Notes
- **Commonly Pairs With**: `atom_dialogue_tree`, `atom_quest_system`, `atom_trading_system`.
- **Conflicts**: `atom_permadeath` (losing an NPC with high affinity can be overly punishing unless specifically designed for emotional impact).

## 8. Anti-Patterns
1. **Gift Spamming**: Allowing players to max out affinity instantly by giving 100 cheap gifts in a row, breaking immersion.
2. **Opaque Decay**: Punishing players with relationship decay without clear communication on how to prevent it.
3. **Irrelevant Rewards**: Providing max affinity rewards that are useless by the time the player achieves them.
