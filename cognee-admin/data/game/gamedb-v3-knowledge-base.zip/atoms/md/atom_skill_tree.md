# Gameplay Atom: Skill Tree (技能树)

## 1. Identity
- **Atom ID:** `atom_skill_tree`
- **English Name:** Skill Tree
- **Chinese Name:** 技能树
- **Category:** E (Progression & RPG Elements)
- **Definition:** A skill tree is a directed graph or hierarchical visual representation of unlockable abilities, stat boosts, or perks that a player can acquire for their character over the course of a game. It structures character progression by requiring players to unlock prerequisite nodes before accessing more advanced or powerful abilities, thereby creating meaningful choices and specialized character builds.

## 2. Core Verb & State Machine
- **Core Verb:** Allocate / Unlock (分配 / 解锁)
- **State Diagram:**
  [Locked] --(Prerequisites Met)--> [Available] --(Spend Skill Point)--> [Unlocked/Active] --(Respec)--> [Locked]
- **States:**
  - `Locked`: The skill node cannot be unlocked yet because prerequisites (e.g., character level, previous nodes) are not met.
  - `Available`: Prerequisites are met, and the player has enough resources (e.g., skill points) to unlock the node.
  - `Unlocked`: The skill node has been purchased, and its benefits are active.
  - `Maxed`: For nodes with multiple levels, the maximum investment has been reached.
- **Transitions:**
  - `Locked` -> `Available`: Triggered when the player meets all prerequisite conditions.
  - `Available` -> `Unlocked`: Triggered when the player spends the required skill points.
  - `Unlocked` -> `Maxed`: Triggered when the player invests the maximum allowed points into a multi-level node.
  - `Unlocked`/`Maxed` -> `Locked`: Triggered when the player uses a "respec" (reset) feature to reclaim spent points.

## 3. MDA Analysis
- **Mechanics:** The system provides a set of nodes connected by edges. Each node has a cost (usually skill points gained from leveling up), prerequisites (other nodes, character level, or specific stats), and a mechanical benefit (new active skill, passive stat increase, or modifier).
- **Dynamics:** Players plan their progression path in advance, optimizing for specific playstyles or "builds." They may hoard points for expensive nodes or spend them immediately for short-term power spikes. The interconnected nature of the tree encourages synergy discovery.
- **Aesthetics:** 
  - *Expression:* Players feel a sense of ownership and personalization over their character's unique build.
  - *Anticipation:* Looking ahead at powerful late-game nodes creates long-term motivation.
  - *Growth:* The visual expansion of the unlocked tree provides a tangible sense of progression and increasing power.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Game) | Unit |
|---|---|---|---|---|
| `total_nodes` | u32 | 20 - 1500 | 1328 (Path of Exile v3.22) | Nodes |
| `max_points` | u32 | 10 - 120 | 123 (Path of Exile v3.22) | Points |
| `points_per_level` | u32 | 1 - 3 | 1 (Diablo II v1.14d) | Points/Level |
| `respec_cost` | f32 | 0.0 - 10000.0 | 1.0 (Orb of Regret, PoE) | Currency |
| `branching_factor` | f32 | 1.5 - 4.0 | 2.5 (Skyrim v1.9) | Nodes/Node |

## 5. Benchmark Data
- **Path of Exile (v3.22):** Features a massive, interconnected passive skill tree shared by all classes.
  - `total_nodes`: 1328
  - `max_points`: 123 (99 from levels, 24 from quests)
  - `points_per_level`: 1
- **Diablo II (v1.14d):** Features class-specific, highly structured skill trees (3 per class).
  - `total_nodes`: 30 per class (10 per tree)
  - `max_points`: 110 (99 from levels, 11 from quests)
  - `points_per_level`: 1
- **The Elder Scrolls V: Skyrim (v1.9):** Features constellation-based skill trees tied to specific activities.
  - `total_nodes`: ~250 (across 18 skills)
  - `max_points`: 80 (soft cap)
  - `points_per_level`: 1

## 6. Common Variants
1. **Linear Skill Paths:** A simplified tree with no branching, forcing a specific progression order (e.g., early Call of Duty weapon unlocks).
2. **Web/Grid Systems:** Non-linear grids where players can expand in any direction from a starting point (e.g., Final Fantasy X's Sphere Grid).
3. **Constellations/Clusters:** Grouped nodes that require unlocking a central node before accessing the surrounding ones (e.g., Skyrim, Grim Dawn).
4. **Randomized/Draft Trees:** Skill options are presented randomly upon leveling up, common in roguelikes (e.g., Hades boons, Vampire Survivors).
5. **Mutually Exclusive Branches:** Choosing one path permanently locks out the other, forcing hard choices (e.g., World of Warcraft's modern talent rows).

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_xp_level` (Leveling systems provide the points), `atom_character_class` (Classes often dictate which tree is available), `atom_active_skill` (Trees unlock these), `atom_passive_buff` (Trees grant these).
- **Incompatible Atoms:** `atom_pure_skill_based_progression` (Games relying entirely on player mechanical skill, like Counter-Strike, conflict with stat-based skill trees).

## 8. Anti-Patterns
1. **Illusion of Choice:** Creating a tree where one path is mathematically vastly superior to all others, rendering the rest of the tree obsolete ("cookie-cutter builds").
2. **Boring Filler Nodes:** Forcing players to spend points on unimpactful nodes (e.g., "+1% damage") just to reach the interesting mechanics, leading to unrewarding level-ups.
3. **Punishing Respecs:** Making it too difficult or impossible to reset skill points, which discourages experimentation and punishes new players for early mistakes.
