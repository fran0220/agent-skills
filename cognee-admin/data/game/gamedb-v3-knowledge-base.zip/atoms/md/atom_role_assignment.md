# Identity
- **Atom ID**: atom_role_assignment
- **English Name**: Role Assignment (Social)
- **Chinese Name**: 角色分配(社交)
- **Category**: E/F (Social/Deduction)
- **Definition**: Role Assignment is a core social deduction mechanic where players are secretly assigned distinct identities, each with unique abilities, win conditions, and information access. This creates an asymmetric information environment that drives deception, deduction, and social interaction among players.

# Core Verb & State Machine
- **Core Verb**: Assign / Reveal / Act
- **State Diagram**:
  [Unassigned] -> (Game Start) -> [Assigned/Hidden]
  [Assigned/Hidden] -> (Use Ability) -> [Acting]
  [Acting] -> (Ability Resolves) -> [Assigned/Hidden]
  [Assigned/Hidden] -> (Death/Endgame) -> [Revealed]

- **States**:
  - `Unassigned`: Players have joined the lobby but have no roles.
  - `Assigned/Hidden`: Players know their own role but keep it secret from others.
  - `Acting`: Players are actively using their role-specific abilities (e.g., killing, investigating).
  - `Revealed`: The player's role is publicly known (usually upon death or game end).

- **Transitions**:
  - `Unassigned` to `Assigned/Hidden`: Triggered by the game starting and roles being distributed.
  - `Assigned/Hidden` to `Acting`: Triggered by the player choosing to use their ability during the appropriate phase.
  - `Acting` to `Assigned/Hidden`: Triggered by the completion of the ability's effect.
  - `Assigned/Hidden` to `Revealed`: Triggered by the player being eliminated or the game concluding.

# MDA Analysis
- **Mechanics**: The system randomly or pseudo-randomly distributes roles from a predefined pool to players. It enforces the rules of each role, managing who can perform what actions and when (e.g., Impostors can kill, Crewmates can do tasks).
- **Dynamics**: The hidden nature of roles leads to emergent behaviors such as bluffing, forming temporary alliances, false accusations, and logical deduction based on player actions and voting patterns.
- **Aesthetics**: Players experience feelings of paranoia, suspense, the thrill of deception, the satisfaction of solving a puzzle, and intense social bonding or betrayal.

# Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value | Unit |
|---|---|---|---|---|
| `impostor_ratio` | Float | 0.1 - 0.3 | 0.2 (Among Us v2021.6.15) | Ratio |
| `role_visibility` | Boolean | True/False | False (Werewolf) | N/A |
| `action_cooldown` | Integer | 10 - 60 | 30 (Among Us v2021.6.15) | Seconds |
| `discussion_time` | Integer | 30 - 120 | 45 (Among Us v2021.6.15) | Seconds |

# Benchmark Data
- **Among Us (v2021.6.15)**:
  - `impostor_ratio`: 0.2 (e.g., 2 Impostors in a 10-player game)
  - `action_cooldown`: 30 seconds (default kill cooldown)
  - `discussion_time`: 45 seconds
- **Werewolf (Standard Party Game)**:
  - `impostor_ratio`: ~0.25 (e.g., 2 Werewolves in an 8-player game)
  - `role_visibility`: False (roles are completely hidden until death)

# Common Variants
1. **Drafting Roles**: Players choose their roles from a limited pool rather than being randomly assigned (e.g., Citadels).
2. **Role Switching**: Roles can change hands during the game, adding a layer of memory and chaos (e.g., One Night Ultimate Werewolf).
3. **Public Roles**: Some roles are known to everyone from the start, acting as anchors for deduction (e.g., the King in some variants).
4. **Infection/Conversion**: Players start on one team but can be converted to another team during the game, changing their role and win condition.

# Compatibility Notes
- **Commonly Pairs With**: `atom_voting` (Voting/Elimination), `atom_hidden_information` (Hidden Information), `atom_player_elimination` (Player Elimination).
- **Known Conflicts**: `atom_perfect_information` (Perfect Information) - Role assignment relies on hidden information; perfect information completely breaks the deduction aspect.

# Anti-Patterns
1. **Unbalanced Ratios**: Having too many or too few "evil" roles makes the game statistically unwinnable for one side, ruining the social dynamics.
2. **Useless Roles**: Creating roles with abilities that rarely impact the game state, leading to player boredom and disengagement.
3. **Early Elimination without Agency**: Players being killed off before they get a chance to use their role or participate in the social deduction, leading to frustration.
