# Drift Boost (漂移加速)

## 1. Identity
- **Atom ID**: atom_drift_boost
- **English Name**: Drift Boost
- **Chinese Name**: 漂移加速
- **Category**: A+B
- **Definition**: Drift Boost is a driving game mechanic where a player initiates a drift (sliding the vehicle sideways through a corner) and, upon successfully maintaining or completing the drift under specific conditions, is rewarded with a temporary burst of speed or acceleration. This mechanic transforms cornering from a simple speed-loss event into a strategic opportunity for gaining an advantage.

## 2. Core Verb & State Machine
The primary player verb is **Drifting** (and subsequently **Boosting**).

**State Diagram**:
[Normal Driving] -> (Initiate Drift) -> [Drifting] -> (Maintain Drift) -> [Charging Boost] -> (Release Drift) -> [Boosting] -> (Boost Expires) -> [Normal Driving]
[Drifting] -> (Collision/Brake) -> [Normal Driving] (Boost Cancelled)

**States and Transitions**:
- **Normal Driving**: The default state of the vehicle.
- **Drifting**: The vehicle is sliding sideways. Transition from Normal Driving via a specific input (e.g., hop + turn).
- **Charging Boost**: The drift has been maintained long enough to start accumulating boost power. Transition from Drifting over time or via specific inputs (e.g., alternating steering).
- **Boosting**: The vehicle experiences a temporary speed increase. Transition from Charging Boost when the drift is released.
- **Boost Cancelled**: The drift was interrupted before release. Transition from Drifting or Charging Boost via collision or braking.

## 3. MDA Analysis
- **Mechanics**: The system tracks the duration and angle of the drift. As the drift continues, an internal counter or meter fills up. When the player releases the drift button, the system applies a forward force multiplier or increases the maximum speed limit for a short duration based on the charge level.
- **Dynamics**: Players will intentionally seek out corners or even weave on straightaways (snaking) to initiate drifts and chain boosts together. This creates a rhythm of tension (maintaining the drift without crashing) and release (the speed burst).
- **Aesthetics**: The player experiences a sense of mastery, thrill, and flow. The visual and audio feedback (sparks changing color, engine roaring) during the charge phase builds anticipation, culminating in the satisfying release of the boost.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Mario Kart 8 Deluxe) | Unit |
|---|---|---|---|---|
| `charge_time_tier1` | f32 | 0.5 - 1.5 | 1.0 | seconds |
| `charge_time_tier2` | f32 | 1.5 - 3.0 | 2.5 | seconds |
| `charge_time_tier3` | f32 | 3.0 - 5.0 | 4.5 | seconds |
| `boost_duration_tier1` | f32 | 0.3 - 1.0 | 0.6 | seconds |
| `boost_duration_tier2` | f32 | 0.8 - 2.0 | 1.2 | seconds |
| `boost_duration_tier3` | f32 | 1.5 - 3.5 | 2.0 | seconds |
| `boost_speed_multiplier` | f32 | 1.1 - 1.5 | 1.25 | multiplier |
| `min_drift_angle` | f32 | 10.0 - 30.0 | 15.0 | degrees |

## 5. Benchmark Data
- **Mario Kart 8 Deluxe (v3.0.1)**:
  - Mini-Turbo (Blue Sparks): Requires ~1.0s of drifting, grants ~0.6s of boost.
  - Super Mini-Turbo (Orange Sparks): Requires ~2.5s of drifting, grants ~1.2s of boost.
  - Ultra Mini-Turbo (Pink Sparks): Requires ~4.5s of drifting, grants ~2.0s of boost.
- **Need for Speed: Hot Pursuit Remastered (v1.0.3)**:
  - Nitrous accumulation rate during drift: ~5% of max capacity per second of continuous drifting.
  - Boost activation is manual, not automatic upon release, but the accumulation is directly tied to the drift state.

## 6. Common Variants
1. **Tiered Release (Mario Kart)**: The boost becomes stronger and lasts longer the longer the drift is maintained, indicated by changing spark colors.
2. **Manual Accumulation (Need for Speed)**: Drifting fills a generic "boost meter" (nitrous) that the player can choose to activate at any time, rather than automatically upon ending the drift.
3. **Perfect Release (Crash Team Racing)**: The player must press a secondary button at a specific timing window during the drift to trigger the boost, allowing for chained boosts within a single drift.
4. **Proximity/Risk Drift (Burnout)**: The boost meter fills faster if the drift is performed close to traffic or walls, rewarding riskier behavior.

## 7. Compatibility Notes
- **Commonly Pairs With**: `atom_jump_boost` (tricking off ramps), `atom_drafting` (slipstreaming behind opponents), `atom_boost_pad` (driving over speed panels).
- **Known Conflicts**: `atom_realistic_physics` (strict simulation games often eschew arcade-style drift boosts in favor of realistic traction loss penalties).

## 8. Anti-Patterns
1. **Overpowered Snaking**: Making the charge time too short allows players to continuously drift back and forth on straightaways, breaking the intended track flow and making normal driving obsolete.
2. **Unclear Feedback**: Failing to provide clear visual or audio cues when a boost tier is reached, leading to players releasing the drift too early or too late.
3. **Punishing Collisions Too Harshly**: If a slight wall tap completely resets a long-charged boost, it can lead to extreme frustration. A small grace period or partial charge retention is often better.
