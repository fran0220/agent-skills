# Gameplay Atom: Dungeon Finder / Matchmaking

## 1. Identity
- **Atom ID:** `atom_dungeon_finder`
- **English Name:** Dungeon Finder / Matchmaking
- **Chinese Name:** 副本匹配
- **Category:** F
- **Definition:** A systemic feature that automatically groups players together based on specific criteria (such as role, skill level, or level range) to participate in instanced multiplayer content, such as dungeons, raids, or competitive matches, reducing the friction of manual group formation.

## 2. Core Verb & State Machine
- **Core Verb:** Queue (Queueing for a match/dungeon)

**State Diagram:**
```text
[Idle] --> (Queue) --> [Queued]
[Queued] --> (Match Found) --> [Confirming]
[Confirming] --> (All Accept) --> [Teleporting/Starting]
[Confirming] --> (Timeout/Decline) --> [Queued] (or [Idle])
[Teleporting/Starting] --> (Instance Complete) --> [Idle]
[Queued] --> (Cancel) --> [Idle]
```

**States:**
- `Idle`: Player is not looking for a group.
- `Queued`: Player is actively waiting in the matchmaking pool.
- `Confirming`: A potential group has been found, waiting for all members to accept.
- `Teleporting/Starting`: Group is formed, transitioning to the instance.

**Transitions:**
- `Idle` -> `Queued`: Triggered by player initiating the queue.
- `Queued` -> `Confirming`: Triggered by the system finding a valid match.
- `Confirming` -> `Teleporting/Starting`: Triggered by all matched players accepting the prompt.
- `Confirming` -> `Queued`: Triggered by one or more players declining or timing out (remaining players return to front of queue).
- `Queued` -> `Idle`: Triggered by player manually canceling the queue.
- `Teleporting/Starting` -> `Idle`: Triggered by completing or leaving the instance.

## 3. MDA Analysis
- **Mechanics:** The system collects players into a pool, evaluates their attributes (role: tank/healer/DPS, MMR, level, latency), and uses an algorithm to form balanced groups that meet the requirements of the selected content. It often includes a reward incentive for in-demand roles.
- **Dynamics:** Players may change their behavior to reduce queue times (e.g., switching to a Tank or Healer role). High-demand roles experience instant queues, while overrepresented roles (DPS) experience long waits. "Queue dodging" or declining prompts can occur if players are AFK.
- **Aesthetics:** Convenience, accessibility, and sometimes frustration (due to long waits or toxic randomly-matched teammates). It fosters a sense of immediate action (Fellowship/Submission) but can diminish the social fabric of server communities.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (WoW 10.0) | Unit |
|---|---|---|---|---|
| `max_queue_time_target` | `u32` | 60 - 1800 | 900 | seconds |
| `role_requirement_tank` | `u32` | 0 - 2 | 1 | count |
| `role_requirement_healer` | `u32` | 0 - 2 | 1 | count |
| `role_requirement_dps` | `u32` | 1 - 5 | 3 | count |
| `mmr_expansion_rate` | `f32` | 1.0 - 10.0 | 2.5 | MMR/sec |
| `confirmation_timeout` | `u32` | 10 - 60 | 40 | seconds |
| `deserter_penalty_duration` | `u32` | 300 - 3600 | 1800 | seconds |

## 5. Benchmark Data
- **World of Warcraft (Retail v10.2):**
  - `confirmation_timeout`: 40 seconds
  - `deserter_penalty_duration`: 1800 seconds (30 minutes)
  - Group composition: 1 Tank, 1 Healer, 3 DPS.
- **Final Fantasy XIV (Patch 6.5):**
  - `confirmation_timeout`: 45 seconds
  - `deserter_penalty_duration`: 1800 seconds (30 minutes, applied after 3 missed queues or leaving early)
  - Group composition (Light Party): 1 Tank, 1 Healer, 2 DPS.
- **Overwatch 2 (Season 8):**
  - `confirmation_timeout`: 10 seconds (auto-accepts in many modes, but match cancel on leave)
  - Group composition (Role Queue): 1 Tank, 2 Support, 2 Damage.

## 6. Common Variants
1. **Role-based Matchmaking:** Players select their role before queueing, and the system strictly adheres to a composition matrix (e.g., WoW, FFXIV).
2. **Skill-based Matchmaking (SBMM):** Prioritizes matching players with similar hidden MMR or visible ranks to ensure competitive fairness (e.g., Overwatch, League of Legends).
3. **Drop-in/Drop-out Matchmaking:** Players can join an ongoing session to replace someone who left, minimizing disruption (e.g., Team Fortress 2, Overwatch Quick Play).
4. **Cross-realm/Cross-play Matchmaking:** Expands the player pool by matching across different servers or platforms to reduce queue times.

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_role_system`, `atom_instanced_dungeon`, `atom_daily_quest`, `atom_mmr_rating`.
- **Incompatible Atoms:** `atom_open_world_pvp`, `atom_permadeath`.

## 8. Anti-Patterns
1. **The "DPS Queue" Problem:** Failing to incentivize underrepresented roles, leading to unacceptable queue times for the majority of the player base.
2. **Opaque Queue States:** Not providing players with an estimated wait time or queue position, leading to frustration and queue cancellation.
3. **Lack of Backfill:** Not having a system to replace players who disconnect or leave early, dooming the remaining matched players to fail the instance.
