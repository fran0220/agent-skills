# Outfit Scoring (服装评分)

## 1. Identity
- **Atom ID:** atom_outfit_scoring
- **English Name:** Outfit Scoring
- **Chinese Name:** 服装评分
- **Category:** G
- **Definition:** A gameplay mechanic where players select and equip various clothing items or accessories on an avatar, and the system evaluates the combination based on predefined attributes, themes, or tags to generate a final score.

## 2. Core Verb & State Machine
- **Core Verb:** Equip / Submit
- **State Diagram:**
  [Idle] -> (Select Item) -> [Equipping] -> (Submit Outfit) -> [Scoring] -> (View Results) -> [Idle]
- **States and Transitions:**
  - **Idle:** The player is viewing the avatar without making changes.
  - **Equipping:** The player is actively adding or removing clothing items.
  - **Scoring:** The system calculates the score based on the equipped items and the current theme.
  - **Transitions:**
    - Idle -> Equipping: Triggered by selecting a clothing category or item.
    - Equipping -> Scoring: Triggered by pressing the "Submit" or "Done" button.
    - Scoring -> Idle: Triggered by closing the result screen.

## 3. MDA Analysis
- **Mechanics:** Each clothing item has specific attributes (e.g., Elegance, Cute, Sexy, Pure, Cool, Warm) and tags (e.g., Swimwear, Office, Fairy). The system compares the sum of these attributes and tag multipliers against a target theme's requirements.
- **Dynamics:** Players optimize their outfits by finding items with the highest relevant attributes and matching tags, sometimes leading to visually chaotic but high-scoring combinations.
- **Aesthetics:** Players experience a sense of expression and achievement through collecting high-value items and solving the "puzzle" of maximizing scores for specific themes.

## 4. Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value (Love Nikki v8.0) | Unit |
|---|---|---|---|---|
| Base Attribute Score | f32 | 100 - 5000 | 1500 | Points |
| Theme Multiplier | f32 | 0.5 - 2.0 | 1.5 | Multiplier |
| Tag Bonus | f32 | 1.0 - 3.0 | 2.0 | Multiplier |
| Penalty Factor | f32 | 0.1 - 1.0 | 0.5 | Multiplier |
| Max Items per Category | u32 | 1 - 5 | 1 | Count |

## 5. Benchmark Data
- **Love Nikki (v8.0):**
  - Base Attribute Score: 1500
  - Theme Multiplier: 1.5
  - Tag Bonus: 2.0
- **Shining Nikki (v3.0):**
  - Base Attribute Score: 3000
  - Theme Multiplier: 1.2
  - Tag Bonus: 1.5

## 6. Common Variants
1. **Rhythm-based Scoring:** Players must tap to the beat while the outfit is being scored to gain bonus points.
2. **Multiplayer Fashion Show:** Players compete against each other in real-time, and scores are compared directly.
3. **Story-driven Dress-up:** The score determines the branching path of the narrative.
4. **Gacha-gated Scoring:** High-scoring items are exclusively available through premium gacha pulls.

## 7. Compatibility Notes
- **Compatible Atoms:** atom_gacha_pull, atom_inventory_management, atom_daily_quests
- **Incompatible Atoms:** atom_permadeath, atom_twitch_combat

## 8. Anti-Patterns
1. **Pay-to-Win Dominance:** Making the highest-scoring items only available via real money, alienating free-to-play users.
2. **Opaque Scoring:** Hiding the exact values or formulas, making it frustrating for players to optimize their outfits.
3. **Visual Chaos:** Allowing players to equip clipping or mismatched items just for stats, ruining the aesthetic appeal of the game.
