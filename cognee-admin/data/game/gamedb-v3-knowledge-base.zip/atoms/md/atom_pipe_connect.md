# Gameplay Atom: Pipe / Circuit Connection (管道/电路连接)

## 1. Identity
- **Atom ID:** `atom_pipe_connect`
- **English Name:** Pipe / Circuit Connection
- **Chinese Name:** 管道/电路连接
- **Category:** Category C (Connection & Circuitry)
- **Definition:** The player connects discrete nodes or tiles using directional or omnidirectional segments to form a continuous path, circuit, or pipeline, allowing flow (fluids, energy, data) from a source to a destination while adhering to spatial and logical constraints.

## 2. Core Verb & State Machine
- **Core Verb:** Connect / Rotate / Place
- **State Diagram:**
  [Empty] --(Place Segment)--> [Disconnected]
  [Disconnected] --(Rotate/Adjust)--> [Disconnected]
  [Disconnected] --(Connect to Source/Target)--> [Connected]
  [Connected] --(Flow Initiated)--> [Active]
  [Active] --(Break Connection)--> [Disconnected]
  [Active] --(Flow Complete)--> [Resolved]

- **States:**
  - `Empty`: No pipe/circuit segment present.
  - `Disconnected`: Segment placed but not forming a valid path.
  - `Connected`: Segment forms a valid path but flow hasn't started.
  - `Active`: Flow is currently passing through the segment.
  - `Resolved`: Flow has successfully reached the destination.

- **Transitions:**
  - `Empty` -> `Disconnected`: Player places a segment.
  - `Disconnected` -> `Disconnected`: Player rotates or modifies the segment.
  - `Disconnected` -> `Connected`: Segment aligns with adjacent valid segments.
  - `Connected` -> `Active`: System initiates flow.
  - `Active` -> `Disconnected`: Player or system breaks the path.
  - `Active` -> `Resolved`: Flow completes its journey.

## 3. MDA Analysis
- **Mechanics:** The system provides a grid or graph of nodes. Players place or manipulate segments with specific connection points (e.g., straight, corner, T-junction, cross). The system evaluates the continuity of the path from a source node to a sink node.
- **Dynamics:** Players must plan ahead to avoid dead ends, manage limited space, and optimize the path length or complexity. Emergent behaviors include creating loops to delay flow or building parallel circuits to handle multiple flows.
- **Aesthetics:** Elicits feelings of logical satisfaction, spatial reasoning, and tension (especially when flow is time-sensitive, as in *Pipe Mania*).

## 4. Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value | Unit |
| --- | --- | --- | --- | --- |
| `grid_width` | u32 | 5 - 20 | 10 (*Pipe Mania v1.0*) | tiles |
| `grid_height` | u32 | 5 - 20 | 10 (*Pipe Mania v1.0*) | tiles |
| `flow_speed` | f32 | 0.5 - 5.0 | 1.5 (*Pipe Mania v1.0*) | tiles/sec |
| `flow_delay` | f32 | 0.0 - 10.0 | 5.0 (*Pipe Mania v1.0*) | seconds |
| `segment_types` | u32 | 2 - 10 | 6 (*SpaceChem v1.0*) | count |

## 5. Benchmark Data
- **Pipe Mania (v1.0):**
  - `grid_width`: 10 tiles
  - `grid_height`: 10 tiles
  - `flow_speed`: 1.5 tiles/sec
  - `flow_delay`: 5.0 seconds
- **SpaceChem (v1.0):**
  - `grid_width`: 10 tiles
  - `grid_height`: 8 tiles
  - `flow_speed`: 2.0 tiles/sec (execution speed)
  - `segment_types`: 6 (straight, corner, cross, sync, input, output)

## 6. Common Variants
1. **Time-Pressure Flow:** The flow starts automatically after a delay, forcing the player to build the path while the flow is moving (e.g., *Pipe Mania*).
2. **Logical Circuits:** Connections carry boolean logic or specific data types, requiring correct routing and transformation (e.g., *Turing Complete*, *SpaceChem*).
3. **Rotational Puzzles:** All segments are pre-placed on the grid, and the player can only rotate them to form a valid connection (e.g., *BioShock* hacking minigame).
4. **Resource Routing:** Multiple sources and sinks with different resource types that must not cross or mix improperly (e.g., *Mini Metro*, *Factorio* fluid system).

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_grid_placement` (Grid Placement), `atom_resource_flow` (Resource Flow), `atom_logic_gate` (Logic Gates).
- **Incompatible Atoms:** `atom_free_movement` (Free Movement) - pipe connections usually require discrete grids or snapped nodes, making continuous free movement conflicting.

## 8. Anti-Patterns
1. **Unreadable Flow Direction:** Failing to clearly indicate which way the flow is moving or which connections are valid, leading to player frustration.
2. **Unwinnable RNG:** In games where segments are randomly provided (like *Pipe Mania*), failing to ensure a valid sequence of pieces can make the level mathematically impossible to solve.
3. **Overly Punishing Mistakes:** Not allowing players to replace or undo segments before the flow reaches them, making experimentation too costly.
