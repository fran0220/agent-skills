# atom_merge_upgrade

## 1. Identity
- **Atom ID**: atom_merge_upgrade
- **English Name**: Merge / Combine Upgrade
- **Chinese Name**: 合并/合成升级
- **Category**: C or D (Progression / Economy)
- **Definition**: A progression mechanic where players combine multiple identical or compatible lower-tier entities to create a single, higher-tier entity with enhanced attributes or new capabilities.

## 2. Core Verb & State Machine
- **Core Verb**: Merge (Combine)
- **State Diagram**:
  [Idle] --(Select Entity 1)--> [Entity 1 Selected]
  [Entity 1 Selected] --(Select Entity 2)--> [Entities Selected]
  [Entities Selected] --(Merge Command)--> [Merging]
  [Merging] --(Success)--> [Upgraded Entity Created]
  [Merging] --(Failure/Cancel)--> [Idle]
- **States**: Idle, Entity 1 Selected, Entities Selected, Merging, Upgraded Entity Created
- **Transitions**:
  - Idle -> Entity 1 Selected: Player selects the first entity.
  - Entity 1 Selected -> Entities Selected: Player selects the second (or more) entity.
  - Entities Selected -> Merging: Player triggers the merge action.
  - Merging -> Upgraded Entity Created: The merge process completes successfully.
  - Merging -> Idle: The merge process is canceled or fails.

## 3. MDA Analysis
- **Mechanics**: The system requires a specific number of identical or compatible entities (e.g., 3 of the same tier) to be combined. Upon combination, the original entities are consumed, and a new entity of a higher tier is generated. The system tracks entity tiers, required quantities for merging, and the resulting entity's stats.
- **Dynamics**: Players actively manage their inventory or board space, hoarding lower-tier entities to build up to higher-tier ones. This creates a cycle of resource accumulation, spatial management, and power spikes when a merge is completed. It encourages planning and delayed gratification.
- **Aesthetics**: Players experience a sense of satisfaction and progression (Growth) when successfully merging entities. There is also a puzzle-like satisfaction (Discovery/Expression) in optimizing board space and deciding when and what to merge.

## 4. Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value | Unit |
|---|---|---|---|---|
| `required_count` | u32 | 2 - 5 | 3 (TFT) | entities |
| `tier_multiplier` | f32 | 1.5 - 3.0 | 1.8 (TFT) | multiplier |
| `max_tier` | u32 | 3 - 10 | 3 (TFT) | tier |
| `merge_cost` | u32 | 0 - 1000 | 0 (Merge Dragons) | currency |
| `success_rate` | f32 | 0.1 - 1.0 | 1.0 (TFT) | probability |

## 5. Benchmark Data
- **Teamfight Tactics (TFT) (Set 10)**:
  - `required_count`: 3
  - `max_tier`: 3 (1-star, 2-star, 3-star)
  - `tier_multiplier`: ~1.8x health and attack damage per tier.
  - `success_rate`: 1.0
- **Merge Dragons! (v10.14.1)**:
  - `required_count`: 3 (standard) or 5 (optimized for 2 results)
  - `max_tier`: Varies by chain, often 10+
  - `merge_cost`: 0

## 6. Common Variants
1. **Match-3 Merge**: Requires exactly 3 adjacent entities on a grid to merge automatically (e.g., Triple Town).
2. **Auto-Chess Merge**: Requires 3 identical entities anywhere on the bench or board to merge automatically (e.g., Teamfight Tactics).
3. **Gacha Duplicate Merge**: Using duplicate characters pulled from a gacha system to unlock nodes or increase the level cap of the base character (e.g., Genshin Impact Constellations).
4. **Crafting Merge**: Combining different specific items to create a new item, rather than identical ones (e.g., Minecraft crafting, though slightly different, often shares the "consume to upgrade" DNA).
5. **Probability Merge**: Merging has a chance to fail, potentially destroying the items or downgrading them (common in Korean MMOs like Lineage).

## 7. Compatibility Notes
- **Compatible Atoms**: `atom_inventory_management` (managing space for merges), `atom_gacha_pull` (acquiring entities to merge), `atom_grid_placement` (placing entities to trigger merges).
- **Incompatible Atoms**: `atom_permadeath` (if entities are easily lost, hoarding for merges becomes frustrating), `atom_linear_story_progression` (merging is usually a systemic, repeatable action, not a narrative one).

## 8. Anti-Patterns
1. **Inventory Choke**: Requiring too many entities to merge without providing adequate inventory space, leading to player frustration and gridlock.
2. **Unrewarding Power Spikes**: The merged entity is not significantly stronger than the sum of its parts, making the effort of merging feel wasted.
3. **Obscure Recipes**: In variants requiring different items, not providing a clear UI or recipe book, forcing players to guess or use external wikis.
