# Gameplay Atom: Sprint with Stamina Cost

## 1. Identity
- **Atom ID:** `atom_sprint_stamina`
- **English Name:** Sprint with Stamina Cost
- **Chinese Name:** 冲刺消耗体力
- **Category:** A (Core Movement/Resource Management)
- **Definition:** A movement mechanic where the player character can temporarily increase their movement speed (sprint) at the continuous cost of a depletable resource (stamina). When the resource is exhausted, the character can no longer sprint until the resource regenerates.

## 2. Core Verb & State Machine
- **Core Verb:** Sprinting / Managing Stamina

**State Diagram:**
```text
[Idle/Walk] --(Press Sprint Button & Stamina > 0)--> [Sprinting]
[Sprinting] --(Release Sprint Button)--> [Idle/Walk]
[Sprinting] --(Stamina == 0)--> [Exhausted]
[Exhausted] --(Stamina > Threshold)--> [Idle/Walk]
```

**States:**
- `Idle/Walk`: The default movement state. Stamina regenerates in this state.
- `Sprinting`: The character moves at an increased speed. Stamina depletes continuously.
- `Exhausted`: A penalty state triggered when stamina reaches zero. The character cannot sprint and may suffer a movement speed penalty or a delay before stamina begins regenerating.

**Transitions:**
- `Idle/Walk` -> `Sprinting`: Triggered by player input (e.g., holding the sprint button) while stamina is greater than zero.
- `Sprinting` -> `Idle/Walk`: Triggered by player releasing the sprint button.
- `Sprinting` -> `Exhausted`: Triggered automatically when stamina drops to zero.
- `Exhausted` -> `Idle/Walk`: Triggered automatically when stamina regenerates past a certain threshold or after a fixed penalty duration.

## 3. MDA Analysis
- **Mechanics:** The system tracks a stamina value that decreases at a fixed rate while the sprint input is active and the character is moving. It increases at a fixed rate when the sprint input is inactive. Sprinting multiplies the base movement speed by a specific factor.
- **Dynamics:** Players must balance their need for speed (to escape enemies, traverse the world quickly) against the risk of being caught without stamina (unable to dodge, attack, or sprint away). This creates a rhythm of bursting movement followed by recovery periods.
- **Aesthetics:** Creates tension and a sense of vulnerability. The player feels the physical exertion of the character. It adds weight and consequence to movement decisions, enhancing immersion and strategic depth.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Dark Souls III v1.15) | Unit |
| :--- | :--- | :--- | :--- | :--- |
| `max_stamina` | `f32` | 50.0 - 200.0 | 100.0 | points |
| `sprint_speed_multiplier` | `f32` | 1.3 - 2.5 | 1.5 | multiplier |
| `stamina_drain_rate` | `f32` | 5.0 - 20.0 | 10.0 | points/sec |
| `stamina_regen_rate` | `f32` | 10.0 - 40.0 | 25.0 | points/sec |
| `regen_delay` | `f32` | 0.2 - 1.5 | 0.5 | seconds |
| `exhaustion_penalty_time` | `f32` | 0.0 - 3.0 | 1.0 | seconds |

## 5. Benchmark Data
- **Dark Souls III (v1.15):**
  - `max_stamina`: 100.0 (base)
  - `sprint_speed_multiplier`: ~1.45
  - `stamina_drain_rate`: ~12.0 points/sec
  - `stamina_regen_rate`: ~45.0 points/sec
  - `regen_delay`: 0.5 seconds
- **The Legend of Zelda: Breath of the Wild (v1.5.0):**
  - `max_stamina`: 1.0 (represented as a full wheel, internally normalized)
  - `sprint_speed_multiplier`: ~1.8
  - `stamina_drain_rate`: 0.2 wheels/sec (approx 5 seconds to drain 1 wheel)
  - `stamina_regen_rate`: 0.33 wheels/sec (approx 3 seconds to refill 1 wheel)
  - `regen_delay`: 0.2 seconds
  - `exhaustion_penalty_time`: 2.0 seconds (panting animation)

## 6. Common Variants
1. **Segmented Stamina:** Stamina is divided into discrete chunks or bars rather than a continuous float (e.g., Hollow Knight's soul system, though less common for sprinting).
2. **Momentum-Based Sprinting:** Sprint speed gradually increases over time while stamina drains, rewarding long, uninterrupted sprints.
3. **Action-Interrupted Regen:** Stamina regeneration is paused not just by sprinting, but by any action (attacking, dodging, jumping).
4. **Exhaustion State Penalty:** Reaching zero stamina doesn't just stop sprinting, but forces the character into a slow walking state or plays a vulnerable "panting" animation (e.g., Breath of the Wild).

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_dodge_roll` (shares the same stamina pool, creating resource tension), `atom_jump` (sprinting before jumping often increases jump distance), `atom_melee_attack` (stamina management across movement and combat).
- **Incompatible Atoms:** `atom_auto_run` (if auto-run doesn't consume stamina, it undermines the sprint mechanic), `atom_infinite_dash` (conflicts with the core limitation of stamina).

## 8. Anti-Patterns
1. **Overly Punishing Exhaustion:** Making the exhaustion penalty too long or severe can frustrate players, turning traversal into a tedious start-stop process rather than an engaging rhythm.
2. **Negligible Drain Rate:** If stamina drains so slowly that the player rarely runs out during normal gameplay, the mechanic becomes superfluous and only serves as an annoyance during long-distance travel.
3. **Instant Regeneration:** If stamina regenerates instantly upon releasing the sprint button, players can "feather" or tap the button to maintain near-sprint speeds without ever triggering exhaustion, bypassing the intended resource management.
