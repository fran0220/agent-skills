# Identity
- **Atom ID**: atom_memory_match
- **English Name**: Memory Match
- **Chinese Name**: 记忆配对
- **Category**: C
- **Definition**: A cognitive gameplay mechanic where the player must reveal hidden elements, remember their locations, and match identical pairs or sets within a limited number of attempts or time.

# Core Verb & State Machine
- **Core Verb**: Reveal, Memorize, Match
- **State Diagram**:
  - [Hidden] -> (Reveal) -> [Revealed_1]
  - [Revealed_1] -> (Reveal) -> [Revealed_2]
  - [Revealed_2] -> (Check Match) -> [Matched] (if identical)
  - [Revealed_2] -> (Check Match) -> [Hidden] (if different, after delay)
- **States**:
  - `Hidden`: The element's identity is concealed from the player.
  - `Revealed_1`: The first element is revealed and its identity is visible.
  - `Revealed_2`: The second element is revealed for comparison.
  - `Matched`: Both elements are identical and remain revealed or are removed from play.
- **Transitions**:
  - `Hidden` to `Revealed_1`: Triggered by player selecting a hidden element.
  - `Revealed_1` to `Revealed_2`: Triggered by player selecting a second hidden element.
  - `Revealed_2` to `Matched`: Triggered automatically if the two revealed elements match.
  - `Revealed_2` to `Hidden`: Triggered automatically after a brief delay if the two revealed elements do not match.

# MDA Analysis
- **Mechanics**: The system generates a grid of paired elements, shuffles them, and hides them. It tracks player selections, compares revealed elements, and updates the game state based on the comparison result. It may also track time, attempts, or score.
- **Dynamics**: Players develop strategies such as scanning systematically, using mnemonic devices, or prioritizing certain areas of the grid. The game creates a tension between speed and accuracy, especially under time pressure.
- **Aesthetics**: Players experience a sense of cognitive challenge, satisfaction upon successfully matching pairs, and frustration when forgetting previously seen locations. It evokes feelings of focus and mental clarity.

# Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value | Unit |
|---|---|---|---|---|
| `grid_width` | u32 | 2 - 10 | 4 (Concentration v1.0) | cells |
| `grid_height` | u32 | 2 - 10 | 4 (Concentration v1.0) | cells |
| `reveal_delay` | f32 | 0.5 - 3.0 | 1.0 (Brain Training v2.1) | seconds |
| `time_limit` | f32 | 30.0 - 300.0 | 60.0 (Brain Training v2.1) | seconds |
| `max_attempts` | u32 | 10 - 100 | 20 (Concentration v1.0) | attempts |

# Benchmark Data
- **Concentration (v1.0)**:
  - `grid_width`: 4
  - `grid_height`: 4
  - `max_attempts`: 20
- **Brain Training (v2.1)**:
  - `reveal_delay`: 1.0
  - `time_limit`: 60.0

# Common Variants
1. **Time Attack**: Players must match as many pairs as possible within a strict time limit.
2. **Limited Mistakes**: The game ends if the player makes a certain number of incorrect matches.
3. **Moving Grid**: The hidden elements slowly move around the screen, adding a spatial tracking challenge.
4. **Multi-Match**: Players must match sets of three or more identical elements instead of just pairs.

# Compatibility Notes
- **Commonly Pairs With**: `atom_timer` (for time limits), `atom_score_multiplier` (for consecutive matches), `atom_level_progression` (increasing grid size).
- **Known Conflicts**: `atom_fast_paced_action` (memory match requires focus and pauses, which conflicts with continuous high-speed action).

# Anti-Patterns
1. **Insufficient Reveal Delay**: If the delay before hiding mismatched cards is too short, players cannot register the identities of the cards, leading to frustration.
2. **Overwhelming Grid Size**: Starting with a grid that is too large overwhelms the player's short-term memory, making the game feel like pure guesswork rather than a memory challenge.
3. **Indistinguishable Elements**: Using card designs that are too visually similar makes it difficult for players to encode and recall them effectively.
