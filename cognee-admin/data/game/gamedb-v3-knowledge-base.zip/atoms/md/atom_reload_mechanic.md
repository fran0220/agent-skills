# Gameplay Atom: Reload Mechanic

## 1. Identity
**Atom ID:** atom_reload_mechanic
**English Name:** Reload Mechanic
**Chinese Name:** 换弹机制
**Category:** A+B
**Definition:** The reload mechanic is a fundamental gameplay system in shooter games that governs the process of replenishing a weapon's ammunition from a reserve pool into its active magazine. It introduces a temporal vulnerability and resource management aspect to combat, forcing players to make tactical decisions about when and where to refresh their offensive capabilities.

## 2. Core Verb & State Machine
**Core Verb:** Reload (换弹)

**State Diagram:**
[Idle] --(Fire)--> [Firing]
[Firing] --(Empty/Manual Reload)--> [Reloading]
[Reloading] --(Interrupt)--> [Idle]
[Reloading] --(Complete)--> [Idle]
[Reloading] --(Active Reload Success)--> [Buffed Idle]

**States and Transitions:**
- **Idle:** The weapon is ready to fire.
- **Firing:** The weapon is discharging ammunition. Transitions to Reloading when the magazine is empty or the player manually triggers a reload.
- **Reloading:** The weapon is currently being replenished. The player is typically unable to fire during this state.
- **Buffed Idle:** A special state achieved through mechanics like "Active Reload," granting temporary bonuses (e.g., increased damage or faster fire rate).

## 3. MDA Analysis
**Mechanics:** The system tracks the current magazine count and reserve ammunition. When a reload is triggered, a timer starts. Upon completion, the magazine is refilled up to its maximum capacity, and the corresponding amount is deducted from the reserve. Advanced mechanics include "Active Reload," where a timed button press during the reload animation can speed up the process or grant buffs.
**Dynamics:** Players must balance the need for a full magazine against the vulnerability of the reload animation. This creates a rhythm in combat, dictating pacing and movement. Players may seek cover, switch weapons, or use abilities to mitigate the downtime.
**Aesthetics:** The reload mechanic contributes to the tension and immersion of combat. A well-timed reload can feel satisfying and empowering, while being caught reloading in the open induces panic and urgency. The audio-visual feedback of the reload animation heavily influences the "game feel."

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Game) | Unit |
| :--- | :--- | :--- | :--- | :--- |
| `reload_time` | f32 | 0.5 - 5.0 | 1.5 (CS:GO AK-47) | Seconds |
| `magazine_size` | u32 | 1 - 200 | 30 (COD: MW M4A1) | Bullets |
| `reserve_ammo` | u32 | 0 - 1000 | 90 (CS:GO AK-47) | Bullets |
| `active_reload_window_start` | f32 | 0.3 - 0.7 | 0.5 (Gears of War Lancer) | Ratio (0-1) |
| `active_reload_window_end` | f32 | 0.4 - 0.8 | 0.6 (Gears of War Lancer) | Ratio (0-1) |
| `can_interrupt` | bool | true/false | true (Apex Legends) | Boolean |

## 5. Benchmark Data
- **Gears of War (v1.0):** The Lancer assault rifle features the iconic Active Reload. `reload_time` is approximately 2.0 seconds. The `active_reload_window_start` is at 0.5 (50% through the animation) and `active_reload_window_end` is at 0.6. Success grants a damage boost.
- **Call of Duty: Modern Warfare (2019):** The M4A1 has a `magazine_size` of 30 and a `reload_time` of 1.25 seconds (empty reload is slightly longer). It emphasizes realistic animations and allows for "staged reloads" where the animation can be interrupted and resumed.
- **Counter-Strike: Global Offensive (v1.38):** The AK-47 has a `reload_time` of 2.5 seconds. The reload cannot be interrupted to fire the remaining bullets once started, forcing commitment.

## 6. Common Variants
1. **Active Reload:** A timing mini-game during the reload that rewards precision with faster reloads or damage buffs (e.g., Gears of War).
2. **Staged Reload:** The reload process is broken into checkpoints (e.g., ejecting mag, inserting new mag). If interrupted, the reload resumes from the last checkpoint rather than starting over (e.g., Call of Duty: Modern Warfare).
3. **Chambered Round:** Reloading a partially empty weapon leaves one round in the chamber, resulting in a capacity of `magazine_size + 1` and a faster reload animation compared to an empty reload (e.g., Battlefield series).
4. **Overheat/Cooldown:** Instead of finite magazines, weapons generate heat and must cool down. "Reloading" is replaced by a venting mechanic (e.g., Mass Effect).
5. **Throwaway Reload:** Reloading discards the remaining bullets in the current magazine (e.g., Helldivers).

## 7. Compatibility Notes
**Commonly Pairs With:**
- `atom_cover_system`: Players naturally seek cover during the vulnerable reload state.
- `atom_weapon_swap`: Swapping to a secondary weapon is often faster than reloading the primary.
- `atom_movement_speed_modifier`: Reloading often reduces player movement speed.

**Known Conflicts:**
- `atom_continuous_fire_buff`: Mechanics that reward holding down the trigger indefinitely conflict with the forced pauses of reloading.

## 8. Anti-Patterns
1. **Excessively Long Reloads Without Mitigation:** Forcing players to endure very long reload times without options like secondary weapons or cover can lead to frustration and break the flow of combat.
2. **Unclear Interrupt Rules:** If players cannot easily tell whether sprinting, meleeing, or swapping weapons will cancel or pause their reload, it leads to clunky and unpredictable gameplay.
3. **Lack of Audio-Visual Feedback:** Failing to provide clear sound cues and animations for when a reload starts, reaches a checkpoint, and finishes makes it difficult for players to manage their timing in chaotic situations.
