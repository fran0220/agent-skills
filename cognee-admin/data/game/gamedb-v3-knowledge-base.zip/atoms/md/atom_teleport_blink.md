# Identity
- **Atom ID**: atom_teleport_blink
- **English Name**: Teleport / Blink
- **Chinese Name**: 瞬移/闪现
- **Category**: Movement
- **Definition**: A movement mechanic that instantaneously translates the player character from their current position to a target location, bypassing the physical space in between.

# Core Verb & State Machine
- **Core Verb**: Blink
- **State Diagram**:
  [Idle] -> (Trigger) -> [Targeting] -> (Confirm) -> [Executing] -> (Cooldown) -> [Idle]
- **States and Transitions**:
  - Idle: Ready to blink.
  - Targeting: Selecting the destination (optional, some games use fixed distance).
  - Executing: The instantaneous movement.
  - Cooldown: Waiting for the ability to recharge.

# MDA Analysis
- **Mechanics**: The system updates the player's coordinates instantly to a new valid position within a maximum range, often checking for line of sight or collision.
- **Dynamics**: Players use it to dodge attacks, traverse gaps, close distance to enemies, or escape dangerous situations.
- **Aesthetics**: Empowers the player with a sense of speed, agility, and mastery over space.

# Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value | Unit |
|---|---|---|---|---|
| max_distance | f32 | 5.0 - 20.0 | 15.0 (Dishonored v1.0) | meters |
| cooldown | f32 | 1.0 - 10.0 | 3.0 (Overwatch v1.0) | seconds |
| requires_los | bool | true/false | true (Dishonored v1.0) | boolean |
| charges | u32 | 1 - 3 | 3 (Overwatch v1.0) | count |

# Benchmark Data
- **Dishonored (v1.0)**: max_distance = 15.0m, cooldown = 0.0s (mana based), requires_los = true.
- **Overwatch (Tracer v1.0)**: max_distance = 7.5m, cooldown = 3.0s per charge, charges = 3.

# Common Variants
1. **Targeted Blink**: Requires aiming at a specific valid surface (Dishonored).
2. **Directional Blink**: Moves a fixed distance in the current movement direction (Overwatch Tracer).
3. **Swap Teleport**: Swaps position with a target entity.
4. **Return Teleport**: Teleports back to a previously marked location.

# Compatibility Notes
- **Compatible Atoms**: atom_double_jump, atom_dash, atom_melee_attack.
- **Incompatible Atoms**: atom_root (cannot blink while rooted).

# Anti-Patterns
1. **Out of Bounds**: Failing to check collision at the destination, allowing players to clip through walls.
2. **Disorientation**: Blinking without visual or audio cues, confusing the player about their new location.
3. **Overpowered Mobility**: Making the cooldown too short, trivializing level design and enemy encounters.
