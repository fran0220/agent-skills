# Gameplay Atom: Ghost Replay (幽灵回放)

## 1. Identity
- **Atom ID**: atom_ghost_replay
- **English Name**: Ghost Replay
- **Chinese Name**: 幽灵回放
- **Category**: G or H (Racing games, speedrun tools)
- **Definition**: Ghost Replay is a gameplay mechanic where a previously recorded playthrough—often the player's personal best, a friend's run, or a world record—is visually represented in the game world as a non-colliding "ghost" entity. This allows players to race against past performances in real-time, providing immediate visual feedback on their current pace compared to the recorded run.

## 2. Core Verb & State Machine
- **Core Verb**: Race (against the ghost)
- **State Diagram**:
  - `Idle` -> `Recording` (Player starts a run)
  - `Recording` -> `Playback` (Player finishes and restarts, ghost appears)
  - `Playback` -> `Finished` (Run ends)
  - `Playback` -> `Paused` (Player pauses the game)
  - `Paused` -> `Playback` (Player resumes)
- **States**:
  - `Idle`: No active run or ghost.
  - `Recording`: The system is actively logging the player's position, rotation, and actions at discrete time intervals.
  - `Playback`: The system is reading the recorded data and interpolating the ghost's state to match the current playback time.
  - `Paused`: Both the player and the ghost are frozen in time.
  - `Finished`: The run is complete, and the ghost disappears or loops.
- **Transitions**:
  - `Start Run`: Transitions from `Idle` to `Recording`.
  - `Restart/Load Ghost`: Transitions from `Recording` or `Idle` to `Playback`.
  - `End Run`: Transitions from `Playback` or `Recording` to `Finished`.
  - `Pause Game`: Transitions from `Playback` to `Paused`.
  - `Resume Game`: Transitions from `Paused` to `Playback`.

## 3. MDA Analysis
- **Mechanics**: The system records the player's transform (position, rotation, scale) and relevant animation states at a fixed tick rate. During playback, it instantiates a visual representation (the ghost) and updates its transform by interpolating between the recorded data points based on the elapsed time. The ghost has collision disabled to prevent interference with the active player.
- **Dynamics**: Players use the ghost as a pacing tool. If they fall behind the ghost, they know they need to optimize their route or execution. If they are ahead, they experience the pressure of maintaining their lead. The ghost provides micro-goals throughout the run, rather than just a final time comparison.
- **Aesthetics**: The primary aesthetic is **Challenge** and **Fellowship** (when racing against others' ghosts). Players feel a sense of continuous improvement and rivalry. The visual presence of the ghost creates a tangible sense of competition, even in a single-player context.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Game/Version) | Unit |
| :--- | :--- | :--- | :--- | :--- |
| `record_tick_rate` | `u32` | 10 - 60 | 30 (Trackmania 2020) | Hz (ticks per second) |
| `ghost_opacity` | `f32` | 0.1 - 1.0 | 0.5 (Mario Kart 8 Deluxe) | Alpha (0-1) |
| `interpolation_mode` | `enum` | Linear, Spline | Linear (Super Meat Boy) | N/A |
| `max_record_time` | `f32` | 60 - 3600 | 300 (Celeste v1.4) | Seconds |
| `ghost_color` | `Color` | Any | Semi-transparent Blue | RGBA |

## 5. Benchmark Data
- **Trackmania (2020)**:
  - `record_tick_rate`: ~30 Hz. The game records inputs and physics states to ensure deterministic playback, but the visual ghost updates frequently enough to appear smooth.
  - `ghost_opacity`: Adjustable by the player, typically defaults to around 0.5 to avoid obscuring the track.
- **Mario Kart 8 Deluxe (v3.0.1)**:
  - `ghost_opacity`: ~0.5. The ghost is clearly visible but does not block the player's view of items or hazards.
  - `max_record_time`: Limited to the maximum time allowed for a Time Trial race (typically around 3-5 minutes depending on the track).
- **Celeste (v1.4.0.0)**:
  - `record_tick_rate`: 60 Hz (tied to the game's physics update rate).
  - `interpolation_mode`: Linear. The game records exact positions every frame for precise playback.

## 6. Common Variants
1. **Input-Based Replay**: Instead of recording positions, the system records the exact inputs (button presses, joystick movements) and feeds them into a deterministic physics engine. This is common in fighting games and highly deterministic platformers (e.g., Super Meat Boy).
2. **Multiple Ghosts**: Allowing the player to race against several ghosts simultaneously (e.g., their personal best, the next medal time, and the world record).
3. **Asynchronous Multiplayer Ghosts**: Downloading ghosts from a leaderboard to race against players who are not currently online.
4. **Trainer Ghosts**: Developer-created ghosts that demonstrate the optimal path or advanced techniques for a level.
5. **Interactive Ghosts**: Rare variant where the ghost can interact with the environment (e.g., breaking blocks) but not the player directly.

## 7. Compatibility Notes
- **Commonly Pairs With**:
  - `atom_time_trial`: Ghost replays are the quintessential feature of time trial modes.
  - `atom_leaderboard`: Ghosts are often attached to leaderboard entries, allowing players to download and race against top times.
  - `atom_checkpoint`: Ghosts can be used to show split times at specific checkpoints.
- **Known Conflicts**:
  - `atom_procedural_generation`: If a level is randomly generated every time, a recorded ghost from a previous run will not match the current level layout, making it useless.
  - `atom_dynamic_physics_objects`: If the environment contains physics objects that behave unpredictably, an input-based ghost might desync, or a position-based ghost might clip through objects that are in different positions than during the recording.

## 8. Anti-Patterns
1. **Obscuring the Player's View**: Making the ghost fully opaque or too bright, which can block the player's line of sight to upcoming obstacles or turns.
2. **High Storage Overhead**: Recording too much data (e.g., full transform and animation state every frame at 144Hz) can lead to massive file sizes for replays, making them difficult to share or store.
3. **Desynchronization in Input Replays**: Failing to ensure strict determinism in the physics engine when using input-based replays, causing the ghost to eventually drift away from the intended path and fail the run.
