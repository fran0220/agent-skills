# Identity
- **Atom ID**: atom_fmv_choice
- **English Name**: FMV Interactive Choice
- **Chinese Name**: 全动态影像选择
- **Category**: E (Narrative & Events)
- **Definition**: A gameplay mechanic where the player makes decisions during or between Full Motion Video (FMV) sequences, directly influencing the narrative branching, scene transitions, or available information.

# Core Verb & State Machine
- **Core Verb**: Choose / Select
- **State Diagram**:
  [Playing Video] -> (Decision Point Reached) -> [Awaiting Choice]
  [Awaiting Choice] -> (Choice Made) -> [Transitioning]
  [Transitioning] -> (Video Loaded) -> [Playing Video]
  [Awaiting Choice] -> (Timeout) -> [Default Choice Auto-Selected] -> [Transitioning]
- **States**: Playing Video, Awaiting Choice, Transitioning
- **Transitions**:
  - Playing Video -> Awaiting Choice: Triggered by reaching a specific timestamp in the video.
  - Awaiting Choice -> Transitioning: Triggered by player input selecting an option.
  - Awaiting Choice -> Transitioning: Triggered by a timer expiring (timeout).
  - Transitioning -> Playing Video: Triggered by the next video segment buffering and starting.

# MDA Analysis
- **Mechanics**: The system plays a video file and pauses or loops a segment while presenting UI overlays for choices. Each choice maps to a specific next video file or scene index. A timer may enforce quick decision-making.
- **Dynamics**: Players must quickly process the narrative context and make a decision under time pressure (if applicable), leading to different story branches. They may experience anxiety or excitement due to the seamless nature of the video.
- **Aesthetics**: Immersion, Narrative Discovery, Tension, Agency.

# Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value (Late Shift v1.0) | Unit |
|---|---|---|---|---|
| choice_timeout | f32 | 3.0 - 10.0 | 5.0 | seconds |
| num_options | u32 | 2 - 4 | 2 | count |
| transition_delay | f32 | 0.0 - 1.0 | 0.1 | seconds |
| seamless_audio | bool | true/false | true | boolean |

# Benchmark Data
- **Late Shift (v1.0)**:
  - choice_timeout: 5.0s
  - num_options: 2
  - transition_delay: 0.1s
- **Her Story (v1.0)**:
  - choice_timeout: 0.0s (infinite)
  - num_options: 5 (search results)
  - transition_delay: 0.5s

# Common Variants
1. **Timed Binary Choice**: Two options with a strict timer (e.g., Late Shift).
2. **Keyword Search Selection**: Typing keywords to select which video to play next (e.g., Her Story).
3. **Hidden Object Selection**: Clicking on elements within the video frame to trigger the next sequence (e.g., Immortality).
4. **QTE Choice**: Quick Time Events overlaid on the video where success/failure determines the branch.

# Compatibility Notes
- **Compatible Atoms**: atom_branching_narrative, atom_qte, atom_inventory_system.
- **Incompatible Atoms**: atom_free_camera_movement (FMV is pre-rendered), atom_procedural_generation (FMV is static).

# Anti-Patterns
1. **Noticeable Buffering**: A long pause or black screen between choices breaks the immersion of FMV.
2. **Illogical Branching**: Choices that lead to identical outcomes without acknowledging the player's input, causing frustration.
3. **Unreadable UI**: Choice text that blends into the video background, making it hard to read within the time limit.
