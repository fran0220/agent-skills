# Identity
- **Atom ID**: atom_timed_choice
- **English Name**: Timed Choice
- **Chinese Name**: 限时选择
- **Category**: E (Narrative/Choice)
- **Definition**: A decision-making mechanic where the player is presented with multiple options and must select one within a strict time limit. Failure to choose typically results in a default action, often with negative or unpredictable consequences.

# Core Verb & State Machine
- **Core Verb**: Choose (within time limit)
- **State Diagram**:
  [Idle] -> (Trigger Event) -> [Active Timer]
  [Active Timer] -> (Player Selects Option) -> [Resolved: Chosen]
  [Active Timer] -> (Timer Expires) -> [Resolved: Default/Timeout]
  [Resolved: Chosen] -> [End]
  [Resolved: Default/Timeout] -> [End]

- **States**:
  - `Idle`: Waiting for the choice event to trigger.
  - `Active Timer`: The choice UI is displayed, and the timer is counting down.
  - `Resolved: Chosen`: The player has made a selection.
  - `Resolved: Default/Timeout`: The timer reached zero without a selection.
  - `End`: The choice sequence is complete, and the game proceeds based on the outcome.

- **Transitions**:
  - `Idle` to `Active Timer`: Triggered by narrative or gameplay event.
  - `Active Timer` to `Resolved: Chosen`: Triggered by player input selecting an option.
  - `Active Timer` to `Resolved: Default/Timeout`: Triggered by the timer reaching 0.
  - `Resolved` states to `End`: Automatic transition after outcome processing.

# MDA Analysis
- **Mechanics**: The system displays a set of options and a countdown timer. It listens for player input corresponding to the options. If input is received before the timer expires, the associated outcome is executed. If the timer expires, a predefined "timeout" outcome is executed.
- **Dynamics**: Players experience time pressure, forcing them to quickly evaluate options based on limited information or intuition. This often leads to impulsive decisions or panic, simulating high-stress situations.
- **Aesthetics**: Tension, urgency, regret, and immersion. The time limit heightens emotional engagement and makes the narrative feel more dynamic and realistic.

# Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value | Unit |
|---|---|---|---|---|
| `time_limit` | f32 | 3.0 - 15.0 | 5.0 (The Walking Dead v1.0) | seconds |
| `num_options` | u32 | 2 - 4 | 4 (Detroit: Become Human v1.0) | count |
| `has_default_action` | bool | true/false | true (The Walking Dead v1.0) | boolean |
| `timer_visibility` | bool | true/false | true (Detroit: Become Human v1.0) | boolean |

# Benchmark Data
- **The Walking Dead (Telltale Games) v1.0**:
  - `time_limit`: 5.0 seconds (typical for high-stress dialogue)
  - `num_options`: 4
  - `has_default_action`: true (usually silence or inaction)
- **Detroit: Become Human (Quantic Dream) v1.0**:
  - `time_limit`: 10.0 seconds (for complex action choices)
  - `num_options`: 4
  - `timer_visibility`: true (represented as a shrinking bar or circle)

# Common Variants
1. **Hidden Timer**: The player knows they must act quickly, but the exact time remaining is not displayed, increasing panic.
2. **Interrupts**: A single action prompt that appears briefly during a cutscene, requiring a quick button press to alter the scene's flow.
3. **Branching Timers**: The time limit changes dynamically based on previous choices or the character's current stress level.
4. **Action-Linked Choices**: The options are tied to physical actions in the game world rather than just dialogue (e.g., choosing which path to run down while being chased).

# Compatibility Notes
- **Commonly Pairs With**: `atom_dialogue_tree`, `atom_quick_time_event`, `atom_moral_choice`, `atom_branching_narrative`.
- **Conflicts**: `atom_turn_based_combat` (time limits disrupt the strategic pacing of turn-based systems), `atom_pause_menu` (if the game allows pausing during the choice, it negates the time pressure).

# Anti-Patterns
1. **Insufficient Time**: Giving the player too little time to even read the options, leading to frustration rather than tension.
2. **Meaningless Timeout**: Making the timeout consequence identical to one of the choices, removing the unique impact of failing to choose.
3. **Overuse**: Placing timed choices too frequently, which can exhaust the player and diminish the emotional impact of the mechanic.
