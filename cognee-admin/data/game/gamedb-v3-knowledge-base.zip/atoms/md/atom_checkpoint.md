# Gameplay Atom: Checkpoint / Bonfire

## 1. Identity
- **Atom ID:** `atom_checkpoint`
- **English Name:** Checkpoint / Bonfire
- **Chinese Name:** 检查点/篆火
- **Category:** G (Game Progression)
- **Definition:** A designated location or state in a game where the player's progress is saved, allowing them to respawn or resume from this point upon failure or exiting the game.

## 2. Core Verb & State Machine
- **Core Verb:** Save / Respawn
- **State Diagram:**
  ```text
  [Unactivated] --(Player interacts/reaches)--> [Activated]
  [Activated] --(Player dies)--> [Respawning]
  [Respawning] --(Respawn complete)--> [Activated]
  ```
- **States:**
  - `Unactivated`: The checkpoint has not been reached or interacted with by the player.
  - `Activated`: The checkpoint is currently the active respawn point.
  - `Respawning`: The player is in the process of being revived at this checkpoint.
- **Transitions:**
  - `Unactivated` -> `Activated`: Triggered when the player enters the activation radius or manually interacts with the checkpoint.
  - `Activated` -> `Respawning`: Triggered when the player's health reaches zero or a fail state is met.
  - `Respawning` -> `Activated`: Triggered after the respawn delay finishes and the player regains control.

## 3. MDA Analysis
- **Mechanics:** The system records the player's current state, including position, inventory, and world progress, to memory or disk. Upon failure, it restores the player to this recorded state.
- **Dynamics:** Creates a rhythm of tension and release. Players experience high tension when far from a checkpoint and relief upon reaching one. It encourages risk-taking immediately after saving.
- **Aesthetics:** Feelings of relief, safety, and accomplishment. It serves as a pacing mechanism that breaks the game into digestible segments.

## 4. Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value | Unit |
|---|---|---|---|---|
| `activation_radius` | f32 | 1.0 - 5.0 | 2.0 (Dark Souls v1.0) | meters |
| `heal_amount` | f32 | 0.0 - 100.0 | 100.0 (Dark Souls v1.0) | percentage |
| `respawn_delay` | f32 | 0.0 - 10.0 | 3.0 (Dark Souls v1.0) | seconds |
| `enemies_respawn` | bool | true/false | true (Dark Souls v1.0) | boolean |

## 5. Benchmark Data
- **Dark Souls (v1.0):** `heal_amount` = 100.0, `enemies_respawn` = true, `respawn_delay` = 5.0
- **Celeste (v1.4):** `heal_amount` = 0.0, `enemies_respawn` = false, `respawn_delay` = 1.0
- **Hollow Knight (v1.5):** `heal_amount` = 100.0, `enemies_respawn` = true, `respawn_delay` = 2.5

## 6. Common Variants
1. **Auto-save Checkpoints:** Invisible triggers that save progress automatically without player input (e.g., Call of Duty).
2. **Manual Save Points:** Require explicit player interaction and sometimes a consumable item to save (e.g., Typewriters in Resident Evil).
3. **World-Resetting Bonfires:** Resting saves progress but also respawns all enemies in the world (e.g., Dark Souls).
4. **Respawn Statues:** Only serve as a respawn location upon death, without saving the game state to disk (e.g., Bioshock Vita-Chambers).

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_health` (restores health), `atom_inventory` (saves items), `atom_fast_travel` (often act as fast travel nodes).
- **Incompatible Atoms:** `atom_permadeath` (fundamentally conflicts with the concept of respawning at a previous state).

## 8. Anti-Patterns
1. **Pre-Cutscene Placement:** Placing a checkpoint right before an unskippable cutscene, forcing the player to rewatch it upon every failure.
2. **Checkpoint Starvation:** Placing checkpoints too far apart, leading to immense frustration and loss of significant progress upon death.
3. **Tensionless Placement:** Placing checkpoints too frequently, removing all risk and tension from the gameplay loop.
