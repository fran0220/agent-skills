# Gameplay Atom: Cascade / Chain Reaction

## 1. Identity
- **Atom ID:** `atom_cascade_chain`
- **English Name:** Cascade / Chain Reaction
- **Chinese Name:** 连锁反应
- **Category:** C (Core Mechanics) / D (Dynamics)
- **Definition:** A gameplay mechanic where a single player action triggers a sequence of automated events, often resulting in exponentially increasing rewards or effects. The initial resolution creates a new state that automatically satisfies the conditions for subsequent resolutions without further player input.

## 2. Core Verb & State Machine
- **Core Verb:** Trigger (or Match/Activate)
- **State Diagram:**
  ```text
  [Idle] --(Player Action)--> [Resolving]
  [Resolving] --(Condition Met)--> [Cascade Check]
  [Cascade Check] --(Match Found)--> [Resolving]
  [Cascade Check] --(No Match)--> [Idle]
  ```
- **States:**
  - `Idle`: Waiting for player input.
  - `Resolving`: Processing the current match or activation, removing elements, and applying effects.
  - `Cascade Check`: Evaluating the new board/game state to see if further matches or activations are triggered automatically.
- **Transitions:**
  - `Idle` -> `Resolving`: Triggered by player action (e.g., swapping gems, placing a piece).
  - `Resolving` -> `Cascade Check`: Triggered automatically after the current resolution finishes and new elements fall or shift into place.
  - `Cascade Check` -> `Resolving`: Triggered if the new state meets the criteria for a match/activation.
  - `Cascade Check` -> `Idle`: Triggered if no further matches/activations are possible.

## 3. MDA Analysis
- **Mechanics:** The system evaluates the game state after an initial resolution. If the new state meets specific criteria (e.g., 3 matching colors in a row), it automatically resolves them, updates the state, and repeats the evaluation. A multiplier or bonus is often applied for each successive step in the chain.
- **Dynamics:** Players attempt to set up the board state so that a single move will trigger multiple subsequent resolutions. This involves planning ahead, understanding the rules of element movement (e.g., gravity in match-3 games), and managing probability.
- **Aesthetics:** The player experiences a sense of mastery, satisfaction, and spectacle. The visual and audio feedback usually escalates with each step of the chain, creating a thrilling "jackpot" feeling.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Game) | Unit |
| :--- | :--- | :--- | :--- | :--- |
| `base_score` | `u32` | 10 - 100 | 60 (Candy Crush Saga v1.2) | points |
| `multiplier_step` | `f32` | 0.1 - 1.0 | 0.5 (Bejeweled 3) | multiplier |
| `max_multiplier` | `f32` | 2.0 - 10.0 | 5.0 (Puyo Puyo Tetris) | multiplier |
| `animation_delay` | `f32` | 0.1 - 0.5 | 0.25 (Candy Crush Saga v1.2) | seconds |
| `gravity_speed` | `f32` | 5.0 - 20.0 | 9.8 (Puyo Puyo Tetris) | units/sec |

## 5. Benchmark Data
- **Candy Crush Saga (v1.230.1.1):**
  - `base_score`: 60 points per standard 3-match.
  - `multiplier_step`: 0.0 (Score scales linearly with the number of candies, but special candies create massive bursts).
  - `animation_delay`: ~0.3 seconds between cascade steps to allow players to comprehend the action.
- **Puyo Puyo Tetris (v1.0.0):**
  - `base_score`: 40 points for a 4-Puyo clear.
  - `multiplier_step`: Scales non-linearly based on the chain length (e.g., Chain 2 is 8x, Chain 3 is 16x).
  - `max_multiplier`: Effectively uncapped, but practically limited by board size (max chain ~19).

## 6. Common Variants
1. **Gravity-Based Match-3:** Elements fall from the top to fill empty spaces, potentially creating new matches (e.g., Candy Crush, Bejeweled).
2. **Combo Systems in Action Games:** Landing successive hits within a tight time window increases a combo counter and damage multiplier (e.g., Devil May Cry, Bayonetta).
3. **Explosive Chain Reactions:** Destroying one object causes an explosion that destroys adjacent objects, which in turn explode (e.g., Bomberman, various puzzle games).
4. **Card Game Combos:** Playing one card triggers an effect that draws or plays another card, leading to a sequence of automated actions (e.g., Hearthstone, Slay the Spire).

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_match_3`, `atom_gravity_fall`, `atom_combo_meter`, `atom_grid_movement`.
- **Incompatible Atoms:** `atom_turn_based_strict` (if the cascade resolves instantly without showing the intermediate steps, it can confuse the player in a strict turn-based tactical game).

## 8. Anti-Patterns
1. **Unreadable Cascades:** If the animation delay is too short, the player cannot understand why a cascade happened, reducing the feeling of skill and making it feel like pure luck.
2. **Infinite Loops:** Poorly designed rules can lead to a state where the cascade never ends, soft-locking the game.
3. **Overpowered Early Chains:** If the multiplier scales too aggressively early on, it trivializes the rest of the game's mechanics and makes standard play feel unrewarding.
