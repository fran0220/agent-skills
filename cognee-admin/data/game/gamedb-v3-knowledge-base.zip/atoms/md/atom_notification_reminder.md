# Gameplay Atom: Notification / Reminder

## 1. Identity
- **Atom ID:** `atom_notification_reminder`
- **English Name:** Notification / Reminder
- **Chinese Name:** 通知/提醒
- **Category:** H (Meta / System)
- **Definition:** A system-driven mechanic designed to alert the player about specific in-game events, state changes, or time-sensitive opportunities, often occurring outside of active gameplay or during idle states to prompt re-engagement.

## 2. Core Verb & State Machine
- **Core Verb:** Acknowledge / Check
- **State Diagram:**
  ```text
  [Idle] --> (Trigger Condition Met) --> [Pending Notification]
  [Pending Notification] --> (Player Opens App/Checks UI) --> [Acknowledged]
  [Pending Notification] --> (Timeout) --> [Expired]
  [Acknowledged] --> (Action Taken) --> [Resolved]
  [Acknowledged] --> (Dismissed) --> [Idle]
  [Resolved] --> [Idle]
  [Expired] --> [Idle]
  ```
- **States:**
  - `Idle`: No active alerts.
  - `Pending Notification`: An alert has been generated but not yet seen by the player.
  - `Acknowledged`: The player has seen the notification.
  - `Resolved`: The player has acted upon the notification's prompt.
  - `Expired`: The notification is no longer relevant and has been removed.
- **Transitions:**
  - `Idle` -> `Pending Notification`: Triggered by a timer, event, or external server push.
  - `Pending Notification` -> `Acknowledged`: Triggered by player interaction.
  - `Pending Notification` -> `Expired`: Triggered by time limit reached.
  - `Acknowledged` -> `Resolved`: Triggered by player completing the associated task.
  - `Acknowledged` -> `Idle`: Triggered by player dismissing the alert.

## 3. MDA Analysis
- **Mechanics:** The game monitors specific variables (e.g., energy recharge, crop growth, daily login reset) and generates a visual, auditory, or push notification when a threshold is met.
- **Dynamics:** Players develop habits around checking the game in response to or in anticipation of notifications, creating a rhythm of play sessions.
- **Aesthetics:** Anticipation, Relief (not missing out), and sometimes Annoyance if overused. It fosters a sense of connection to a persistent world.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value | Unit |
|---|---|---|---|---|
| `trigger_delay` | `u32` | 0 - 86400 | 3600 (Clash of Clans v15.0) | seconds |
| `expiration_time` | `u32` | 3600 - 604800 | 86400 (Genshin Impact v4.0) | seconds |
| `max_queued_notifications` | `u32` | 1 - 50 | 10 (Tamagotchi Uni v1.0) | count |
| `is_push_enabled` | `bool` | true/false | true | boolean |
| `cooldown_between_alerts` | `u32` | 300 - 86400 | 14400 (Hay Day v1.55) | seconds |

## 5. Benchmark Data
- **Clash of Clans (v15.0):**
  - `trigger_delay`: 0 (Immediate upon troop training completion)
  - `cooldown_between_alerts`: 3600 (Limits spam if multiple buildings finish)
- **Tamagotchi Uni (v1.0):**
  - `max_queued_notifications`: 5 (Hunger, Poop, Sadness, Sleep, Event)
  - `expiration_time`: 43200 (12 hours before severe consequence)
- **Genshin Impact (v4.0):**
  - `trigger_delay`: 0 (Resin capped)
  - `is_push_enabled`: true (Mobile only)

## 6. Common Variants
1. **Push Notifications:** OS-level alerts sent when the app is closed (e.g., "Your energy is full!").
2. **In-Game Badges (Red Dots):** UI indicators showing new content or claimable rewards.
3. **Diegetic Reminders:** In-world characters or sounds alerting the player (e.g., a Tamagotchi beeping).
4. **Calendar/Event Alarms:** Scheduled notifications for limited-time events.

## 7. Compatibility Notes
- **Commonly Pairs With:** `atom_energy_system`, `atom_daily_reward`, `atom_crafting_timer`, `atom_virtual_pet_needs`.
- **Conflicts:** `atom_permadeath` (if the notification implies saving the player from immediate unpreventable doom), `atom_flow_state` (intrusive notifications disrupt deep immersion).

## 8. Anti-Patterns
1. **Notification Spam:** Sending too many alerts in a short period, leading the player to disable notifications entirely.
2. **False Urgency:** Notifying the player about trivial events with high-urgency sounds or language.
3. **Unclear Actionability:** Sending a notification that doesn't clearly tell the player what they need to do or where to go in the UI.
