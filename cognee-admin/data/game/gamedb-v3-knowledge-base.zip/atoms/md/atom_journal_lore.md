# Gameplay Atom: Journal / Lore Entry

## 1. Identity
- **Atom ID:** `atom_journal_lore`
- **English Name:** Journal / Lore Entry
- **Chinese Name:** 日志/传说条目
- **Category:** E (Exploration / Narrative)
- **Definition:** A collectible or discoverable piece of text, audio, or visual information that expands the game's world-building, backstory, or narrative context without necessarily advancing the main quest. It rewards player exploration with narrative depth.

## 2. Core Verb & State Machine
- **Core Verb:** Read / Listen / Inspect
- **State Diagram:**
  ```text
  [Hidden] --(Discover)--> [Unread] --(Interact)--> [Reading/Listening] --(Close)--> [Read/Archived]
  ```
- **States:**
  - `Hidden`: The lore entry is placed in the world but not yet found by the player.
  - `Unread`: The player has picked up or unlocked the entry but hasn't consumed its content.
  - `Reading/Listening`: The player is actively viewing the text or listening to the audio.
  - `Read/Archived`: The entry is stored in the player's journal or codex for future reference.
- **Transitions:**
  - `Hidden` -> `Unread`: Triggered by player proximity or interaction (e.g., picking up a book).
  - `Unread` -> `Reading/Listening`: Triggered by player opening the entry in the UI.
  - `Reading/Listening` -> `Read/Archived`: Triggered by player closing the UI or audio finishing.

## 3. MDA Analysis
- **Mechanics:** The system places interactive objects in the environment. Upon interaction, it unlocks a UI element containing text/audio and flags the item as collected. It may grant minor rewards (e.g., XP).
- **Dynamics:** Players actively search corners of the map, deviating from the critical path to find hidden lore. They piece together fragmented stories over time.
- **Aesthetics:** Discovery, Narrative Immersion, Fantasy. Players feel like archaeologists or detectives uncovering the secrets of the world.

## 4. Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value (Game) | Unit |
| --- | --- | --- | --- | --- |
| `interaction_radius` | f32 | 1.0 - 5.0 | 2.5 (Skyrim v1.5) | meters |
| `read_xp_reward` | u32 | 0 - 50 | 10 (Witcher 3 v1.32) | XP |
| `word_count_limit` | u32 | 50 - 1000 | 300 (Skyrim v1.5) | words |
| `auto_pause_game` | bool | true/false | true (Hollow Knight v1.5) | boolean |

## 5. Benchmark Data
- **The Elder Scrolls V: Skyrim (v1.5):**
  - `interaction_radius`: 2.5 meters
  - `read_xp_reward`: 0 (except skill books which grant 1 skill level)
  - `word_count_limit`: ~300 words per page
  - `auto_pause_game`: true
- **The Witcher 3: Wild Hunt (v1.32):**
  - `interaction_radius`: 1.5 meters
  - `read_xp_reward`: 10 XP (for some quest-related notes)
  - `word_count_limit`: ~150 words
  - `auto_pause_game`: true
- **Hollow Knight (v1.5):**
  - `interaction_radius`: 1.0 meters (Lore Tablets)
  - `read_xp_reward`: 0
  - `word_count_limit`: ~50 words
  - `auto_pause_game`: true

## 6. Common Variants
1. **Audio Logs:** Instead of text, the lore is delivered via voice acting while the player continues to play (e.g., BioShock, Horizon Zero Dawn).
2. **Environmental Storytelling:** No explicit text; the lore is conveyed through the arrangement of objects or corpses (e.g., Fallout series).
3. **Bestiary/Codex:** Lore entries are unlocked by defeating enemies or scanning objects, rather than finding books (e.g., Mass Effect, Doom).
4. **Skill Books:** Reading the lore entry provides a tangible gameplay benefit, such as a stat increase or new skill (e.g., Skyrim).

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_exploration_reward`, `atom_inventory_system`, `atom_quest_trigger`, `atom_achievement_tracker`.
- **Incompatible Atoms:** `atom_speedrun_timer` (forced reading interrupts flow), `atom_pure_arcade_combat` (narrative pacing clashes with constant action).

## 8. Anti-Patterns
1. **Wall of Text:** Providing too much text at once, causing players to skip reading entirely.
2. **Critical Path Blocking:** Hiding essential puzzle solutions or main quest directions in obscure, optional lore entries.
3. **Immersion Breaking UI:** Using a modern, clean UI for a lore entry in a dark fantasy game, breaking the aesthetic consistency.
