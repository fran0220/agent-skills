# Achievement System (成就/奖杯)

## 1. Identity
**Atom ID**: atom_achievement_system
**English Name**: Achievement / Trophy
**Chinese Name**: 成就/奖杯
**Category**: E (Extrinsic Motivation) / F (Feedback)
**Representative Games**: Steam, PlayStation, Xbox

The Achievement System, also known as Trophies or Gamerscore depending on the platform, is a meta-game reward structure designed to track and recognize player accomplishments outside the core gameplay loop. By providing extrinsic motivation and long-term goals, this system encourages players to explore different facets of a game, master its mechanics, and engage with content they might otherwise overlook. It serves as a permanent record of a player's journey, offering a sense of completion and social prestige within the gaming community.

## 2. Core Verb & State Machine
The primary player verb associated with this atom is **Unlock** (解锁). Players perform specific actions or reach milestones to transition an achievement from a locked state to an unlocked state.

**State Diagram**:
[Locked] --(Progress)--> [In Progress] --(Condition Met)--> [Unlocked]

The system operates on a relatively straightforward state machine with three primary states:
- **Locked**: The achievement is visible (or sometimes hidden to prevent spoilers) but has not yet been earned by the player. The conditions for unlocking it are usually displayed.
- **In Progress**: The player has made partial progress towards the requirement. This state is particularly relevant for cumulative achievements, such as defeating a certain number of enemies or collecting a specific amount of currency.
- **Unlocked**: The achievement condition has been fully met, triggering a notification and permanently recording the completion on the player's profile.

The transitions between these states are driven by player actions:
- **Locked -> In Progress**: The player performs an action that contributes to the achievement's requirements, initiating the tracking process.
- **In Progress -> Unlocked**: The player reaches the required threshold or completes the final step of the achievement.
- **Locked -> Unlocked**: The player completes a single-step requirement, bypassing the in-progress state entirely.

## 3. MDA Analysis
**Mechanics**: At its core, the achievement system mechanics involve tracking specific player actions, statistics, or milestones throughout their gameplay experience. The game continuously monitors these variables against predefined conditions. When a condition is met, the system triggers a notification (often accompanied by a distinct sound effect and visual cue) and permanently records the completion on the player's platform profile or in-game ledger.

**Dynamics**: The presence of achievements can significantly alter player behavior and emergent gameplay dynamics. Players may intentionally change their playstyle to pursue specific achievements, such as using a suboptimal weapon to secure a "100 kills with X" achievement or attempting a pacifist run to earn a special reward. This dynamic encourages exploration of alternative strategies and mastery of different game systems, extending the game's lifespan and replayability.

**Aesthetics**: From an aesthetic perspective, the achievement system caters to several player motivations. It provides a profound sense of completion (Completionism) for players who strive to experience everything a game has to offer. It also offers bragging rights and social prestige (Social Status) when players display rare or difficult achievements on their profiles. Furthermore, it delivers satisfaction from overcoming optional, often demanding challenges (Challenge), reinforcing the player's sense of competence and skill.

## 4. Parameter Space
The following table outlines the tunable parameters that define the configuration and balance of an achievement system.

| Parameter Name | Type | Typical Range | Benchmark Value | Unit |
|---|---|---|---|---|
| `total_achievements` | u32 | 10 - 100 | 50 (Steam average) | count |
| `rarity_threshold` | f32 | 0.01 - 0.50 | 0.10 (PlayStation Ultra Rare) | percentage |
| `progress_steps` | u32 | 1 - 10000 | 100 | count |
| `points_value` | u32 | 5 - 100 | 15 (Xbox Gamerscore) | points |

## 5. Benchmark Data
To provide context for these parameters, we can look at benchmark data from representative platforms and games:

- **Steam (General)**: On average, a standard game on Steam features around 50 achievements. The rarity of these achievements is calculated dynamically based on the percentage of the total player base that has unlocked them, providing a real-time reflection of their difficulty or obscurity.
- **PlayStation Network (PS5)**: The PlayStation ecosystem categorizes trophies into Bronze (common), Silver (uncommon), Gold (rare), and Platinum. The Platinum trophy is uniquely awarded only when a player unlocks all other base-game trophies. A rarity threshold of 0.10 (10%) or lower often classifies a trophy as "Ultra Rare."
- **Xbox Live (Xbox Series X)**: Xbox achievements award Gamerscore (G). A standard retail game typically has a total of 1000G distributed across its achievements. A common benchmark value for a standard achievement is 15G, with more challenging accomplishments awarding 50G or even 100G.

## 6. Common Variants
The achievement system has evolved to include several common variations across different games and platforms:

- **Hidden Achievements**: The description and title of the achievement are obscured until it is unlocked. This variant is primarily used to prevent story spoilers or to hide secret, easter-egg-style accomplishments that players are meant to discover organically.
- **Progressive Achievements**: A series of linked achievements that reward the same type of action at increasing thresholds (e.g., "Kill 10 enemies," "Kill 100 enemies," "Kill 1000 enemies"). This provides continuous short-term goals while working towards a long-term objective.
- **Time-Limited Achievements**: These achievements can only be unlocked during specific real-world events, seasons, or promotional periods. They leverage the fear of missing out (FOMO) to drive player engagement during specific timeframes.
- **Meta-Achievements**: Achievements that are unlocked exclusively by unlocking a specific set of other achievements. The PlayStation Platinum trophy is the most prominent example of this variant.

## 7. Compatibility Notes
The achievement system interacts with various other gameplay atoms, often enhancing their effectiveness:

- **Compatible Atoms**: The system pairs exceptionally well with `atom_xp_level` (where unlocking achievements grants experience points towards a meta-progression system) and `atom_cosmetic_reward` (where achievements unlock exclusive skins, titles, or avatars, providing a tangible in-game benefit for meta-game accomplishments).
- **Incompatible Atoms**: There can be friction with `atom_permadeath_wipe`. If a game features complete meta-progression wipes upon death, achievements must be carefully designed to remain permanent at the account level, otherwise, they lose their value as long-term records of accomplishment.

## 8. Anti-Patterns
When implementing an achievement system, designers should be wary of several common pitfalls:

- **Grindy Achievements**: Designing achievements that require an unreasonable amount of repetitive, unengaging actions (e.g., "Play 10,000 multiplayer matches"). This leads to player burnout and frustration rather than a sense of fun or accomplishment.
- **Multiplayer Achievements in Single-Player Focused Games**: Forcing players to engage with tacked-on or dead multiplayer modes to achieve a 100% completion rate. This often alienates the core audience who purchased the game for its single-player experience.
- **Missable Achievements**: Creating achievements that can be permanently missed during a standard playthrough without any prior warning, forcing completionists to restart the entire game or reload an old save file just to fulfill a single, obscure requirement.
