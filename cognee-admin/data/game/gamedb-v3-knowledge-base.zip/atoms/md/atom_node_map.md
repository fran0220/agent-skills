# Gameplay Atom: Node Map / Path Selection

## 1. Identity
- **Atom ID:** `atom_node_map`
- **English Name:** Node Map / Path Selection
- **Chinese Name:** 节点地图/路径选择
- **Category:** G/H (Progression / World Structure)
- **Definition:** A structural progression system where players navigate through a network of interconnected nodes, each representing a distinct encounter, event, or reward. Players must make strategic pathing decisions, balancing risk and reward, as they move forward through the map, typically with no option to backtrack.

## 2. Core Verb & State Machine
**Core Verb:** Select Path / Navigate

**State Diagram:**
[Idle] --> (Select Node) --> [Moving] --> (Arrive at Node) --> [Encounter] --> (Resolve Encounter) --> [Idle]

**States and Transitions:**
- **Idle:** The player is viewing the map and evaluating potential paths.
- **Moving:** The player has selected a valid adjacent node and is transitioning to it.
- **Encounter:** The player is engaged in the gameplay event associated with the node (e.g., combat, shop, event).
- **Transitions:**
  - *Idle -> Moving:* Triggered when the player clicks/selects an accessible forward node.
  - *Moving -> Encounter:* Triggered automatically upon reaching the node.
  - *Encounter -> Idle:* Triggered when the encounter is successfully resolved or bypassed.

## 3. MDA Analysis
- **Mechanics:** The system generates a directed acyclic graph (DAG) of nodes. Each node has a specific type (e.g., Monster, Elite, Rest, Shop). The player starts at the bottom/beginning and must choose a connected path to reach the boss/end.
- **Dynamics:** Players engage in long-term planning and risk assessment. They might route towards Elites for better rewards if their health is high, or path towards Rest sites if they are in danger. The inability to backtrack forces commitment to chosen paths.
- **Aesthetics:** Elicits feelings of anticipation, strategic satisfaction, and tension. The player feels a sense of agency in shaping their journey, mixed with the suspense of unknown or challenging upcoming nodes.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Game) | Unit |
|---|---|---|---|---|
| `num_layers` | u32 | 10 - 20 | 15 (Slay the Spire v2.2) | layers |
| `nodes_per_layer` | u32 | 3 - 7 | 5 (Slay the Spire v2.2) | nodes |
| `branching_factor` | f32 | 1.2 - 2.5 | 1.5 (FTL v1.6) | paths/node |
| `elite_density` | f32 | 0.05 - 0.20 | 0.12 (Slay the Spire v2.2) | ratio |
| `shop_density` | f32 | 0.05 - 0.15 | 0.08 (Slay the Spire v2.2) | ratio |

## 5. Benchmark Data
- **Slay the Spire (v2.2):**
  - `num_layers`: 15
  - `nodes_per_layer`: 5 (average width)
  - `elite_density`: 0.12
  - `shop_density`: 0.08
- **FTL: Faster Than Light (v1.6):**
  - `num_layers`: 8 (sectors)
  - `nodes_per_layer`: ~15-20 (beacons per sector)
  - `branching_factor`: 2.5 (highly interconnected)

## 6. Common Variants
1. **Hidden Nodes:** The types of upcoming nodes are obscured (e.g., fog of war) until the player is adjacent to them.
2. **Free Movement:** Players can move back and forth between connected nodes, often limited by a resource (e.g., fuel in FTL).
3. **Branching Paths with Keys:** Certain paths are locked and require specific items or conditions met earlier in the run to access.
4. **Dynamic Maps:** The map topology changes based on player actions or time elapsed (e.g., nodes disappearing or changing type).

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_roguelike_permadeath`, `atom_random_encounter`, `atom_resource_management`, `atom_deck_building`.
- **Incompatible Atoms:** `atom_open_world_exploration` (Node maps are inherently restrictive and structured, conflicting with free-roam open worlds).

## 8. Anti-Patterns
1. **Illusion of Choice:** Creating maps where all paths effectively lead to the same outcomes or where one path is mathematically always superior, removing meaningful decision-making.
2. **Excessive Dead Ends:** Designing maps where players can easily trap themselves without a path forward, leading to frustrating run-ending situations.
3. **Information Overload:** Displaying too many nodes or overly complex connections that make it difficult for the player to parse potential routes.
