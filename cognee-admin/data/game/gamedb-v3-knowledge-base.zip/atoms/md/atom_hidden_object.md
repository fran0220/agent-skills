# Gameplay Atom: Hidden Object Search

## 1. Identity
- **Atom ID:** atom_hidden_object
- **English Name:** Hidden Object Search
- **Chinese Name:** 隐藏物品搜索
- **Category:** C
- **Definition:** A gameplay mechanic where the player must visually scan a complex environment to locate and select specific target objects hidden among distractors.

## 2. Core Verb & State Machine
- **Core Verb:** Search / Find / Select
- **State Diagram:**
  [Idle] -> (Player Scans) -> [Searching]
  [Searching] -> (Player Clicks Target) -> [Found]
  [Searching] -> (Player Clicks Distractor) -> [Penalty/Miss]
  [Found] -> (All Targets Found) -> [Completed]
  [Found] -> (More Targets Remain) -> [Searching]
- **States:**
  - `Idle`: The level is loaded, waiting for player input.
  - `Searching`: The player is actively looking for objects.
  - `Found`: A target object has been successfully identified and selected.
  - `Penalty`: The player selected an incorrect object, triggering a brief timeout or score reduction.
  - `Completed`: All required objects have been found.
- **Transitions:**
  - `Idle` to `Searching`: Automatic upon level start.
  - `Searching` to `Found`: Triggered by clicking a valid target's hitbox.
  - `Searching` to `Penalty`: Triggered by clicking outside any valid target hitbox.
  - `Found` to `Searching`: Automatic after target collection animation.
  - `Found` to `Completed`: Triggered when the `targets_found` count equals `total_targets`.

## 3. MDA Analysis
- **Mechanics:** The system populates a scene with a set of target objects and numerous distractor objects. It tracks the player's cursor/tap inputs, comparing them against the hitboxes of the target objects. It maintains a list of remaining targets and may implement a hint system with a cooldown.
- **Dynamics:** Players develop scanning strategies (e.g., grid search, edge-first, color-matching). Time pressure or penalty mechanics discourage random clicking (spamming) and encourage deliberate observation. The use of hints introduces resource management.
- **Aesthetics:** 
  - *Discovery:* The satisfying "aha!" moment when a camouflaged object is finally spotted.
  - *Challenge:* The cognitive load of filtering out visual noise.
  - *Relaxation:* In untimed modes, a zen-like state of flow while observing detailed art.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Hidden Folks v1.0) | Unit |
| :--- | :--- | :--- | :--- | :--- |
| `total_targets` | u32 | 5 - 30 | 15 | objects |
| `hitbox_margin` | f32 | 1.0 - 5.0 | 2.0 | pixels |
| `penalty_cooldown` | f32 | 0.0 - 5.0 | 0.0 | seconds |
| `hint_cooldown` | f32 | 10.0 - 120.0 | 30.0 | seconds |
| `zoom_levels` | u32 | 1 - 5 | 3 | levels |
| `distractor_density` | f32 | 0.1 - 0.9 | 0.7 | ratio |

## 5. Benchmark Data
- **Hidden Folks (v1.0):**
  - `total_targets`: 15
  - `hitbox_margin`: 2.0
  - `penalty_cooldown`: 0.0
  - `hint_cooldown`: 30.0
  - `zoom_levels`: 3
- **I Spy Spooky Mansion (v1.0):**
  - `total_targets`: 10
  - `hitbox_margin`: 5.0
  - `penalty_cooldown`: 0.0
  - `hint_cooldown`: 60.0
  - `zoom_levels`: 1

## 6. Common Variants
1. **Time Attack:** Players must find as many objects as possible within a strict time limit.
2. **Silhouette Matching:** Targets are shown only as silhouettes rather than full-color images.
3. **Difference Finding:** A variant where the player compares two nearly identical scenes to find missing or altered objects.
4. **Interactive Environments:** Objects are hidden behind or inside other objects that must be clicked to open/move (e.g., opening a tent in Hidden Folks).
5. **Word List:** Targets are given as text words instead of visual icons.

## 7. Compatibility Notes
- **Compatible Atoms:**
  - `atom_zoom_pan`: Essential for navigating large, detailed scenes.
  - `atom_hint_system`: Provides a fallback for frustrated players.
  - `atom_timer`: Adds pressure for competitive or arcade variants.
- **Incompatible Atoms:**
  - `atom_fast_paced_combat`: The slow, deliberate nature of hidden object search conflicts with high-action mechanics.
  - `atom_procedural_generation`: Purely random placement often leads to unfair or impossible hiding spots, breaking the crafted illusion.

## 8. Anti-Patterns
1. **Pixel Hunting:** Making the target hitboxes too small or exact, requiring the player to click precisely on a tiny area rather than the general object.
2. **Color Mismatch:** Hiding objects by simply tinting them to match the background in a way that feels cheap rather than clever.
3. **Lack of Feedback:** Failing to provide clear visual or audio feedback when an object is found or when a penalty is incurred, leaving the player confused about their progress.
