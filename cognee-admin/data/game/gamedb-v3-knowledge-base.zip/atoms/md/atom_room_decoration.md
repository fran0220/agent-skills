# Gameplay Atom: Room / Space Decoration

## 1. Identity
- **Atom ID:** atom_room_decoration
- **English Name:** Room / Space Decoration
- **Chinese Name:** 房间/空间装饰
- **Category:** G/H (Simulation / Customization)
- **Definition:** The core gameplay loop of acquiring, placing, arranging, and customizing objects within a defined spatial boundary to achieve aesthetic, functional, or systemic goals.

## 2. Core Verb & State Machine
- **Core Verb:** Decorate / Arrange
- **State Diagram:**
  [Idle] -> (Select Object) -> [Holding Object]
  [Holding Object] -> (Move/Rotate) -> [Positioning]
  [Positioning] -> (Confirm Placement) -> [Placed]
  [Placed] -> (Interact/Modify) -> [Holding Object]
  [Placed] -> (Remove) -> [Inventory]

- **States:**
  - `Idle`: Player is navigating the space without an active object.
  - `Holding Object`: Player has selected an object from inventory or the environment.
  - `Positioning`: Player is actively moving or rotating the object to find a valid placement spot.
  - `Placed`: The object is successfully placed in the environment.
  - `Inventory`: The object is stored and not currently in the space.

- **Transitions:**
  - `Idle` -> `Holding Object`: Triggered by selecting an item from inventory or picking up a placed item.
  - `Holding Object` -> `Positioning`: Triggered by moving the cursor or character.
  - `Positioning` -> `Placed`: Triggered by confirming placement in a valid location.
  - `Placed` -> `Holding Object`: Triggered by selecting a placed item to move it.
  - `Placed` -> `Inventory`: Triggered by choosing to store the item.

## 3. MDA Analysis
- **Mechanics:** Grid-based or freeform placement systems, collision detection, object snapping, rotation matrices, and spatial scoring (e.g., Feng Shui, environment score).
- **Dynamics:** Players optimize their space for both aesthetic appeal and functional efficiency (e.g., pathing for NPCs, maximizing score within a limited area).
- **Aesthetics:** Expression (self-expression through design), Discovery (finding new items), and Submission (relaxing activity).

## 4. Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value (Game) | Unit |
|---|---|---|---|---|
| `grid_size` | f32 | 0.1 - 1.0 | 0.5 (Animal Crossing: NH v1.0) | meters |
| `max_objects` | u32 | 50 - 1000 | 200 (The Sims 4 v1.90) | count |
| `rotation_steps` | u32 | 4 - 360 | 4 (Animal Crossing: NH v1.0) | degrees/step |
| `placement_radius` | f32 | 1.0 - 10.0 | 5.0 (The Sims 4 v1.90) | meters |

## 5. Benchmark Data
- **Animal Crossing: New Horizons (v1.0):**
  - `grid_size`: 0.5 meters (half-tile)
  - `rotation_steps`: 4 (90-degree increments)
  - `max_objects`: 200 per room
- **The Sims 4 (v1.90):**
  - `grid_size`: 0.25 meters (quarter-tile, with free placement option)
  - `rotation_steps`: 8 (45-degree increments, or free rotation)
  - `max_objects`: 500

## 6. Common Variants
1. **Grid-Locked Placement:** Objects snap strictly to a coarse grid (e.g., classic Animal Crossing).
2. **Freeform Placement:** Objects can be placed anywhere with pixel-perfect precision, often with optional grid snapping (e.g., The Sims 4).
3. **Slot-Based Placement:** Objects can only be placed in specific predefined slots on other objects (e.g., placing a lamp on a table).
4. **Physics-Based Placement:** Objects are dropped into the world and settle based on physics (e.g., Skyrim).

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_inventory_management`, `atom_crafting`, `atom_npc_pathfinding`, `atom_economy`.
- **Incompatible Atoms:** `atom_fast_paced_combat` (complex decoration mechanics often disrupt high-speed action flows).

## 8. Anti-Patterns
1. **Overly Restrictive Collisions:** Making bounding boxes too large, preventing players from placing objects visually close to each other.
2. **Lack of Undo/Redo:** Forcing players to manually revert complex arrangements if they make a mistake.
3. **Clunky Camera Controls:** Failing to provide adequate camera angles (e.g., top-down or isometric views) during the decoration phase, making depth perception difficult.
