# Board Movement (Dice) - 棋盘移动(掷骰)

## 1. Identity
- **Atom ID**: atom_board_movement
- **English Name**: Board Movement (Dice)
- **Chinese Name**: 棋盘移动(掷骰)
- **Category**: G
- **Definition**: A core gameplay mechanic where a player's progression along a predefined path or grid is determined by generating a random number, typically through rolling one or more dice.

## 2. Core Verb & State Machine
- **Core Verb**: Roll & Move
- **State Diagram**:
  [Idle] -> (Roll Dice) -> [Rolling] -> (Result Determined) -> [Moving] -> (Reach Destination) -> [Action/Event] -> (End Turn) -> [Idle]
- **States**:
  - `Idle`: Waiting for the player to initiate the roll.
  - `Rolling`: The dice are currently in motion or the random number is being generated.
  - `Moving`: The player piece is advancing along the board based on the roll result.
  - `Action/Event`: The player resolves the effect of the landed space.
- **Transitions**:
  - `Idle` to `Rolling`: Triggered by player input (e.g., pressing a button).
  - `Rolling` to `Moving`: Triggered by the dice settling on a value.
  - `Moving` to `Action/Event`: Triggered by the piece reaching the target space.
  - `Action/Event` to `Idle`: Triggered by the completion of the space's effect.

## 3. MDA Analysis
- **Mechanics**: The system generates a random integer within a specific range (e.g., 1-6) and advances the player's token by that exact number of spaces on a structured board.
- **Dynamics**: Players experience variable progression rates, leading to clustering, overtaking, and unpredictable encounters with board hazards or rewards.
- **Aesthetics**: Creates feelings of anticipation, excitement, luck-based tension, and sometimes frustration when missing a desired target space.

## 4. Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value | Unit |
|---|---|---|---|---|
| `dice_count` | u32 | 1-3 | 1 (Mario Party Superstars v1.1.1) | dice |
| `faces_per_die` | u32 | 4-10 | 6 (Monopoly Classic) | faces |
| `move_speed` | f32 | 1.0-5.0 | 2.5 (Mario Party Superstars v1.1.1) | spaces/sec |
| `base_modifier` | i32 | -5 to +5 | 0 (Monopoly Classic) | spaces |

## 5. Benchmark Data
- **Mario Party Superstars (v1.1.1)**:
  - `dice_count`: 1
  - `faces_per_die`: 10 (Custom dice block 1-10)
  - `move_speed`: 2.5 spaces/sec
- **Monopoly (Classic Edition)**:
  - `dice_count`: 2
  - `faces_per_die`: 6
  - `base_modifier`: 0

## 6. Common Variants
1. **Custom Dice Blocks**: Dice with non-standard numbers (e.g., 0, 1, 1, 2, 3, 3) to alter probability distributions.
2. **Drafting Movement**: Rolling multiple dice and choosing which one to use for movement.
3. **Action Point Movement**: Dice roll determines action points, which can be spent on movement or other actions.
4. **Card-Driven Movement**: Using a deck of cards with movement values instead of dice to reduce pure randomness.

## 7. Compatibility Notes
- **Compatible Atoms**: `atom_space_event` (triggering effects upon landing), `atom_branching_path` (choosing directions at intersections).
- **Incompatible Atoms**: `atom_continuous_movement` (real-time physics-based movement conflicts with discrete grid steps).

## 8. Anti-Patterns
1. **Excessive Randomness**: Relying solely on dice rolls without any mitigation mechanics (like items or custom dice), leading to a lack of player agency.
2. **Overly Long Animations**: Making the dice rolling and piece moving animations too slow, which bogs down the pacing of the game.
3. **Meaningless Choices**: Presenting branching paths where the outcome is entirely dependent on a subsequent random roll rather than strategic planning.
