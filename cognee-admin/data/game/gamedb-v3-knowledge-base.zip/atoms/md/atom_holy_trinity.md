# Gameplay Atom: Holy Trinity (Tank/Heal/DPS)

## 1. Identity
- **Atom ID:** atom_holy_trinity
- **English Name:** Holy Trinity (Tank/Heal/DPS)
- **Chinese Name:** 神圣三角
- **Category:** E
- **Definition:** The Holy Trinity is a foundational multiplayer role-playing game design paradigm that divides player responsibilities into three distinct and interdependent roles: Tank (absorbs damage and manages enemy aggression), Healer (restores health and mitigates incoming damage), and Damage Dealer or DPS (inflicts the majority of damage to defeat enemies). This division of labor forces cooperation, as no single role can efficiently overcome challenges designed for the trinity without the support of the others.

## 2. Core Verb & State Machine
- **Core Verb:** Cooperate / Fulfill Role

**State Diagram (Text):**
[Idle] --> (Engage Combat) --> [Combat Active]
[Combat Active] --> (Tank loses aggro) --> [Chaos/Wipe Risk]
[Chaos/Wipe Risk] --> (Tank regains aggro) --> [Combat Active]
[Combat Active] --> (Health drops) --> [Healing Required]
[Healing Required] --> (Healer casts spell) --> [Combat Active]
[Combat Active] --> (Enemy HP reaches 0) --> [Victory]
[Combat Active] --> (Party HP reaches 0) --> [Defeat]

**States:**
- `Idle`: Party is out of combat, preparing.
- `Combat Active`: The standard flow where Tank holds aggro, DPS deals damage, and Healer maintains party health.
- `Chaos/Wipe Risk`: Aggro is lost, enemies attack non-Tanks.
- `Healing Required`: Party members are taking damage and need restoration.
- `Victory`: Encounter successfully completed.
- `Defeat`: Entire party is incapacitated.

**Transitions:**
- `Idle` -> `Combat Active`: Triggered by pulling the boss or entering aggro radius.
- `Combat Active` -> `Chaos/Wipe Risk`: Triggered when Tank's threat level is surpassed by a DPS or Healer.
- `Chaos/Wipe Risk` -> `Combat Active`: Triggered by Tank using a taunt or generating sufficient threat.
- `Combat Active` -> `Healing Required`: Triggered by enemy attacks reducing player HP.
- `Healing Required` -> `Combat Active`: Triggered by Healer restoring HP to safe thresholds.
- `Combat Active` -> `Victory`: Triggered by enemy HP reaching zero.
- `Combat Active` -> `Defeat`: Triggered by all party members dying.

## 3. MDA Analysis
- **Mechanics:** The system utilizes a "Threat" or "Aggro" metric where enemies target the player with the highest threat. Tanks have high threat multipliers and defensive stats. Healers have abilities that restore HP but generate moderate threat. DPS have high damage output but low defensive capabilities and moderate threat generation.
- **Dynamics:** Players must constantly monitor their specific metrics (Tank: Threat and Mitigation; Healer: Mana and Party HP; DPS: Damage output and Threat limits). This creates a dynamic where DPS must sometimes throttle their damage to avoid pulling aggro, while Healers must triage who to heal first during heavy damage phases.
- **Aesthetics:** Fosters a strong sense of camaraderie, fellowship, and interdependence. Players feel a specialized mastery over their chosen role and experience the satisfaction of a well-oiled machine when the group coordinates perfectly.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Game) | Unit |
|---|---|---|---|---|
| `tank_threat_multiplier` | f32 | 2.0 - 10.0 | 10.0 (WoW v10.0) | Multiplier |
| `taunt_duration` | f32 | 3.0 - 15.0 | 3.0 (FFXIV v6.0) | Seconds |
| `healer_threat_ratio` | f32 | 0.2 - 0.5 | 0.5 (WoW v10.0) | Threat per Healing |
| `dps_threat_ratio` | f32 | 0.8 - 1.0 | 1.0 (ESO v8.0) | Threat per Damage |
| `tank_mitigation_base` | f32 | 0.2 - 0.5 | 0.3 (FFXIV v6.0) | % Damage Reduction |

## 5. Benchmark Data
- **World of Warcraft (v10.0):**
  - `tank_threat_multiplier`: 10.0 (Tanks generate significantly more threat to easily hold aggro against burst DPS).
  - `healer_threat_ratio`: 0.5 (Healing generates half the threat of damage to prevent healers from easily pulling aggro).
- **Final Fantasy XIV (v6.0):**
  - `tank_threat_multiplier`: 10.0 (Tank stance massively increases enmity generation).
  - `taunt_duration`: 3.0 seconds (Provoke places the tank at the top of the enmity list).
- **Elder Scrolls Online (v8.0):**
  - `taunt_duration`: 15.0 seconds (Puncture forces the enemy to attack the tank for 15 seconds, a different approach than pure threat values).

## 6. Common Variants
1. **Soft Trinity:** Games like *Guild Wars 2* where roles exist but are fluid; every class has self-healing and mitigation, blurring the strict lines of the traditional trinity.
2. **Action Trinity:** Games like *Monster Hunter* where there is no explicit aggro system, but players naturally adopt roles based on weapon types (e.g., Lance as a pseudo-tank, Hunting Horn as a support/buffer).
3. **Quad-Role System:** Adding a dedicated "Support" or "Controller" role (e.g., *EverQuest* Enchanter or *City of Heroes* Controller) focused on crowd control and buffs rather than direct healing or damage.
4. **Asymmetric Trinity:** Where the ratio is not 1:1:1. For example, standard MMO dungeons often use 1 Tank, 1 Healer, and 3 DPS.

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_aggro_system` (Threat management), `atom_health_pool` (HP tracking), `atom_cooldown_management` (Ability pacing), `atom_party_buffs` (Synergy).
- **Incompatible Atoms:** `atom_solo_scaling` (Mechanics designed purely for single-player balance often break when strict roles are introduced), `atom_universal_self_sustain` (If everyone can heal themselves fully, the Healer role becomes obsolete).

## 8. Anti-Patterns
1. **The God Tank:** Making the Tank so durable and self-sufficient that they do not need a Healer, breaking the interdependence.
2. **Threat Irrelevance:** Making threat generation so trivial that DPS never have to manage their output, removing a layer of dynamic gameplay.
3. **Healer as DPS:** Designing encounters with such low incoming damage that Healers spend 90% of their time acting as sub-par DPS, leading to role dissatisfaction.
