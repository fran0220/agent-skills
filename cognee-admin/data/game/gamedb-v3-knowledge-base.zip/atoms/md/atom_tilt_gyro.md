# Identity
- **Atom ID**: atom_tilt_gyro
- **English Name**: Tilt / Gyroscope
- **Chinese Name**: 倾斜/陀螺仪
- **Category**: G/H
- **Definition**: A control mechanism that translates the physical rotation, tilt, or orientation of the input device into in-game actions, commonly used for steering or precise aiming.

# Core Verb & State Machine
- **Core Verb**: Tilt
- **State Diagram**:
  [Idle] --(Device tilted)--> [Tilting]
  [Tilting] --(Device returned to neutral)--> [Idle]
  [Tilting] --(Tilt exceeds threshold)--> [Max Tilt]
  [Max Tilt] --(Tilt reduced)--> [Tilting]

# MDA Analysis
- **Mechanics**: The system reads gyroscope and accelerometer data to calculate the device's pitch, yaw, and roll. These values are mapped to in-game variables like camera rotation or vehicle steering angle, often with deadzones and sensitivity curves applied.
- **Dynamics**: Players physically move their controllers or devices, leading to a more embodied and intuitive control scheme. It allows for micro-adjustments that are difficult with traditional analog sticks.
- **Aesthetics**: Creates a sense of immersion and physical connection to the game world. It can feel highly rewarding when mastered, though it may cause fatigue over long sessions.

# Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value | Unit |
|---|---|---|---|---|
| sensitivity_x | f32 | 0.1 - 10.0 | 1.5 (Splatoon 3) | multiplier |
| sensitivity_y | f32 | 0.1 - 10.0 | 1.5 (Splatoon 3) | multiplier |
| deadzone | f32 | 0.0 - 0.2 | 0.05 (Mario Kart 8) | radians |
| smoothing_factor | f32 | 0.0 - 1.0 | 0.8 (PUBG Mobile) | ratio |
| max_angle | f32 | 30.0 - 90.0 | 45.0 (Real Racing 3) | degrees |

# Benchmark Data
- **Splatoon 3 (v1.0.0)**: sensitivity_x = 1.5, sensitivity_y = 1.5, deadzone = 0.02
- **Mario Kart 8 Deluxe (v2.1.0)**: sensitivity_x = 1.0, deadzone = 0.05, max_angle = 45.0
- **PUBG Mobile (v2.5.0)**: sensitivity_x = 2.0, sensitivity_y = 2.0, smoothing_factor = 0.8

# Common Variants
1. **Aim Assist Gyro**: Gyroscope is only active when the player is aiming down sights (ADS).
2. **Steering Wheel Gyro**: Device is held horizontally and rotated like a steering wheel.
3. **Flick Stick + Gyro**: Right stick is used for macro turns, while gyro handles all vertical and micro horizontal aiming.
4. **Always-On Gyro**: Gyroscope is constantly active for camera control.

# Compatibility Notes
- **Compatible Atoms**: atom_analog_stick, atom_aim_assist, atom_vehicle_steering.
- **Incompatible Atoms**: atom_mouse_aim.

# Anti-Patterns
1. **Lack of Recenter Button**: Failing to provide a quick way to reset the neutral position, leading to awkward hand contortions.
2. **No Deadzone Configuration**: Forcing a strict 0 deadzone which causes jitter from natural hand tremors.
3. **Forced Gyro**: Not allowing players to disable gyro controls, alienating those with accessibility needs or motion sickness.
