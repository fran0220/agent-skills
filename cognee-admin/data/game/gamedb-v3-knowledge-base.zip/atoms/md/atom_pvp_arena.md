# PvP Arena / Duel (PvP竞技场/决斗)

## 1. Identity
- **Atom ID:** `atom_pvp_arena`
- **English Name:** PvP Arena / Duel
- **Chinese Name:** PvP竞技场/决斗
- **Category:** E/F (Multiplayer / Combat)
- **Definition:** A structured, instanced, or localized environment where two or more players engage in direct combat against each other under a specific set of rules, usually with clear win/loss conditions and rewards.

## 2. Core Verb & State Machine
- **Core Verb:** "Duel" / "Compete"

**State Diagram:**
```text
[Idle] --> (Queue/Challenge) --> [Matchmaking/Waiting]
[Matchmaking/Waiting] --> (Match Found/Accepted) --> [Preparation]
[Preparation] --> (Countdown Ends) --> [Combat]
[Combat] --> (Player Defeated/Time Out) --> [Resolution]
[Resolution] --> (Rewards Distributed) --> [Idle]
```

**States and Transitions:**
- **Idle:** Player is outside the arena.
- **Matchmaking/Waiting:** Player has initiated a challenge or queued for an arena match.
- **Preparation:** Players are loaded into the arena, waiting for the match to start.
- **Combat:** Active engagement between players.
- **Resolution:** Match has concluded, determining the winner and loser.

## 3. MDA Analysis
- **Mechanics:** The system matches players, isolates them in a bounded environment, tracks health/score, enforces a time limit, and determines a victor based on predefined rules (e.g., last man standing, most kills).
- **Dynamics:** Players develop meta-strategies, counter-builds, and psychological mind games (yomi). Positioning, resource management (cooldowns, stamina), and timing become critical.
- **Aesthetics:** Competition, Challenge, Fellowship (in team arenas), and Expression (through unique builds and playstyles).

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Game) | Unit |
|---|---|---|---|---|
| `time_limit` | `u32` | 60 - 600 | 300 (WoW v10.0) | seconds |
| `arena_radius` | `f32` | 10.0 - 100.0 | 30.0 (Dark Souls 3 v1.15) | meters |
| `max_players` | `u32` | 2 - 10 | 6 (WoW 3v3 Arena) | count |
| `preparation_time` | `u32` | 5 - 60 | 45 (WoW v10.0) | seconds |
| `healing_reduction` | `f32` | 0.0 - 1.0 | 0.1 (WoW Dampening) | multiplier/min |

## 5. Benchmark Data
- **World of Warcraft (v10.0):**
  - `time_limit`: 1200 seconds (20 minutes, though dampening usually ends it faster)
  - `preparation_time`: 45 seconds
  - `max_players`: 6 (for 3v3)
  - `healing_reduction`: Starts at 0% or 10% depending on bracket, increases over time (Dampening).
- **Dark Souls 3 (v1.15 - Undead Match):**
  - `time_limit`: 180 seconds (Duel)
  - `preparation_time`: 5 seconds
  - `max_players`: 2 (Duel)
  - `healing_reduction`: Estus Flasks are disabled (1.0 reduction for primary healing).

## 6. Common Variants
1. **1v1 Duel:** Pure test of individual skill and build (e.g., Dark Souls, Fighting Games).
2. **Team Arena (2v2, 3v3):** Introduces team synergy, cross-crowd control, and support roles (e.g., WoW Arenas, Battlerite).
3. **Round-Based Arena:** Match is divided into multiple rounds, first to X wins (e.g., CS:GO Wingman, Fighting Games).
4. **Asymmetrical Arena:** One powerful player vs multiple weaker players (e.g., Boss mode in some fighting games).
5. **Free-for-All (Deathmatch):** Multiple players, no teams, highest score wins.

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_health_pool`, `atom_cooldown_system`, `atom_matchmaking_rating` (MMR), `atom_crowd_control`.
- **Incompatible Atoms:** `atom_permadeath` (usually disabled or heavily modified in arenas to prevent extreme frustration), `atom_infinite_respawn` (conflicts with round-based or elimination formats).

## 8. Anti-Patterns
1. **Stalemate Design:** Lack of a tie-breaker or dampening mechanic leading to infinitely long matches (e.g., two healers fighting).
2. **Line-of-Sight (LoS) Abuse:** Arena geometry that allows players to infinitely kite without counterplay.
3. **Snowballing Advantages:** Giving the first player to land a hit an insurmountable advantage, reducing the chance for comebacks.
