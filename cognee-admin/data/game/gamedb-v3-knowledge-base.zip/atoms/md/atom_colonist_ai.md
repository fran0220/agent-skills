# Gameplay Atom: Colonist AI / Needs

## 1. Identity
- **Atom ID:** atom_colonist_ai
- **English Name:** Colonist AI / Needs
- **Chinese Name:** 殖民者AI/需求
- **Category:** G (Simulation & AI)
- **Definition:** The Colonist AI / Needs atom defines the autonomous behavior of individual agents (colonists) driven by a set of internal physiological and psychological needs. These agents evaluate their environment, prioritize tasks based on their current needs (e.g., hunger, sleep, recreation), and execute actions to satisfy those needs while contributing to the overall goals of the colony.

## 2. Core Verb & State Machine
- **Core Verb:** Manage / Prioritize (Player indirectly manages colonists by setting schedules, priorities, and building facilities).

**State Diagram:**
```text
[Idle] --> (Need threshold crossed) --> [Seeking Satisfaction]
[Seeking Satisfaction] --> (Path found) --> [Moving to Target]
[Moving to Target] --> (Arrived) --> [Consuming/Interacting]
[Consuming/Interacting] --> (Need satisfied) --> [Idle]
[Idle] --> (Work available & Needs met) --> [Working]
[Working] --> (Task complete) --> [Idle]
[Working] --> (Need becomes critical) --> [Seeking Satisfaction]
[Any State] --> (Extreme negative mood) --> [Mental Break]
[Mental Break] --> (Duration ends / Intervention) --> [Idle]
```

**States:**
- `Idle`: The colonist has no immediate critical needs and no assigned work.
- `Seeking Satisfaction`: The colonist is looking for a way to fulfill a specific need (e.g., finding food).
- `Moving to Target`: The colonist is navigating to the location of the need-fulfilling object.
- `Consuming/Interacting`: The colonist is actively fulfilling the need (e.g., eating, sleeping).
- `Working`: The colonist is performing an assigned colony task.
- `Mental Break`: The colonist has lost control due to unmet needs and acts unpredictably.

**Transitions:**
- `Idle` -> `Seeking Satisfaction`: Triggered when a need value drops below a specific threshold.
- `Seeking Satisfaction` -> `Moving to Target`: Triggered when a valid target is identified.
- `Moving to Target` -> `Consuming/Interacting`: Triggered upon reaching the target's interaction range.
- `Consuming/Interacting` -> `Idle`: Triggered when the need is sufficiently restored.
- `Idle` -> `Working`: Triggered when work is available and needs are above critical thresholds.
- `Working` -> `Seeking Satisfaction`: Triggered when a need becomes critical, interrupting work.
- `Any State` -> `Mental Break`: Triggered when overall mood/needs fall below the breakdown threshold.
- `Mental Break` -> `Idle`: Triggered after a set duration or external intervention.

## 3. MDA Analysis
- **Mechanics:** Agents possess multiple continuous variables representing needs (hunger, energy, joy). These variables decay over time. Agents use utility-based AI or behavior trees to select actions that maximize their need fulfillment while balancing assigned work priorities.
- **Dynamics:** The interplay of decaying needs and limited resources creates a constant balancing act. Emergent behaviors arise when multiple colonists compete for the same resources, or when a critical failure (e.g., food shortage) causes a cascading effect of mental breaks and colony collapse.
- **Aesthetics:** Players experience a sense of responsibility and empathy for the colonists. The system generates narrative drama (e.g., a colonist going berserk because they ate without a table) and satisfaction when a well-oiled, happy colony is achieved.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Game) | Unit |
| :--- | :--- | :--- | :--- | :--- |
| `hunger_decay_rate` | `f32` | 0.5 - 5.0 | 1.5 (RimWorld v1.4) | points/hour |
| `max_energy` | `f32` | 50.0 - 200.0 | 100.0 (RimWorld v1.4) | points |
| `sleep_restore_rate` | `f32` | 5.0 - 20.0 | 12.0 (RimWorld v1.4) | points/hour |
| `mental_break_threshold` | `f32` | 0.0 - 0.5 | 0.35 (RimWorld v1.4) | ratio (0-1) |
| `work_priority_weight` | `f32` | 0.1 - 10.0 | 1.0 (Dwarf Fortress v50) | multiplier |

## 5. Benchmark Data
- **RimWorld (v1.4):**
  - `hunger_decay_rate`: 1.5 points per in-game hour.
  - `max_energy`: 100.0 points.
  - `sleep_restore_rate`: 12.0 points per hour (varies by bed quality).
  - `mental_break_threshold`: 0.35 (Minor break threshold).
- **Dwarf Fortress (v50):**
  - Needs are more complex and tied to personality, but a baseline `work_priority_weight` of 1.0 is used for standard tasks, modified heavily by individual dwarf preferences and stress levels. Stress decay is roughly 10.0 points per day in optimal conditions.

## 6. Common Variants
1. **Maslow's Hierarchy Model:** Needs must be fulfilled in a strict order (e.g., food before entertainment). Seen in games like *The Sims*.
2. **Stress-Centric Model:** Instead of multiple needs, everything feeds into a single "Stress" or "Sanity" meter. Seen in *Oxygen Not Included* (early access) or *Don't Starve*.
3. **Trait-Modified Needs:** Colonists have traits that drastically alter need decay rates (e.g., a "Glutton" trait doubles hunger decay). Common in *RimWorld*.
4. **Group Needs:** Needs are calculated for the colony as a whole rather than individuals (e.g., overall colony morale). Seen in simpler city builders like *Banished*.

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_resource_management` (Needs consume resources), `atom_task_scheduling` (Work must be balanced with needs), `atom_base_building` (Facilities are required to fulfill needs).
- **Incompatible Atoms:** `atom_direct_unit_control` (RTS-style direct control conflicts with autonomous need-seeking behavior).

## 8. Anti-Patterns
1. **Death Spiral:** Making need penalties too severe, causing a minor issue (e.g., one missed meal) to trigger a mental break, which stops work, leading to more missed meals and inevitable colony wipe.
2. **Ping-Ponging:** Agents constantly switching between working and fulfilling needs because the "satisfied" threshold is too close to the "seeking" threshold, resulting in wasted travel time.
3. **Opaque Needs:** Hiding need values or causes of negative mood from the player, making it impossible for them to diagnose and fix colony issues.
