# Gameplay Atom: Spaced Repetition

## 1. Identity
- **Atom ID:** `atom_spaced_repetition`
- **English Name:** Spaced Repetition
- **Chinese Name:** 间隔重复
- **Category:** H (Habit & Progression)
- **Definition:** Spaced Repetition is a gameplay and learning mechanic where players are prompted to review or practice specific content (such as vocabulary, skills, or trivia) at increasing intervals of time. This leverages the psychological spacing effect to improve long-term retention and mastery, often used in educational games or skill-based progression systems.

## 2. Core Verb & State Machine
- **Core Verb:** Review / Practice

**State Diagram:**
```text
[Unseen] --> (First Encounter) --> [Learning]
[Learning] --> (Successful Review) --> [Reviewing (Short Interval)]
[Learning] --> (Failed Review) --> [Learning]
[Reviewing] --> (Successful Review) --> [Reviewing (Longer Interval)]
[Reviewing] --> (Failed Review) --> [Learning / Short Interval]
[Reviewing] --> (Max Interval Reached) --> [Mastered]
```

**States:**
- `Unseen`: The content has not been introduced to the player yet.
- `Learning`: The player is currently trying to memorize or master the content.
- `Reviewing`: The content is in the spaced repetition queue, waiting for the next review time.
- `Mastered`: The content is considered fully learned and requires very infrequent or no further reviews.

**Transitions:**
- `Unseen` -> `Learning`: Triggered by the player encountering the content for the first time.
- `Learning` -> `Reviewing`: Triggered by a successful initial recall or practice.
- `Reviewing` -> `Reviewing`: Triggered by a successful review, increasing the interval.
- `Reviewing` -> `Learning`: Triggered by a failed review, resetting or decreasing the interval.
- `Reviewing` -> `Mastered`: Triggered when the review interval exceeds a predefined maximum threshold.

## 3. MDA Analysis
- **Mechanics:** The system tracks the player's performance on specific items and schedules future reviews based on an algorithm (e.g., SuperMemo-2). Correct answers increase the time until the next review, while incorrect answers decrease it.
- **Dynamics:** Players develop a daily or regular habit of logging in to clear their review queues. The difficulty dynamically adjusts to the player's memory retention, ensuring they are challenged just enough to reinforce learning without becoming overwhelmed.
- **Aesthetics:** Players experience a sense of progression, mastery, and satisfaction as they see their knowledge base grow and their review intervals lengthen. It creates a feeling of productive engagement.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Game) | Unit |
| --- | --- | --- | --- | --- |
| `initial_interval` | `f32` | 1.0 - 24.0 | 24.0 (Anki v2.1) | Hours |
| `interval_modifier` | `f32` | 1.2 - 3.0 | 2.5 (Anki v2.1) | Multiplier |
| `easy_bonus` | `f32` | 1.0 - 2.0 | 1.3 (Anki v2.1) | Multiplier |
| `hard_penalty` | `f32` | 0.1 - 0.8 | 0.5 (Anki v2.1) | Multiplier |
| `max_interval` | `f32` | 30.0 - 36500.0 | 36500.0 (Anki v2.1) | Days |

## 5. Benchmark Data
- **Anki (v2.1):**
  - `initial_interval`: 1 day (24 hours) for the first successful review.
  - `interval_modifier` (Ease Factor): Starts at 2.5.
  - `easy_bonus`: 1.3 multiplier applied to the interval if the user marks the review as "Easy".
- **Duolingo (v5.0):**
  - Uses a proprietary half-life regression model, but effectively translates to:
  - `initial_interval`: ~12-24 hours.
  - `decay_rate`: Varies based on word complexity and user history.

## 6. Common Variants
1. **Leitner System (Flashcard Boxes):** Items are moved between physical or virtual boxes based on success/failure. Each box has a fixed review interval (e.g., Box 1 = daily, Box 2 = every 3 days).
2. **SuperMemo-2 (SM-2):** The classic algorithm using an Ease Factor that adjusts based on the quality of the response (0-5 scale).
3. **Half-Life Regression:** Uses machine learning to predict the probability of recall and schedules reviews when the probability drops below a certain threshold (e.g., Duolingo).
4. **Gamified Streaks:** Ties the spaced repetition directly to a daily streak mechanic, punishing missed days heavily to enforce the habit.

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_daily_quests` (Daily Quests), `atom_streak` (Streaks), `atom_skill_tree` (Skill Trees). Spaced repetition pairs perfectly with daily engagement mechanics.
- **Incompatible Atoms:** `atom_permadeath` (Permadeath), `atom_speedrun` (Speedrunning). Spaced repetition requires long-term, consistent engagement, which conflicts with short, high-stakes, or reset-heavy gameplay loops.

## 8. Anti-Patterns
1. **Review Overload:** Allowing the review queue to grow infinitely without capping daily reviews, leading to player burnout and churn.
2. **Punishing Missed Days Too Harshly:** Resetting all progress if a player misses a day, which discourages them from returning after a break.
3. **Opaque Scheduling:** Not giving players any indication of when an item will appear next, making the system feel random rather than structured.
