# Gameplay Atom: Body Hiding (藏尸)

## 1. Identity
- **Atom ID:** `atom_body_hiding`
- **English Name:** Body Hiding
- **Chinese Name:** 藏尸
- **Category:** A
- **Definition:** The act of picking up, dragging, or carrying an incapacitated or deceased NPC and placing them into a designated container or concealed area to prevent other NPCs from discovering them and triggering an alarm state.

## 2. Core Verb & State Machine
**Core Verb:** Hide Body (Drag/Carry -> Conceal)

**State Machine:**
- `Idle`: The body is resting on the ground, undiscovered.
- `Being_Carried`: The player is actively moving the body.
- `Concealed`: The body is placed inside a hiding spot (e.g., locker, dumpster, tall grass).
- `Discovered`: An NPC has seen the body.

**Transitions:**
- `Idle` -> `Being_Carried`: Player interacts with the body (Grab/Carry).
- `Being_Carried` -> `Idle`: Player drops the body in the open.
- `Being_Carried` -> `Concealed`: Player interacts with a valid hiding spot while carrying the body.
- `Idle` -> `Discovered`: NPC line of sight intersects with the body.
- `Concealed` -> `Discovered`: NPC searches the specific hiding spot (rare, usually scripted or high alert).

## 3. MDA Analysis
**Mechanics:**
The system tracks the position and visibility state of NPC bodies. When a body is in the `Concealed` state, it is removed from the visual detection queries of patrolling AI. The player's movement speed and available actions (e.g., using two-handed weapons) are typically restricted while in the `Being_Carried` state.

**Dynamics:**
Players are forced to evaluate the risk vs. reward of leaving a body in the open versus taking the time to hide it. This creates a tension loop: the longer the player spends moving a body, the higher the chance of a patrolling guard stumbling upon them. It encourages spatial awareness and planning escape routes that include hiding spots.

**Aesthetics:**
Creates feelings of tension, suspense, and ultimately relief or satisfaction when a clean stealth operation is executed. It reinforces the fantasy of being a meticulous, professional infiltrator or assassin.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Hitman 3 v3.10) | Unit |
|---|---|---|---|---|
| `carry_speed_multiplier` | f32 | 0.3 - 0.8 | 0.6 | multiplier |
| `pickup_duration` | f32 | 0.5 - 3.0 | 1.5 | seconds |
| `conceal_duration` | f32 | 1.0 - 4.0 | 2.0 | seconds |
| `container_capacity` | u32 | 1 - 4 | 2 | bodies |
| `noise_radius_drop` | f32 | 0.0 - 10.0 | 3.0 | meters |

## 5. Benchmark Data
- **Hitman 3 (v3.10):**
  - `carry_speed_multiplier`: 0.6
  - `pickup_duration`: 1.5s
  - `conceal_duration`: 2.0s
  - `container_capacity`: 2
  - `noise_radius_drop`: 3.0m
- **Metal Gear Solid V: The Phantom Pain (v1.15):**
  - `carry_speed_multiplier`: 0.7
  - `pickup_duration`: 2.2s (hoisting onto shoulder)
  - `conceal_duration`: 1.8s (dumpster)
  - `container_capacity`: 1 (lockers), 2 (dumpsters)
  - `noise_radius_drop`: 4.5m

## 6. Common Variants
1. **Drag vs. Carry:** Some games only allow dragging (slower, leaves blood trails) while others allow carrying over the shoulder (faster, frees one hand, no trails).
2. **Environmental Concealment:** Hiding bodies in tall grass or shadows rather than hard containers. These bodies can still be discovered if guards walk directly through the area.
3. **Disintegration/Dissolve:** Sci-fi or fantasy games where bodies dissolve automatically or via a specific tool, bypassing the need for physical relocation.
4. **Booby-Trapped Bodies:** Allowing the player to place explosives on a body to kill the guard who comes to investigate.

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_stealth_takedown`, `atom_distraction_throw`, `atom_guard_patrol`, `atom_container_interaction`.
- **Incompatible Atoms:** `atom_fast_paced_arena_combat` (breaks flow), `atom_gore_dismemberment` (complicates what constitutes a "body" to hide).

## 8. Anti-Patterns
1. **Overly Punishing Carry Speeds:** Making the player move so slowly that hiding bodies becomes a tedious chore rather than a tense mechanic.
2. **Unclear Container Limits:** Not visually communicating when a container is full, leading to frustrating moments where the player is caught trying to hide a body in a full locker.
3. **Inconsistent AI Vision:** Guards spotting a "hidden" body because a small polygon (like a foot) clipped through the container or grass.
