# Momentum Storage (动量存储)

## 1. Identity
- **Atom ID:** `atom_momentum_storage`
- **English Name:** Momentum Storage
- **Chinese Name:** 动量存储
- **Category:** A+B
- **Definition:** A mechanic where a player character retains or accumulates momentum from previous actions (such as dashing, falling, or moving platforms) and can release it later to achieve higher speeds or longer jump distances.

## 2. Core Verb & State Machine
- **Core Verb:** Store / Release
- **State Diagram:**
  [Idle] -> (Move/Dash) -> [Accumulating Momentum]
  [Accumulating Momentum] -> (Jump/Release) -> [Releasing Momentum]
  [Releasing Momentum] -> (Land/Friction) -> [Idle]
- **States:**
  - `Idle`: Normal state with base momentum.
  - `Accumulating Momentum`: Gaining extra speed from external forces or specific actions.
  - `Releasing Momentum`: Applying the stored momentum to a new action (e.g., jumping).
- **Transitions:**
  - `Idle` to `Accumulating Momentum`: Triggered by dashing, falling, or moving on a fast platform.
  - `Accumulating Momentum` to `Releasing Momentum`: Triggered by jumping or specific release inputs.
  - `Releasing Momentum` to `Idle`: Triggered by landing, hitting a wall, or friction over time.

## 3. MDA Analysis
- **Mechanics:** The system tracks the character's velocity vector. When certain conditions are met (e.g., jumping immediately after a dash), the velocity vector is preserved or multiplied rather than reset to a base jump velocity.
- **Dynamics:** Players learn to chain movements together, finding optimal timings to transfer speed from one action to another, creating fluid and fast-paced traversal.
- **Aesthetics:** Creates a feeling of flow, mastery, and exhilaration. Players feel rewarded for precise timing and understanding of the physics engine.

## 4. Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value | Unit |
|---|---|---|---|---|
| `momentum_multiplier` | f32 | 0.5 - 2.0 | 1.2 (Celeste v1.4) | multiplier |
| `storage_window_frames` | u32 | 1 - 10 | 3 (Celeste v1.4) | frames |
| `max_stored_velocity` | f32 | 300.0 - 1000.0 | 600.0 (TowerFall v1.3) | pixels/sec |
| `friction_decay_rate` | f32 | 0.8 - 0.99 | 0.95 (Celeste v1.4) | multiplier/frame |

## 5. Benchmark Data
- **Celeste (v1.4):**
  - `momentum_multiplier`: 1.2
  - `storage_window_frames`: 3
  - `max_stored_velocity`: 500.0
  - `friction_decay_rate`: 0.95
- **TowerFall (v1.3):**
  - `momentum_multiplier`: 1.5
  - `storage_window_frames`: 5
  - `max_stored_velocity`: 600.0
  - `friction_decay_rate`: 0.90

## 6. Common Variants
- **Coyote Time Momentum:** Storing momentum even slightly after leaving a ledge.
- **Directional Storage:** Only storing momentum in specific directions (e.g., horizontal but not vertical).
- **B-hopping (Bunny Hopping):** Continuous jumping to prevent friction from decaying stored momentum.
- **Wave Dashing:** Dashing into the ground and jumping to convert downward/diagonal momentum into horizontal speed.

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_dash`, `atom_wall_jump`, `atom_coyote_time`, `atom_moving_platform`.
- **Incompatible Atoms:** `atom_fixed_jump_arc` (conflicts with variable momentum), `atom_heavy_friction` (kills momentum too quickly).

## 8. Anti-Patterns
- **Uncapped Momentum:** Failing to cap the maximum stored velocity, allowing players to break the game's collision detection or skip entire levels.
- **Inconsistent Storage Windows:** Making the frame window for releasing momentum too tight or variable, leading to frustration.
- **Loss of Control:** Giving the player too much speed without adjusting camera tracking or air control, resulting in blind jumps.
