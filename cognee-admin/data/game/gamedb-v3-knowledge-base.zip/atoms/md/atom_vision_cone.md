# Vision Cone Detection (视锥检测)

## 1. Identity
- **Atom ID:** atom_vision_cone
- **English Name:** Vision Cone Detection
- **Chinese Name:** 视锥检测
- **Category:** A
- **Definition:** A spatial detection mechanism where an entity (usually an NPC or enemy) detects other entities (usually the player) within a specific conical volume originating from its "eyes" or sensor point, simulating realistic field of view and line of sight.

## 2. Core Verb & State Machine
- **Core Verb:** Detect / Evade
- **State Diagram:**
  [Idle] --(Target enters cone)--> [Suspicious]
  [Suspicious] --(Target stays in cone & visibility > threshold)--> [Alert]
  [Alert] --(Target leaves cone & timeout)--> [Searching]
  [Searching] --(Timeout)--> [Idle]
- **States:**
  - `Idle`: Normal patrol or stationary state.
  - `Suspicious`: Target partially detected or briefly seen.
  - `Alert`: Target fully detected, engaging or raising alarm.
  - `Searching`: Target lost, actively looking for target.
- **Transitions:**
  - `Idle` -> `Suspicious`: Triggered when target enters the vision cone.
  - `Suspicious` -> `Alert`: Triggered when detection meter fills up.
  - `Alert` -> `Searching`: Triggered when target breaks line of sight or leaves cone.
  - `Searching` -> `Idle`: Triggered when search timer expires.

## 3. MDA Analysis
- **Mechanics:** The system calculates the angle and distance between the detector and the target. If the distance is within the cone's radius and the angle is within the cone's field of view (FOV), and there are no occluding obstacles (raycast check), the target is detected.
- **Dynamics:** Players learn to navigate around the edges of the vision cones, using cover to break line of sight, or timing their movements when the detector is facing away.
- **Aesthetics:** Creates tension, suspense, and a sense of mastery when successfully bypassing enemies.

## 4. Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value (Game) | Unit |
|---|---|---|---|---|
| `fov_angle` | f32 | 45.0 - 120.0 | 90.0 (Metal Gear Solid V) | Degrees |
| `view_distance` | f32 | 10.0 - 100.0 | 45.0 (Splinter Cell: Chaos Theory) | Meters |
| `peripheral_fov` | f32 | 90.0 - 180.0 | 160.0 (Metal Gear Solid V) | Degrees |
| `peripheral_distance` | f32 | 2.0 - 15.0 | 5.0 (Splinter Cell: Chaos Theory) | Meters |
| `detection_speed` | f32 | 0.1 - 5.0 | 1.5 (Metal Gear Solid V) | Multiplier |

## 5. Benchmark Data
- **Metal Gear Solid V: The Phantom Pain (v1.15):**
  - `fov_angle`: 90.0 degrees (primary vision)
  - `view_distance`: 60.0 meters (daylight), 40.0 meters (night)
  - `peripheral_fov`: 160.0 degrees
  - `peripheral_distance`: 10.0 meters
- **Splinter Cell: Chaos Theory (v1.05):**
  - `fov_angle`: 80.0 degrees
  - `view_distance`: 45.0 meters
  - `detection_speed` scales heavily with player illumination and movement speed.

## 6. Common Variants
1. **Multi-Tiered Vision Cones:** Having a central "focus" cone that detects instantly, and a wider "peripheral" cone that detects slowly.
2. **Dynamic FOV:** The vision cone narrows and lengthens when the enemy is aiming or alert, and widens but shortens when relaxed.
3. **Verticality-Aware Cones:** Cones that have a specific vertical angle (pitch) limit, allowing players to hide above or below the enemy's line of sight.
4. **Light-Dependent Cones:** The effective distance of the cone shrinks in dark areas and expands in well-lit areas.

## 7. Compatibility Notes
- **Commonly Pairs With:** `atom_stealth_meter`, `atom_cover_system`, `atom_noise_emission`, `atom_patrol_route`.
- **Conflicts:** Can conflict with `atom_omnipresent_ai` (where AI always knows player location), requiring careful state management to ensure the vision cone is the primary source of truth for detection.

## 8. Anti-Patterns
1. **Instant Detection:** Failing to provide a buffer (like a suspicion meter) before full detection, leading to frustrating gameplay.
2. **Ignoring Verticality:** Using 2D vision cones in a 3D game, causing enemies to detect players through floors or ceilings.
3. **Perfect Raycasting:** Using a single raycast to the player's center, which can be blocked by a tiny obstacle while the rest of the player is visible.
