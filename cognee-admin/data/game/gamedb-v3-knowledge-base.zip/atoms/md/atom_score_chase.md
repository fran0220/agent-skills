# Gameplay Atom: Score Chase / Leaderboard

## 1. Identity
- **Atom ID:** `atom_score_chase`
- **English Name:** Score Chase / Leaderboard
- **Chinese Name:** 分数追逐/排行榜
- **Category:** E/F (Arcade games, hyper-casual)
- **Definition:** A core gameplay loop where the primary objective is to maximize a numerical score through repeated attempts, often comparing the result against previous personal bests or other players on a leaderboard. It drives replayability through intrinsic motivation to improve and extrinsic motivation of social comparison.

## 2. Core Verb & State Machine
- **Core Verb:** "Score" / "Survive" / "Combo"

**State Diagram:**
```text
[Idle] --> (Start Game) --> [Playing]
[Playing] --> (Score Event) --> [Playing]
[Playing] --> (Combo Timeout) --> [Playing]
[Playing] --> (Fail Condition) --> [Game Over]
[Game Over] --> (Submit Score) --> [Leaderboard]
[Leaderboard] --> (Restart) --> [Playing]
[Leaderboard] --> (Quit) --> [Idle]
```

**States and Transitions:**
- **Idle:** The player is in the main menu.
- **Playing:** The active gameplay state where the player performs actions to gain score.
- **Game Over:** The state triggered when the player fails (e.g., runs out of health or time).
- **Leaderboard:** The state where the final score is tallied, compared, and displayed.

## 3. MDA Analysis
- **Mechanics:** The system awards points for specific actions (e.g., defeating enemies, collecting items, surviving time). It may include combo multipliers that increase with rapid successive actions and reset upon taking damage or waiting too long.
- **Dynamics:** Players optimize their playstyle to maximize points, taking greater risks for higher rewards (e.g., keeping a combo alive). They experience a cycle of tension during the run and release upon seeing the final score.
- **Aesthetics:** Competition, Challenge, Submission. Players feel a sense of mastery as their scores improve, and a competitive drive when comparing with others.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Game) | Unit |
|---|---|---|---|---|
| `base_score` | `u32` | 10 - 1000 | 100 (Pac-Man v1.0) | Points |
| `combo_multiplier_max` | `f32` | 1.0 - 10.0 | 8.0 (Tony Hawk's Pro Skater 1+2) | Multiplier |
| `combo_timeout` | `f32` | 1.0 - 5.0 | 2.5 (OlliOlli World) | Seconds |
| `score_decay_rate` | `f32` | 0.0 - 10.0 | 0.0 (Tetris Classic) | Points/Sec |
| `bonus_threshold` | `u32` | 1000 - 50000 | 10000 (Space Invaders) | Points |

## 5. Benchmark Data
- **Pac-Man (Arcade, 1980):**
  - `base_score` (Dot): 10
  - `bonus_threshold` (Extra Life): 10000
  - `combo_multiplier_max` (Ghosts): 8.0 (200, 400, 800, 1600)
- **Tetris (NES, 1989):**
  - `base_score` (Single Line): 40
  - `combo_multiplier_max` (Tetris): 30.0 (1200 points for 4 lines vs 40 for 1)
- **Subway Surfers (v3.14.2):**
  - `base_score` (Coin): 1
  - `combo_multiplier_max`: 30.0

## 6. Common Variants
1. **Endless Runner:** Score is tied to distance traveled and items collected (e.g., Temple Run).
2. **Combo-Driven Action:** Score relies heavily on maintaining a combo meter without getting hit (e.g., Devil May Cry style meters).
3. **Time Attack:** Players must achieve the highest score within a strict time limit.
4. **High Score Survival:** Players survive waves of enemies, with score increasing based on survival time and kills (e.g., Vampire Survivors).
5. **Rhythm Game Scoring:** Score is based on the timing accuracy of inputs (e.g., osu!, Beat Saber).

## 7. Compatibility Notes
- **Commonly Pairs With:** `atom_combo_system`, `atom_endless_generation`, `atom_time_limit`, `atom_leaderboard_ui`.
- **Conflicts:** `atom_narrative_choice` (heavy story focus interrupts the fast-paced loop of score chasing), `atom_save_scumming` (undermines the integrity of a single run's score).

## 8. Anti-Patterns
1. **Unclear Scoring Mechanics:** Players cannot easily understand what actions yield the most points, leading to frustration.
2. **Pay-to-Win Leaderboards:** Allowing players to buy score multipliers or revives that directly inflate their score, ruining competitive integrity.
3. **Lack of Catch-up or Escalation:** The game does not increase in difficulty, making high scores a measure of endurance rather than skill.
