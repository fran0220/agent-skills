# Timing Window Judgment (判定窗口)

## 1. Identity
**Atom ID:** atom_timing_window
**English Name:** Timing Window Judgment
**Chinese Name:** 判定窗口
**Category:** G/H (Timing/Execution)
**Definition:** A gameplay mechanic where the player must perform an action within a specific, often very brief, timeframe relative to an in-game event to achieve a successful outcome. This is the foundational mechanic for rhythm games, parry systems, and active reload mechanics.

## 2. Core Verb & State Machine
**Core Verb:** Time (or React/Execute)

**State Diagram:**
[Idle] -> (Event Trigger) -> [Window Open] -> (Player Input) -> [Success/Failure Evaluation] -> [Cooldown/Resolution] -> [Idle]
[Window Open] -> (Timeout) -> [Miss] -> [Cooldown/Resolution] -> [Idle]

**States and Transitions:**
- **Idle:** The default state waiting for an event.
- **Window Open:** The specific timeframe during which player input is evaluated.
- **Success/Failure Evaluation:** The state where the timing of the input is compared against the optimal timing.
- **Miss:** The state reached if no input is provided before the window closes.
- **Cooldown/Resolution:** The aftermath of the action, applying effects (damage, score, etc.) before returning to Idle.

## 3. MDA Analysis
**Mechanics:** The system defines a target time ($T_{target}$) and a set of acceptable deviation ranges ($\Delta t$). When the player inputs an action at time $T_{input}$, the system calculates the absolute difference $|T_{input} - T_{target}|$. Based on which range this difference falls into (e.g., Perfect, Great, Good, Bad), a specific outcome is triggered.
**Dynamics:** Players learn to anticipate the target time through visual, auditory, or rhythmic cues. They adjust their physical execution to minimize the deviation. This creates a loop of anticipation, execution, and immediate feedback, leading to skill mastery over time.
**Aesthetics:** The mechanic evokes feelings of precision, mastery, and flow. Successfully hitting a tight timing window (like a "Perfect" parry or a "Marvelous" rhythm note) provides a strong sense of satisfaction and empowerment, often accompanied by rewarding audiovisual feedback.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Game) | Unit |
|---|---|---|---|---|
| `perfect_window` | f32 | 0.016 - 0.050 | 0.033 (Sekiro: Shadows Die Twice v1.06) | seconds |
| `good_window` | f32 | 0.050 - 0.150 | 0.100 (Hollow Knight v1.5) | seconds |
| `punish_window` | f32 | 0.100 - 0.300 | 0.200 (Dark Souls III v1.15) | seconds |
| `input_delay_compensation` | f32 | 0.000 - 0.050 | 0.016 (Street Fighter V) | seconds |

## 5. Benchmark Data
- **Sekiro: Shadows Die Twice (v1.06):** The base parry (deflect) window is approximately 12 frames at 60 FPS, which translates to 0.200 seconds. However, the "perfect" deflect window is much tighter, often cited around 2-4 frames (0.033 - 0.066 seconds) depending on the specific enemy attack.
- **Dance Dance Revolution A20:** The "Marvelous" timing window is extremely strict, typically $\pm 0.015$ seconds (15 milliseconds). The "Perfect" window is $\pm 0.030$ seconds.
- **Gears of War 4:** The "Active Reload" perfect window varies by weapon but is generally around 0.100 to 0.150 seconds, providing a damage boost if hit correctly.

## 6. Common Variants
- **Rhythm Game Multi-Tier:** Multiple concentric windows (Marvelous, Perfect, Great, Good, Bad, Miss) with scaling score rewards.
- **Action Game Binary:** A simple pass/fail window (e.g., standard dodge roll invincibility frames).
- **Risk/Reward Parry:** A tight window for a massive advantage (parry), surrounded by a wider window for a lesser advantage (block), and a failure state (taking damage).
- **Asymmetric Windows:** The window to hit early is different from the window to hit late (e.g., forgiving early inputs but strict on late inputs).
- **Dynamic Windows:** The timing window size changes based on player stats, difficulty level, or consecutive successes/failures.

## 7. Compatibility Notes
- **Commonly Pairs With:** `atom_telegraphing` (providing the cue for the timing window), `atom_combo_system` (chaining successful timing hits), `atom_hit_stop` (emphasizing the impact of a perfect timing hit).
- **Known Conflicts:** Can conflict with `atom_high_latency_network` (strict timing windows feel unfair if network latency fluctuates unpredictably).

## 8. Anti-Patterns
- **Unclear Telegraphing:** Providing a timing window without adequate visual or auditory cues, making it feel like guesswork rather than skill.
- **Inconsistent Input Latency:** If the game engine or hardware introduces variable input lag, players cannot reliably learn the timing window.
- **Overly Punishing Near-Misses:** Making the penalty for missing by 1 millisecond the same as missing entirely can lead to frustration. A graded failure system is often better.
