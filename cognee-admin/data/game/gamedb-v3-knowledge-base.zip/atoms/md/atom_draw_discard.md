# Gameplay Atom: Draw / Discard Pile (atom_draw_discard)

## 1. Identity
- **Atom ID:** atom_draw_discard
- **English Name:** Draw / Discard Pile
- **Chinese Name:** 抽牌堆/弃牌堆
- **Category:** C
- **Definition:** A system managing a collection of cards or elements where players draw from a randomized or ordered pile (Draw Pile) into their hand, and place used or discarded elements into a separate pile (Discard Pile), which is typically reshuffled into the Draw Pile when empty.

## 2. Core Verb & State Machine
- **Core Verb:** Draw, Discard, Reshuffle
- **State Diagram:**
  [Draw Pile] --(Draw)--> [Hand] --(Play/Discard)--> [Discard Pile] --(Reshuffle)--> [Draw Pile]
- **States:**
  - `InDrawPile`: Card is waiting to be drawn.
  - `InHand`: Card is currently held by the player.
  - `InPlay`: Card is actively being resolved.
  - `InDiscardPile`: Card has been used or discarded.
  - `Exhausted/Banished`: Card is removed from the cycle (optional state).
- **Transitions:**
  - `Draw`: InDrawPile -> InHand
  - `Play`: InHand -> InPlay
  - `Resolve`: InPlay -> InDiscardPile
  - `Discard`: InHand -> InDiscardPile
  - `Reshuffle`: InDiscardPile -> InDrawPile

## 3. MDA Analysis
- **Mechanics:** The system maintains two primary lists of entities. The draw action removes the top element from the draw list and adds it to the player's hand. The discard action moves elements to the discard list. When the draw list is empty and a draw is requested, the discard list is randomized and becomes the new draw list.
- **Dynamics:** Players cycle through their deck, creating a rhythm of resource availability. The probability of drawing specific cards changes as the draw pile shrinks, allowing players to calculate odds and plan future turns.
- **Aesthetics:** Anticipation and excitement when drawing cards (RNG). Satisfaction of executing a planned combo. Tension when needing a specific card before a reshuffle.

## 4. Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value (Slay the Spire v2.3) | Unit |
|---|---|---|---|---|
| `draw_amount` | u32 | 1 - 10 | 5 | cards/turn |
| `max_hand_size` | u32 | 5 - 15 | 10 | cards |
| `reshuffle_penalty` | u32 | 0 - 10 | 0 | damage/cards |
| `initial_deck_size` | u32 | 10 - 40 | 10 | cards |

## 5. Benchmark Data
- **Slay the Spire (v2.3):**
  - `draw_amount`: 5
  - `max_hand_size`: 10
  - `reshuffle_penalty`: 0
- **Dominion (2nd Edition):**
  - `draw_amount`: 5
  - `max_hand_size`: No strict limit (discard down to 0, draw 5)
  - `reshuffle_penalty`: 0

## 6. Common Variants
1. **Fatigue System:** Taking damage when attempting to draw from an empty deck instead of reshuffling (e.g., Hearthstone).
2. **Ordered Discard:** The discard pile cannot be rearranged, and cards are returned to the draw pile in a specific order or without shuffling (e.g., Aeon's End).
3. **Continuous Draw:** Drawing up to a certain hand size at the end of each turn rather than a fixed amount.
4. **Shared Deck:** Multiple players draw from the same central draw pile.

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_hand_management`, `atom_action_points`, `atom_deck_building`, `atom_card_drafting`.
- **Incompatible Atoms:** `atom_fixed_action_set` (if actions are entirely static, a randomized draw pile contradicts this).

## 8. Anti-Patterns
1. **Infinite Draw Loops:** Allowing players to draw their entire deck and play it in a single turn without resource constraints, leading to non-interactive gameplay.
2. **Overly Punishing Reshuffles:** Making the reshuffle penalty so high that players are discouraged from playing cards or cycling their deck.
3. **Unmanageable Hand Sizes:** Lacking a maximum hand size or discard step, causing UI clutter and analysis paralysis.
