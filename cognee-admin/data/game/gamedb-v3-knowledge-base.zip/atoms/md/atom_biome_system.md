# Biome System (生态群落)

## 1. Identity
- **Atom ID**: atom_biome_system
- **English Name**: Biome System
- **Chinese Name**: 生态群落
- **Category**: G (World Generation)
- **Definition**: A system that divides the game world into distinct regions, each characterized by specific environmental conditions, flora, fauna, terrain generation rules, and resources, creating varied and immersive gameplay experiences.

## 2. Core Verb & State Machine
- **Core Verb**: Explore / Traverse
- **State Diagram**:
  [Unloaded] -> (Player approaches) -> [Generating] -> (Generation complete) -> [Active] -> (Player leaves) -> [Unloaded]
- **States**:
  - `Unloaded`: The biome data is stored but not instantiated in the game world.
  - `Generating`: The procedural generation algorithms are actively creating the terrain and populating entities for the biome.
  - `Active`: The biome is fully loaded, and its specific rules (weather, spawning, resources) are in effect.
- **Transitions**:
  - `Unloaded` to `Generating`: Triggered when a player enters the generation radius.
  - `Generating` to `Active`: Triggered when all chunks in the biome region are fully generated.
  - `Active` to `Unloaded`: Triggered when all players leave the active radius and the chunk is marked for unloading.

## 3. MDA Analysis
- **Mechanics**: The system uses noise functions (e.g., Perlin or Simplex noise) to determine temperature, humidity, and elevation maps. These maps intersect to define specific biome types (e.g., high temp + low humidity = desert). It dictates block/terrain types, entity spawn tables, and weather patterns.
- **Dynamics**: Players adapt their survival strategies based on the biome they are in. They may travel long distances to find specific biomes for unique resources or optimal building conditions. The transition between biomes creates a sense of journey and discovery.
- **Aesthetics**: Evokes feelings of discovery, wonder, and environmental challenge. The distinct visual and audio cues of each biome provide a strong sense of place and atmosphere.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Game) | Unit |
|---|---|---|---|---|
| `temperature` | f32 | [-1.0, 2.0] | 0.5 (Minecraft 1.18) | N/A |
| `humidity` | f32 | [0.0, 1.0] | 0.5 (Minecraft 1.18) | N/A |
| `elevation` | f32 | [-64.0, 320.0] | 64.0 (Minecraft 1.18) | Blocks |
| `spawn_rate_multiplier` | f32 | [0.0, 5.0] | 1.0 (Terraria 1.4) | Multiplier |
| `resource_density` | f32 | [0.0, 1.0] | 0.1 (No Man's Sky) | % per chunk |

## 5. Benchmark Data
- **Minecraft (Java Edition 1.18)**:
  - `temperature`: 2.0 (Desert), -0.7 (Snowy Taiga)
  - `humidity`: 0.0 (Desert), 0.8 (Jungle)
- **Terraria (1.4.4)**:
  - `spawn_rate_multiplier`: 1.5 (Jungle), 2.0 (Blood Moon in any biome)
- **No Man's Sky (Waypoint)**:
  - `resource_density`: Varies heavily, but typically 0.05 to 0.2 depending on planet type.

## 6. Common Variants
1. **Temperature/Humidity Matrix**: Biomes are determined by a 2D or 3D matrix of noise values (Minecraft).
2. **Discrete Regions**: Biomes are hand-placed or generated as distinct, non-overlapping zones with hard borders (Terraria).
3. **Planetary Biomes**: Entire planets or large celestial bodies act as single, uniform biomes (No Man's Sky).
4. **Layered Biomes**: Biomes change based on depth or elevation rather than horizontal position (Subnautica).

## 7. Compatibility Notes
- **Commonly Pairs With**: `atom_procedural_terrain`, `atom_weather_system`, `atom_resource_spawning`, `atom_entity_spawning`.
- **Conflicts**: Can conflict with strict linear level design (`atom_linear_progression`) if not carefully managed, as biomes encourage non-linear exploration.

## 8. Anti-Patterns
1. **Abrupt Transitions**: Failing to blend terrain or weather between drastically different biomes (e.g., a snow biome immediately next to a desert without a transition zone).
2. **Empty Biomes**: Creating visually distinct biomes that lack unique gameplay elements, resources, or challenges, making them feel superficial.
3. **Over-Fragmentation**: Generating biomes that are too small, preventing the player from fully experiencing the environment or gathering necessary resources before transitioning to the next.
