# Elimination Round (淘汰赛)

## 1. Identity
- **Atom ID:** atom_elimination_round
- **English Name:** Elimination Round
- **Chinese Name:** 淘汰赛
- **Category:** G (Game Flow)
- **Definition:** A structured gameplay phase where a subset of participating players or entities are permanently removed from the current session based on specific failure conditions, while the remaining participants advance to subsequent rounds until a final victor or surviving group is determined.

## 2. Core Verb & State Machine
- **Core Verb:** Survive / Qualify

**State Diagram:**
[Waiting] -> [Active] -> [Evaluating] -> [Eliminated] / [Qualified]
[Qualified] -> [Waiting] (for next round)

**States:**
- `Waiting`: Players are in a lobby or starting area, waiting for the round to begin.
- `Active`: The round is ongoing, and players are actively competing to meet qualification criteria.
- `Evaluating`: The system checks which players met the criteria and which failed.
- `Eliminated`: The player has failed the criteria and is removed from the session.
- `Qualified`: The player has met the criteria and advances to the next round.

**Transitions:**
- `Waiting` -> `Active`: Round start timer reaches zero.
- `Active` -> `Evaluating`: Round time limit reached, or target number of qualifiers reached.
- `Evaluating` -> `Eliminated`: Player score/position is below the qualification threshold.
- `Evaluating` -> `Qualified`: Player score/position meets or exceeds the qualification threshold.
- `Qualified` -> `Waiting`: Transition to the next round's lobby.

## 3. MDA Analysis
- **Mechanics:** The system enforces a hard limit on the number of players who can progress, or sets a strict performance threshold. It tracks player states and culls those who fail to meet the criteria at the end of the round.
- **Dynamics:** Players experience high-stakes competition, often leading to aggressive or highly optimized playstyles as the elimination threshold approaches. Alliances may form temporarily but dissolve as slots become scarce.
- **Aesthetics:** Tension, relief (upon qualifying), frustration (upon elimination), and a sense of escalating stakes as the player pool shrinks.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value | Unit |
|---|---|---|---|---|
| `initial_player_count` | u32 | 2 - 100 | 60 (Fall Guys v1.0) | players |
| `elimination_rate` | f32 | 0.1 - 0.9 | 0.3 (Fall Guys v1.0) | ratio |
| `round_time_limit` | f32 | 30.0 - 300.0 | 120.0 (Fall Guys v1.0) | seconds |
| `qualification_threshold` | u32 | 1 - 99 | 42 (Fall Guys v1.0) | players |

## 5. Benchmark Data
- **Fall Guys (v1.0):**
  - `initial_player_count`: 60
  - `elimination_rate`: 0.3
  - `round_time_limit`: 120.0
  - `qualification_threshold`: 42
- **Apex Legends (Battle Royale mode, Season 1):**
  - `initial_player_count`: 60
  - `elimination_rate`: 0.95
  - `round_time_limit`: 180.0
  - `qualification_threshold`: 3

## 6. Common Variants
1. **Fixed Quota Elimination:** A specific number of players qualify (e.g., first 10 to cross the finish line).
2. **Time-Based Elimination:** Anyone who fails to complete an objective within a time limit is eliminated.
3. **Continuous Elimination (Battle Royale):** No discrete rounds; players are eliminated continuously until one remains.
4. **Bottom-N Elimination:** At the end of a set time, the lowest-scoring N players are eliminated.
5. **Sudden Death:** Any mistake leads to immediate elimination.

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_timer`, `atom_score_ranking`, `atom_health_pool`, `atom_shrinking_zone`.
- **Incompatible Atoms:** `atom_infinite_respawn` (conflicts with the permanent removal aspect of elimination).

## 8. Anti-Patterns
1. **Snowballing Advantage:** Allowing players who qualify early to gain massive advantages in subsequent rounds, making the final round unbalanced.
2. **Unclear Elimination Criteria:** Players being eliminated without understanding why or how close they were to qualifying.
3. **Excessive Downtime:** Forcing eliminated players to wait too long before they can join a new session.
