# Gameplay Atom: Combo Counter

## 1. Identity
- **Atom ID:** atom_combo_counter
- **English Name:** Combo Counter
- **Chinese Name:** 连击计数
- **Category:** G (Gameplay Mechanics)
- **Definition:** A system that tracks consecutive successful player actions within a specific time window, often rewarding higher counts with increased damage, score multipliers, or special abilities.

## 2. Core Verb & State Machine
- **Core Verb:** Attack / Hit
- **State Diagram:**
  - `Idle` -> (Hit) -> `Active`
  - `Active` -> (Hit within window) -> `Active` (Increment Counter)
  - `Active` -> (Timeout / Miss / Take Damage) -> `Idle` (Reset Counter)
- **States:** `Idle`, `Active`
- **Transitions:**
  - `Idle` to `Active`: Triggered by an initial successful hit.
  - `Active` to `Active`: Triggered by a subsequent successful hit before the combo timer expires.
  - `Active` to `Idle`: Triggered by the combo timer expiring, the player missing an attack, or the player taking damage.

## 3. MDA Analysis
- **Mechanics:** The system increments an integer counter for each consecutive hit. A timer resets after each hit. If the timer reaches zero, the counter resets to zero. The counter value may be used as a multiplier for score or damage.
- **Dynamics:** Players are incentivized to maintain an aggressive playstyle to keep the combo alive. It creates a risk/reward scenario where players might overextend to land another hit before the timer runs out.
- **Aesthetics:** Excitement, flow, mastery, and tension. The visual and auditory feedback of a rising combo counter enhances the feeling of power and skill.

## 4. Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value (Game) | Unit |
|---|---|---|---|---|
| `combo_window` | f32 | 1.0 - 5.0 | 3.0 (Devil May Cry 5) | seconds |
| `max_combo` | u32 | 10 - 999 | 999 (Bayonetta) | hits |
| `damage_multiplier_base` | f32 | 1.0 - 1.5 | 1.0 (Standard Action Game) | multiplier |
| `damage_multiplier_step` | f32 | 0.01 - 0.1 | 0.05 (Standard Action Game) | multiplier per hit |
| `score_multiplier_base` | f32 | 1.0 - 2.0 | 1.0 (Tony Hawk's Pro Skater) | multiplier |

## 5. Benchmark Data
- **Devil May Cry 5 (v1.0):** `combo_window` = ~3.0s (varies slightly by move), `max_combo` = effectively infinite for style ranking, but numerical hits can go very high.
- **Bayonetta (v1.0):** `combo_window` = ~2.5s, `max_combo` = 9999.
- **Osu! (v2023):** `combo_window` = tied to rhythm timing windows (milliseconds), `max_combo` = depends on song length.

## 6. Common Variants
- **Time-Based Combo:** The combo drops if a hit isn't landed within a specific time frame (e.g., Devil May Cry).
- **Action-Based Combo:** The combo drops if the player performs a non-combo action, misses, or gets hit, regardless of time (e.g., some fighting games).
- **Rhythm-Based Combo:** The combo is maintained by hitting inputs in time with music; missing a beat drops the combo (e.g., Rhythm Heaven, Osu!).
- **Juggle Combo:** A specific type of combo where the enemy is kept airborne; the combo ends when the enemy hits the ground (e.g., Tekken).

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_score_multiplier`, `atom_style_meter`, `atom_stagger_meter`, `atom_hit_stop`.
- **Incompatible Atoms:** `atom_turn_based_combat` (usually, though variants exist), `atom_stealth_takedown` (typically single-hit).

## 8. Anti-Patterns
- **Overly Strict Timing:** Making the combo window too short can frustrate players and discourage experimentation.
- **Lack of Feedback:** Failing to provide clear visual or auditory cues when a combo is maintained or dropped.
- **Snowballing:** Making the rewards for high combos so powerful that the game becomes trivial, or conversely, making the base damage so low that combos are mandatory for basic progression.
