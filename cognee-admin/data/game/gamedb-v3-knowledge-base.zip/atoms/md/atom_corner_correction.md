# Identity
- **Atom ID**: atom_corner_correction
- **English Name**: Corner Correction
- **Chinese Name**: 拐角修正
- **Category**: A
- **Definition**: A subtle movement assist mechanism that slightly shifts the player character's position when they narrowly miss a jump around a corner, allowing them to smoothly bypass the obstacle instead of colliding with it and losing momentum.

# Core Verb & State Machine
- **Core Verb**: Correct Position
- **State Diagram**:
  [Airborne] -> (Collision Detected near Corner) -> [Correcting] -> (Position Adjusted) -> [Airborne]
- **States**:
  - `Airborne`: The character is moving through the air.
  - `Correcting`: The system detects a near-miss collision with a corner and applies a positional shift.
- **Transitions**:
  - `Airborne` to `Correcting`: Triggered when the character's bounding box intersects a corner within the correction threshold.
  - `Correcting` to `Airborne`: Triggered immediately after the positional shift is applied.

# MDA Analysis
- **Mechanics**: The game continuously checks the character's bounding box against level geometry. If a collision occurs but the overlap is within a predefined small threshold (e.g., a few pixels) near a corner, the character's position is nudged outwards to clear the corner.
- **Dynamics**: Players can execute tighter jumps and maintain momentum without needing pixel-perfect precision. It reduces the frustration of getting snagged on level geometry.
- **Aesthetics**: Creates a feeling of fluidity, responsiveness, and fairness. The player feels skilled and agile, unaware of the subtle assistance the game is providing.

# Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value | Unit |
|---|---|---|---|---|
| `correction_distance_x` | f32 | 1.0 - 5.0 | 4.0 (Celeste v1.4) | pixels |
| `correction_distance_y` | f32 | 1.0 - 5.0 | 4.0 (Celeste v1.4) | pixels |
| `velocity_threshold` | f32 | 0.0 - 100.0 | 0.0 (Celeste v1.4) | pixels/sec |

# Benchmark Data
- **Celeste (v1.4)**:
  - `correction_distance_x`: 4.0 pixels
  - `correction_distance_y`: 4.0 pixels
- **Super Meat Boy (v1.2)**:
  - `correction_distance_x`: 3.0 pixels
  - `correction_distance_y`: 3.0 pixels

# Common Variants
1. **Horizontal Only**: Only corrects horizontal movement when hitting a ceiling corner.
2. **Vertical Only**: Only corrects vertical movement when hitting a wall corner.
3. **Velocity-Dependent**: The correction distance scales with the character's velocity.
4. **Ledge Forgiveness**: A specific type of corner correction applied only when jumping off a ledge (often combined with Coyote Time).

# Compatibility Notes
- **Compatible Atoms**: `atom_coyote_time`, `atom_jump_buffering`, `atom_wall_jump`.
- **Conflicts**: May conflict with `atom_precise_collision` if the game relies on exact pixel-perfect hitboxes for puzzle solving.

# Anti-Patterns
1. **Over-Correction**: Setting the correction distance too high, causing the character to visibly teleport or glitch through solid walls.
2. **Inconsistent Application**: Applying corner correction to some corners but not others, leading to unpredictable gameplay.
3. **Ignoring Velocity**: Applying correction even when the character is moving very slowly, which can feel unnatural.
