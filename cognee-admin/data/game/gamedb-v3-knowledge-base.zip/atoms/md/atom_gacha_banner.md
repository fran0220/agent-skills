# Gameplay Atom: Gacha Banner / Pull

## 1. Identity
- **Atom ID:** atom_gacha_banner
- **English Name:** Gacha Banner / Pull
- **Chinese Name:** 抽卡卡池
- **Category:** C (Monetization & Progression)
- **Definition:** A probabilistic monetization and progression system where players spend premium or earned currency to receive a random set of rewards, typically characters, items, or equipment, often governed by a pity system to guarantee high-rarity drops after a certain number of unsuccessful attempts.

## 2. Core Verb & State Machine
- **Core Verb:** Pull / Roll / Summon
- **State Diagram:**
  [Idle] -> (Spend Currency) -> [Rolling Animation] -> (Determine Result) -> [Reveal Reward] -> (Acknowledge) -> [Idle]
- **States and Transitions:**
  - **Idle:** The player is viewing the banner UI.
  - **Rolling Animation:** The player has confirmed the pull, and the game plays a suspenseful animation.
  - **Reveal Reward:** The game displays the obtained items.
  - **Transitions:**
    - Idle -> Rolling Animation: Triggered by the player pressing the "Pull" button and having sufficient currency.
    - Rolling Animation -> Reveal Reward: Triggered automatically after the animation finishes or is skipped.
    - Reveal Reward -> Idle: Triggered by the player clicking "OK" or "Continue".

## 3. MDA Analysis
- **Mechanics:** The system uses a pseudo-random number generator (PRNG) with weighted probabilities to determine the outcome of a pull. It often includes a "pity" counter that increments on unsuccessful pulls and guarantees a high-rarity reward when reaching a threshold.
- **Dynamics:** Players accumulate currency over time or through purchases, then spend it in bursts on specific banners. The pity system creates a predictable upper bound on cost, encouraging players to save up for guaranteed rewards.
- **Aesthetics:** Anticipation, excitement, frustration, and relief. The visual and auditory feedback during the rolling animation heightens the emotional impact of the result.

## 4. Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value (Genshin Impact v4.0) | Unit |
|---|---|---|---|---|
| `base_probability_5_star` | f32 | 0.001 - 0.05 | 0.006 | Probability (0-1) |
| `base_probability_4_star` | f32 | 0.05 - 0.20 | 0.051 | Probability (0-1) |
| `hard_pity_threshold` | u32 | 50 - 300 | 90 | Pulls |
| `soft_pity_start` | u32 | 40 - 80 | 74 | Pulls |
| `soft_pity_increment` | f32 | 0.01 - 0.10 | 0.06 | Probability (0-1) |
| `pull_cost` | u32 | 100 - 300 | 160 | Currency |

## 5. Benchmark Data
- **Genshin Impact (v4.0):**
  - `base_probability_5_star`: 0.006 (0.6%)
  - `hard_pity_threshold`: 90
  - `soft_pity_start`: 74
  - `pull_cost`: 160 Primogems
- **Arknights (v3.0):**
  - `base_probability_6_star`: 0.02 (2%)
  - `hard_pity_threshold`: 99 (Standard), 300 (Limited Spark)
  - `soft_pity_start`: 50
  - `pull_cost`: 600 Orundum
- **Fate/Grand Order (v2.0):**
  - `base_probability_5_star_servant`: 0.01 (1%)
  - `hard_pity_threshold`: 330
  - `pull_cost`: 30 Saint Quartz (for 11 pulls)

## 6. Common Variants
1. **Step-Up Banner:** The cost or probability changes with each consecutive pull (e.g., first pull is discounted, 5th pull guarantees a specific rarity).
2. **Box Gacha:** A finite pool of rewards. Once an item is pulled, it is removed from the pool, guaranteeing all items eventually.
3. **Spark System:** Pulling grants a secondary currency (sparks). Accumulating enough sparks allows the player to directly purchase the banner's featured item.
4. **Discounted Daily Pull:** A single pull available once per day at a significantly reduced premium currency cost.

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_premium_currency`, `atom_character_progression`, `atom_daily_login_bonus`, `atom_battle_pass`.
- **Incompatible Atoms:** `atom_permadeath` (losing a character you paid for is generally unacceptable), `atom_pure_skill_check` (gacha introduces pay-to-win elements that conflict with pure skill).

## 8. Anti-Patterns
1. **No Pity System:** Relying purely on RNG without a safety net can lead to extreme player frustration and churn.
2. **Diluted Reward Pool:** Filling the gacha with useless "trash" items makes pulls feel unrewarding and deceptive.
3. **Hidden Probabilities:** Failing to disclose the exact drop rates violates trust and often legal regulations in many jurisdictions.
