# Atom: Fast Travel (快速旅行)

## 1. Identity
- **Atom ID:** `atom_fast_travel`
- **English Name:** Fast Travel
- **Chinese Name:** 快速旅行
- **Category:** G (Game Mechanics)
- **Definition:** A mechanic that allows a player character to instantaneously travel between previously discovered locations without having to traverse the space in real-time.

## 2. Core Verb & State Machine
- **Core Verb:** Teleport / Travel
- **State Diagram:**
  ```text
  [Idle] --> (Open Map) --> [SelectingDestination]
  [SelectingDestination] --> (Confirm Destination) --> [Loading]
  [Loading] --> (Load Complete) --> [Arrived]
  [Arrived] --> (Resume Gameplay) --> [Idle]
  ```
- **States and Transitions:**
  - `Idle`: The player is in normal gameplay.
  - `SelectingDestination`: The player has opened the map or interacted with a fast travel point and is choosing where to go.
  - `Loading`: The game is loading the new area.
  - `Arrived`: The player has spawned at the destination.

## 3. MDA Analysis
- **Mechanics:** Map UI, fast travel points (waypoints, shrines, stations), cost (currency, consumable items), loading screen, time advancement.
- **Dynamics:** Players optimize their routes, skip tedious backtracking, and sometimes use fast travel to escape danger or reset enemy spawns.
- **Aesthetics:** Convenience, mastery of the world, pacing control, and reduction of frustration.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value | Unit |
|---|---|---|---|---|
| `cost_amount` | u32 | 0 - 1000 | 0 (Skyrim v1.5) | currency/items |
| `cast_time` | f32 | 0.0 - 10.0 | 3.0 (BotW v1.5) | seconds |
| `cooldown` | f32 | 0.0 - 3600.0 | 0.0 (Skyrim v1.5) | seconds |
| `combat_lockout` | bool | true/false | true (Skyrim v1.5) | boolean |

## 5. Benchmark Data
- **Skyrim (v1.5):** `cost_amount` = 0, `cast_time` = 0.0s, `combat_lockout` = true. Fast travel advances in-game time based on distance.
- **Hollow Knight (v1.5):** `cost_amount` = 1 (Stag Station ticket/geo), `cast_time` = 0.0s, `combat_lockout` = false (can only be initiated from safe zones).
- **Breath of the Wild (v1.5):** `cost_amount` = 0, `cast_time` = 3.0s (animation), `combat_lockout` = false (can teleport away from danger).

## 6. Common Variants
- **Consumable-based:** Requires an item to initiate (e.g., Town Portal Scroll in Diablo).
- **Station-to-Station:** Can only travel from specific points to other specific points (e.g., Stag Stations in Hollow Knight).
- **Anywhere-to-Point:** Can travel from anywhere in the open world to a discovered point (e.g., Shrines in Breath of the Wild).

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_exploration`, `atom_world_map`, `atom_checkpoints`.
- **Incompatible Atoms:** `atom_survival_tension` (fast travel can ruin the tension of being stranded), `atom_escort_mission` (usually disabled during escorts).

## 8. Anti-Patterns
- **Trivializing Exploration:** Giving access to fast travel too early before the player has learned the layout of the world.
- **Interrupting Tension:** Allowing fast travel during critical story moments or boss fights, ruining the narrative pacing.
- **Excessive Loading Screens:** Designing quests that require constant fast traveling back and forth, leading to more time spent in loading screens than playing.
