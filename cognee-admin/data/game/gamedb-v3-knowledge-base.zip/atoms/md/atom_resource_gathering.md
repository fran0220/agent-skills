# Resource Gathering (资源采集)

## 1. Identity
- **Atom ID:** atom_resource_gathering
- **English Name:** Resource Gathering
- **Chinese Name:** 资源采集
- **Category:** C
- **Definition:** The process by which a player interacts with the game world to extract, collect, or harvest raw materials or items that can be used for crafting, building, trading, or survival.

## 2. Core Verb & State Machine
- **Core Verb:** Gather / Harvest
- **State Diagram:**
  [Idle] --(Initiate Gathering)--> [Gathering]
  [Gathering] --(Interrupted)--> [Idle]
  [Gathering] --(Complete)--> [Loot Dropped/Collected]
  [Loot Dropped/Collected] --(Return to Idle)--> [Idle]
- **States:**
  - `Idle`: The player is not currently gathering.
  - `Gathering`: The player is actively extracting resources (e.g., swinging a pickaxe).
  - `Loot Dropped/Collected`: The resource node is depleted or yields items, which are added to the inventory or dropped in the world.
- **Transitions:**
  - `Idle` -> `Gathering`: Triggered by player input (e.g., holding left click on a tree).
  - `Gathering` -> `Idle`: Triggered by player releasing input, moving away, or taking damage.
  - `Gathering` -> `Loot Dropped/Collected`: Triggered when the gathering timer or node health reaches zero.
  - `Loot Dropped/Collected` -> `Idle`: Automatic transition after loot is processed.

## 3. MDA Analysis
- **Mechanics:** The system tracks the health or yield of a resource node. The player applies a gathering tool or action that reduces the node's health or increments a gathering progress bar over time. Upon completion, the system generates items based on a loot table and adds them to the player's inventory.
- **Dynamics:** Players optimize their gathering routes, upgrade tools to increase gathering speed or yield, and manage inventory space. Competition for scarce resources may emerge in multiplayer environments.
- **Aesthetics:** A sense of progression, satisfaction from accumulation, and the relaxing or rhythmic nature of repetitive harvesting tasks.

## 4. Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value | Unit |
|---|---|---|---|---|
| `gathering_time` | f32 | 0.5 - 10.0 | 3.0 (Minecraft 1.20) | seconds |
| `tool_multiplier` | f32 | 1.0 - 10.0 | 2.0 (Stardew Valley 1.5) | multiplier |
| `node_health` | f32 | 1.0 - 100.0 | 10.0 (Rust) | hit points |
| `yield_amount` | u32 | 1 - 50 | 1 (Minecraft 1.20) | items |
| `respawn_time` | f32 | 0.0 - 86400.0 | 86400.0 (Stardew Valley 1.5) | seconds |

## 5. Benchmark Data
- **Minecraft (1.20):**
  - `gathering_time`: 3.0 seconds (e.g., breaking wood with bare hands)
  - `yield_amount`: 1 item (e.g., 1 wood block)
- **Stardew Valley (1.5):**
  - `tool_multiplier`: 2.0 (e.g., Copper Axe vs Basic Axe)
  - `respawn_time`: 86400.0 seconds (1 in-game day for daily forage/respawns)
- **Rust:**
  - `node_health`: 10.0 hits (e.g., hitting a tree with a rock)

## 6. Common Variants
1. **Hold-to-Gather:** The player must hold down a button continuously to gather (e.g., Minecraft, Rust).
2. **Click-to-Gather:** A single click initiates an automated gathering sequence or instantly gathers the item (e.g., Stardew Valley foraging, RTS games).
3. **Minigame Gathering:** Gathering requires completing a small minigame for success or bonus yield (e.g., fishing in Stardew Valley, active reload mechanics applied to gathering).
4. **Passive Gathering:** Resources are gathered automatically over time by placed structures (e.g., Factorio miners).

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_crafting`, `atom_inventory_management`, `atom_tool_durability`, `atom_base_building`.
- **Incompatible Atoms:** `atom_pure_linear_narrative` (heavy resource gathering can disrupt pacing in strictly linear story games).

## 8. Anti-Patterns
1. **Excessive Grind:** Requiring too much gathering time for basic progression, leading to player burnout.
2. **Inventory Clutter:** Dropping too many low-value or distinct resource types without adequate inventory space or management tools.
3. **Lack of Feedback:** Failing to provide visual or audio cues during the gathering process, making it feel unresponsive or tedious.
