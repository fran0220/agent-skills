# Identity
- **Atom ID**: atom_instant_restart
- **English Name**: Instant Restart
- **Chinese Name**: 即时重开
- **Category**: G/H (Gameplay/Handling)
- **Definition**: A mechanic that allows the player to immediately restart a level or challenge upon failure or manual input, with zero or near-zero loading time, maintaining flow and reducing frustration.

# Core Verb & State Machine
- **Core Verb**: Restart
- **State Diagram**:
  - Playing -> Failed (Trigger: Player dies)
  - Playing -> Restarting (Trigger: Manual restart input)
  - Failed -> Restarting (Trigger: Automatic or manual restart input)
  - Restarting -> Playing (Trigger: State reset complete)

# MDA Analysis
- **Mechanics**: The system resets the player's position, level state, and timers to their initial values instantly without reloading assets.
- **Dynamics**: Players are encouraged to take risks and experiment, as the penalty for failure (time lost) is minimized. This leads to rapid iteration and learning.
- **Aesthetics**: Creates a feeling of "flow", determination, and addiction ("just one more try"). Reduces frustration typically associated with failure.

# Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value | Unit |
|---|---|---|---|---|
| restart_delay | f32 | 0.0 - 1.0 | 0.1 (Super Meat Boy v1.2) | seconds |
| fade_duration | f32 | 0.0 - 0.5 | 0.0 (Celeste v1.4) | seconds |
| auto_restart | bool | true/false | true (Flappy Bird v1.0) | boolean |

# Benchmark Data
- **Super Meat Boy (v1.2)**: restart_delay = 0.1s, fade_duration = 0.0s, auto_restart = false
- **Celeste (v1.4)**: restart_delay = 0.2s, fade_duration = 0.0s, auto_restart = false
- **Flappy Bird (v1.0)**: restart_delay = 0.5s, fade_duration = 0.2s, auto_restart = true

# Common Variants
1. **Manual Quick Restart**: Player must press a dedicated button to restart (e.g., Super Meat Boy).
2. **Auto-Restart on Death**: The game automatically restarts after a brief death animation (e.g., Flappy Bird).
3. **Rewind**: Instead of a full restart, the player rewinds time to a safe state (e.g., Braid).
4. **Checkpoint Restart**: Restarts at the last checkpoint rather than the beginning of the level (e.g., Celeste).

# Compatibility Notes
- **Compatible Atoms**: atom_checkpoints, atom_speedrun_timer, atom_one_hit_kill
- **Incompatible Atoms**: atom_permadeath, atom_long_loading_screens, atom_unskippable_cutscenes

# Anti-Patterns
1. **Forced Unskippable Death Animations**: Defeats the purpose of an instant restart by introducing a delay.
2. **State Leakage**: Failing to properly reset all variables (e.g., enemy positions, timers), leading to bugs on restart.
3. **Loss of Flow**: Requiring the player to navigate menus to restart instead of a single button press.
