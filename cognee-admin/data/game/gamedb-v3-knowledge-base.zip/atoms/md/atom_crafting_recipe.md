# Identity
- **Atom ID**: atom_crafting_recipe
- **English Name**: Crafting Recipe
- **Chinese Name**: 制造配方
- **Category**: C
- **Definition**: A structured rule defining the required input resources, conditions, and time to produce a specific output item or entity.

# Core Verb & State Machine
- **Core Verb**: Craft
- **State Diagram**:
  [Idle] --(Initiate Crafting)--> [Crafting]
  [Crafting] --(Time Elapsed)--> [Completed]
  [Crafting] --(Cancel)--> [Idle]
  [Completed] --(Collect)--> [Idle]
- **States**: Idle, Crafting, Completed
- **Transitions**:
  - Idle -> Crafting: Triggered by player initiating craft with sufficient resources.
  - Crafting -> Completed: Triggered by crafting time elapsed.
  - Crafting -> Idle: Triggered by player cancellation.
  - Completed -> Idle: Triggered by player collecting the output.

# MDA Analysis
- **Mechanics**: The system checks player inventory against recipe requirements. If met, it consumes inputs and initiates a timer (or instant). Upon completion, it grants the output.
- **Dynamics**: Players optimize resource gathering and production chains to maximize output efficiency.
- **Aesthetics**: Satisfaction of creation, progression, and mastering complex production systems.

# Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value | Unit |
|---|---|---|---|---|
| input_quantities | array[u32] | 1-100 | 5 (Minecraft 1.20) | items |
| output_quantity | u32 | 1-64 | 1 (Minecraft 1.20) | items |
| crafting_time | f32 | 0.0-600.0 | 0.5 (Factorio 1.1) | seconds |
| success_chance | f32 | 0.0-1.0 | 1.0 (Terraria 1.4) | percentage |

# Benchmark Data
- **Minecraft (1.20)**: crafting_time = 0.0s, success_chance = 1.0
- **Factorio (1.1)**: crafting_time = 0.5s (Iron Gear Wheel), success_chance = 1.0
- **Terraria (1.4)**: crafting_time = 0.0s, success_chance = 1.0

# Common Variants
1. **Instant Crafting**: Output is generated immediately upon request (Minecraft).
2. **Time-Delayed Crafting**: Output requires time to process (Factorio).
3. **Probabilistic Crafting**: Crafting has a chance to fail or produce varied quality (MMORPGs).
4. **Minigame Crafting**: Player must complete a minigame to determine success/quality.

# Compatibility Notes
- **Compatible Atoms**: atom_inventory, atom_resource_node, atom_tech_tree
- **Incompatible Atoms**: None typically, but conflicts with purely action-based progression without items.

# Anti-Patterns
1. **Overly Complex Recipes**: Requiring too many nested sub-components without adequate inventory space.
2. **Hidden Requirements**: Not clearly communicating what is needed to craft an item.
3. **Meaningless Wait Times**: Adding long crafting times without a strategic reason or offline progression.
