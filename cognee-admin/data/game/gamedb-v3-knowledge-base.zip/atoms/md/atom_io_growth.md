# Identity
- **Atom ID**: atom_io_growth
- **English Name**: IO Growth (Eat to Grow)
- **Chinese Name**: IO成长(大鱼吃小鱼)
- **Category**: G+H
- **Definition**: A core gameplay loop where entities consume smaller entities or resources to increase their own size, mass, or power, while avoiding being consumed by larger entities.

# Core Verb & State Machine
- **Primary Player Verb**: Consume / Move
- **State Diagram**:
  - `Spawning` -> `Active`
  - `Active` -> `Consuming` (when overlapping smaller entity)
  - `Consuming` -> `Active` (after growth applied)
  - `Active` -> `Fleeing` (when near larger entity)
  - `Active` -> `Dead` (when consumed by larger entity)
- **States**: Spawning, Active, Consuming, Fleeing, Dead
- **Transitions**:
  - Spawning to Active: Initialization complete
  - Active to Consuming: Collision with smaller mass
  - Consuming to Active: Mass absorbed
  - Active to Fleeing: Proximity to larger mass
  - Active to Dead: Collision with larger mass

# MDA Analysis
- **Mechanics**: Players control an entity that moves around a bounded arena. The entity has a mass value. Collisions between entities result in the larger entity absorbing the mass of the smaller one. Movement speed is often inversely proportional to mass.
- **Dynamics**: Players constantly evaluate risk vs. reward. Small players move quickly to gather passive resources and avoid large players. Large players move slowly and try to corner or trap smaller players.
- **Aesthetics**: Tension, thrill of the chase, satisfaction of growth, fear of sudden loss.

# Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value | Unit |
|---|---|---|---|---|
| `base_speed` | f32 | 10.0 - 50.0 | 30.0 (Agar.io v1.0) | units/sec |
| `speed_decay_factor` | f32 | 0.1 - 0.9 | 0.5 (Agar.io v1.0) | multiplier |
| `starting_mass` | f32 | 10.0 - 100.0 | 10.0 (Agar.io v1.0) | mass units |
| `mass_absorption_rate` | f32 | 0.5 - 1.0 | 1.0 (Agar.io v1.0) | multiplier |
| `passive_mass_loss` | f32 | 0.0 - 0.05 | 0.002 (Agar.io v1.0) | mass/sec |

# Benchmark Data
- **Agar.io (v1.0)**: `base_speed` = 30.0, `speed_decay_factor` = 0.5, `starting_mass` = 10.0, `mass_absorption_rate` = 1.0, `passive_mass_loss` = 0.002
- **Slither.io (v1.0)**: `base_speed` = 40.0, `speed_decay_factor` = 0.0 (speed is constant but turning radius increases), `starting_mass` = 10.0, `mass_absorption_rate` = 0.8, `passive_mass_loss` = 0.0

# Common Variants
1. **Snake-like Growth**: Instead of a single blob, the entity grows in length (e.g., Slither.io).
2. **Weaponized Growth**: Growth increases weapon size or range instead of just body mass (e.g., Diep.io).
3. **Swarm Growth**: The entity is a swarm of smaller units; consuming adds more units to the swarm (e.g., Hole.io).
4. **Black Hole**: The entity is a hole that grows by consuming environment objects (e.g., Hole.io).

# Compatibility Notes
- **Compatible Atoms**: atom_movement_joystick, atom_split_mechanic, atom_dash_mechanic
- **Conflicts**: atom_fixed_camera (usually requires a dynamic camera that scales with player size)

# Anti-Patterns
1. **Snowball Effect**: If large players have no disadvantages (like slower speed), they become unstoppable, ruining the experience for new players.
2. **Infinite Growth**: Without passive mass loss or a size cap, the server can become unstable or the screen unreadable.
3. **Spawn Killing**: Spawning new players near massive players leads to immediate death and frustration.
