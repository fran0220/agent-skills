# Identity
- **Atom ID**: atom_parry_riposte
- **English Name**: Parry / Riposte
- **Chinese Name**: 弹反/处决
- **Category**: A+B
- **Definition**: A defensive maneuver that, when timed perfectly against an incoming attack, nullifies damage and creates a window of vulnerability in the attacker, often allowing for a devastating counter-attack (riposte).

# Core Verb & State Machine
- **Core Verb**: Deflect / Counter
- **State Diagram**:
  Idle -> Startup (Parry initiated)
  Startup -> Active (Parry window)
  Active -> Recovery (Parry missed)
  Active -> Success (Attack deflected)
  Success -> Riposte (Counter-attack initiated)
  Riposte -> Idle
  Recovery -> Idle

# MDA Analysis
- **Mechanics**: The system checks the collision of an incoming attack hitbox against a specific parry hurtbox or state during a precise frame window. If they intersect, the attack is negated, and the attacker's state is changed to 'staggered' or 'vulnerable'.
- **Dynamics**: Players learn enemy attack patterns to anticipate the exact moment to parry. This creates a high-risk, high-reward dynamic where failure results in taking full damage, but success yields a significant advantage.
- **Aesthetics**: The player feels a sense of mastery, tension, and immense satisfaction. The audiovisual feedback (sparks, loud clang, dramatic camera angle) enhances the feeling of power and precision.

# Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value (Game) | Unit |
|---|---|---|---|---|
| startup_frames | u32 | 1-15 | 4 (Dark Souls III v1.15) | frames |
| active_frames | u32 | 2-12 | 6 (Dark Souls III v1.15) | frames |
| recovery_frames | u32 | 10-40 | 20 (Dark Souls III v1.15) | frames |
| vulnerability_duration | f32 | 1.0-4.0 | 2.5 (Sekiro v1.06) | seconds |
| damage_multiplier | f32 | 1.5-4.0 | 2.0 (Metal Gear Rising) | multiplier |

# Benchmark Data
- **Dark Souls III (v1.15)**: Small Shield Parry - Startup: 4 frames, Active: 6 frames, Recovery: 20 frames.
- **Sekiro: Shadows Die Twice (v1.06)**: Deflect - Startup: 1 frame, Active: 12 frames (decreases on spam), Posture Damage: High.
- **Metal Gear Rising: Revengeance (v1.00)**: Parry - Startup: 1 frame, Active: variable (based on input), Counter Damage Multiplier: 2.0x.

# Common Variants
1. **Perfect Guard**: Reduces damage to 0 and stamina cost, but doesn't necessarily open the enemy to a riposte (e.g., Lies of P).
2. **Directional Parry**: Requires matching the direction of the incoming attack (e.g., For Honor).
3. **Projectile Reflection**: Parrying a projectile sends it back to the sender (e.g., The Legend of Zelda: Breath of the Wild).
4. **Magic/Spell Parry**: Specifically designed to deflect or absorb magical attacks.

# Compatibility Notes
- **Compatible Atoms**: atom_dodge, atom_block, atom_stamina_management, atom_posture_break.
- **Conflicts**: atom_auto_guard (can interfere with manual parry timing).

# Anti-Patterns
1. **Unreadable Attacks**: Enemy attacks with no telegraphing make parrying feel like luck rather than skill.
2. **Inconsistent Windows**: Varying the active frames of a parry unpredictably frustrates players.
3. **Low Reward**: If the riposte damage is lower than a standard combo, players will ignore the mechanic due to the high risk.
