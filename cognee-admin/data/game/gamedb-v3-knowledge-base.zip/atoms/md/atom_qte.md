# Gameplay Atom: Quick Time Event (QTE)

## 1. Identity
- **Atom ID:** `atom_qte`
- **English Name:** Quick Time Event
- **Chinese Name:** 快速反应事件
- **Category:** A
- **Definition:** A Quick Time Event (QTE) is a method of context-sensitive gameplay in which the player performs actions on the control device shortly after the appearance of an on-screen prompt. It allows for limited control of the player character during cutscenes or cinematic sequences, testing the player's reflexes and attention rather than their mastery of the game's core mechanics.

## 2. Core Verb & State Machine
- **Core Verb:** React / Press
- **State Diagram:**
  ```text
  [Idle] --> (Trigger Event) --> [Prompt Displayed]
  [Prompt Displayed] --> (Correct Input) --> [Success]
  [Prompt Displayed] --> (Incorrect Input) --> [Failure]
  [Prompt Displayed] --> (Timeout) --> [Failure]
  [Success] --> (Sequence Complete) --> [End]
  [Success] --> (Next Prompt) --> [Prompt Displayed]
  [Failure] --> (Penalty/Death) --> [End]
  ```
- **States:**
  - `Idle`: The system is waiting for a cinematic or gameplay trigger.
  - `Prompt Displayed`: The UI shows the required input and a timer starts.
  - `Success`: The player provided the correct input within the time limit.
  - `Failure`: The player provided the wrong input or ran out of time.
  - `End`: The QTE sequence concludes, returning to normal gameplay or triggering a cutscene.
- **Transitions:**
  - `Idle` -> `Prompt Displayed`: Triggered by a specific event in the game.
  - `Prompt Displayed` -> `Success`: Triggered by correct player input.
  - `Prompt Displayed` -> `Failure`: Triggered by incorrect input or timeout.
  - `Success` -> `End`: Triggered when the sequence is complete.
  - `Success` -> `Prompt Displayed`: Triggered when a multi-stage QTE requires another input.
  - `Failure` -> `End`: Triggered after applying the failure penalty.

## 3. MDA Analysis
- **Mechanics:** The system displays a specific button prompt on the screen for a limited duration. It listens for player input and compares it against the expected input. It tracks the time elapsed and resolves the event as a success or failure based on the input correctness and timing.
- **Dynamics:** Players experience a sudden shift from passive observation (watching a cutscene) to active participation. The time pressure forces quick decision-making and reflex actions. In multi-stage QTEs, players may develop a rhythm or anticipate prompts based on the on-screen action.
- **Aesthetics:** Tension, surprise, and relief. The sudden appearance of a prompt creates a spike in adrenaline. Successfully completing a QTE provides a sense of accomplishment and cinematic flair, while failure can lead to frustration or amusement depending on the penalty.

## 4. Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value (Game) | Unit |
|---|---|---|---|---|
| `time_limit` | `f32` | 0.5 - 3.0 | 1.5 (God of War 2018) | seconds |
| `prompt_type` | `enum` | Single, Mash, Hold | Single | N/A |
| `mash_target` | `u32` | 5 - 20 | 10 (Resident Evil 4) | presses |
| `mash_decay` | `f32` | 0.1 - 2.0 | 0.5 | presses/sec |
| `hold_duration` | `f32` | 1.0 - 5.0 | 2.0 | seconds |
| `wrong_input_penalty` | `bool` | True/False | True | N/A |

## 5. Benchmark Data
- **God of War (2018) - v1.0:**
  - `time_limit`: 1.5s for standard single-button prompts.
  - `mash_target`: 15 presses for heavy attacks.
  - `wrong_input_penalty`: True (often results in taking damage or failing the sequence).
- **Resident Evil 4 (2005) - v1.0:**
  - `time_limit`: 0.8s for sudden death evasions (e.g., dodging boulders).
  - `mash_target`: 10 presses for escaping grabs.
  - `wrong_input_penalty`: True (instant death in many cases).
- **Bayonetta (2009) - v1.0:**
  - `time_limit`: 1.0s for Torture Attacks.
  - `mash_target`: Variable, often requires rapid mashing to maximize bonus halos.
  - `wrong_input_penalty`: False (failure usually just means less bonus score, not death).

## 6. Common Variants
1. **Single Button Press:** The most basic form; press the displayed button before time runs out.
2. **Button Mashing:** Repeatedly press a specific button to fill a gauge or overpower an enemy.
3. **Hold and Release:** Hold a button for a specific duration or release it at a precise moment.
4. **Directional Input:** Move the analog stick in a specific direction or perform a sequence of directional inputs.
5. **Rhythm QTE:** Press buttons in time with music or visual cues, often seen in rhythm games or specific mini-games.

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_cinematic_camera` (often paired to create dramatic angles during the QTE), `atom_execution` (used as the input method for finishing moves), `atom_grapple` (used to escape or win a grapple state).
- **Incompatible Atoms:** `atom_free_aim` (QTEs usually lock the camera and player movement, conflicting with free aiming), `atom_inventory_management` (opening menus during a QTE breaks the flow and timing).

## 8. Anti-Patterns
1. **Unpredictable Prompts:** Placing QTEs in long cutscenes where the player has likely put down the controller, leading to unfair failures.
2. **Overuse:** Relying too heavily on QTEs for boss fights instead of core combat mechanics, making the gameplay feel shallow and interactive-movie-like.
3. **Instant Death on Minor Failure:** Punishing the player with instant death and a long loading screen for missing a single prompt in a long sequence, causing immense frustration.
