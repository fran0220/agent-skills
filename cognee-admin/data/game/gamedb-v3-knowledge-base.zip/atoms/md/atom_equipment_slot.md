# Equipment Slot (atom_equipment_slot)

## 1. Identity
- **Atom ID:** `atom_equipment_slot`
- **English Name:** Equipment Slot
- **Chinese Name:** 装备栏位
- **Category:** C (Character/Customization)
- **Definition:** An equipment slot is a designated logical space on a character or entity where specific types of items can be equipped. When an item is placed in a slot, it typically grants the character statistical bonuses, new abilities, or cosmetic changes, serving as a primary vector for player progression and build customization.

## 2. Core Verb & State Machine
- **Primary Player Verb:** Equip / Unequip / Swap
- **State Diagram:**
  ```text
  [Empty] <--(Unequip)-- [Equipped]
     |                       ^
     |                       |
     +-------(Equip)---------+
     |                       |
     +-------(Swap)----------+
  ```
- **States:**
  - `Empty`: The slot contains no item. No bonuses are applied.
  - `Equipped`: The slot contains a valid item. The item's modifiers are active.
- **Transitions:**
  - `Empty -> Equipped`: Triggered when the player equips a valid item into the empty slot.
  - `Equipped -> Empty`: Triggered when the player unequips the item, returning it to the inventory.
  - `Equipped -> Equipped`: Triggered when the player swaps the currently equipped item with a new one directly.

## 3. MDA Analysis
- **Mechanics:** The system defines specific slots (e.g., Head, Chest, Weapon) and validates item types against these slot restrictions before allowing an equip action. Once equipped, the system reads the item's properties and applies the corresponding modifiers to the character's base stats.
- **Dynamics:** Players engage in inventory management and loadout optimization. They constantly evaluate trade-offs (e.g., sacrificing defense for offense) and seek out synergistic combinations of items across different slots to maximize their effectiveness in specific encounters.
- **Aesthetics:** The system fosters a sense of *Progression* as players acquire better gear to fill their slots. It also supports *Expression* by allowing players to customize their character's appearance and playstyle, fulfilling the fantasy of growing from a novice to a powerful hero.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Game/Version) | Unit |
|---|---|---|---|---|
| `slot_id` | string | N/A | "head" (WoW 1.12) | N/A |
| `accepted_types` | list | 1-5 types | ["helmet", "hat"] (Diablo II 1.14) | N/A |
| `max_capacity` | u32 | 1-2 | 1 (Elden Ring 1.09) | count |
| `stat_multiplier` | f32 | 0.0 - 2.0 | 1.0 (WoW 1.12) | multiplier |
| `is_unlocked` | bool | true/false | true (Elden Ring 1.09) | boolean |

## 5. Benchmark Data
- **Diablo II (1.14):** Features 10 standard equipment slots: Head, Amulet, Body Armor, Weapon 1, Shield 1, Ring 1, Ring 2, Belt, Boots, and Gloves. Weapons and shields can be swapped to a secondary set (Weapon 2, Shield 2).
- **World of Warcraft (1.12):** Features 19 distinct slots, including specialized slots like Ranged/Relic, Tabard, Shirt, and two Trinket slots, allowing for highly granular stat customization.
- **Elden Ring (1.09):** Features 4 armor slots (Head, Chest, Arms, Legs), up to 4 Talisman slots (unlocked progressively), and 6 weapon slots (3 for the left hand, 3 for the right hand), emphasizing quick swapping during combat.

## 6. Common Variants
- **Universal Slots:** Slots that accept any type of item, often used for modular upgrades (e.g., Jewel sockets in *Path of Exile* or Materia slots in *Final Fantasy VII*).
- **Progressive/Unlockable Slots:** The player starts with a limited number of slots and unlocks more through gameplay progression (e.g., Talisman Pouches in *Elden Ring*).
- **Multi-Slot Items:** Items that are so large or complex they occupy multiple slots simultaneously (e.g., a two-handed weapon occupying both the main-hand and off-hand slots).
- **Degrading Slots:** Slots that apply wear and tear to the equipped item over time or usage, eventually requiring repair or replacement.

## 7. Compatibility Notes
- **Commonly Pairs With:** `atom_inventory` (source of items), `atom_stat_modifier` (applying the item's effects), `atom_item_durability` (tracking wear).
- **Known Conflicts:** `atom_class_restriction` can cause conflicts if an item is valid for a slot but invalid for the character's class, requiring clear UI feedback to resolve the ambiguity.

## 8. Anti-Patterns
- **Slot Bloat:** Providing too many slots with marginal impacts, causing cognitive overload and making gear upgrades feel insignificant.
- **Illusion of Choice:** Designing slots where only one specific item or type is ever mathematically optimal, eliminating actual player decision-making.
- **Hidden Dependencies:** Implementing rules where equipping an item in one slot silently unequips or disables another slot without clear explanation to the player.
