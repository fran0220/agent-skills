# Identity
The `atom_festival_event` gameplay atom, known as Festival / Seasonal Event in English and 节日/季节活动 in Chinese, belongs to the G/H category. It is defined as a time-limited, recurring or unique event within the game world that alters normal gameplay routines, introduces special activities, and fosters community engagement or narrative progression.

# Core Verb & State Machine
The primary player verb for this atom is to Participate or Celebrate. The state machine for a festival event involves several key states and transitions.

The state diagram can be represented as follows:
[Idle] -> (Time Trigger) -> [Announced]
[Announced] -> (Start Time) -> [Active]
[Active] -> (Player Participates) -> [Engaged]
[Engaged] -> (Complete Activity) -> [Rewarded]
[Rewarded] -> (End Time) -> [Concluded]
[Active] -> (End Time) -> [Concluded]
[Concluded] -> (Reset) -> [Idle]

The system begins in the `Idle` state, which represents the normal game state with no festival active. When triggered by an in-game calendar or real-world date, it transitions to the `Announced` state, notifying players of an upcoming festival. Once the start time is reached, the state becomes `Active`, meaning the festival is ongoing and special activities are available. If a player interacts with a festival NPC or object, the state shifts to `Engaged`, indicating active participation in a festival minigame or quest. Upon successful completion of the activity, the state moves to `Rewarded`, where the player receives rewards. When the festival duration expires, whether from the `Rewarded` or `Active` state, it transitions to `Concluded`. Finally, a system reset after the event returns the state to `Idle`.

# MDA Analysis
From a Mechanics perspective, this atom involves the time-gated availability of specific zones, NPCs, minigames, and exclusive loot tables. It often includes the modification of existing game rules, such as closing regular shops or introducing a special currency.

In terms of Dynamics, players typically alter their daily routines to prioritize festival activities. This creates emergent social behaviors as players gather in specific locations or collaborate on event goals. The Fear of Missing Out (FOMO) serves as a strong driver for player engagement during the limited time window.

The Aesthetics of this atom focus on Fellowship, allowing players to socialize with NPCs or other players. It also emphasizes Discovery by providing new content to experience, and Submission by offering an enjoyable break from the core gameplay loop.

# Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value | Unit |
|---|---|---|---|---|
| `duration_days` | u32 | 1 - 30 | 14 (Genshin Impact v4.0) | Days |
| `preparation_time` | u32 | 1 - 7 | 3 (Stardew Valley v1.5) | Days |
| `exclusive_currency_rate` | f32 | 0.5 - 5.0 | 1.5 (Animal Crossing: NH v2.0) | Currency/Min |
| `participation_reward_multiplier` | f32 | 1.0 - 3.0 | 2.0 (Genshin Impact v4.0) | Multiplier |
| `minigame_difficulty_scaling` | f32 | 0.8 - 1.5 | 1.0 (Stardew Valley v1.5) | Multiplier |

# Benchmark Data
In Stardew Valley (v1.5), the `duration_days` is typically set to 1, with a `preparation_time` of 3 days and a `minigame_difficulty_scaling` of 1.0.

Animal Crossing: New Horizons (v2.0) features a `duration_days` of 1 for its events, accompanied by an `exclusive_currency_rate` of 1.5.

Genshin Impact (v4.0) generally runs events with a `duration_days` of 14, offering a `participation_reward_multiplier` of 2.0.

# Common Variants
Real-World Synchronized events mirror real-world holidays, such as Halloween or Christmas, exactly in real-time, as seen in Animal Crossing.

In-Game Calendar events occur on specific dates within the game's accelerated time system, a common approach in Stardew Valley.

Web/Meta Events require participation outside the core game client, often via a web browser, to earn in-game rewards, which is frequently utilized in Genshin Impact.

Community Milestone events involve the entire player base contributing to a shared goal to unlock rewards for everyone.

# Compatibility Notes
This atom is highly compatible with `atom_minigame`, `atom_exclusive_loot`, `atom_daily_quest`, and `atom_social_hub`.

However, it is generally incompatible with `atom_permadeath_hardcore`, as it often conflicts with the lighthearted nature of festivals, and `atom_time_pause`, which disrupts the time-limited nature of events.

# Anti-Patterns
One common anti-pattern is Excessive Grind, where making the festival rewards require an unreasonable amount of repetitive grinding leads to player burnout rather than enjoyment.

Another issue is Punishing FOMO, which involves locking crucial progression items behind a time-limited event, permanently disadvantaging players who miss it.

Finally, Immersion Breaking occurs when introducing a festival that completely contradicts the established lore or tone of the game world without any narrative explanation.
