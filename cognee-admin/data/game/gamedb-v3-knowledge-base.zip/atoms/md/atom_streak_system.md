# Gameplay Atom: Daily Streak

## 1. Identity
- **Atom ID:** `atom_streak_system`
- **English Name:** Daily Streak
- **Chinese Name:** 每日连续打卡
- **Category:** E (Engagement)
- **Definition:** A retention mechanism that rewards players for performing a specific action on consecutive days. If the player misses a day, the streak resets to zero, creating a loss aversion dynamic that encourages daily engagement.

## 2. Core Verb & State Machine
- **Core Verb:** Check-in / Play daily

**State Diagram:**
```text
[Inactive] --(First Check-in)--> [Active Streak]
[Active Streak] --(Daily Check-in)--> [Active Streak (Incremented)]
[Active Streak] --(Missed Day)--> [Broken Streak]
[Broken Streak] --(Streak Freeze/Repair)--> [Active Streak]
[Broken Streak] --(New Check-in)--> [Active Streak (Reset to 1)]
```

**States:**
- `Inactive`: The player has not started a streak.
- `Active Streak`: The player has checked in for one or more consecutive days.
- `Broken Streak`: The player missed a check-in window.

**Transitions:**
- `Inactive` -> `Active Streak`: Triggered by the first check-in.
- `Active Streak` -> `Active Streak`: Triggered by checking in within the valid daily window.
- `Active Streak` -> `Broken Streak`: Triggered by failing to check in before the window expires.
- `Broken Streak` -> `Active Streak`: Triggered by using a streak repair item or starting over.

## 3. MDA Analysis
- **Mechanics:** The system tracks the number of consecutive days a player logs in or completes a core action. It provides escalating or milestone-based rewards as the streak count increases. It enforces a strict time window (usually 24 hours or tied to a daily server reset) for the action.
- **Dynamics:** Players develop a daily habit. As the streak grows, the perceived value of the streak increases, leading to loss aversion. Players may log in solely to maintain the streak even if they don't intend to play a full session.
- **Aesthetics:** A sense of accomplishment, commitment, and routine. Fear of missing out (FOMO) and anxiety about losing progress. Relief when a streak is maintained or repaired.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Game) | Unit |
| --- | --- | --- | --- | --- |
| `grace_period_hours` | u32 | 0 - 48 | 24 (Duolingo v6.1) | hours |
| `max_streak_rewards` | u32 | 7 - 30 | 7 (Genshin Impact v4.0) | days |
| `streak_freeze_cost` | u32 | 0 - 1000 | 200 (Duolingo v6.1) | gems/currency |
| `reward_multiplier` | f32 | 1.0 - 5.0 | 1.5 (Wordle Web) | multiplier |

## 5. Benchmark Data
- **Duolingo (v6.1):**
  - `grace_period_hours`: 24 (resets at midnight local time)
  - `streak_freeze_cost`: 200 gems
  - `max_streak_rewards`: Infinite visual tracking, milestone rewards every 7/30/100 days.
- **Wordle (Web 2023):**
  - `grace_period_hours`: 24 (resets at midnight local time)
  - `reward_multiplier`: 1.0 (purely visual/bragging rights, no in-game currency)
  - `max_streak_rewards`: Infinite visual tracking.

## 6. Common Variants
1. **Milestone Streak:** Rewards are only given at specific milestones (e.g., Day 7, Day 30) rather than escalating daily.
2. **Forgiving Streak:** Allows missing one day per week without breaking the streak, or provides free "streak freezes".
3. **Escalating Multiplier:** The core gameplay rewards (e.g., XP, Gold) are multiplied by a factor that increases with the streak length, capping at a certain point.
4. **Weekend Warrior:** A streak system that only applies to weekends or specific event days.

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_daily_quests` (Daily Quests), `atom_login_rewards` (Login Rewards), `atom_battle_pass` (Battle Pass).
- **Incompatible Atoms:** `atom_binge_play` (mechanics encouraging playing for 10+ hours in one sitting), `atom_permadeath` (if death resets out-of-match streaks).

## 8. Anti-Patterns
1. **Punishing Resets:** Making the loss of a long streak so devastating that the player quits the game entirely rather than starting over.
2. **Meaningless Streaks:** Tracking a streak without providing any visual flair, social recognition, or tangible rewards, leading to player apathy.
3. **Timezone Frustration:** Using strict UTC resets for a global audience, causing players to accidentally miss their streak due to local time confusion.
