# Gameplay Atom: Seasonal Rank / Ladder

## 1. Identity
- **Atom ID:** `atom_season_rank`
- **English Name:** Seasonal Rank / Ladder
- **Chinese Name:** 赛季排名/天梯
- **Category:** Category E (Meta-game & Progression)
- **Definition:** A competitive progression system that evaluates and ranks players based on their performance in matches over a predefined period (a "season"). At the end of the season, ranks are typically reset or soft-reset, and rewards are distributed based on the highest or final rank achieved.

## 2. Core Verb & State Machine
- **Core Verb:** Compete / Climb
- **State Diagram:**
  [Unranked] --> (Play Placement Matches) --> [Ranked]
  [Ranked] --> (Win Match) --> [Gain RP/LP] --> [Rank Up]
  [Ranked] --> (Lose Match) --> [Lose RP/LP] --> [Rank Down]
  [Ranked] --> (Season Ends) --> [Season Rewards] --> [Soft Reset] --> [Unranked]

- **States:**
  - `Unranked`: Player has no visible rank, usually requires placement matches.
  - `Ranked`: Player has an active rank and rating points.
  - `Rank Up`: Transition state when crossing an upper threshold.
  - `Rank Down`: Transition state when crossing a lower threshold.
  - `Season End`: Temporary state for reward distribution and reset.

- **Transitions:**
  - `Unranked` -> `Ranked`: Triggered by completing `N` placement matches.
  - `Ranked` -> `Ranked`: Triggered by completing a match (RP changes but tier remains).
  - `Ranked` -> `Rank Up`: Triggered when RP exceeds the current tier's maximum.
  - `Ranked` -> `Rank Down`: Triggered when RP falls below zero at the lowest division of a tier (often with demotion protection).
  - `Ranked` -> `Unranked`: Triggered by the end of the season.

## 3. MDA Analysis
- **Mechanics:** The system tracks wins, losses, and individual performance to calculate a hidden Matchmaking Rating (MMR) and a visible Rank Point (RP) value. Players are grouped into tiers (e.g., Bronze, Silver, Gold). Seasons dictate the timeframe for this progression.
- **Dynamics:** Players experience "ladder anxiety" or "grind." The soft reset at the start of a season creates a rush of activity. Demotion protection creates "floors" where players might experiment or play less seriously.
- **Aesthetics:** Challenge, Fellowship (in team games), and Submission (grinding). Players feel a sense of prestige and accomplishment when reaching a new tier, and frustration or determination when losing.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Game/Ver) | Unit |
| --- | --- | --- | --- | --- |
| `placement_matches` | u32 | 5 - 10 | 5 (League of Legends v13.1) | matches |
| `season_duration_days` | u32 | 30 - 120 | 90 (Apex Legends S18) | days |
| `tiers_count` | u32 | 5 - 10 | 9 (Valorant Ep 7) | tiers |
| `divisions_per_tier` | u32 | 3 - 5 | 4 (League of Legends v13.1) | divisions |
| `points_per_division` | u32 | 100 - 1000 | 100 (League of Legends v13.1) | points |
| `win_point_gain` | f32 | 10.0 - 30.0 | 20.0 (League of Legends v13.1) | points |
| `loss_point_deduction` | f32 | 10.0 - 30.0 | 15.0 (League of Legends v13.1) | points |
| `demotion_protection_games` | u32 | 0 - 3 | 3 (Valorant Ep 7) | matches |

## 5. Benchmark Data
- **League of Legends (v13.1):**
  - Placement Matches: 5
  - Tiers: 10 (Iron to Challenger)
  - Divisions per Tier: 4 (for lower tiers)
  - Points per Division: 100 LP
  - Soft Reset Multiplier: ~0.5 to MMR distance from average.
- **Apex Legends (Season 18):**
  - Placement Matches: 10
  - Tiers: 7 (Rookie to Apex Predator)
  - Points per Division: 1000 LP
  - Entry Cost: Varies by tier (e.g., 50 LP for Silver).
- **Valorant (Episode 7):**
  - Placement Matches: 5
  - Tiers: 9 (Iron to Radiant)
  - Divisions per Tier: 3
  - Points per Division: 100 RR

## 6. Common Variants
1. **Zero-Sum vs. Inflationary:** Chess Elo is strictly zero-sum, while many modern games (Apex Legends) inject points into the economy to ensure active players climb over time.
2. **Hidden MMR vs. Visible Rating:** Some games only show a rank tier and hide the exact rating, while others show the exact MMR number (e.g., Dota 2 historically).
3. **Decay Systems:** High ranks often feature point decay if the player doesn't play for a certain number of days, forcing active participation to maintain top leaderboard spots.
4. **Split Seasons:** A single season is divided into two "splits" with a soft reset in between to maintain engagement (e.g., Apex Legends).

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_matchmaking_rating`, `atom_battle_pass`, `atom_daily_quests`
- **Incompatible Atoms:** `atom_permadeath`, `atom_sandbox_creative`

## 8. Anti-Patterns
1. **Excessive Grind:** Making the point gain too low compared to the season duration, causing players to burn out before reaching their true rank.
2. **Opaque Placement:** Not giving players any feedback during placement matches, leading to confusion and frustration when the final rank is revealed.
3. **Rank Inflation:** Injecting too many points into the system without sinks, causing the highest tiers to become overcrowded and lose their prestige by the end of the season.
