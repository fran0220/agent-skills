# Gameplay Atom: Endless / Infinite Mode

## 1. Identity
- **Atom ID:** `atom_endless_mode`
- **English Name:** Endless / Infinite Mode
- **Chinese Name:** 无尽模式
- **Category:** G/H (Game Modes / Progression)
- **Definition:** A gameplay mode where the game does not have a predefined end or victory condition. Instead, the player continues to play until they fail (e.g., die, run out of time, or fail an objective), with the primary goal usually being to achieve the highest possible score, survive the longest time, or travel the furthest distance. The difficulty typically scales up over time to ensure eventual failure.

## 2. Core Verb & State Machine
- **Core Verb:** Survive / Progress
- **State Diagram:**
  ```text
  [Start] --> (Playing)
  (Playing) --> (Difficulty Increase) : Time/Score Threshold Reached
  (Difficulty Increase) --> (Playing) : Applied
  (Playing) --> (Game Over) : Player Fails (Health = 0, Time = 0, etc.)
  (Game Over) --> [End/Restart]
  ```
- **States:**
  - `Start`: Initialization of the endless environment and player state.
  - `Playing`: The core loop where the player interacts with the game.
  - `Difficulty Increase`: A transitional state where parameters (speed, spawn rate, enemy health) are adjusted to increase challenge.
  - `Game Over`: The failure state where the run ends and the score is finalized.
- **Transitions:**
  - `Start` -> `Playing`: Player initiates the run.
  - `Playing` -> `Difficulty Increase`: Triggered by internal metrics (time elapsed, distance covered).
  - `Difficulty Increase` -> `Playing`: Immediate return after parameter adjustment.
  - `Playing` -> `Game Over`: Triggered by a failure condition.

## 3. MDA Analysis
- **Mechanics:** The system continuously generates content (obstacles, enemies, terrain) and progressively increases the difficulty parameters (e.g., movement speed, spawn frequency) without a cap, until the player's skill is overwhelmed.
- **Dynamics:** Players experience a rhythm of flow that gradually shifts from easy/boring to challenging, and eventually to overwhelming. They must adapt to the increasing pace and optimize their reaction times or resource management.
- **Aesthetics:** Tension, Flow, and Challenge. The player feels a sense of adrenaline and "just one more try" compulsion (addictive loop) driven by the desire to beat their own or others' high scores.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Game) | Unit |
|---|---|---|---|---|
| `base_speed` | f32 | 5.0 - 20.0 | 10.0 (Temple Run v1.0) | m/s |
| `speed_multiplier` | f32 | 1.01 - 1.10 | 1.05 (Subway Surfers v1.0) | per minute |
| `max_speed` | f32 | 30.0 - 100.0 | 50.0 (Temple Run v1.0) | m/s |
| `spawn_rate_base` | f32 | 0.5 - 5.0 | 2.0 (Subway Surfers v1.0) | obstacles/sec |
| `difficulty_curve_exponent` | f32 | 1.0 - 2.0 | 1.2 (Temple Run v1.0) | N/A |

## 5. Benchmark Data
- **Temple Run (v1.0):**
  - `base_speed`: 10.0 m/s
  - `max_speed`: 50.0 m/s
  - `difficulty_curve_exponent`: 1.2
- **Subway Surfers (v1.0):**
  - `base_speed`: 8.0 m/s
  - `speed_multiplier`: 1.05 per minute
  - `spawn_rate_base`: 2.0 obstacles/sec

## 6. Common Variants
1. **Endless Runner:** The player character moves forward automatically, and the player only controls dodging/jumping (e.g., Temple Run, Subway Surfers).
2. **Survival Horde / Arena:** The player is confined to an arena and must survive endless waves of enemies (e.g., Vampire Survivors, Call of Duty Zombies).
3. **Endless Fall / Climb:** Vertical progression where the player falls down or climbs up infinitely (e.g., Doodle Jump, Downwell).
4. **Endless Puzzle:** Tetris-like games where pieces fall endlessly and speed increases until the board fills up.

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_procedural_generation` (essential for creating infinite content), `atom_high_score_system` (provides the primary motivation), `atom_power_ups` (adds variance and temporary relief).
- **Incompatible Atoms:** `atom_fixed_narrative_ending` (contradicts the endless nature), `atom_finite_level_design` (requires infinite or looped generation instead).

## 8. Anti-Patterns
1. **Flat Difficulty Curve:** If the difficulty doesn't increase, the game becomes a test of endurance rather than skill, leading to extreme boredom.
2. **Unfair Scaling:** Increasing difficulty by making challenges physically impossible to react to (e.g., obstacles spawning too close to the player at high speeds) rather than testing legitimate skill limits.
3. **Lack of Pacing:** Constant high intensity without brief moments of relief (valleys in the pacing curve) exhausts the player too quickly.
