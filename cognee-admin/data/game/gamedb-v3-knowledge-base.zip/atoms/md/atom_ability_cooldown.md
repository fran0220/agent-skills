# Atom: Ability Cooldown

## 1. Identity
- **Atom ID**: atom_ability_cooldown
- **English Name**: Ability Cooldown
- **Chinese Name**: 技能冷却
- **Category**: A
- **Definition**: A temporal restriction mechanism that prevents a player from repeatedly using a specific ability or action within a predefined time window after its execution, forcing strategic decision-making and pacing the gameplay.

## 2. Core Verb & State Machine
- **Core Verb**: Wait / Manage Time
- **State Diagram**:
  [Ready] --(Use Ability)--> [On Cooldown]
  [On Cooldown] --(Time Passes == Cooldown Duration)--> [Ready]
  [On Cooldown] --(Cooldown Reset Trigger)--> [Ready]
- **States**:
  - `Ready`: The ability is available to be used.
  - `On Cooldown`: The ability has been used and is currently unavailable.
- **Transitions**:
  - `Ready` -> `On Cooldown`: Triggered by the player using the ability.
  - `On Cooldown` -> `Ready`: Triggered by the elapsed time reaching the cooldown duration, or by a specific reset event.

## 3. MDA Analysis
- **Mechanics**: The system tracks the timestamp of ability usage and compares the current time against it. If the difference is less than the cooldown parameter, the ability execution is blocked.
- **Dynamics**: Players must decide the optimal moment to use an ability, leading to baiting tactics, resource management, and burst damage windows. It creates a rhythm of engagement and disengagement.
- **Aesthetics**: Anticipation, tension during vulnerability windows, and satisfaction when a high-impact ability becomes available at the perfect moment.

## 4. Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value | Unit |
|---|---|---|---|---|
| `base_cooldown` | f32 | 1.0 - 120.0 | 10.0 (Overwatch v2.0) | seconds |
| `cooldown_reduction` | f32 | 0.0 - 0.4 | 0.0 (League of Legends v13.1) | percentage |
| `has_charges` | bool | true/false | false (Hades v1.0) | boolean |
| `max_charges` | u32 | 1 - 3 | 1 (Overwatch v2.0) | count |

## 5. Benchmark Data
- **Overwatch (v2.0)**: Tracer's Recall has a `base_cooldown` of 12.0 seconds. Ana's Biotic Grenade has a `base_cooldown` of 10.0 seconds.
- **League of Legends (v13.1)**: Flash has a `base_cooldown` of 300.0 seconds. Ezreal's Mystic Shot has a `base_cooldown` of 5.5 seconds.
- **Hades (v1.0)**: Cast ability typically has a `base_cooldown` of 3.0 seconds (when using Infernal Soul).

## 6. Common Variants
1. **Charge-based Cooldown**: The ability can store multiple uses (charges). Cooldown replenishes one charge at a time.
2. **Dynamic Cooldown**: Cooldown duration changes based on game state (e.g., reduced if the ability hits an enemy).
3. **Global Cooldown (GCD)**: Using one ability puts all other abilities on a short cooldown (common in MMOs).
4. **Resource-linked Cooldown**: Cooldown is bypassed or reduced by spending a secondary resource.

## 7. Compatibility Notes
- **Compatible Atoms**: `atom_resource_cost` (Mana/Energy), `atom_status_effect` (Buffs/Debuffs), `atom_projectile_spawn`.
- **Incompatible Atoms**: `atom_infinite_spam` (Direct conflict as cooldown prevents spamming).

## 8. Anti-Patterns
1. **Excessive Cooldowns on Core Verbs**: Putting a player's primary means of interaction on a long cooldown leads to boring downtime.
2. **Unclear Cooldown Feedback**: Failing to provide clear visual or auditory cues when an ability is ready or on cooldown frustrates players.
3. **Overlapping Long Cooldowns**: Designing a kit where all abilities have long, desynced cooldowns can make the character feel clunky and unresponsive.
