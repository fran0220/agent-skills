# Gameplay Atom: Supply / Population Cap

## 1. Identity
- **Atom ID:** `atom_supply_cap`
- **English Name:** Supply / Population Cap
- **Chinese Name:** 人口上限
- **Category:** G/H (Resource Management / Economy)
- **Definition:** A systemic limit on the total number of active units a player can control or maintain simultaneously. This limit is typically divided into a "current capacity" that can be expanded by building specific structures or units (e.g., Supply Depots, Overlords, Houses), and an "absolute maximum capacity" that cannot be exceeded regardless of resources spent.

## 2. Core Verb & State Machine
- **Core Verb:** Expand (Capacity) / Consume (Capacity)

**State Diagram:**
[Below Cap] <--> [At Current Cap] --> [At Absolute Max Cap]

**States:**
- `Below Cap`: The player has available supply and can produce new units.
- `At Current Cap`: The player has reached their current supply limit and must build capacity-increasing structures/units to produce more.
- `At Absolute Max Cap`: The player has reached the hard limit of the game engine or design (e.g., 200 supply in StarCraft) and cannot increase capacity further.

**Transitions:**
- `Produce Unit`: Transitions from `Below Cap` to `At Current Cap` (if supply becomes full) or remains in `Below Cap`.
- `Lose Unit`: Transitions from `At Current Cap` or `At Absolute Max Cap` to `Below Cap`.
- `Expand Capacity`: Transitions from `At Current Cap` to `Below Cap` (unless absolute max is reached).
- `Lose Capacity`: Transitions from `Below Cap` to `At Current Cap` (if capacity drops below current unit count, often resulting in a "supply block").

## 3. MDA Analysis
- **Mechanics:** The game tracks a global `current_supply` and `max_supply`. Every unit has a `supply_cost`. Production of a unit is blocked if `current_supply + supply_cost > max_supply`. `max_supply` is increased by specific entities up to an `absolute_limit`.
- **Dynamics:** Players must balance resource expenditure between military/economic units and supply-providing structures. Forgetting to build supply structures leads to "supply blocks," halting production and creating windows of vulnerability. It also forces players to optimize their army composition as they approach the absolute limit.
- **Aesthetics:** Creates a rhythm of macro-management (Challenge). Reaching the maximum cap provides a sense of completion and signals the climax of army building (Expression/Fantasy). Supply blocks create tension and frustration.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (StarCraft II v5.0) | Unit |
| --- | --- | --- | --- | --- |
| `absolute_max_supply` | u32 | 100 - 1000 | 200 | Units/Supply |
| `starting_supply` | u32 | 5 - 20 | 15 | Units/Supply |
| `supply_per_structure` | u32 | 5 - 15 | 8 (Supply Depot) | Units/Supply |
| `structure_cost` | u32 | 50 - 150 | 100 (Minerals) | Resources |
| `unit_supply_cost` | u32 | 1 - 8 | 1 (Marine) | Units/Supply |

## 5. Benchmark Data
- **StarCraft II (v5.0.11):**
  - `absolute_max_supply`: 200
  - `starting_supply`: 15 (Command Center provides 15)
  - `supply_per_structure`: 8 (Supply Depot)
  - `unit_supply_cost`: 1 (Marine), 2 (Marauder), 6 (Battlecruiser)
- **Age of Empires II: Definitive Edition (Update 81058):**
  - `absolute_max_supply`: 200 (Standard, configurable up to 500)
  - `starting_supply`: 5 (Town Center provides 5)
  - `supply_per_structure`: 5 (House)
  - `unit_supply_cost`: 1 (Most units), 0.5 (Karambit Warrior)

## 6. Common Variants
1. **Soft Cap (Upkeep):** Exceeding the cap doesn't block production but imposes an economic penalty (e.g., Warcraft III upkeep system reduces gold income as army size grows).
2. **Dynamic Cap:** The cap is tied to territorial control rather than specific buildings (e.g., Company of Heroes, where capturing points increases population cap).
3. **Asymmetric Supply:** Different factions have entirely different supply mechanics (e.g., Zerg Overlords are mobile units, Protoss Pylons provide power fields).
4. **No Absolute Cap:** The game engine allows infinite units, limited only by the player's ability to build capacity structures (e.g., Supreme Commander).

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_resource_gathering` (requires resources to build supply), `atom_unit_production` (consumes supply), `atom_tech_tree` (unlocking higher-tier units that cost more supply).
- **Incompatible Atoms:** `atom_single_character_control` (RPGs typically don't use RTS-style supply caps).

## 8. Anti-Patterns
1. **Excessive Supply Cost:** Making basic structures cost too much supply, severely limiting the player's ability to build a functioning base.
2. **Hidden Supply Mechanics:** Not clearly communicating to the player when they are about to be supply-blocked, leading to frustrating interruptions in gameplay.
3. **Trivialized Supply:** Making supply structures so cheap and fast to build that the mechanic becomes a meaningless chore rather than a strategic consideration.
