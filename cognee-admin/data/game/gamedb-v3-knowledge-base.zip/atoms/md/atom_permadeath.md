# Gameplay Atom: Permadeath

## 1. Identity
- **Atom ID:** atom_permadeath
- **English Name:** Permadeath
- **Chinese Name:** 永久死亡
- **Category:** G (Game Mechanics)
- **Definition:** Permadeath is a core game mechanic in which player characters who lose all their health or are otherwise killed are permanently dead. The player cannot reload a previous save state to resurrect the character, forcing them to either restart the game entirely or continue with other characters, permanently losing the progress, items, and emotional investment associated with the deceased character.

## 2. Core Verb & State Machine
- **Primary Player Verb:** Survive / Risk-Assess
- **State Diagram:**
  ```text
  [Alive] --(Take Fatal Damage)--> [Dead]
  [Dead] --(Game Over / Restart)--> [Alive (New Character)]
  ```
- **States:**
  - `Alive`: The character is active, can perform actions, and accumulate progress.
  - `Dead`: The character is permanently removed from the active roster or the game ends.
- **Transitions:**
  - `Alive -> Dead`: Triggered when health reaches zero or a fatal event occurs.
  - `Dead -> Alive (New Character)`: Triggered when the player starts a new run or recruits a new character.

## 3. MDA Analysis
- **Mechanics:** The system deletes or locks the save file upon character death, or permanently flags a specific character entity as unusable. It restricts the ability to load previous states.
- **Dynamics:** Players exhibit highly cautious behavior, prioritize defensive strategies, and engage in deep risk-to-reward calculations before taking actions. It discourages reckless trial-and-error gameplay.
- **Aesthetics:** Creates intense emotional highs and lows. Players feel a profound sense of tension (thrill), deep attachment to their characters, and genuine grief or frustration upon loss.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value | Unit |
|---|---|---|---|---|
| `lives_count` | u32 | 1 | 1 | lives |
| `save_deletion` | bool | true/false | true | N/A |
| `legacy_multiplier` | f32 | 0.0 - 1.0 | 0.0 | multiplier |
| `grace_period_ms` | u32 | 0 - 5000 | 0 | milliseconds |

## 5. Benchmark Data
- **XCOM: Enemy Unknown (v1.0):** `save_deletion` = true (in Ironman mode), `lives_count` = 1 per soldier.
- **Fire Emblem: Awakening (v1.0):** `lives_count` = 1 (in Classic mode), `save_deletion` = false (can restart chapter, but character is dead if continuing).
- **Spelunky (v1.4):** `lives_count` = 1, `legacy_multiplier` = 0.0 (pure roguelike, no meta-progression).

## 6. Common Variants
1. **Pure Roguelike:** Complete wipe of all progress upon death (e.g., Nethack).
2. **Roguelite (Meta-progression):** Character dies permanently, but some resources or unlocks carry over to the next run (e.g., Hades, Rogue Legacy).
3. **Roster Permadeath:** Individual characters die permanently, but the game continues with the rest of the team (e.g., Fire Emblem, XCOM).
4. **Hardcore / Ironman Mode:** An optional difficulty setting in otherwise standard games that enforces a single save file that is deleted upon death (e.g., Minecraft Hardcore, Diablo Hardcore).

## 7. Compatibility Notes
- **Commonly Pairs With:** Procedural Generation (`atom_procedural_gen`), Turn-Based Tactics, Resource Management.
- **Known Conflicts:** Quick Save / Quick Load (`atom_quicksave`), Trial-and-Error Platforming, Scripted Unavoidable Deaths.

## 8. Anti-Patterns
1. **Unavoidable Instant Death:** "Gotcha" traps or RNG events that kill the player without any prior warning or opportunity for counterplay, leading to frustration rather than a feeling of fair challenge.
2. **Excessive Post-Death Grinding:** Forcing the player to repeat hours of trivial, unchallenging content just to get back to the point where they died.
3. **Inconsistent Rules:** Having certain deaths be permanent while others are not, without clear communication to the player.
