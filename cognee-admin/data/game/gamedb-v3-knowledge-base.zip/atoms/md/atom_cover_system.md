# Gameplay Atom: Cover System (掩体系统)

## 1. Identity
- **Atom ID:** `atom_cover_system`
- **English Name:** Cover System
- **Chinese Name:** 掩体系统
- **Category:** A
- **Definition:** A gameplay mechanic that allows a player character to use environmental objects to avoid taking damage from enemy attacks, typically involving snapping to the object, modifying the character's hitbox, and providing specific actions like peeking or blind firing.

## 2. Core Verb & State Machine
- **Core Verb:** Take Cover (进入掩体)
- **State Diagram:**
  ```text
  [Idle/Moving] --(Take Cover Input near Cover)--> [In Cover]
  [In Cover] --(Aim Input)--> [Peeking]
  [In Cover] --(Fire Input without Aim)--> [Blind Firing]
  [In Cover] --(Move Input along Cover)--> [Moving in Cover]
  [In Cover] --(Exit Cover Input / Move away)--> [Idle/Moving]
  [In Cover] --(Cover Destroyed)--> [Idle/Moving]
  [Peeking] --(Release Aim)--> [In Cover]
  [Blind Firing] --(Release Fire)--> [In Cover]
  ```
- **States:**
  - `Idle/Moving`: The default state outside of cover.
  - `In Cover`: The character is snapped to the cover object, reducing their exposed hitbox.
  - `Peeking`: The character leans out or pops up from cover to aim, exposing a portion of their hitbox.
  - `Blind Firing`: The character fires their weapon over or around the cover without exposing their head/torso, resulting in low accuracy.
  - `Moving in Cover`: The character slides or walks along the edge of the cover object.
- **Transitions:**
  - `Idle/Moving` -> `In Cover`: Triggered by pressing the cover button when within the snap radius of a valid cover object.
  - `In Cover` -> `Peeking`: Triggered by holding the aim button.
  - `In Cover` -> `Blind Firing`: Triggered by pressing the fire button without aiming.
  - `In Cover` -> `Moving in Cover`: Triggered by directional input parallel to the cover surface.
  - `In Cover` -> `Idle/Moving`: Triggered by pressing the cover button again, moving away from the cover, or if the cover is destroyed.

## 3. MDA Analysis
- **Mechanics:** The system detects valid cover geometry within a certain radius of the player. Upon input, it transitions the player's state, snaps their position to the cover, plays specific animations, and applies damage mitigation or hitbox reduction. It also enables contextual actions like peeking and blind firing.
- **Dynamics:** Players actively seek out cover to survive engagements. The spatial arrangement of cover dictates the flow of combat, encouraging flanking maneuvers and positional awareness. Destructible cover forces players to constantly reposition.
- **Aesthetics:** The cover system creates a sense of tension and tactical depth. Players feel protected when in cover and vulnerable when exposed. It emphasizes deliberate pacing and strategic positioning over pure reflexes.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Game/Version) | Unit |
| :--- | :--- | :--- | :--- | :--- |
| `snap_radius` | `f32` | 0.5 - 2.0 | 1.2 (Gears of War 4) | meters |
| `snap_speed` | `f32` | 2.0 - 10.0 | 5.0 (The Division 2) | m/s |
| `damage_reduction` | `f32` | 0.0 - 1.0 | 1.0 (XCOM 2) | multiplier |
| `peek_exposure` | `f32` | 0.1 - 0.5 | 0.3 (Gears of War 4) | fraction |
| `blind_fire_accuracy` | `f32` | 0.0 - 0.5 | 0.1 (Uncharted 4) | multiplier |
| `exit_delay` | `f32` | 0.0 - 0.5 | 0.15 (Gears of War 4) | seconds |

## 5. Benchmark Data
- **Gears of War 4 (v1.0):**
  - `snap_radius`: 1.2 meters
  - `peek_exposure`: 0.3 (30% of hitbox exposed)
  - `exit_delay`: 0.15 seconds
- **XCOM 2 (v1.0):**
  - `damage_reduction`: 1.0 (Full cover provides complete line-of-sight blockage or high defense bonus)
  - `snap_radius`: N/A (Grid-based movement)
- **The Division 2 (v1.0):**
  - `snap_speed`: 5.0 m/s
  - `blind_fire_accuracy`: 0.15

## 6. Common Variants
1. **Hard Snap Cover:** The player presses a button to attach to cover. Movement is restricted to the cover's surface until detached (e.g., Gears of War).
2. **Soft/Auto Cover:** The player automatically enters a cover state when moving against a valid object. No button press is required (e.g., Tomb Raider reboot, The Last of Us).
3. **Grid-Based Cover:** Cover is defined by discrete tiles on a grid, providing statistical defense bonuses rather than physical hitbox occlusion (e.g., XCOM).
4. **First-Person Leaning:** The player manually leans left or right from behind an obstacle without a formal "snap" mechanic (e.g., Rainbow Six Siege).

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_shooting_mechanics`, `atom_stealth_system`, `atom_health_regeneration`, `atom_destructible_environment`.
- **Incompatible Atoms:** `atom_fast_paced_movement` (e.g., wall-running or constant dashing often conflicts with stationary cover mechanics), `atom_melee_focus` (pure melee games rarely benefit from ranged cover systems).

## 8. Anti-Patterns
1. **Sticky Cover:** Making the snap radius too large or the exit delay too long, causing players to accidentally attach to cover or struggle to detach when trying to escape danger.
2. **Unclear Cover Validity:** Failing to visually communicate which objects can be used as cover, leading to player frustration when they try to hide behind an invalid object.
3. **Overpowered Blind Fire:** Making blind firing too accurate, which disincentivizes peeking and reduces the risk/reward dynamic of the combat loop.
