# Gameplay Atom: Co-op Revive

## 1. Identity
- **Atom ID:** `atom_coop_revive`
- **English Name:** Co-op Revive
- **Chinese Name:** 合作复活
- **Category:** E/F (Multiplayer Interaction / Survival Mechanics)
- **Definition:** A cooperative multiplayer mechanic where a downed or incapacitated player can be restored to a functional state by the active intervention of one or more surviving teammates, usually requiring them to remain in close proximity and channel an action for a specific duration, creating a high-risk, high-reward tactical scenario.

## 2. Core Verb & State Machine
- **Core Verb:** Revive (Channeling interaction to restore a teammate)

**State Diagram:**
```text
[Alive] --> (Health <= 0) --> [Downed]
[Downed] --> (Revive Channeled) --> [Reviving]
[Reviving] --> (Channel Complete) --> [Alive]
[Reviving] --> (Channel Interrupted) --> [Downed]
[Downed] --> (Bleedout Timer Expires) --> [Dead]
[Dead] --> (Respawn Mechanic) --> [Alive]
```

**States:**
- `Alive`: Player is fully functional and can perform all actions.
- `Downed`: Player is incapacitated, usually restricted to crawling, cannot use primary weapons, and has a bleedout timer.
- `Reviving`: A teammate is actively interacting with the downed player. The bleedout timer is usually paused.
- `Dead`: Player has fully succumbed and must wait for a respawn or the end of the round.

**Transitions:**
- `Alive -> Downed`: Triggered when HP reaches 0.
- `Downed -> Reviving`: Triggered when a teammate presses and holds the interact button within range.
- `Reviving -> Alive`: Triggered when the revive channel duration is successfully completed.
- `Reviving -> Downed`: Triggered if the reviving player moves, takes damage (in some games), or releases the interact button.
- `Downed -> Dead`: Triggered when the bleedout timer reaches 0 or the downed player takes fatal execution damage.

## 3. MDA Analysis
- **Mechanics:** The system tracks the downed player's bleedout timer and the reviving player's channel timer. It checks for proximity, line of sight, and interruption conditions (like taking damage or moving). Upon success, it restores a percentage of the downed player's health.
- **Dynamics:** Creates a temporary localized objective for the surviving team. It forces players to make tactical decisions: clear the area of enemies first, use crowd control/smoke grenades, or risk a mid-combat revive. It often leads to "baiting" where enemies use the downed player to lure out teammates.
- **Aesthetics:** Generates intense moments of tension, camaraderie, and heroism. Successfully pulling off a risky revive under fire provides a strong sense of fellowship and relief, while failing can lead to dramatic, cascading team wipes.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Apex Legends v19) | Unit |
| --- | --- | --- | --- | --- |
| `revive_duration` | f32 | 1.0 - 10.0 | 5.0 | seconds |
| `bleedout_duration` | f32 | 10.0 - 60.0 | 30.0 | seconds |
| `revive_range` | f32 | 1.0 - 5.0 | 2.0 | meters |
| `health_restored_pct` | f32 | 0.1 - 1.0 | 0.2 | percentage |
| `pause_bleedout_on_revive` | bool | true/false | true | boolean |
| `interrupt_on_damage` | bool | true/false | false | boolean |

## 5. Benchmark Data
- **Apex Legends (v19.0):**
  - `revive_duration`: 5.0s (can be modified by specific characters like Lifeline or Gibraltar).
  - `bleedout_duration`: 30.0s (decreases on subsequent downs).
  - `health_restored_pct`: 0.2 (20 HP out of 100 base).
- **Borderlands 3 (v1.0):**
  - `revive_duration`: 3.0s.
  - `bleedout_duration`: 12.0s (Fight For Your Life).
  - `health_restored_pct`: 0.5 (50% max health).
- **It Takes Two (v1.0):**
  - `revive_duration`: 0.0s (Instant button mash).
  - `bleedout_duration`: Infinite (until both players are dead).
  - `health_restored_pct`: 1.0 (Full health upon respawn).

## 6. Common Variants
1. **Token/Item Revive:** Requires a consumable item (e.g., Phoenix Down in Final Fantasy, Defibrillators in Battlefield) to perform the revive, sometimes making it instant.
2. **Sacrificial Revive:** The reviving player transfers their own health to the downed player (e.g., some abilities in Warframe).
3. **Automated/Drone Revive:** A deployed gadget or pet performs the revive, freeing the player to continue fighting (e.g., Lifeline's DOC drone in Apex Legends).
4. **Kill-to-Revive (Second Wind):** The downed player can revive themselves by securing a kill before the bleedout timer expires (e.g., Borderlands' "Fight For Your Life").
5. **Proximity Passive Revive:** Simply standing near the downed player slowly fills the revive meter without requiring a button hold (e.g., Overwatch payload healing mechanics adapted for revives).

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_downed_state` (prerequisite), `atom_ping_system` (for calling for help), `atom_smoke_grenade` (for cover during revive), `atom_invulnerability_frames` (brief protection post-revive).
- **Incompatible Atoms:** `atom_instant_respawn` (makes reviving redundant), `atom_solo_permadeath` (fundamentally conflicts with co-op revival).

## 8. Anti-Patterns
1. **Unclear Interruption Rules:** If players don't know what interrupts a revive (e.g., taking 1 point of damage vs. being hard CC'd), it leads to frustration.
2. **Revive Looping:** If the post-revive invulnerability is too long or the revive time is too short, players can endlessly revive each other in a corner, stalling the game.
3. **Lack of Feedback:** Failing to provide clear audio-visual cues for the start, progress, and completion of a revive, leaving both the reviver and the downed player unsure of the state.
