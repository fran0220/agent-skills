# Gameplay Atom: Touch & Drag (触摸拖拽)

## 1. Identity
- **Atom ID:** atom_touch_drag
- **English Name:** Touch & Drag
- **Chinese Name:** 触摸拖拽
- **Category:** G/H (Input/Interaction)
- **Definition:** A fundamental interaction mechanic where the player touches an object on the screen and moves their finger (or cursor) while maintaining contact to displace the object or define a vector, releasing to trigger an action.

## 2. Core Verb & State Machine
- **Core Verb:** Drag
- **State Diagram:**
  [Idle] --(Touch Down)--> [Dragging]
  [Dragging] --(Move)--> [Dragging]
  [Dragging] --(Touch Up)--> [Released]
  [Released] --(Action Complete)--> [Idle]
- **States:**
  - `Idle`: Waiting for player input.
  - `Dragging`: Player is actively holding and moving the touch point.
  - `Released`: Player has lifted the touch, triggering the resulting action.
- **Transitions:**
  - `Idle` -> `Dragging`: Triggered by `Touch Down` on a valid target.
  - `Dragging` -> `Dragging`: Triggered by `Move` (updating coordinates).
  - `Dragging` -> `Released`: Triggered by `Touch Up`.
  - `Released` -> `Idle`: Triggered by the completion of the resulting action (e.g., projectile fired).

## 3. MDA Analysis
- **Mechanics:** The system tracks the initial touch coordinates, continuously updates the current coordinates during movement, calculates the delta vector (distance and angle), and applies this data to game objects (e.g., moving an object, stretching a slingshot).
- **Dynamics:** Players can adjust their aim or movement precisely before committing. The visual feedback (like a trajectory line or stretching band) dynamically responds to the drag vector, creating a sense of tension and control.
- **Aesthetics:** Provides a tactile, satisfying feeling of physical interaction. The tension building up during the drag phase creates anticipation, followed by release and satisfaction.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value | Unit |
|---|---|---|---|---|
| `max_drag_distance` | f32 | 50.0 - 300.0 | 150.0 (Angry Birds v1.0) | pixels |
| `drag_sensitivity` | f32 | 0.5 - 2.0 | 1.0 (Cut the Rope v1.0) | multiplier |
| `snap_back_speed` | f32 | 10.0 - 50.0 | 20.0 (Angry Birds v1.0) | units/sec |
| `cancel_threshold` | f32 | 0.0 - 20.0 | 10.0 (Cut the Rope v1.0) | pixels |

## 5. Benchmark Data
- **Angry Birds (v1.0):**
  - `max_drag_distance`: 150.0 pixels (limits how far the slingshot can be pulled).
  - `snap_back_speed`: 20.0 units/sec (speed at which the band returns if canceled).
- **Cut the Rope (v1.0):**
  - `drag_sensitivity`: 1.0 multiplier (1:1 movement with finger).
  - `cancel_threshold`: 10.0 pixels (minimum drag distance to register as a cut/drag rather than a tap).

## 6. Common Variants
1. **Slingshot Drag:** Dragging away from the target to build tension and define a reverse vector (e.g., Angry Birds).
2. **Direct Placement:** Dragging an object directly to a new location (e.g., inventory management, puzzle pieces).
3. **Line Drawing:** Dragging to draw a path or cut a rope (e.g., Cut the Rope, Flight Control).
4. **Virtual Joystick:** Dragging from a fixed or dynamic center point to control character movement.

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_projectile_motion` (often triggers projectiles), `atom_physics_collision` (dragged objects interact with the world), `atom_camera_pan` (dragging the background to move the camera).
- **Conflicts:** `atom_tap_to_move` (can conflict if tap and drag thresholds are not clearly defined).

## 8. Anti-Patterns
1. **Lack of Visual Feedback:** Failing to show the player the result of their drag (e.g., missing trajectory line) leads to frustration.
2. **Poor Hitboxes:** Making the initial touch area too small, causing players to miss the object and accidentally trigger other actions (like camera panning).
3. **No Cancel Option:** Forcing the player to commit to an action once dragging starts, without a way to safely cancel (e.g., dragging back to the origin).
