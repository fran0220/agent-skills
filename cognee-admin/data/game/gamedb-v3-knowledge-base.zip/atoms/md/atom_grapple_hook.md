# Gameplay Atom: Grapple Hook / Tether

## 1. Identity
- **Atom ID:** `atom_grapple_hook`
- **English Name:** Grapple Hook / Tether
- **Chinese Name:** 钩锁/绳索
- **Category:** A+B (Movement & Interaction)
- **Definition:** A mechanic that allows the player to shoot a projectile that attaches to a surface, object, or enemy, creating a physical or energetic tether. This tether is then used to pull the player toward the attachment point, pull the object/enemy toward the player, or allow the player to swing from the pivot point, fundamentally altering traversal and combat dynamics.

## 2. Core Verb & State Machine
- **Core Verb:** Grapple (Aim, Fire, Attach, Pull/Swing, Detach)

**State Diagram:**
```text
[Idle] --> (Fire) --> [Extending]
[Extending] --> (Hit Surface) --> [Attached]
[Extending] --> (Miss/Max Range) --> [Retracting]
[Attached] --> (Pull Player) --> [Zipping]
[Attached] --> (Swing) --> [Swinging]
[Attached] --> (Pull Object) --> [Reeling]
[Zipping] --> (Reach Target/Cancel) --> [Idle/Falling]
[Swinging] --> (Release/Jump) --> [Idle/Falling]
[Reeling] --> (Object Reached) --> [Idle]
[Retracting] --> (Fully Retracted) --> [Idle]
```

**States and Transitions:**
- **Idle:** The grapple is ready to be used.
- **Extending:** The hook is traveling through the air toward the target.
- **Attached:** The hook has successfully latched onto a valid target.
- **Retracting:** The hook missed or hit an invalid target and is returning to the player.
- **Zipping:** The player is being rapidly pulled toward the attachment point.
- **Swinging:** The player is using the tether as a pendulum to swing.
- **Reeling:** An object or enemy is being pulled toward the player.

## 3. MDA Analysis
- **Mechanics:** The system calculates a raycast or projectile trajectory to determine a hit. Upon a valid hit, it establishes a constraint (spring, distance, or fixed joint) between the player and the target. It applies forces to move the player or the object based on input and physics parameters.
- **Dynamics:** Players can chain grapples with jumps, dashes, or wall runs to maintain momentum and stay airborne. In combat, it allows for rapid gap-closing or isolating enemies by pulling them out of formation. The physics-based swinging creates emergent trajectories based on release timing.
- **Aesthetics:** Empowers the player with a sense of extreme mobility, freedom, and verticality. It evokes feelings of agility (like Spider-Man or Rico Rodriguez) and aggressive dominance in combat (like Scorpion or Sekiro).

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Game/Ver) | Unit |
| :--- | :--- | :--- | :--- | :--- |
| `max_range` | `f32` | 10.0 - 100.0 | 50.0 (Just Cause 4 v1.0) | meters |
| `extension_speed` | `f32` | 20.0 - 200.0 | 120.0 (Sekiro v1.06) | m/s |
| `pull_acceleration` | `f32` | 10.0 - 100.0 | 45.0 (Just Cause 4 v1.0) | m/s^2 |
| `max_pull_speed` | `f32` | 15.0 - 80.0 | 40.0 (Sekiro v1.06) | m/s |
| `cooldown` | `f32` | 0.0 - 10.0 | 0.5 (Bionic Commando) | seconds |
| `auto_aim_angle` | `f32` | 0.0 - 45.0 | 15.0 (Sekiro v1.06) | degrees |
| `swing_gravity_scale` | `f32` | 0.5 - 2.0 | 1.2 (Just Cause 4 v1.0) | multiplier |
| `detach_jump_boost` | `f32` | 0.0 - 20.0 | 10.0 (Sekiro v1.06) | m/s |

## 5. Benchmark Data
- **Just Cause 4 (v1.0):**
  - `max_range`: 50.0 m
  - `pull_acceleration`: 45.0 m/s^2
  - `swing_gravity_scale`: 1.2
  - *Notes:* Focuses on tethering multiple objects and high-speed traversal.
- **Sekiro: Shadows Die Twice (v1.06):**
  - `max_range`: 25.0 m
  - `extension_speed`: 120.0 m/s
  - `max_pull_speed`: 40.0 m/s
  - `auto_aim_angle`: 15.0 degrees
  - `detach_jump_boost`: 10.0 m/s
  - *Notes:* Highly snappy, context-sensitive grapple points, used for rapid vertical repositioning and specific combat counters.
- **Bionic Commando (2009):**
  - `max_range`: 35.0 m
  - `cooldown`: 0.5 s
  - *Notes:* Heavy emphasis on physics-based swinging and momentum conservation.

## 6. Common Variants
1. **Point-to-Point Zip:** The player is pulled in a straight line to the target at a constant or accelerating speed (e.g., Sekiro).
2. **Physics Pendulum Swing:** The tether acts as a rope, allowing the player to swing using gravity and momentum (e.g., Spider-Man, Bionic Commando).
3. **Tether Creation:** The player connects two objects together, and the tether contracts to pull them into each other (e.g., Just Cause).
4. **Enemy Pull (Get Over Here):** The player remains stationary while the target is pulled toward them (e.g., Mortal Kombat's Scorpion, Halo Infinite Grappleshot on light enemies).
5. **Grapple Melee Strike:** The grapple pulls the player to the enemy and automatically transitions into a melee attack upon arrival.

## 7. Compatibility Notes
- **Compatible Atoms:**
  - `atom_double_jump`: Allows correcting trajectory after a grapple detach.
  - `atom_wall_run`: Grappling to a wall seamlessly transitions into a wall run.
  - `atom_glide`: Grappling can be used to gain altitude and speed before deploying a glider.
  - `atom_slow_motion`: Aiming the grapple mid-air triggers slow motion for precise targeting.
- **Incompatible/Conflict Atoms:**
  - `atom_heavy_encumbrance`: Grappling mechanics often conflict with systems designed to make the player feel heavy or grounded.
  - `atom_cover_system`: Snapping to cover can interfere with the fluid momentum of a grapple release.

## 8. Anti-Patterns
1. **Unpredictable Momentum Loss:** Killing the player's momentum entirely upon detaching from a swing, making the movement feel stiff and unrewarding.
2. **Overly Strict Targeting:** Requiring pixel-perfect aim to attach to a grapple point, especially while moving fast, leading to frustration. (Solution: Implement generous auto-aim or magnetism).
3. **Camera Whiplash:** Failing to smooth the camera during rapid acceleration or sudden directional changes when zipping, causing motion sickness or disorientation.
