# Gameplay Atom: XP / Level Up

## 1. Identity
- **Atom ID:** atom_xp_level
- **English Name:** XP / Level Up
- **Chinese Name:** 经验值/升级
- **Category:** E or F (Progression/Economy)
- **Definition:** A progression system where players accumulate Experience Points (XP) through various activities, and upon reaching specific thresholds, their character or entity advances to a higher Level, typically unlocking new abilities, increasing stats, or granting access to new content.

## 2. Core Verb & State Machine
- **Core Verb:** Earn (XP), Level Up
- **State Diagram:**
  [Idle] --(Perform Action)--> [Earning XP]
  [Earning XP] --(XP < Threshold)--> [Idle]
  [Earning XP] --(XP >= Threshold)--> [Leveling Up]
  [Leveling Up] --(Apply Rewards/Stats)--> [Idle]
- **States:**
  - `Idle`: The default state where the player is not actively gaining XP.
  - `Earning XP`: The state triggered when an action yields XP.
  - `Leveling Up`: The transitional state where the player's level increments and rewards are processed.
- **Transitions:**
  - `Idle` -> `Earning XP`: Triggered by defeating enemies, completing quests, etc.
  - `Earning XP` -> `Idle`: Triggered when the accumulated XP is below the next level's requirement.
  - `Earning XP` -> `Leveling Up`: Triggered when the accumulated XP meets or exceeds the next level's requirement.
  - `Leveling Up` -> `Idle`: Triggered after level-up effects (stat increases, skill points) are applied.

## 3. MDA Analysis
- **Mechanics:** The system tracks a cumulative integer or float value (XP). A mathematical formula or lookup table defines the XP required for each level. When current XP >= required XP, the level increments, and the required XP for the next level is updated.
- **Dynamics:** Players engage in repetitive or challenging tasks ("grinding") to optimize XP gain. The rate of leveling typically slows down over time as the XP requirements scale exponentially or polynomially, creating a pacing curve.
- **Aesthetics:** 
  - *Submission/Pastime:* Grinding can be a relaxing, repetitive activity.
  - *Challenge:* Overcoming difficult foes yields higher XP, rewarding skill.
  - *Discovery:* Leveling up often unlocks new areas or abilities.
  - *Expression:* Choosing how to allocate stat points or skills upon leveling up.

## 4. Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value (WoW Classic) | Unit |
|---|---|---|---|---|
| `base_xp_requirement` | u32 | 100 - 1000 | 400 | XP |
| `xp_scaling_factor` | f32 | 1.1 - 2.0 | 1.5 | Multiplier |
| `max_level` | u32 | 20 - 100 | 60 | Levels |
| `xp_kill_reward` | u32 | 10 - 500 | 50 | XP |
| `xp_quest_reward` | u32 | 100 - 5000 | 850 | XP |

## 5. Benchmark Data
- **World of Warcraft (Classic 1.12):**
  - `max_level`: 60
  - `base_xp_requirement` (Level 1 to 2): 400 XP
  - `xp_scaling_factor`: Varies, roughly polynomial scaling.
- **Final Fantasy VII (PS1):**
  - `max_level`: 99
  - `base_xp_requirement`: Variable per character, Cloud needs 120 XP for Level 2.
- **Dungeons & Dragons (5th Edition):**
  - `max_level`: 20
  - `base_xp_requirement` (Level 1 to 2): 300 XP
  - `xp_scaling_factor`: Fixed lookup table with steep jumps at tiers of play.

## 6. Common Variants
1. **Skill-Based Leveling (e.g., The Elder Scrolls V: Skyrim):** Instead of general XP, players gain XP in specific skills by using them. General level increases when enough skill levels are gained.
2. **Milestone Leveling (e.g., D&D 5e Variant):** XP is ignored entirely; players level up when they reach specific narrative milestones.
3. **Diminishing Returns (e.g., MMOs):** XP gained from low-level enemies decreases as the player's level increases, eventually reaching zero to prevent trivial grinding.
4. **Shared Party XP (e.g., Pokémon Exp. Share):** XP earned by one character is distributed among all party members.
5. **Loss of XP on Death (e.g., Dark Souls, EverQuest):** Players lose a portion of their accumulated XP or even levels upon dying, adding high stakes.

## 7. Compatibility Notes
- **Commonly Pairs With:** `atom_stat_attributes` (Stats increase on level up), `atom_skill_tree` (Skill points awarded on level up), `atom_enemy_scaling` (Enemies scale with player level).
- **Known Conflicts:** `atom_permadeath` (If progression is entirely wiped, long XP grinds can feel overly punishing unless the game is designed as a roguelike with meta-progression).

## 8. Anti-Patterns
1. **The Grind Wall:** Making the XP requirement for the next level so high that players must spend hours doing repetitive, unengaging tasks to progress the story.
2. **Meaningless Levels:** Leveling up provides no noticeable increase in power or new options, making the event feel hollow.
3. **Over-Scaling Enemies:** If enemies scale perfectly with the player's level, the player never feels more powerful, negating the primary aesthetic reward of leveling up (e.g., Oblivion's scaling issue).
