# Gameplay Atom: Constellation / Dupe System

## 1. Identity
- **Atom ID:** `atom_constellation_dupe`
- **English Name:** Constellation / Dupe System
- **Chinese Name:** 命座/重复系统
- **Category:** E/F (Progression / Monetization)
- **Definition:** A progression mechanic where acquiring duplicate copies of a character, item, or equipment unlocks sequential, permanent upgrades or new passive abilities. This system is heavily utilized in gacha games to provide long-term value for pulling duplicates, transforming what would be a redundant reward into a highly desirable power spike.

## 2. Core Verb & State Machine
- **Core Verb:** "Unlock" or "Awaken" (consuming a duplicate to gain power).

**State Diagram:**
```text
[Locked] --> (Acquire Base) --> [Base Unlocked (C0)]
[Base Unlocked (C0)] --> (Acquire Dupe 1) --> [Constellation 1 (C1)]
[Constellation 1 (C1)] --> (Acquire Dupe 2) --> [Constellation 2 (C2)]
...
[Constellation N-1] --> (Acquire Dupe N) --> [Max Constellation (C6)]
[Max Constellation (C6)] --> (Acquire Extra Dupe) --> [Overflow Compensation]
```

**States:**
- `Locked`: The entity is not yet owned.
- `Base Unlocked`: The entity is owned at its baseline power level.
- `Constellation X`: The entity has been upgraded X times using duplicates.
- `Max Constellation`: The entity has reached the maximum number of duplicate upgrades.
- `Overflow Compensation`: The state when a duplicate is acquired for an already maxed entity, usually granting alternative currency.

**Transitions:**
- `Acquire Base`: Player obtains the first copy.
- `Acquire Dupe`: Player obtains a duplicate copy and consumes it.
- `Acquire Extra Dupe`: Player obtains a duplicate beyond the maximum limit, triggering a fallback reward.

## 3. MDA Analysis
- **Mechanics:** The system tracks the number of duplicate copies acquired for a specific entity. Each duplicate can be consumed to unlock a node in a linear or branching upgrade tree, granting stat boosts, modifying skill behaviors, or adding new passives. A hard cap exists on the number of usable duplicates.
- **Dynamics:** Players strategically plan their resource allocation (e.g., premium currency) to target specific "break points" (e.g., C2 in Genshin Impact) where the power spike is most significant. It creates a dynamic where pulling a duplicate is a moment of excitement rather than disappointment.
- **Aesthetics:** The system evokes feelings of anticipation, investment, and satisfaction. Players feel a sense of completion and immense power when maxing out a character, appealing to both completionists and min-maxers.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Genshin Impact v4.0) | Unit |
| :--- | :--- | :--- | :--- | :--- |
| `max_dupes` | Integer | 3 - 10 | 6 | Copies |
| `stat_boost_multiplier` | Float | 1.05 - 1.50 | 1.15 | Multiplier |
| `skill_level_bonus` | Integer | 1 - 5 | 3 | Levels |
| `overflow_currency_amount` | Integer | 1 - 50 | 25 (Starglitter for 5-star) | Currency |
| `dupe_requirement_per_node` | Integer | 1 - 5 | 1 | Copies |

## 5. Benchmark Data
- **Genshin Impact (v4.0):** Characters have exactly 6 Constellation nodes (C1 to C6). Each node requires exactly 1 duplicate (represented by Stella Fortuna). Nodes 3 and 5 typically grant +3 levels to the character's Elemental Skill and Elemental Burst. Pulling a 7th duplicate grants 25 Masterless Starglitter (for 5-star characters) instead of a constellation item.
- **Honkai: Star Rail (v1.0):** Characters have 6 Eidolon levels (E1 to E6). Similar to Genshin, each requires 1 duplicate. The power spikes are often distributed differently, with E1, E2, and E6 usually being the most impactful gameplay modifiers.
- **Arknights (v3.0):** Operators have a "Potential" system with 6 levels (Pot 1 to Pot 6). Duplicates grant tokens. Upgrades provide minor stat boosts (e.g., Attack +25) or reduce deployment cost (e.g., DP Cost -1), which is less transformative than Genshin's system but still valuable for high-end gameplay.

## 6. Common Variants
1. **Linear Skill Modifiers:** Each duplicate strictly enhances an existing skill or adds a new passive (e.g., Genshin Impact).
2. **Stat-Only Unlocks:** Duplicates only provide raw stat increases without changing gameplay mechanics (e.g., many older idle RPGs).
3. **Shard/Fragment System:** Instead of full duplicates, players collect shards. A specific number of shards is required to unlock the next tier, and the requirement scales up (e.g., Princess Connect! Re: Dive).
4. **Universal Dupe Material:** Players can use a rare, universal item in place of a specific character duplicate to unlock a node (e.g., Bulin in Azur Lane).
5. **Branching Paths:** Duplicates grant points that can be spent on a non-linear skill tree, allowing players to customize the upgrade path.

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_gacha_pull` (The primary source of duplicates), `atom_character_level` (Constellations often scale with base stats), `atom_skill_tree` (Can be integrated as special nodes).
- **Incompatible Atoms:** `atom_permadeath` (Losing a highly invested, max-dupe character creates extreme frustration and churn), `atom_pure_horizontal_progression` (Dupe systems are inherently vertical power scaling).

## 8. Anti-Patterns
1. **Paywalling Core Mechanics:** Locking a character's fundamental, intended playstyle behind a duplicate (e.g., making a character feel incomplete or clunky at C0).
2. **Worthless Intermediate Nodes:** Having duplicate nodes that provide negligible benefits, making the player feel cheated when they pull a duplicate that doesn't reach a major breakpoint.
3. **Punishing Overflow:** Providing inadequate compensation when a player pulls a duplicate beyond the maximum limit, leading to "whaler's remorse."
