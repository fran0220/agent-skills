# Gameplay Atom: Card Draft

## 1. Identity
- **Atom ID:** `atom_card_draft`
- **English Name:** Card Draft
- **Chinese Name:** 卡牌选择
- **Category:** C (Core Mechanics / Card Systems)
- **Definition:** A mechanic where a player is presented with a limited selection of cards (or similar discrete options) and must choose one or more to add to their deck, inventory, or immediate play area. This process introduces controlled randomness and forces strategic decision-making under constraints.

## 2. Core Verb & State Machine
- **Core Verb:** Draft (Select / Choose)
- **State Diagram:**
  ```text
  [Idle] --> (Trigger Event) --> [Generating Options]
  [Generating Options] --> (Options Ready) --> [Waiting for Selection]
  [Waiting for Selection] --> (Player Selects Card) --> [Processing Selection]
  [Waiting for Selection] --> (Player Skips) --> [Processing Skip]
  [Processing Selection] --> (Card Added) --> [Resolution]
  [Processing Skip] --> (Reward Skipped) --> [Resolution]
  [Resolution] --> (End of Draft) --> [Idle]
  ```
- **States:**
  - `Idle`: The default state before a draft is triggered.
  - `Generating Options`: The system determines which cards to present based on drop tables, weights, and RNG.
  - `Waiting for Selection`: The player is reviewing the options.
  - `Processing Selection`: The chosen card is being added to the player's deck.
  - `Processing Skip`: The player chose not to draft any card.
  - `Resolution`: Cleanup of the draft UI and state.
- **Transitions:**
  - `Idle` -> `Generating Options`: Triggered by winning a battle, opening a pack, or an event.
  - `Generating Options` -> `Waiting for Selection`: Options are successfully generated and displayed.
  - `Waiting for Selection` -> `Processing Selection`: Player clicks a card.
  - `Waiting for Selection` -> `Processing Skip`: Player clicks the "Skip" button.
  - `Processing Selection` -> `Resolution`: Card is successfully added.
  - `Processing Skip` -> `Resolution`: Skip is confirmed.
  - `Resolution` -> `Idle`: Draft sequence ends.

## 3. MDA Analysis
- **Mechanics:** The game randomly selects a subset of cards from a larger pool (often weighted by rarity or player class) and presents them to the player. The player may select a specified number of cards (usually 1) or skip.
- **Dynamics:** Players must evaluate the presented options against their current deck composition, anticipating future synergies and immediate needs. This creates a dynamic where players sometimes pivot their entire strategy based on a high-rarity draft.
- **Aesthetics:** 
  - *Discovery:* The excitement of seeing what options are available.
  - *Expression:* Building a unique deck that reflects the player's choices.
  - *Challenge:* Making the optimal choice under uncertainty.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value | Unit |
|---|---|---|---|---|
| `options_count` | u32 | 2 - 5 | 3 (Slay the Spire v2.3) | cards |
| `can_skip` | bool | true/false | true (Slay the Spire v2.3) | boolean |
| `rare_chance` | f32 | 0.01 - 0.20 | 0.03 (Slay the Spire v2.3) | probability |
| `uncommon_chance` | f32 | 0.10 - 0.40 | 0.37 (Slay the Spire v2.3) | probability |
| `picks_allowed` | u32 | 1 - 3 | 1 (Monster Train v1.2) | cards |

## 5. Benchmark Data
- **Slay the Spire (v2.3):**
  - `options_count`: 3
  - `can_skip`: true
  - `rare_chance`: 0.03
  - `uncommon_chance`: 0.37
  - `picks_allowed`: 1
- **Monster Train (v1.2):**
  - `options_count`: 3
  - `can_skip`: true
  - `rare_chance`: 0.10
  - `picks_allowed`: 1

## 6. Common Variants
1. **Draft with Reroll:** The player can spend currency to replace the current options with a new set (e.g., *Vampire Survivors* level up).
2. **Draft Multiple:** The player can select more than one card from the presented options (e.g., specific boss relics in *Slay the Spire*).
3. **Draft from Grid/Pack:** Players pick one card from a larger pack, and the rest are passed to other players or discarded (e.g., *Magic: The Gathering* booster draft).
4. **Weighted Draft:** Options are heavily weighted by the player's current deck archetypes to ensure viability.

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_deck_building`, `atom_rng_manipulation`, `atom_resource_management`, `atom_pity_timer`.
- **Incompatible Atoms:** `atom_fixed_progression` (Conflicts with the inherent randomness of drafting).

## 8. Anti-Patterns
1. **Illusion of Choice:** Presenting options where one is mathematically always superior, removing the strategic decision.
2. **Pool Dilution:** Adding too many highly specific or weak cards to the draft pool, making it impossible for players to find synergies.
3. **Forced Drafting:** Not allowing the player to skip when all options actively harm their current deck strategy.
