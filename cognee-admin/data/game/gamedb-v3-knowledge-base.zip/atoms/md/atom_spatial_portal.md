# Identity
- **Atom ID**: atom_spatial_portal
- **English Name**: Spatial Portal
- **Chinese Name**: 空间传送门
- **Category**: C
- **Definition**: A gameplay mechanic that connects two distinct points in space, allowing entities to instantly travel between them while preserving momentum.

# Core Verb & State Machine
- **Core Verb**: Teleport
- **State Diagram**:
  - `Idle` -> `Opening` (Trigger: Player fires portal gun)
  - `Opening` -> `Active` (Trigger: Portal fully formed)
  - `Active` -> `Teleporting` (Trigger: Entity enters portal)
  - `Teleporting` -> `Active` (Trigger: Entity exits portal)
  - `Active` -> `Closing` (Trigger: Portal replaced or removed)
  - `Closing` -> `Idle` (Trigger: Portal fully closed)

# MDA Analysis
- **Mechanics**: The system creates two linked surfaces. When an object intersects one surface, it is translated and rotated relative to the other surface, maintaining its velocity vector relative to the portal normal.
- **Dynamics**: Players can use portals to bypass obstacles, redirect projectiles, or build infinite falling loops to gain terminal velocity.
- **Aesthetics**: Creates a sense of mind-bending discovery, puzzle-solving satisfaction, and spatial awareness.

# Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value | Unit |
|---|---|---|---|---|
| `portal_width` | f32 | 1.0 - 3.0 | 2.0 (Portal) | meters |
| `portal_height` | f32 | 2.0 - 4.0 | 3.0 (Portal) | meters |
| `momentum_retention` | f32 | 0.0 - 1.0 | 1.0 (Portal) | ratio |
| `teleport_cooldown` | f32 | 0.0 - 1.0 | 0.1 (Portal 2) | seconds |

# Benchmark Data
- **Portal (v1.0)**: `portal_width` = 2.0, `portal_height` = 3.0, `momentum_retention` = 1.0
- **Portal 2 (v1.0)**: `portal_width` = 2.0, `portal_height` = 3.0, `momentum_retention` = 1.0, `teleport_cooldown` = 0.1

# Common Variants
1. **One-Way Portal**: Entities can only travel from A to B, not B to A.
2. **Time-Limited Portal**: Portals close automatically after a set duration.
3. **Size-Altering Portal**: Entities change size upon exiting the portal.

# Compatibility Notes
- **Compatible Atoms**: atom_momentum_conservation, atom_projectile_physics
- **Incompatible Atoms**: atom_rigid_body_collision (when halfway through portal)

# Anti-Patterns
1. **Camera Clipping**: Failing to render the destination view correctly, causing visual artifacts.
2. **Infinite Loops**: Allowing portals to overlap or be placed inside each other, causing physics engine crashes.
