# Identity
- **Atom ID**: atom_minigame_rotation
- **English Name**: Minigame Rotation
- **Chinese Name**: 小游戏轮换
- **Category**: G
- **Definition**: A gameplay structure where players engage in a rapid succession of short, distinct mini-games, often with varying mechanics, objectives, and controls, transitioning quickly from one to the next.

# Core Verb & State Machine
- **Core Verb**: Adapt (to rapidly changing rules and controls)
- **State Diagram**:
  [Idle/Lobby] -> [Minigame Intro] -> [Playing Minigame] -> [Result/Score] -> [Transition] -> [Minigame Intro] (Loop) -> [Final Results]
- **States**:
  - `Idle/Lobby`: Waiting for the rotation to start.
  - `Minigame Intro`: Brief explanation of the upcoming minigame's rules and controls.
  - `Playing Minigame`: Active gameplay phase of the current minigame.
  - `Result/Score`: Displaying the outcome of the just-completed minigame.
  - `Transition`: Moving to the next minigame in the queue.
  - `Final Results`: Overall scoring and ranking after all minigames are completed.
- **Transitions**:
  - `Idle/Lobby` -> `Minigame Intro`: Start rotation.
  - `Minigame Intro` -> `Playing Minigame`: Intro timer ends.
  - `Playing Minigame` -> `Result/Score`: Minigame win/loss condition met or timer ends.
  - `Result/Score` -> `Transition`: Score display timer ends.
  - `Transition` -> `Minigame Intro`: Next minigame loaded.
  - `Result/Score` -> `Final Results`: All minigames in the rotation completed.

# MDA Analysis
- **Mechanics**: The system randomly or sequentially selects a minigame from a pool, loads its specific ruleset and assets, provides a brief tutorial, and executes the game loop for a short duration before tallying scores and moving to the next.
- **Dynamics**: Players must constantly shift their mental models and physical inputs. The rapid context switching creates a chaotic, high-energy environment where adaptability is more valuable than deep mastery of a single mechanic.
- **Aesthetics**: Frantic fun, surprise, tension, and comedy (especially when players fail to adapt quickly).

# Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value | Unit |
|---|---|---|---|---|
| `intro_duration` | f32 | 1.0 - 5.0 | 3.0 (Mario Party Superstars) | seconds |
| `minigame_duration` | f32 | 3.0 - 60.0 | 5.0 (WarioWare: Get It Together!) | seconds |
| `transition_duration` | f32 | 0.5 - 3.0 | 1.5 (WarioWare: Get It Together!) | seconds |
| `speed_multiplier` | f32 | 1.0 - 3.0 | 1.2 (WarioWare: Get It Together!) | multiplier |
| `games_per_rotation` | u32 | 5 - 100 | 15 (WarioWare: Get It Together!) | count |

# Benchmark Data
- **WarioWare: Get It Together! (v1.0.0)**:
  - `intro_duration`: 2.0s
  - `minigame_duration`: 4.0s (base speed)
  - `transition_duration`: 1.0s
  - `speed_multiplier`: Increases by 0.1 every 5 games.
- **Mario Party Superstars (v1.1.1)**:
  - `intro_duration`: 5.0s (can be skipped)
  - `minigame_duration`: 30.0s - 60.0s
  - `transition_duration`: 3.0s

# Common Variants
1. **Microgame Rush**: Extremely short games (3-5 seconds) with increasing speed and difficulty (e.g., WarioWare).
2. **Board Game Intermission**: Minigames played at the end of a turn cycle in a larger board game structure (e.g., Mario Party).
3. **Party Gauntlet**: A set playlist of longer minigames played back-to-back for a cumulative score (e.g., Fall Guys shows).
4. **Training Montage**: A sequence of minigames designed to test different specific skills (e.g., Brain Age).

# Compatibility Notes
- **Compatible Atoms**: `atom_score_accumulation`, `atom_random_selection`, `atom_timer_countdown`, `atom_elimination`.
- **Incompatible Atoms**: `atom_deep_tech_tree`, `atom_long_term_planning`, `atom_persistent_world`.
- **Conflicts**: Atoms requiring long setup times or deep immersion conflict with the rapid context switching of minigame rotation.

# Anti-Patterns
1. **Inadequate Intro**: Failing to clearly communicate the rules and controls in the short intro window, leading to player frustration.
2. **Jarring Difficulty Spikes**: Placing a highly complex minigame immediately after a simple one without adjusting the intro time or pacing.
3. **Overly Long Transitions**: Breaking the frantic flow of the rotation with excessive loading screens or unskippable animations.
