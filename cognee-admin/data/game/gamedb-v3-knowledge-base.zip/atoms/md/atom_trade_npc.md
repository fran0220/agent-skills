# Identity
- **Atom ID**: atom_trade_npc
- **English Name**: NPC Trade / Shop
- **Chinese Name**: NPC交易/商店
- **Category**: C
- **Definition**: A system where players can exchange resources (usually currency) for items, services, or other resources with a non-player character (NPC), facilitating economic progression and resource conversion.

# Core Verb & State Machine
- **Core Verb**: Trade / Buy / Sell
- **State Diagram**:
  [Idle] -> (Interact) -> [Browsing]
  [Browsing] -> (Select Item) -> [Confirming]
  [Confirming] -> (Confirm Purchase/Sale) -> [Transaction Processing]
  [Transaction Processing] -> (Success) -> [Browsing]
  [Transaction Processing] -> (Failure: Insufficient Funds/Space) -> [Browsing]
  [Browsing] -> (Exit) -> [Idle]

# MDA Analysis
- **Mechanics**: The system provides a list of available items with associated costs. It checks player inventory for sufficient currency and space before transferring items and deducting currency.
- **Dynamics**: Players engage in resource gathering to afford desired items. They may optimize their gathering routes or wait for specific items to appear in rotating inventories.
- **Aesthetics**: Provides a sense of progression, reward, and anticipation (especially with rotating or rare stock). It creates a feeling of a living world where NPCs have economic roles.

# Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value | Unit |
|---|---|---|---|---|
| `buy_price_multiplier` | f32 | 1.0 - 5.0 | 2.0 (Stardew Valley v1.5) | multiplier |
| `sell_price_multiplier` | f32 | 0.1 - 1.0 | 0.5 (Stardew Valley v1.5) | multiplier |
| `restock_time` | u32 | 0 - 168 | 24 (Stardew Valley v1.5) | hours |
| `max_stock` | u32 | 1 - 999 | 99 (Zelda: BotW v1.5.0) | items |
| `discount_rate` | f32 | 0.0 - 0.5 | 0.0 (Diablo II v1.14d) | multiplier |

# Benchmark Data
- **Stardew Valley (v1.5)**: `buy_price_multiplier` = 2.0, `sell_price_multiplier` = 0.5, `restock_time` = 24
- **Zelda: Breath of the Wild (v1.5.0)**: `max_stock` = 99, `buy_price_multiplier` = 4.0, `sell_price_multiplier` = 0.25
- **Diablo II (v1.14d)**: `discount_rate` = 0.0 (base), can increase with specific items/quests.

# Common Variants
1. **Rotating Shop**: Inventory changes periodically (e.g., daily or weekly).
2. **Reputation Shop**: Prices or available items improve as the player's reputation with the NPC or faction increases.
3. **Barter System**: Trading items directly for other items without a universal currency.
4. **Dynamic Pricing**: Prices fluctuate based on supply and demand or player actions.

# Compatibility Notes
- **Compatible Atoms**: `atom_inventory_management`, `atom_currency_system`, `atom_reputation_system`, `atom_crafting`.
- **Conflicts**: May conflict with strict survival mechanics if resources are too easily obtained via trade.

# Anti-Patterns
1. **Economy Breaking**: Setting sell prices too high, allowing players to easily generate infinite wealth through simple loops.
2. **Useless Shops**: Filling shops with items that are easily found in the world or quickly outclassed, making the shop irrelevant.
3. **Clunky UI**: Requiring too many clicks to buy/sell multiple items, causing player frustration.
