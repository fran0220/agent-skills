# Gameplay Atom: Energy Per Turn

## 1. Identity
- **Atom ID**: atom_energy_per_turn
- **English Name**: Energy Per Turn
- **Chinese Name**: 每回合能量
- **Category**: C (Resource Management)
- **Definition**: The fundamental resource regeneration mechanic in turn-based games where a player is granted a specific, usually fixed, amount of action points or "energy" at the beginning of each of their turns, which is then consumed to play cards, use abilities, or perform actions.

## 2. Core Verb & State Machine
- **Core Verb**: Spend (Energy)
- **State Diagram**:
  [Turn Start] -> (Regenerate Energy) -> [Idle/Action Phase] -> (Spend Energy) -> [Action Executed] -> (Check Remaining Energy) -> [Idle/Action Phase] OR [End Turn]
- **States**:
  - `Turn_Start`: The beginning of the player's turn.
  - `Energy_Regenerated`: The state immediately after the base energy amount is added to the player's pool.
  - `Action_Phase`: The main state where the player can choose actions.
  - `Energy_Spent`: The transitional state when an action is confirmed and energy is deducted.
  - `Turn_End`: The conclusion of the player's turn, often resetting or clearing unspent energy.
- **Transitions**:
  - `Turn_Start` to `Energy_Regenerated`: Triggered automatically at the start of the turn.
  - `Energy_Regenerated` to `Action_Phase`: Automatic transition once resources are updated.
  - `Action_Phase` to `Energy_Spent`: Triggered by the player selecting and confirming a valid action that costs energy.
  - `Energy_Spent` to `Action_Phase`: Automatic return after the action resolves, provided the turn hasn't ended.
  - `Action_Phase` to `Turn_End`: Triggered by the player explicitly ending their turn, or automatically if no valid actions remain and auto-end is enabled.

## 3. MDA Analysis
- **Mechanics**: The system sets a base energy value (e.g., 3). At the start of the player's turn, their current energy is set to this base value (or increased by it, depending on whether energy carries over). Each action (card play, unit movement) has an energy cost. The system checks if current energy >= cost before allowing the action. Upon execution, current energy is reduced by the cost.
- **Dynamics**: Players must optimize their action sequencing within the strict constraint of their energy pool. This creates a puzzle-like dynamic each turn: "How can I maximize value with my 3 energy?" It encourages evaluating the cost-efficiency of different actions and often leads to "combo" turns if energy generation actions are available.
- **Aesthetics**: The primary feeling is one of calculated constraint and resourcefulness. Players feel a sense of satisfaction when they perfectly spend all their energy for maximum effect (efficiency). Conversely, there is tension when deciding between a high-cost, high-impact action versus multiple low-cost actions.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value | Unit |
| :--- | :--- | :--- | :--- | :--- |
| `base_energy` | `u32` | 1 - 10 | 3 (Slay the Spire v2.3) | Points |
| `max_energy` | `u32` | 3 - 99 | 999 (Monster Train) | Points |
| `carry_over` | `bool` | true / false | false (Slay the Spire) | Boolean |
| `energy_cap` | `u32` | 3 - 10 | 10 (Hearthstone) | Points |

## 5. Benchmark Data
- **Slay the Spire (v2.3)**:
  - `base_energy`: 3
  - `carry_over`: false (unspent energy is lost at end of turn unless specific relics/cards are used, like Ice Cream).
- **Monster Train (v1.2)**:
  - `base_energy`: 3 (Ember)
  - `carry_over`: false (unspent Ember is lost).
- **Hearthstone (v28.0)**:
  - `base_energy`: Starts at 1, increases by 1 each turn up to 10.
  - `carry_over`: false.

## 6. Common Variants
1. **Incremental Energy**: The base energy increases by a fixed amount each turn up to a cap (e.g., Hearthstone's Mana Crystals).
2. **Carry-Over Energy**: Unspent energy from the previous turn is added to the next turn's pool, allowing players to "save up" for massive turns (e.g., Legends of Runeterra's Spell Mana).
3. **Variable Regeneration**: The amount of energy regenerated depends on board state, specific units, or previous actions, rather than a static base value.
4. **Action-Specific Energy**: Different pools of energy for different types of actions (e.g., Movement points vs. Action points in tactical RPGs).

## 7. Compatibility Notes
- **Compatible Atoms**:
  - `atom_card_draw`: Drawing cards provides the options to spend the energy on.
  - `atom_energy_boost`: Temporary or permanent increases to the base energy pool.
  - `atom_cost_reduction`: Modifying the cost of actions to fit more into the energy constraint.
- **Incompatible Atoms**:
  - `atom_real_time_cooldowns`: Mixing strict turn-based energy with real-time cooldowns often creates confusing pacing and UI challenges.

## 8. Anti-Patterns
1. **Energy Starvation**: Setting the base energy too low relative to average action costs, leading to turns where the player can do nothing meaningful, causing frustration.
2. **Irrelevant Constraints**: Providing so much energy generation that the constraint disappears entirely, turning the game into a pure card-draw check rather than a resource management puzzle.
3. **Hidden Costs**: Having actions that consume energy in non-obvious ways, leading to players miscalculating their turns and feeling cheated by the system.
