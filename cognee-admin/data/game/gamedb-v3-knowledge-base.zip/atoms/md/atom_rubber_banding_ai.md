# Gameplay Atom: Rubber Banding AI

## 1. Identity
- **Atom ID:** atom_rubber_banding_ai
- **English Name:** Rubber Banding AI
- **Chinese Name:** 橡皮筋AI
- **Category:** G (Game AI)
- **Definition:** Rubber Banding AI is a dynamic difficulty adjustment system commonly used in racing games that artificially alters the speed, acceleration, or capabilities of AI-controlled entities based on their distance from the player. This creates a "rubber band" effect where AI opponents catch up quickly when behind but slow down when ahead, ensuring the player always experiences close, competitive gameplay regardless of their actual skill level.

## 2. Core Verb & State Machine
- **Core Verb:** Adjust (Speed/Acceleration)

**State Diagram:**
```text
[Idle] --> (Race Starts) --> [Tracking]
[Tracking] --> (Player is far ahead) --> [Boosting]
[Tracking] --> (Player is far behind) --> [Handicapping]
[Boosting] --> (Distance normalizes) --> [Tracking]
[Handicapping] --> (Distance normalizes) --> [Tracking]
[Tracking] --> (Race Ends) --> [Finished]
```

**States and Transitions:**
- **Idle:** The AI is waiting for the race to begin.
- **Tracking:** The AI is moving at its base speed, monitoring the distance to the player.
- **Boosting:** The AI receives a temporary increase in speed and acceleration to catch up to the player.
- **Handicapping:** The AI's speed and acceleration are artificially reduced to allow the player to catch up.
- **Finished:** The race has concluded, and the AI stops adjusting its speed.

## 3. MDA Analysis
- **Mechanics:** The system continuously calculates the distance between the player and the AI. If the distance exceeds a predefined maximum threshold, the AI's speed multiplier increases. If the distance falls below a minimum threshold (meaning the player is far behind), the AI's speed multiplier decreases.
- **Dynamics:** This creates a self-correcting race ecosystem. No matter how perfectly the player drives, the AI will always remain a threat. Conversely, if the player makes multiple mistakes, the AI will wait for them, preventing the race from becoming unwinnable early on.
- **Aesthetics:** Players experience a heightened sense of tension, excitement, and challenge. The constant proximity of opponents fosters a feeling of a "close race," enhancing the dramatic climax near the finish line. However, if implemented poorly, it can lead to frustration, as players may feel their skill and effort are invalidated by the system's artificial adjustments.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Mario Kart 8 Deluxe v2.3.0) | Unit |
|---|---|---|---|---|
| `base_speed` | f32 | 50.0 - 150.0 | 100.0 | units/sec |
| `catch_up_distance` | f32 | 100.0 - 500.0 | 300.0 | units |
| `slow_down_distance` | f32 | 100.0 - 500.0 | 250.0 | units |
| `max_boost_multiplier` | f32 | 1.1 - 2.0 | 1.35 | multiplier |
| `min_handicap_multiplier` | f32 | 0.5 - 0.9 | 0.75 | multiplier |
| `adjustment_rate` | f32 | 0.1 - 5.0 | 1.5 | multiplier/sec |

## 5. Benchmark Data
- **Mario Kart 8 Deluxe (v2.3.0):**
  - `base_speed`: 100.0
  - `catch_up_distance`: 300.0
  - `max_boost_multiplier`: 1.35
  - `min_handicap_multiplier`: 0.75
- **Need for Speed: Underground (v1.4):**
  - `base_speed`: 120.0
  - `catch_up_distance`: 400.0
  - `max_boost_multiplier`: 1.50
  - `min_handicap_multiplier`: 0.80
- **F-Zero GX (v1.0):**
  - `base_speed`: 200.0
  - `catch_up_distance`: 500.0
  - `max_boost_multiplier`: 1.20
  - `min_handicap_multiplier`: 0.90

## 6. Common Variants
1. **Item-Based Rubber Banding:** Instead of directly altering speed, the system manipulates item drop probabilities. Players further behind receive powerful catch-up items (e.g., Blue Shell, Bullet Bill), while players in first place receive defensive or weak items (e.g., Banana, Coin).
2. **Checkpoint-Based Rubber Banding:** The AI's speed is only adjusted at specific checkpoints on the track rather than continuously, making the adjustments less obvious to the player.
3. **Asymmetric Rubber Banding:** The AI will aggressively boost to catch up to the player but will not slow down significantly if the player falls behind, maintaining a high level of difficulty.
4. **Tiered Rubber Banding:** Different AI opponents have different rubber banding profiles. A "rival" AI might have aggressive rubber banding to always challenge the player, while "filler" AI have weaker rubber banding.

## 7. Compatibility Notes
- **Commonly Pairs With:**
  - `atom_dynamic_item_generation` (Dynamic Item Generation): Works synergistically to keep races close.
  - `atom_slipstreaming` (Slipstreaming/Drafting): Provides a natural, diegetic way for trailing vehicles to gain speed, masking the artificial rubber banding.
- **Known Conflicts:**
  - `atom_strict_simulation` (Strict Physics Simulation): Rubber banding fundamentally violates strict physics and vehicle performance metrics, leading to a clash in design philosophy.
  - `atom_time_trial_ghosts` (Time Trial Ghosts): Rubber banding must be disabled in time trials, as the goal is pure skill expression against a static recording.

## 8. Anti-Patterns
1. **The "Superman" AI:** Giving the AI such a massive speed boost that they visibly break the game's physics or pass the player at impossible speeds, breaking immersion and causing extreme frustration.
2. **The "Snail" AI:** Slowing the AI down so much when the player is behind that they appear to be parking on the track, making the game feel patronizing and unearned.
3. **Ignoring Track Topology:** Applying speed boosts without considering corners or hazards, causing the rubber-banding AI to constantly crash or fly off the track because they are moving too fast for the geometry.
