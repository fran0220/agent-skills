# atom_socket_gem

## 1. Identity
- **Atom ID**: atom_socket_gem
- **English Name**: Socket / Gem System
- **Chinese Name**: 镶嵌/宝石系统
- **Category**: C/D
- **Definition**: A progression system where players insert modular items (gems, runes, jewels) into equipment slots (sockets) to grant customizable, often removable, stat bonuses or new abilities to the base item.

## 2. Core Verb & State Machine
- **Core Verb**: Socket (Insert), Unsocket (Remove)
- **State Diagram**:
  [Empty Socket] --(Socket Gem)--> [Filled Socket]
  [Filled Socket] --(Unsocket Gem)--> [Empty Socket]
- **States**:
  - `Empty`: The socket is available to receive a compatible gem.
  - `Filled`: The socket contains a gem, applying its modifiers to the item.
- **Transitions**:
  - `Empty` -> `Filled`: Triggered by player action "Socket Gem", requires a compatible gem and an empty socket.
  - `Filled` -> `Empty`: Triggered by player action "Unsocket Gem", may require currency or a specific tool, and may destroy the gem or return it to inventory.

## 3. MDA Analysis
- **Mechanics**: Equipment has a predefined or random number of sockets. Gems have specific stats. Inserting a gem adds the gem's stats to the equipment. Sockets and gems may have colors or shapes restricting compatibility.
- **Dynamics**: Players hoard gems and seek equipment with optimal socket configurations. They face choices between using a good gem now or saving it for better equipment later.
- **Aesthetics**: Expression (customizing gear to fit a build), Discovery (finding rare gems or runewords), and Progression (incremental power gains).

## 4. Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value | Unit |
|---|---|---|---|---|
| `max_sockets` | u32 | 1 - 6 | 6 (Path of Exile v3.20) | sockets |
| `socket_chance` | f32 | 0.01 - 1.0 | 0.15 (Diablo 2 Resurrected) | probability |
| `unsocket_cost` | u32 | 0 - 1000 | 1 (Hel Rune, D2R) | currency/item |
| `gem_power_multiplier` | f32 | 1.0 - 5.0 | 1.0 | multiplier |

## 5. Benchmark Data
- **Diablo 2 Resurrected (v1.0)**:
  - `max_sockets`: 6 (for specific weapons/armor)
  - `unsocket_cost`: 1 (Hel Rune + Scroll of Town Portal recipe destroys gem)
- **Path of Exile (v3.20)**:
  - `max_sockets`: 6 (for two-handed weapons and body armors)
  - `unsocket_cost`: 0 (freely removable)

## 6. Common Variants
1. **Color-Matched Sockets**: Gems and sockets have colors; they must match (e.g., Path of Exile).
2. **Destructive Unsocketing**: Removing a gem destroys the gem, or destroying the item to save the gem (e.g., World of Warcraft early expansions).
3. **Runewords**: Inserting specific gems in a specific order grants massive hidden bonuses (e.g., Diablo 2).
4. **Linked Sockets**: Sockets are connected, allowing support gems to modify active skill gems (e.g., Path of Exile).

## 7. Compatibility Notes
- **Compatible Atoms**: `atom_random_affix`, `atom_crafting`, `atom_durability`
- **Incompatible Atoms**: `atom_fixed_progression`

## 8. Anti-Patterns
1. **Hoarding Paralysis**: Making unsocketing too expensive or impossible, causing players to never use their best gems.
2. **Trivial Choices**: Gems offer such minor bonuses that the system feels like unnecessary micromanagement.
3. **Over-RNG**: Making both getting sockets and getting gems too random, leading to extreme frustration.
