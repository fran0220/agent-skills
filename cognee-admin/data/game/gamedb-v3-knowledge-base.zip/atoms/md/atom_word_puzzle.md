# Gameplay Atom: Word Puzzle

## 1. Identity
- **Atom ID:** `atom_word_puzzle`
- **English Name:** Word Puzzle
- **Chinese Name:** 文字谜题
- **Category:** C
- **Definition:** A gameplay atom where the player interacts with letters, words, or linguistic structures to solve a challenge. This typically involves guessing a hidden word, forming valid words from a set of letters, or finding words within a grid, relying on the player's vocabulary and pattern recognition skills.

## 2. Core Verb & State Machine
- **Core Verb:** Spell / Guess / Arrange
- **State Diagram:**
  [Idle] --> (Input Letter) --> [Evaluating]
  [Evaluating] --> (Valid Word) --> [Success]
  [Evaluating] --> (Invalid Word) --> [Penalty/Retry]
  [Evaluating] --> (Partial Match) --> [Feedback] --> [Idle]
- **States:**
  - `Idle`: Waiting for player input.
  - `Evaluating`: Checking the player's input against the dictionary or target word.
  - `Feedback`: Providing hints (e.g., correct letter, wrong position).
  - `Success`: The puzzle is solved.
  - `Failed`: The player runs out of attempts or time.
- **Transitions:**
  - `Idle` -> `Evaluating`: Triggered by submitting a guess.
  - `Evaluating` -> `Feedback`: Triggered when the guess is valid but not the target word.
  - `Evaluating` -> `Success`: Triggered when the guess matches the target word.
  - `Evaluating` -> `Failed`: Triggered when max attempts are reached.

## 3. MDA Analysis
- **Mechanics:** The system provides a set of constraints (e.g., word length, available letters, maximum attempts) and evaluates player input against a predefined dictionary or target word. Feedback is given based on the accuracy of the input.
- **Dynamics:** Players develop strategies such as starting with vowel-heavy words, using process of elimination, or recognizing common prefixes/suffixes. The constraint of limited attempts creates tension.
- **Aesthetics:** Intellectual satisfaction, "Aha!" moments, tension, and relief. The joy of discovering a hidden pattern or successfully recalling a rare word.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Wordle v1.0) | Unit |
|---|---|---|---|---|
| `word_length` | u32 | 3 - 8 | 5 | letters |
| `max_attempts` | u32 | 3 - 10 | 6 | attempts |
| `time_limit` | f32 | 0.0 - 300.0 | 0.0 (unlimited) | seconds |
| `dictionary_size` | u32 | 1000 - 100000 | 2315 (answers) | words |
| `hint_penalty` | f32 | 0.0 - 1.0 | 0.0 | score multiplier |

## 5. Benchmark Data
- **Wordle (Web Version, 2021):**
  - `word_length`: 5
  - `max_attempts`: 6
  - `time_limit`: 0.0
  - `dictionary_size`: 2315
- **Scrabble (Standard Board Game Rules):**
  - `word_length`: 15
  - `max_attempts`: 0
  - `time_limit`: 0.0
  - `dictionary_size`: 279000

## 6. Common Variants
1. **Hidden Word Guessing (Wordle):** Guess a specific word with positional feedback.
2. **Tile Placement (Scrabble):** Form words on a grid using a limited hand of letter tiles, scoring based on letter rarity and board multipliers.
3. **Word Search (Boggle):** Find as many words as possible in a grid of adjacent letters within a time limit.
4. **Anagrams:** Rearrange a given set of letters to form all possible valid words.
5. **Crosswords:** Fill in a grid based on semantic clues and intersecting letter constraints.

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_timer` (adds time pressure), `atom_score_multiplier` (rewards longer or more complex words), `atom_combo_system` (rewards consecutive rapid solves).
- **Incompatible Atoms:** `atom_twitch_reflex` (fast-paced physical reactions often conflict with the cognitive load of word puzzles).

## 8. Anti-Patterns
1. **Obscure Vocabulary:** Using a dictionary that includes too many archaic or highly specialized words, leading to player frustration.
2. **Lack of Clear Feedback:** Failing to clearly indicate why a word is invalid or providing ambiguous hints.
3. **Overly Punishing Time Limits:** Setting a time limit that is too strict for the cognitive task, shifting the challenge from puzzle-solving to panic.
