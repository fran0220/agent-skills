# Gameplay Atom: Seasonal Calendar

## 1. Identity
**Atom ID:** atom_seasonal_calendar
**English Name:** Seasonal Calendar
**Chinese Name:** 季节日历
**Category:** G/H (Game Loop / Habituation)
**Definition:** The Seasonal Calendar is a time-tracking system that divides the game's timeline into distinct periods (seasons, months, or festivals), each bringing unique environmental changes, resource availability, and specific events. It serves as a macro-level pacing mechanism that encourages long-term planning and provides a rhythmic structure to the player's experience, ensuring that gameplay remains fresh and varied over extended play sessions.

## 2. Core Verb & State Machine
**Core Verb:** Plan / Wait / Transition

**State Diagram:**
[Spring] --> [Summer] --> [Autumn] --> [Winter] --> (Loops back to Spring)
   |            |            |            |
   v            v            v            v
[Events]     [Events]     [Events]     [Events]

**States:**
- `Spring`: A state characterized by renewal, specific crops, and early-year festivals.
- `Summer`: A state with high growth rates, unique foraging items, and mid-year events.
- `Autumn`: A state focused on harvest, changing aesthetics, and late-year preparations.
- `Winter`: A state with limited agricultural activity, focusing on social interactions, mining, or special winter events.

**Transitions:**
- `End of Spring` -> `Summer`: Triggered when the predefined number of days in Spring elapses.
- `End of Summer` -> `Autumn`: Triggered when the predefined number of days in Summer elapses.
- `End of Autumn` -> `Winter`: Triggered when the predefined number of days in Autumn elapses.
- `End of Winter` -> `Spring`: Triggered when the predefined number of days in Winter elapses, incrementing the game year.

## 3. MDA Analysis
**Mechanics:** The system tracks the passage of in-game time (days, weeks, months) and maps it to a cyclical calendar. It modifies global variables such as weather probabilities, crop growth rules, NPC schedules, and available quests based on the current season.
**Dynamics:** Players adapt their strategies based on the current and upcoming seasons. For example, they may hoard resources before Winter or maximize crop yield during Summer. The cyclical nature creates a predictable yet engaging rhythm of preparation and execution.
**Aesthetics:** The Seasonal Calendar evokes feelings of anticipation, nostalgia, and immersion. Players feel a connection to the passage of time and a sense of accomplishment as they survive or thrive through different seasonal challenges.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Game) | Unit |
|---|---|---|---|---|
| `days_per_season` | u32 | 7 - 30 | 28 (Stardew Valley v1.5) | Days |
| `seasons_per_year` | u32 | 4 - 12 | 4 (Stardew Valley v1.5) | Seasons |
| `day_duration_real_seconds` | f32 | 600.0 - 1440.0 | 860.0 (Stardew Valley v1.5) | Seconds |
| `weather_change_probability` | f32 | 0.1 - 0.5 | 0.25 (Animal Crossing: New Horizons v2.0) | Probability |

## 5. Benchmark Data
- **Stardew Valley (v1.5):** 
  - `days_per_season`: 28
  - `seasons_per_year`: 4
  - `day_duration_real_seconds`: 860.0 (14 minutes and 20 seconds of real time for a full 18-hour waking day)
- **Animal Crossing: New Horizons (v2.0):**
  - `days_per_season`: ~90 (Tied to real-world calendar)
  - `seasons_per_year`: 4
  - `day_duration_real_seconds`: 86400.0 (Real-time 24 hours)

## 6. Common Variants
1. **Real-Time Sync:** The in-game calendar mirrors the real-world calendar, requiring players to wait actual months for seasonal changes (e.g., Animal Crossing).
2. **Accelerated Seasons:** Seasons change very rapidly, sometimes within a single play session, to force quick adaptation (e.g., Don't Starve).
3. **Dynamic Seasons:** The length or severity of seasons is influenced by player actions or random global events, making the cycle unpredictable.
4. **Micro-Seasons:** The year is divided into many smaller periods (e.g., 24 solar terms) rather than just four broad seasons.

## 7. Compatibility Notes
**Compatible Atoms:**
- `atom_farming_system`: Highly synergistic, as crops are often season-dependent.
- `atom_npc_schedule`: NPCs can have different routines or dialogue based on the season.
- `atom_weather_system`: Seasons directly dictate weather patterns (e.g., snow only in Winter).

**Incompatible Atoms:**
- `atom_static_world`: A world that never changes conflicts fundamentally with the concept of a seasonal calendar.

## 8. Anti-Patterns
1. **Meaningless Seasons:** Implementing visual changes for seasons without any mechanical impact (e.g., snow falls but doesn't affect gameplay), which breaks player expectations.
2. **Overly Punishing Winters:** Making a specific season so difficult or restrictive that players simply skip playing during that time rather than engaging with the challenge.
3. **Desynced Pacing:** Having seasons change too quickly for players to accomplish seasonal goals, or too slowly, causing boredom and stagnation.
