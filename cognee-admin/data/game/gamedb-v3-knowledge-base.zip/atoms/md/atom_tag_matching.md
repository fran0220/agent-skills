# Atom: Tag / Attribute Matching (标签/属性匹配)

## 1. Identity
- **Atom ID:** atom_tag_matching
- **English Name:** Tag / Attribute Matching
- **Chinese Name:** 标签/属性匹配
- **Category:** G/H (Progression / Evaluation)
- **Definition:** Tag / Attribute Matching is a core gameplay mechanic where players select items, characters, or actions that possess specific qualitative or quantitative tags to meet a set of target criteria. The system evaluates the overlap and synergy between the player's selection and the target requirements, often calculating a final score based on base values, tag multipliers, and synergy bonuses. This mechanic is widely used in dress-up games, team-building RPGs, and simulation games to create depth in loadout preparation.

## 2. Core Verb & State Machine
- **Core Verb:** Select / Match

**State Diagram:**
[Idle] -> (Player selects item) -> [Selecting]
[Selecting] -> (Player confirms selection) -> [Evaluating]
[Evaluating] -> (System calculates score) -> [Result]
[Result] -> (Player accepts or retries) -> [Idle]

**States and Transitions:**
- **Idle:** The default state where the player is presented with the target tags and requirements.
- **Selecting:** The player browses their inventory and selects items with specific tags.
- **Evaluating:** The system compares the selected items' tags against the target tags, applying multipliers and calculating the final score.
- **Result:** The final score is displayed, determining success or failure based on a threshold.

## 3. MDA Analysis
- **Mechanics:** The system defines a target with specific desired tags (e.g., "Elegant", "Warm"). Players choose from a pool of items, each possessing its own set of tags and base stats. The system calculates a score by summing the base stats of items that match the target tags, often applying a multiplier for exact matches or penalizing conflicting tags.
- **Dynamics:** Players engage in a puzzle-like optimization process, trying to maximize their score with limited resources. They may discover unexpected synergies or have to make trade-offs when an item has a high base stat but lacks the perfect tag.
- **Aesthetics:** The mechanic evokes feelings of satisfaction, expression, and mastery. Players feel a sense of accomplishment when they perfectly align their choices with the system's demands, and enjoy the expressive freedom of combining different elements.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Game) | Unit |
|---|---|---|---|---|
| `base_score` | f32 | 10.0 - 1000.0 | 150.0 (Love Nikki v8.1) | Points |
| `tag_multiplier` | f32 | 1.0 - 5.0 | 2.5 (Love Nikki v8.1) | Multiplier |
| `penalty_multiplier` | f32 | 0.0 - 1.0 | 0.5 (Shining Nikki v2.0) | Multiplier |
| `synergy_bonus` | f32 | 0.0 - 500.0 | 100.0 (Genshin Impact v4.0) | Points |
| `match_threshold` | f32 | 100.0 - 10000.0 | 5000.0 (Love Nikki v8.1) | Points |

## 5. Benchmark Data
- **Love Nikki (v8.1):** The game heavily relies on tag matching for its styling battles. A typical stage might require "Simple" and "Elegant" tags. An item with both tags receives a massive `tag_multiplier` (often around 2.5x to 3.0x), while items with conflicting tags (e.g., "Gorgeous") might receive a `penalty_multiplier` or contribute 0 to the score. The `match_threshold` for an S-rank can range from 30,000 to 100,000 points depending on the chapter.
- **Genshin Impact (v4.0):** Elemental resonance and reactions act as a form of tag matching. Matching two characters of the same element (tag) provides a `synergy_bonus` (e.g., +25% ATK for Pyro). The `tag_multiplier` is seen in elemental reactions, where applying Hydro then Pyro yields a 1.5x damage multiplier.

## 6. Common Variants
1. **Binary Tag Matching:** Items either have the tag or don't. The score is simply the count of matching tags. Common in simple puzzle games.
2. **Weighted Tag Matching:** Tags have different weights or tiers (e.g., Primary Tag, Secondary Tag). Primary tags contribute more to the final score.
3. **Negative Tagging (Blacklisting):** Certain tags actively reduce the score or cause immediate failure if included in the selection.
4. **Synergistic Tagging:** Tags don't just match a target, but match with *each other* within the player's selection to create set bonuses.

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_inventory_management` (players need a diverse inventory to match various tags), `atom_gacha_pull` (acquiring items with rare tags), `atom_stat_progression` (leveling up items to increase their `base_score`).
- **Incompatible Atoms:** `atom_twitch_reflexes` (tag matching is inherently a slow, analytical process; adding real-time pressure often frustrates players).

## 8. Anti-Patterns
1. **Opaque Scoring:** Hiding the exact multipliers or failing to clearly indicate which tags are required, leading to player frustration as they cannot optimize their choices.
2. **Single Dominant Strategy:** Creating an item that possesses all positive tags, rendering the matching puzzle obsolete and reducing the mechanic to a simple "equip the best item" action.
3. **Tag Bloat:** Introducing too many highly specific tags (e.g., "Red-Striped-Summer-Hat") that are rarely reused, making inventory management a nightmare and reducing the value of individual items.
