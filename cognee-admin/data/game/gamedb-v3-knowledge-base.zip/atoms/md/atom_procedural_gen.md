# Gameplay Atom: Procedural Generation (程序化生成)

## 1. Identity
- **Atom ID:** atom_procedural_gen
- **English Name:** Procedural Generation
- **Chinese Name:** 程序化生成
- **Category:** G
- **Definition:** Procedural generation is a method of creating data algorithmically rather than manually, typically through a combination of human-generated assets and algorithms coupled with computer-generated randomness and processing power. It is widely used in video games to generate content such as levels, maps, items, quests, and even entire worlds dynamically, ensuring each playthrough offers a unique experience.

## 2. Core Verb & State Machine
- **Core Verb:** Generate (生成)
- **State Diagram:**
  [Idle] -> (Trigger Generation) -> [Generating] -> (Generation Complete) -> [Ready] -> (Consume/Explore) -> [Depleted] -> (Trigger Generation) -> [Generating]
- **States and Transitions:**
  - **Idle:** The system is waiting for a trigger to start generation.
  - **Generating:** The algorithm is actively creating content based on predefined rules and seeds.
  - **Ready:** The generated content is available for the player to interact with.
  - **Depleted:** The content has been fully explored or consumed, requiring new generation.
  - **Transitions:**
    - *Idle -> Generating:* Triggered by player action (e.g., entering a new area) or system event.
    - *Generating -> Ready:* Triggered when the algorithm completes its execution.
    - *Ready -> Depleted:* Triggered when the player exhausts the content.
    - *Depleted -> Generating:* Triggered when new content is needed.

## 3. MDA Analysis
- **Mechanics:** The system uses algorithms (e.g., Perlin noise, cellular automata, L-systems) and a random seed to produce game assets or environments. It involves defining rules, constraints, and parameter ranges to ensure the output is playable and coherent.
- **Dynamics:** Players experience a constantly changing environment, which encourages exploration, adaptability, and replayability. The unpredictability forces players to develop general strategies rather than memorizing specific layouts.
- **Aesthetics:** The primary aesthetic is **Discovery**. Players feel a sense of wonder and curiosity as they explore unknown territories. It also contributes to **Challenge**, as players must adapt to unforeseen obstacles, and **Endless**, providing a feeling of infinite possibilities.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Game/Version) | Unit |
|---|---|---|---|---|
| `seed` | u32 | 0 - 4294967295 | 123456789 (Minecraft 1.19) | N/A |
| `noise_scale` | f32 | 0.01 - 100.0 | 0.05 (Minecraft 1.19) | multiplier |
| `octaves` | u32 | 1 - 8 | 4 (No Man's Sky 3.0) | count |
| `persistence` | f32 | 0.1 - 1.0 | 0.5 (Spelunky 2 1.23) | multiplier |
| `lacunarity` | f32 | 1.0 - 4.0 | 2.0 (Minecraft 1.19) | multiplier |
| `threshold` | f32 | 0.0 - 1.0 | 0.45 (Spelunky 2 1.23) | ratio |

## 5. Benchmark Data
- **Minecraft (Version 1.19):**
  - `seed`: User-defined or randomly generated 64-bit integer (mapped to u32 for simplicity).
  - `noise_scale`: ~0.05 for terrain generation.
  - `octaves`: 4 for standard biome noise.
  - `lacunarity`: 2.0.
- **Spelunky 2 (Version 1.23):**
  - `persistence`: 0.5 for room template selection.
  - `threshold`: 0.45 for obstacle placement density.
- **No Man's Sky (Version 3.0):**
  - `octaves`: 4 to 6 for planetary terrain complexity.

## 6. Common Variants
1. **Noise-Based Terrain Generation:** Uses Perlin or Simplex noise to create continuous, natural-looking landscapes (e.g., Minecraft).
2. **Template-Based Room Generation:** Assembles pre-designed rooms or chunks in a randomized order, ensuring playability while maintaining variety (e.g., Spelunky).
3. **Grammar-Based Generation:** Uses L-systems or similar grammars to generate structures like trees, plants, or even city layouts.
4. **Cellular Automata:** Used for cave generation, simulating natural erosion or organic growth by iteratively applying rules to a grid.
5. **Wave Function Collapse:** A constraint-solving algorithm that generates patterns or levels by ensuring local constraints are met (e.g., Caves of Qud).

## 7. Compatibility Notes
- **Compatible Atoms:**
  - `atom_exploration`: Procedural generation naturally supports exploration by providing endless new content.
  - `atom_resource_gathering`: Resources can be procedurally distributed, making gathering dynamic.
  - `atom_permadeath`: Often paired in roguelikes to ensure each run is unique.
- **Incompatible Atoms:**
  - `atom_linear_storytelling`: Highly procedural environments can disrupt tightly scripted narrative pacing.
  - `atom_memorization_puzzle`: Puzzles that rely on fixed layouts are incompatible with procedural generation.

## 8. Anti-Patterns
1. **"Bowl of Oatmeal" Syndrome:** Generating vast amounts of content that all feels the same because the variations lack meaningful gameplay impact.
2. **Unplayable Configurations:** Failing to implement sufficient constraints, resulting in generated levels that are impossible to complete (e.g., blocking the critical path).
3. **Performance Bottlenecks:** Running complex generation algorithms on the main thread during gameplay, causing stuttering or long load times.
