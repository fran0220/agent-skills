# Gameplay Atom: Physics-Based Puzzle

## 1. Identity
- **Atom ID:** `atom_physics_puzzle`
- **English Name:** Physics-Based Puzzle
- **Chinese Name:** 物理谜题
- **Category:** C
- **Definition:** A gameplay atom where players manipulate objects governed by simulated physical laws (such as gravity, mass, friction, and momentum) to achieve a specific goal, such as clearing a path, reaching a target, or triggering a mechanism.

## 2. Core Verb & State Machine
- **Core Verb:** Manipulate (Push, Pull, Lift, Throw, Stack)
- **State Diagram:**
  [Idle] --(Interact)--> [Manipulating]
  [Manipulating] --(Release/Throw)--> [Simulating]
  [Simulating] --(Settle)--> [Idle]
  [Simulating] --(Solve Condition Met)--> [Solved]
- **States:**
  - `Idle`: Objects are at rest, waiting for player interaction.
  - `Manipulating`: Player is actively applying forces or constraints to objects.
  - `Simulating`: Objects are moving under the influence of physics engine forces.
  - `Solved`: The puzzle's success condition has been met.
- **Transitions:**
  - `Idle` -> `Manipulating`: Player grabs or applies force to an object.
  - `Manipulating` -> `Simulating`: Player releases the object or applies an impulse.
  - `Simulating` -> `Idle`: Object comes to a complete stop without solving the puzzle.
  - `Simulating` -> `Solved`: Object reaches the target zone or triggers the required sensor.

## 3. MDA Analysis
- **Mechanics:** The system simulates rigid body dynamics, collision detection, and physical constraints (joints, springs). It evaluates the state of objects against success criteria (e.g., total mass on a pressure plate, object intersecting a trigger volume).
- **Dynamics:** Players experiment with different combinations of objects, discovering emergent solutions through trial and error. Chain reactions and unintended physical interactions often occur.
- **Aesthetics:** Evokes feelings of intellectual satisfaction, curiosity, and sometimes amusement from unpredictable physical reactions. It taps into the player's intuitive understanding of real-world physics.

## 4. Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value (Game) | Unit |
|---|---|---|---|---|
| `gravity_scale` | f32 | 0.5 - 2.0 | 1.0 (Half-Life 2 v1.0) | multiplier |
| `object_mass` | f32 | 1.0 - 1000.0 | 50.0 (Breath of the Wild v1.5.0) | kg |
| `friction_coeff` | f32 | 0.0 - 1.0 | 0.6 (Half-Life 2 v1.0) | coefficient |
| `bounciness` | f32 | 0.0 - 1.0 | 0.2 (Breath of the Wild v1.5.0) | coefficient |
| `solve_tolerance` | f32 | 0.01 - 1.0 | 0.1 (Portal 2 v1.0) | meters |

## 5. Benchmark Data
- **Half-Life 2 (v1.0):**
  - `gravity_scale`: 1.0
  - `object_mass` (standard crate): 40.0 kg
  - `friction_coeff`: 0.6
- **The Legend of Zelda: Breath of the Wild (v1.5.0):**
  - `gravity_scale`: 1.2 (feels slightly heavier for faster falling)
  - `object_mass` (metal block): 500.0 kg
  - `bounciness`: 0.1
- **Portal 2 (v1.0):**
  - `solve_tolerance`: 0.1 meters (for cube on button)
  - `object_mass` (companion cube): 40.0 kg

## 6. Common Variants
1. **Weight/Balance Puzzles:** Players must place objects of specific masses on scales or pressure plates to achieve equilibrium or trigger a threshold.
2. **Trajectory/Ballistics Puzzles:** Players must launch an object at the correct angle and velocity to hit a target.
3. **Stacking/Structure Puzzles:** Players must build a stable structure using various shapes to reach a height or bridge a gap.
4. **Buoyancy Puzzles:** Players manipulate water levels or object densities to make items float to specific locations.
5. **Kinetic Energy/Domino Puzzles:** Players set up a chain reaction where the momentum of one object transfers to others.

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_grab_throw`, `atom_environmental_destruction`, `atom_time_manipulation` (e.g., Stasis in BotW).
- **Incompatible Atoms:** `atom_grid_movement` (continuous physics clashes with discrete grid logic), `atom_turn_based_combat` (real-time physics simulation disrupts turn flow).

## 8. Anti-Patterns
1. **Overly Strict Tolerances:** Requiring pixel-perfect placement or exact timing in a physics simulation, leading to frustration due to the inherent unpredictability of physics engines.
2. **Unclear Physical Properties:** Objects that look heavy but act light, or vice versa, breaking the player's intuitive understanding and making the puzzle feel arbitrary.
3. **Physics Jitter/Explosions:** Poorly tuned collision meshes or constraints causing objects to violently intersect and fly apart, breaking the puzzle state.
