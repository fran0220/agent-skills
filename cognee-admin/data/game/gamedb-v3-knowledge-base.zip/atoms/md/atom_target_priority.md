# Targeting Priority (目标优先级)

## 1. Identity
- **Atom ID:** atom_target_priority
- **English Name:** Targeting Priority
- **Chinese Name:** 目标优先级
- **Category:** G
- **Definition:** The system that determines which entity an actor (such as a tower or unit) will attack or interact with when multiple valid targets are within range.

## 2. Core Verb & State Machine
- **Core Verb:** Target (Select and focus on an entity)
- **State Diagram:**
  [Idle] --> (Enemy enters range) --> [Evaluating Targets]
  [Evaluating Targets] --> (Target selected) --> [Engaging]
  [Engaging] --> (Target dies/leaves range) --> [Evaluating Targets]
  [Evaluating Targets] --> (No targets in range) --> [Idle]
- **States:** Idle, Evaluating Targets, Engaging
- **Transitions:**
  - Idle -> Evaluating Targets: Triggered when one or more valid targets enter the interaction range.
  - Evaluating Targets -> Engaging: Triggered when the priority algorithm selects a specific target.
  - Engaging -> Evaluating Targets: Triggered when the current target is destroyed, becomes invalid, or moves out of range.
  - Evaluating Targets -> Idle: Triggered when no valid targets remain in range.

## 3. MDA Analysis
- **Mechanics:** The game continuously or periodically evaluates a list of potential targets within a specific radius and applies a sorting algorithm based on predefined criteria (e.g., distance, health, threat level) to select the optimal target.
- **Dynamics:** Players strategically place units or towers to maximize the efficiency of their targeting priorities. For example, placing a tower that targets "highest health" near the entrance to soften up tough enemies, while "closest to exit" towers are placed near the end to catch leakers.
- **Aesthetics:** Provides a sense of control and strategic depth. Players feel satisfaction when their defensive setup efficiently handles waves of enemies due to well-optimized targeting behaviors.

## 4. Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value | Unit |
|---|---|---|---|---|
| `scan_radius` | f32 | 1.0 - 20.0 | 5.0 (Kingdom Rush v1.0) | tiles |
| `priority_mode` | enum | 0 - 4 | 0 (Closest) | N/A |
| `retarget_delay` | f32 | 0.0 - 2.0 | 0.5 (Bloons TD 6 v30.0) | seconds |
| `sticky_targeting` | bool | true/false | true (Arknights v1.0) | N/A |

## 5. Benchmark Data
- **Kingdom Rush (v1.0):** `scan_radius` = 5.0, `priority_mode` = 0 (Closest to exit), `sticky_targeting` = true.
- **Bloons TD 6 (v30.0):** `scan_radius` = 40.0, `priority_mode` = 1 (First/Strong/Last/Close options available), `retarget_delay` = 0.0.
- **Arknights (v1.0):** `scan_radius` = 3.0, `priority_mode` = 2 (Closest to blue box), `sticky_targeting` = true.

## 6. Common Variants
1. **Distance-based:** Targets the closest enemy to the unit.
2. **Progress-based:** Targets the enemy closest to the objective/exit.
3. **Attribute-based:** Targets the enemy with the highest/lowest health, armor, or specific tags.
4. **Threat-based:** Targets the enemy that deals the most damage or poses the highest risk.
5. **Random:** Selects a random valid target within range.

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_damage_calculation`, `atom_attack_speed`, `atom_area_of_effect`.
- **Conflicts:** May conflict with `atom_mind_control` if the target suddenly switches factions, requiring immediate retargeting logic.

## 8. Anti-Patterns
1. **Target Thrashing:** If `sticky_targeting` is false and multiple enemies constantly swap being the "highest priority", the unit might constantly switch targets and never actually attack due to attack animations resetting.
2. **Overly Complex Priority:** Giving players too many targeting options can lead to analysis paralysis, especially in fast-paced games.
3. **Ignoring Z-Axis:** In 3D games, calculating distance purely on the X/Y plane can lead to units targeting enemies that are technically further away in 3D space.
