# Weapon Bloom / Spread (弹道散布)

## 1. Identity
- **Atom ID:** atom_weapon_bloom
- **English Name:** Weapon Bloom / Spread
- **Chinese Name:** 弹道散布
- **Category:** A (Core Combat Mechanics)
- **Definition:** Weapon bloom, or spread, is a mechanic where projectiles fired from a weapon deviate from the exact center of the crosshair within a dynamically changing cone or radius. This deviation typically increases with continuous firing, movement, or jumping, and decreases when the player is stationary, crouching, or aiming down sights (ADS). It serves to balance weapon effectiveness at different ranges and encourages burst firing or controlled engagement pacing.

## 2. Core Verb & State Machine
- **Core Verb:** Fire (Shoot)
- **State Diagram:**
  [Idle] --(Fire)--> [Firing]
  [Firing] --(Continuous Fire)--> [Max Bloom]
  [Firing] --(Stop Fire)--> [Recovering]
  [Max Bloom] --(Stop Fire)--> [Recovering]
  [Recovering] --(Time Passes)--> [Idle]
  [Any State] --(Move/Jump)--> [Increased Base Bloom]
  [Any State] --(Crouch/ADS)--> [Decreased Base Bloom]

- **States:**
  - `Idle`: The weapon is not being fired. Bloom is at its minimum base value depending on the player's stance and movement.
  - `Firing`: The weapon is actively discharging projectiles. Bloom increases per shot or over time.
  - `Max Bloom`: The weapon has reached its maximum allowed spread. Further firing does not increase bloom, but accuracy is at its lowest.
  - `Recovering`: The player has stopped firing. Bloom smoothly interpolates back to the `Idle` state value.

- **Transitions:**
  - `Idle` to `Firing`: Triggered by the player pressing the fire input.
  - `Firing` to `Max Bloom`: Triggered when the accumulated bloom reaches the weapon's defined maximum limit.
  - `Firing` to `Recovering`: Triggered by the player releasing the fire input before reaching max bloom.
  - `Max Bloom` to `Recovering`: Triggered by the player releasing the fire input.
  - `Recovering` to `Idle`: Triggered when the bloom value fully returns to the base value.

## 3. MDA Analysis
- **Mechanics:** The system calculates a random trajectory for each projectile within a cone. The angle of this cone (bloom) is a variable that increases with each shot fired (bloom per shot) and decays over time when not firing (bloom recovery rate). Modifiers are applied based on player state (moving, jumping, crouching, aiming).
- **Dynamics:** Players learn to manage their fire rate, opting for short bursts or tap-firing at medium to long ranges to maintain accuracy, while relying on full-auto fire only in close-quarters combat. Movement becomes a tactical trade-off between evasion and accuracy.
- **Aesthetics:** Creates a sense of weapon weight, recoil, and realism. It induces tension during engagements as players must balance the urgency to deal damage with the need to maintain control over their weapon. It rewards discipline and mastery of weapon-specific rhythms.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Game/Version) | Unit |
| :--- | :--- | :--- | :--- | :--- |
| `base_spread` | f32 | 0.0 - 5.0 | 0.1 (Fortnite v28.00 - Assault Rifle) | Degrees |
| `max_spread` | f32 | 2.0 - 15.0 | 3.5 (Fortnite v28.00 - Assault Rifle) | Degrees |
| `spread_per_shot` | f32 | 0.1 - 2.0 | 0.2 (Halo Infinite v1.1 - Assault Rifle) | Degrees |
| `recovery_rate` | f32 | 1.0 - 20.0 | 10.0 (Fortnite v28.00 - Assault Rifle) | Degrees/sec |
| `movement_multiplier` | f32 | 1.2 - 3.0 | 1.5 (Halo Infinite v1.1) | Multiplier |
| `crouch_multiplier` | f32 | 0.4 - 0.8 | 0.6 (Fortnite v28.00) | Multiplier |
| `jump_multiplier` | f32 | 2.0 - 5.0 | 3.0 (Fortnite v28.00) | Multiplier |

## 5. Benchmark Data
- **Fortnite (v28.00) - Standard Assault Rifle:**
  - `base_spread`: 0.1 degrees
  - `max_spread`: 3.5 degrees
  - `spread_per_shot`: 0.15 degrees
  - `recovery_rate`: 12.0 degrees/sec
  - `movement_multiplier`: 1.5
  - `crouch_multiplier`: 0.65
- **Halo Infinite (v1.1) - MA40 Assault Rifle:**
  - `base_spread`: 0.5 degrees
  - `max_spread`: 4.0 degrees
  - `spread_per_shot`: 0.2 degrees
  - `recovery_rate`: 8.0 degrees/sec
  - `movement_multiplier`: 1.2

## 6. Common Variants
1. **Pattern-Based Recoil (CS:GO/CS2):** Instead of purely random bloom within a cone, weapons follow a predictable, learnable spray pattern, though a small amount of random inaccuracy (bloom) is still applied on top of the pattern.
2. **First-Shot Accuracy:** The very first shot fired after fully recovering bloom is perfectly accurate (0 spread), rewarding patient, precise aiming.
3. **Progressive Bloom:** The `spread_per_shot` is not constant but increases non-linearly (e.g., the first few shots add little bloom, but subsequent shots add exponentially more).
4. **Visual-Only Bloom (Crosshair Expansion):** The crosshair expands to visually represent inaccuracy, but the actual projectile might still favor the center of the cone (center-weighted distribution) rather than being uniformly random.

## 7. Compatibility Notes
- **Commonly Pairs With:** `atom_recoil` (Camera movement), `atom_ads` (Aim Down Sights), `atom_projectile_ballistics` (Bullet drop and travel time), `atom_hitscan`.
- **Known Conflicts:** Can conflict with `atom_perfect_accuracy_weapons` (e.g., sniper rifles often bypass bloom in favor of sway or perfect accuracy when scoped). Overlapping heavy bloom with heavy camera recoil can make weapons feel uncontrollable and frustrating.

## 8. Anti-Patterns
1. **Excessive RNG:** Making the bloom cone too large at base or max states, causing engagements to feel like a lottery rather than a test of skill. If a player aims perfectly but misses due to massive bloom, it creates frustration.
2. **Instant Recovery:** Allowing bloom to reset instantly between shots, which completely negates the intended pacing and allows players to macro or spam tap-fire with full-auto speed and perfect accuracy.
3. **Uncommunicated State:** Failing to visually represent the current bloom state to the player (e.g., a static crosshair while the underlying spread is increasing), leading to confusion about why shots are missing.
