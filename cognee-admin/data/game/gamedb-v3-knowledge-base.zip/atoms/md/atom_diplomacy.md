# Diplomacy System (atom_diplomacy)

## 1. Identity
- **Atom ID:** atom_diplomacy
- **English Name:** Diplomacy System
- **Chinese Name:** 外交系统
- **Category:** E or F (Expansion/Exploration/Faction)
- **Representative Games:** Civilization, Stellaris, Europa Universalis
- **Definition:** The Diplomacy System is a core gameplay mechanic that allows distinct factions or entities within a game world to interact, negotiate, form alliances, declare wars, and trade resources without necessarily resorting to immediate combat. It provides a non-violent avenue for conflict resolution and strategic advantage.

## 2. Core Verb & State Machine
- **Core Verb:** Negotiate / Interact
- **State Diagram:**
  [Neutral] <--> [Friendly] <--> [Allied]
      |              |
      v              v
  [Hostile] <--> [At War]

- **States:**
  - `Neutral`: Default state, no special bonuses or penalties.
  - `Friendly`: Positive relations, trade is possible, borders might be open.
  - `Allied`: Mutual defense pacts, shared vision, cooperative victory conditions.
  - `Hostile`: Negative relations, trade embargoes, border friction.
  - `At War`: Active combat, diplomatic options restricted to peace treaties.

- **Transitions:**
  - `Neutral` -> `Friendly`: Improve relations via gifts, favorable trade, or shared enemies.
  - `Friendly` -> `Allied`: Sign alliance treaty, high trust threshold met.
  - `Neutral` -> `Hostile`: Border disputes, conflicting ideologies, or espionage discovered.
  - `Hostile` -> `At War`: Declaration of war, casus belli triggered.
  - `At War` -> `Neutral` / `Hostile`: Peace treaty signed, war exhaustion reaches limit.

## 3. MDA Analysis
- **Mechanics:** Players use a dedicated interface to send envoys, propose trades, sign treaties, and declare wars. The system tracks a "relation score" or "trust value" between factions, modified by actions, ideologies, and events.
- **Dynamics:** Players form power blocs to counter dominant factions. Betrayals and shifting alliances create a dynamic geopolitical landscape. Players might use diplomacy to stall for time while building up military strength.
- **Aesthetics:** Players experience a sense of statesmanship, cunning, and grand strategy. The tension of a fragile alliance or the satisfaction of a well-negotiated peace treaty evokes feelings of mastery and political intrigue.

## 4. Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value | Unit |
|---|---|---|---|---|
| `base_relation` | f32 | -100.0 to 100.0 | 0.0 (Civ VI) | Points |
| `trust_decay_rate` | f32 | 0.0 to 5.0 | 1.0 (Stellaris 3.0) | Points/Turn |
| `gift_impact_multiplier` | f32 | 0.1 to 2.0 | 0.5 (EU4 1.30) | Multiplier |
| `war_exhaustion_rate` | f32 | 0.0 to 10.0 | 0.1 (Stellaris 3.0) | Points/Month |
| `alliance_threshold` | f32 | 50.0 to 100.0 | 80.0 (Civ VI) | Points |

## 5. Benchmark Data
- **Civilization VI (v1.0.12.9):**
  - `base_relation`: 0.0
  - `alliance_threshold`: 80.0
- **Stellaris (v3.0.3):**
  - `trust_decay_rate`: 1.0
  - `war_exhaustion_rate`: 0.1
- **Europa Universalis IV (v1.30):**
  - `gift_impact_multiplier`: 0.5

## 6. Common Variants
1. **Opinion-Based:** Simple linear scale from -100 to +100 (e.g., older Total War games).
2. **Favor/Trust System:** Separates immediate opinion from long-term trust or favors that can be spent (e.g., Civilization VI, Stellaris).
3. **Casus Belli System:** Requires a valid justification to declare war without massive penalties (e.g., Crusader Kings, Europa Universalis).
4. **Coalition/Federation:** Advanced alliance structures with their own internal laws and progression (e.g., Stellaris Federations).

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_trade` (Trade System), `atom_espionage` (Espionage System), `atom_warfare` (Warfare System).
- **Incompatible Atoms:** `atom_pure_survival` (Pure Survival - where all other entities are inherently hostile).

## 8. Anti-Patterns
1. **Schizophrenic AI:** AI factions rapidly alternating between friendly and hostile states without clear reasons, frustrating the player.
2. **Diplomatic Exploit:** Allowing players to infinitely bribe AI for favors or peace, bypassing the intended challenge.
3. **Opaque Modifiers:** Hiding the reasons behind relation changes, making it impossible for the player to make informed diplomatic decisions.
