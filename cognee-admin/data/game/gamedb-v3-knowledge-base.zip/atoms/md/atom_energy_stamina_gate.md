# Identity
- **Atom ID**: atom_energy_stamina_gate
- **English Name**: Energy / Stamina Gate
- **Chinese Name**: 体力门控
- **Category**: C or D (Progression / Monetization)
- **Definition**: A system that limits the player's ability to perform certain actions or play sessions by requiring a consumable resource (energy or stamina) that regenerates over real-world time or can be purchased.

# Core Verb & State Machine
- **Core Verb**: Consume (Energy) / Wait (for regeneration)
- **State Diagram**:
  [Full Energy] --(Play Level)--> [Depleted Energy]
  [Depleted Energy] --(Wait Time)--> [Regenerating]
  [Regenerating] --(Wait Time)--> [Full Energy]
  [Depleted Energy] --(Purchase Refill)--> [Full Energy]
- **States**: Full Energy, Depleted Energy, Regenerating
- **Transitions**:
  - Full Energy -> Depleted Energy: Triggered by playing a level or performing an action.
  - Depleted Energy -> Regenerating: Triggered automatically over time.
  - Regenerating -> Full Energy: Triggered when energy reaches maximum capacity.
  - Depleted Energy -> Full Energy: Triggered by using a premium item or currency.

# MDA Analysis
- **Mechanics**: The game tracks a numerical value representing energy. Actions cost a specific amount of energy. Energy regenerates at a fixed rate (e.g., 1 point per 5 minutes) up to a maximum cap.
- **Dynamics**: Players must optimize their play sessions around their energy cap and regeneration rate. They may log in multiple times a day to prevent energy from capping out and being "wasted."
- **Aesthetics**: Creates a sense of anticipation and habituation. It can also cause frustration (if the gate is too restrictive) or relief/satisfaction (when returning to a full energy bar).

# Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value | Unit |
|---|---|---|---|---|
| max_energy | u32 | 20 - 200 | 160 (Genshin Impact v4.0) | points |
| regen_rate | u32 | 1 - 10 | 8 (Genshin Impact v4.0) | minutes per point |
| action_cost | u32 | 5 - 40 | 20 (Genshin Impact v4.0) | points |
| refill_cost | u32 | 10 - 100 | 50 (Genshin Impact v4.0) | premium currency |

# Benchmark Data
- **Genshin Impact (v4.0)**: Max Resin (Energy) = 160, Regen Rate = 1 per 8 minutes, Domain Cost = 20, Boss Cost = 40.
- **Fate/Grand Order (v2.0)**: Max AP scales with level (e.g., 140 at high levels), Regen Rate = 1 per 5 minutes, Quest Cost = 10-40.
- **Candy Crush Saga (v1.250)**: Max Lives = 5, Regen Rate = 1 per 30 minutes, Level Attempt Cost = 1 Life (only lost on failure).

# Common Variants
1. **Success-Based Energy**: Energy is only consumed if the player fails the level (e.g., Candy Crush).
2. **Variable Cost**: Different activities cost different amounts of energy (e.g., Genshin Impact domains vs. weekly bosses).
3. **Overflow Energy**: Players can temporarily exceed the maximum energy cap when using refill items.
4. **Time-Specific Energy**: Energy that can only be used during specific events or times of day.

# Compatibility Notes
- **Compatible Atoms**: atom_daily_login_reward (often gives energy), atom_premium_currency (used to buy energy), atom_gacha_pull (energy used to farm materials for gacha characters).
- **Incompatible Atoms**: atom_infinite_grind (contradicts the purpose of an energy gate).

# Anti-Patterns
1. **Overly Restrictive Cap**: Setting the maximum energy too low, forcing players to log in too frequently or lose out on regeneration.
2. **Punishing Costs**: Making core activities cost too much energy relative to the regeneration rate, leading to very short play sessions.
3. **Lack of Overflow**: Not allowing energy to overflow when a player levels up or uses a refill item, causing them to waste resources.
