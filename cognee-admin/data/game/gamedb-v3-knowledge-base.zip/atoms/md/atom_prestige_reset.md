# Gameplay Atom: Prestige / Ascension Reset

## 1. Identity
- **Atom ID:** `atom_prestige_reset`
- **English Name:** Prestige / Ascension Reset
- **Chinese Name:** 声望/飞升重置
- **Category:** E/F (Progression / Meta-Progression)
- **Definition:** A mechanic where the player voluntarily resets their current progress (usually back to the beginning of the game or a specific checkpoint) in exchange for a permanent meta-currency, multiplier, or unlockable upgrades that accelerate future playthroughs.

## 2. Core Verb & State Machine
- **Core Verb:** Reset / Ascend / Prestige

**State Diagram:**
```text
[Playing] --> (Trigger Prestige) --> [Confirmation]
[Confirmation] --> (Cancel) --> [Playing]
[Confirmation] --> (Confirm) --> [Resetting]
[Resetting] --> (Award Meta-Currency) --> [Meta-Progression Menu]
[Meta-Progression Menu] --> (Start New Run) --> [Playing]
```

**States:**
- `Playing`: The normal gameplay loop where the player accumulates primary resources.
- `Confirmation`: A prompt ensuring the player wants to reset their progress.
- `Resetting`: The transitional state where primary progress is wiped and meta-currency is calculated.
- `Meta-Progression Menu`: The interface where players spend their newly acquired meta-currency.

**Transitions:**
- `Playing` -> `Confirmation`: Player clicks the prestige button.
- `Confirmation` -> `Playing`: Player cancels the prestige action.
- `Confirmation` -> `Resetting`: Player confirms the prestige action.
- `Resetting` -> `Meta-Progression Menu`: System finishes wiping progress and awards meta-currency.
- `Meta-Progression Menu` -> `Playing`: Player begins a new run with permanent bonuses.

## 3. MDA Analysis
- **Mechanics:** The system tracks a lifetime accumulation of a specific resource or milestone. Upon triggering the prestige, it calculates a reward based on a mathematical formula (often sub-linear, like a square root or logarithmic function of total resources), resets the primary game state, and adds the reward to a persistent meta-inventory.
- **Dynamics:** Players must optimize the timing of their resets. Resetting too early yields little reward, while waiting too long results in diminishing returns due to the sub-linear reward scaling. This creates a cyclical pacing of fast early progress slowing down until a reset is optimal.
- **Aesthetics:** Provides a sense of immense power and continuous growth (Fantasy/Submission). The joy of re-experiencing the early game at a vastly accelerated pace (Abnegation/Discovery).

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value | Unit |
|---|---|---|---|---|
| `base_requirement` | `f64` | 1e6 - 1e12 | 1e12 (Cookie Clicker v2.048) | Primary Currency |
| `scaling_exponent` | `f64` | 0.3 - 0.5 | 0.5 (AdVenture Capitalist v8.0) | Multiplier |
| `reward_multiplier` | `f64` | 0.01 - 0.1 | 0.02 (AdVenture Capitalist v8.0) | % Bonus per point |
| `min_time_between_resets` | `f64` | 0 - 86400 | 0 (Most idle games) | Seconds |

## 5. Benchmark Data
- **Cookie Clicker (v2.048):**
  - Prestige level is calculated as the cube root of total cookies baked all time divided by 1 trillion.
  - Formula: `Prestige = cbrt(Total Cookies / 1e12)`
  - Each prestige level grants +1% CpS (Cookies per Second).
- **AdVenture Capitalist (v8.0):**
  - Angel Investors (meta-currency) are calculated based on lifetime earnings.
  - Formula: `Angels = 150 * sqrt(Lifetime Earnings / 1e15)`
  - Each Angel Investor provides a +2% bonus to all profits.

## 6. Common Variants
1. **Soft Prestige:** Only resets specific layers of progress rather than the entire game (e.g., resetting a specific planet or dimension but keeping overall galactic progress).
2. **Forced Prestige:** The game forces a reset upon reaching a specific narrative or mechanical milestone, often introducing a paradigm shift in gameplay.
3. **Multi-Layered Prestige:** Games with multiple tiers of prestige (e.g., resetting to gain Currency A, then later resetting Currency A to gain Currency B).
4. **Targeted Prestige:** Players choose specific aspects of their progress to reset in exchange for targeted buffs, rather than a global wipe.

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_incremental_generator`, `atom_offline_progress`, `atom_skill_tree`
- **Incompatible Atoms:** `atom_permadeath_roguelike`, `atom_linear_narrative`

## 8. Anti-Patterns
1. **Linear Scaling:** Using a linear formula for prestige rewards. This leads to runaway inflation where each run is exponentially faster without bounds, breaking the game's economy.
2. **Opaque Formulas:** Hiding the exact requirements for the next prestige point, frustrating players who cannot optimize their reset timing.
3. **Meaningless Early Game:** Making the post-prestige early game so fast that it becomes a tedious chore of clicking through menus rather than engaging gameplay.
