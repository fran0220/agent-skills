# Gameplay Atom: Alert State Machine

## 1. Identity
- **Atom ID**: `atom_alert_states`
- **English Name**: Alert State Machine
- **Chinese Name**: 警戒状态机
- **Category**: A
- **Definition**: The Alert State Machine is a core AI behavior system that governs how non-player characters (NPCs) transition between different levels of awareness and hostility in response to player actions or environmental stimuli. It typically involves states such as Idle, Suspicious, Searching, and Combat, providing a structured way to manage stealth gameplay and enemy reactions.

## 2. Core Verb & State Machine
- **Primary Player Verb**: Evade / Sneak
- **State Diagram**:
  ```text
  [Idle] --(Hear Noise/See Glimpse)--> [Suspicious]
  [Suspicious] --(Investigate/Find Nothing)--> [Idle]
  [Suspicious] --(See Player/Find Body)--> [Combat]
  [Combat] --(Lose Sight of Player)--> [Searching]
  [Searching] --(Find Player)--> [Combat]
  [Searching] --(Time Expires)--> [Suspicious]
  ```
- **States**:
  - **Idle**: NPC is unaware of any threat, following normal patrol routes or standing guard.
  - **Suspicious**: NPC has detected a minor disturbance and is investigating the source.
  - **Searching**: NPC knows the player is present but has lost visual contact, actively hunting.
  - **Combat**: NPC has confirmed the player's location and is actively engaging or calling for backup.
- **Transitions**:
  - Idle -> Suspicious: Triggered by low-level sensory input (footsteps, distant shadow).
  - Suspicious -> Idle: Triggered by a timeout after investigating without finding anything.
  - Suspicious -> Combat: Triggered by high-level sensory input (clear line of sight, being attacked).
  - Combat -> Searching: Triggered when the player breaks line of sight for a certain duration.
  - Searching -> Combat: Triggered when the player is spotted again.
  - Searching -> Suspicious: Triggered when the search timer expires without finding the player.

## 3. MDA Analysis
- **Mechanics**: The system uses sensory volumes (vision cones, hearing radii) attached to NPCs. When the player intersects these volumes, an awareness meter fills up. Crossing specific thresholds triggers state transitions.
- **Dynamics**: Players learn to manipulate the state machine by intentionally triggering the Suspicious state (e.g., throwing a rock) to move guards out of position, creating emergent stealth opportunities.
- **Aesthetics**: Creates a tense, thrilling experience (Challenge/Submission). The player feels a sense of mastery when successfully navigating or manipulating the AI's awareness.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value | Unit |
| --- | --- | --- | --- | --- |
| `vision_range_idle` | f32 | 10.0 - 30.0 | 20.0 (MGS V) | meters |
| `vision_cone_angle` | f32 | 45.0 - 120.0 | 90.0 (Hitman 3) | degrees |
| `hearing_radius` | f32 | 5.0 - 25.0 | 15.0 (MGS V) | meters |
| `suspicion_decay_rate` | f32 | 1.0 - 10.0 | 5.0 (Hitman 3) | points/sec |
| `search_duration` | f32 | 10.0 - 60.0 | 30.0 (MGS V) | seconds |

## 5. Benchmark Data
- **Metal Gear Solid V: The Phantom Pain (v1.15)**:
  - `vision_range_idle`: 20.0 meters
  - `hearing_radius`: 15.0 meters
  - `search_duration`: 30.0 seconds
- **Hitman 3 (v3.100)**:
  - `vision_cone_angle`: 90.0 degrees
  - `suspicion_decay_rate`: 5.0 points/sec
  - `search_duration`: 45.0 seconds

## 6. Common Variants
1. **Binary Alert**: Simplified version with only Idle and Combat states (common in fast-paced action games).
2. **Hive Mind Alert**: When one NPC enters Combat, all NPCs in the network instantly share the player's location.
3. **Escalating Alert**: Features multiple tiers of Combat (e.g., calling in heavily armored reinforcements if the initial Combat state lasts too long).
4. **Fear State**: Replaces or supplements Combat; if the player is too powerful, NPCs transition to a Fleeing or Cowering state instead of attacking.

## 7. Compatibility Notes
- **Compatible Atoms**: `atom_stealth_takedown`, `atom_distraction_item`, `atom_line_of_sight`.
- **Incompatible Atoms**: `atom_auto_aggro_swarm` (conflicts with the nuanced awareness levels).

## 8. Anti-Patterns
1. **Instant Omniscience**: NPCs instantly knowing the player's exact location upon entering the Combat state, ignoring line of sight or last known position.
2. **Amnesia**: NPCs returning to the Idle state too quickly after a major disturbance (e.g., finding a dead body), breaking immersion.
3. **Unclear Feedback**: Failing to provide the player with clear visual or auditory cues about the NPC's current state or awareness level.
