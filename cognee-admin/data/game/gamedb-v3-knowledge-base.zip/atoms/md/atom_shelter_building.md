# Shelter Building (庇护所建造)

## 1. Identity
- **Atom ID**: atom_shelter_building
- **English Name**: Shelter Building
- **Chinese Name**: 庇护所建造
- **Category**: G (Gameplay Systems)
- **Definition**: The process by which players construct protective structures using gathered resources to defend against environmental hazards and hostile entities.

## 2. Core Verb & State Machine
- **Core Verb**: Build (Construct)
- **State Diagram**:
  [Idle] -> (Select Blueprint) -> [Previewing]
  [Previewing] -> (Place Blueprint) -> [Placing]
  [Placing] -> (Add Resources) -> [Constructing]
  [Constructing] -> (Complete) -> [Built]
  [Built] -> (Take Damage) -> [Damaged]
  [Damaged] -> (Repair) -> [Built]
  [Damaged] -> (Destroyed) -> [Destroyed]

## 3. MDA Analysis
- **Mechanics**: Players gather resources, select building parts (walls, floors, roofs), place them in the world adhering to structural integrity rules, and complete construction.
- **Dynamics**: Players optimize base layouts for defense, efficiency, and aesthetics. They may create trap bases, multi-story towers, or hidden bunkers.
- **Aesthetics**: Sense of security, creative expression, ownership, and progression.

## 4. Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value (Rust v1.0) | Unit |
| --- | --- | --- | --- | --- |
| `health` | f32 | 100 - 2000 | 500 (Wood Wall) | HP |
| `build_cost` | u32 | 10 - 500 | 300 (Wood) | Resources |
| `stability_loss` | f32 | 0.0 - 1.0 | 0.1 | Ratio |
| `decay_rate` | f32 | 0.0 - 10.0 | 1.0 | HP/hour |

## 5. Benchmark Data
- **Rust (v1.0)**: Wood Wall Health = 500, Stone Wall Health = 1000, Metal Wall Health = 2000.
- **The Forest (v1.12)**: Custom Wall Cost = 1 Log per segment.
- **Valheim (v0.217)**: Wood Wall Health = 400, Stability loss per vertical block = 0.16.

## 6. Common Variants
- **Grid-based Building**: Structures snap to a rigid grid (e.g., Minecraft).
- **Freeform Building**: Structures can be placed anywhere with minimal snapping (e.g., The Forest).
- **Modular Building**: Pre-defined parts snap together (e.g., Rust, Valheim).
- **Prefab Building**: Placing entire buildings at once (e.g., Age of Empires).

## 7. Compatibility Notes
- **Compatible Atoms**: `atom_resource_gathering`, `atom_crafting`, `atom_base_defense`, `atom_territory_control`.
- **Incompatible Atoms**: `atom_nomadic_lifestyle` (often conflicts as building encourages staying in one place).

## 8. Anti-Patterns
- **Overly Restrictive Placement**: Making it too hard to place objects on slightly uneven terrain.
- **Tedious Upkeep**: Requiring players to spend too much time repairing or maintaining structures.
- **Lack of Structural Integrity**: Allowing floating bases which break immersion and balance.
