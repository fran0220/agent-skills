# Ability Gating (能力门控)

## 1. Identity
- **Atom ID:** `atom_ability_gating`
- **English Name:** Ability Gating
- **Chinese Name:** 能力门控
- **Category:** G
- **Definition:** Ability Gating is a structural design pattern where progress through the game world or access to specific content is restricted until the player acquires a specific ability, item, or upgrade. This creates a non-linear exploration experience, encouraging backtracking and rewarding player progression with expanded traversal or interaction capabilities.

## 2. Core Verb & State Machine
- **Core Verb:** Unlock / Traverse
- **State Diagram:**
  [Unreachable] --(Acquire Ability)--> [Reachable] --(Use Ability)--> [Traversed]
- **States:**
  - `Unreachable`: The area or interaction is currently blocked.
  - `Reachable`: The player has the required ability but has not yet used it to pass the gate.
  - `Traversed`: The player has successfully used the ability to pass the gate.
- **Transitions:**
  - `Unreachable` -> `Reachable`: Triggered by acquiring the necessary ability (e.g., finding the Double Jump boots).
  - `Reachable` -> `Traversed`: Triggered by executing the ability at the gate (e.g., double jumping over a high wall).

## 3. MDA Analysis
- **Mechanics:** The game world contains obstacles (gates) that check for specific player states or inventory items (keys/abilities). If the condition is met, the obstacle can be bypassed.
- **Dynamics:** Players explore until they hit a roadblock, remember its location, find the required ability elsewhere, and then backtrack to the roadblock to progress. This creates a loop of discovery, restriction, empowerment, and resolution.
- **Aesthetics:** Evokes feelings of curiosity, anticipation, and the satisfaction of empowerment (epiphany) when a previously insurmountable obstacle becomes trivial.

## 4. Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value (Game + Version) | Unit |
|---|---|---|---|---|
| `required_ability_id` | string | N/A | "double_jump" (Hollow Knight v1.5) | N/A |
| `gate_health` | u32 | 1 - 100 | 1 (Metroid Dread v1.0) | HP |
| `bypass_distance` | f32 | 2.0 - 15.0 | 5.0 (Zelda: Ocarina of Time v1.0) | meters |
| `is_consumable` | bool | true/false | false (Hollow Knight v1.5) | N/A |

## 5. Benchmark Data
- **Hollow Knight (v1.5.78.11833):**
  - `required_ability_id`: "mantis_claw" (Wall Jump)
  - `is_consumable`: false
  - `bypass_distance`: 8.0 (vertical units)
- **Metroid Dread (v1.0.0):**
  - `required_ability_id`: "morph_ball"
  - `gate_health`: 1 (destroyed by bomb)
  - `bypass_distance`: 1.0 (tile size)
- **The Legend of Zelda: Ocarina of Time (v1.0):**
  - `required_ability_id`: "hookshot"
  - `is_consumable`: false
  - `bypass_distance`: 15.0 (meters)

## 6. Common Variants
1. **Key-and-Door Gating:** The simplest form, where an explicit key opens an explicit door (e.g., Doom).
2. **Traversal Gating:** An ability changes how the player moves, naturally allowing them to bypass environmental hazards or gaps (e.g., Double Jump, Dash).
3. **Weapon/Tool Gating:** A specific weapon is needed to destroy a specific type of block or enemy blocking the path (e.g., Super Missiles in Metroid).
4. **Knowledge Gating:** The player learns a code, password, or mechanic that allows them to pass, which they could technically do from the start if they knew how (e.g., Outer Wilds).

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_exploration`, `atom_power_progression`, `atom_backtracking`, `atom_hidden_secrets`.
- **Incompatible Atoms:** `atom_linear_corridor` (conflicts with the backtracking nature of ability gating), `atom_pure_sandbox` (where all tools are available from the start).

## 8. Anti-Patterns
1. **Forgettable Gates:** Placing a gate so early or making it so visually indistinct that the player forgets where it is by the time they get the ability.
2. **Tedious Backtracking:** Forcing the player to traverse long, empty, or overly difficult sections just to return to a gate after getting the ability.
3. **Redundant Abilities:** Giving the player an ability that is only used for a single specific gate and has no other utility in combat or general traversal.
