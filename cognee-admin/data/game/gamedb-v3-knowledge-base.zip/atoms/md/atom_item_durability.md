# Identity
- **Atom ID**: atom_item_durability
- **English Name**: Item Durability
- **Chinese Name**: 物品耐久度
- **Category**: C (Core Mechanics)
- **Definition**: Item Durability is a mechanic where equipment, tools, or weapons degrade over time or with use, eventually breaking or becoming less effective, requiring the player to repair, replace, or manage their resources carefully.

# Core Verb & State Machine
- **Core Verb**: Use (Weapon/Tool/Armor)
- **State Diagram**:
  [Pristine] -> (Use) -> [Damaged] -> (Use) -> [Broken]
  [Damaged] -> (Repair) -> [Pristine]
  [Broken] -> (Repair) -> [Pristine] (in some games) or [Destroyed]
- **States**: Pristine, Damaged, Broken, Destroyed
- **Transitions**:
  - Pristine to Damaged: Triggered by using the item.
  - Damaged to Broken: Triggered by durability reaching zero.
  - Damaged to Pristine: Triggered by repairing the item.
  - Broken to Destroyed: Triggered by item breaking permanently.

# MDA Analysis
- **Mechanics**: Each item has a maximum durability value and a current durability value. Using the item decreases the current durability by a specific amount. When durability reaches zero, the item breaks or its stats are significantly reduced.
- **Dynamics**: Players are forced to constantly evaluate the cost-benefit of using their best items. It encourages resource gathering, inventory management, and adapting to different weapons or tools when preferred ones break.
- **Aesthetics**: Creates a sense of survival, tension, and attachment to items. It can also lead to frustration if balanced poorly, but when done right, it enhances the feeling of a harsh, realistic world.

# Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value | Unit |
|---|---|---|---|---|
| max_durability | u32 | 10 - 1000 | 100 (Dark Souls III v1.15) | points |
| current_durability | u32 | 0 - max_durability | 100 | points |
| degradation_rate | f32 | 0.1 - 10.0 | 1.0 (Breath of the Wild v1.5.0) | points/use |
| repair_cost_multiplier | f32 | 0.5 - 5.0 | 2.0 (Rust v2394) | resources/point |

# Benchmark Data
- **The Legend of Zelda: Breath of the Wild (v1.5.0)**: Weapons have low durability (e.g., Tree Branch has 2, Master Sword has 40). Weapons break permanently (except Master Sword which recharges).
- **Dark Souls III (v1.15)**: Weapons have moderate durability (e.g., Longsword has 70). Durability resets at bonfires. Breaking reduces damage significantly but can be repaired at a blacksmith.
- **Rust (v2394)**: Tools and weapons degrade with use. Can be repaired at a repair bench, but maximum durability decreases with each repair.

# Common Variants
1. **Permanent Destruction**: Items disappear from inventory when broken (e.g., Breath of the Wild).
2. **Stat Penalty**: Items remain in inventory but suffer severe stat penalties until repaired (e.g., Dark Souls).
3. **Diminishing Returns**: Items can be repaired, but their maximum durability decreases each time (e.g., Rust).
4. **Recharging**: Items "break" but slowly regain durability over time (e.g., Master Sword in BotW).

# Compatibility Notes
- **Compatible Atoms**: atom_inventory_management, atom_crafting_system, atom_resource_gathering.
- **Incompatible Atoms**: atom_infinite_ammo (often conflicts conceptually, though can coexist if applied to different item types).

# Anti-Patterns
1. **Too Fragile**: Items break so quickly that players spend more time managing inventory than engaging in core gameplay.
2. **Hoarding Syndrome**: Players refuse to use their best items because they fear breaking them, leading to a less enjoyable experience.
3. **Trivial Repair**: Repairing is so cheap and accessible that the durability mechanic becomes a minor annoyance rather than a meaningful strategic element.
