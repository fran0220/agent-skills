# Gameplay Atom: Raid Mechanic

## 1. Identity
- **Atom ID:** `atom_raid_mechanic`
- **English Name:** Raid Mechanic
- **Chinese Name:** 团本机制
- **Category:** H (High-end PvE)
- **Definition:** A complex, multi-phase encounter design requiring coordinated group actions, precise positioning, and specific role execution to overcome a boss or environmental challenge. Failure to execute correctly often results in severe penalties or a group wipe.

## 2. Core Verb & State Machine
- **Core Verb:** Coordinate (Position, React, Execute)
- **State Diagram:**
  ```text
  [Idle] --> (Engage) --> [Phase 1]
  [Phase 1] --> (Health Threshold Reached) --> [Transition]
  [Transition] --> (Timer Ends) --> [Phase 2]
  [Phase 2] --> (Mechanic Failed) --> [Wipe]
  [Phase 2] --> (Boss Defeated) --> [Victory]
  [Wipe] --> (Reset) --> [Idle]
  ```
- **States:** Idle, Phase 1, Transition, Phase 2, Wipe, Victory
- **Transitions:**
  - Idle -> Phase 1: Engage
  - Phase 1 -> Transition: Health Threshold Reached
  - Transition -> Phase 2: Timer Ends
  - Phase 2 -> Wipe: Mechanic Failed
  - Phase 2 -> Victory: Boss Defeated
  - Wipe -> Idle: Reset

## 3. MDA Analysis
- **Mechanics:** The system tracks player positions, health, and roles. It spawns telegraphs, applies debuffs, and triggers massive damage events based on timers or boss health thresholds.
- **Dynamics:** Players must communicate, memorize patterns, and adapt to random targeting. Emergent behaviors include "shotcalling" (one player directing others) and optimizing damage output while moving.
- **Aesthetics:** Fellowship (working together), Challenge (overcoming difficult obstacles), and Discovery (learning the fight). Players feel a sense of epic accomplishment upon victory.

## 4. Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value (Game) | Unit |
| --- | --- | --- | --- | --- |
| `enrage_timer` | f32 | 300.0 - 900.0 | 600.0 (WoW 10.2) | seconds |
| `mechanic_interval` | f32 | 10.0 - 45.0 | 30.0 (FFXIV 6.5) | seconds |
| `wipe_damage` | u32 | 99999 - 999999 | 999999 (Destiny 2) | HP |
| `safe_zone_radius` | f32 | 2.0 - 10.0 | 5.0 (WoW 10.2) | meters |
| `requires_soak` | bool | true/false | true (FFXIV 6.5) | boolean |

## 5. Benchmark Data
- **World of Warcraft (Version 10.2):**
  - `enrage_timer`: 600.0 seconds
  - `mechanic_interval`: 25.0 seconds
  - `safe_zone_radius`: 5.0 meters
- **Final Fantasy XIV (Version 6.5):**
  - `enrage_timer`: 720.0 seconds
  - `mechanic_interval`: 30.0 seconds
  - `requires_soak`: true
- **Destiny 2 (Season 23):**
  - `wipe_damage`: 999999 HP
  - `mechanic_interval`: 45.0 seconds

## 6. Common Variants
1. **Stack/Spread:** Players must group up to share damage or spread out to avoid overlapping damage.
2. **Gaze/Look Away:** Players must face away from the boss or a specific object to avoid being petrified or taking damage.
3. **Tethers:** Players are linked together and must move apart to break the tether or stay close to maintain it.
4. **Add Management:** Additional enemies spawn and must be killed quickly or crowd-controlled before they overwhelm the group.
5. **Relay/Pass:** A debuff or item must be passed between players before a timer expires.

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_telegraph`, `atom_aggro_management`, `atom_dps_check`, `atom_healing_check`
- **Incompatible Atoms:** `atom_solo_stealth`, `atom_idle_progression` (Raid mechanics require active group participation).

## 8. Anti-Patterns
1. **Overlapping Unreadable Telegraphs:** Creating visual clutter where players cannot distinguish which mechanic is happening first.
2. **Instant Untelegraphed Wipes:** Punishing players without giving them a chance to learn or react to the mechanic.
3. **Extreme RNG:** Relying too heavily on random targeting that can create impossible-to-survive situations regardless of player skill.
