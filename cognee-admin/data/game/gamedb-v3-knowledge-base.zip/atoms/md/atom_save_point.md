# Atom: Save Point / Save Room (存档点/安全房间)

## 1. Identity
- **Atom ID**: atom_save_point
- **English Name**: Save Point / Save Room
- **Chinese Name**: 存档点/安全房间
- **Category**: G
- **Definition**: A designated location or object within the game world where the player can record their current progress, restore resources, and find temporary respite from threats.

## 2. Core Verb & State Machine
- **Core Verb**: Save (Record Progress)
- **State Diagram**:
  - [Unvisited] -> (Player Discovers) -> [Available]
  - [Available] -> (Player Interacts) -> [Saving]
  - [Saving] -> (Save Complete) -> [Saved/Cooldown]
  - [Saved/Cooldown] -> (Time Passes/Player Leaves) -> [Available]
- **States**:
  - `Unvisited`: The save point has not been found or activated by the player.
  - `Available`: The save point is active and ready to be used.
  - `Saving`: The system is currently writing player data to storage.
  - `Saved/Cooldown`: The save is complete, and the point may be temporarily inactive to prevent spamming.
- **Transitions**:
  - `Discover`: Player enters the proximity of the save point.
  - `Interact`: Player presses the action button to initiate a save.
  - `Complete`: The game confirms the save data is written.
  - `Reset`: The save point becomes available again after a short delay or when the player re-enters the area.

## 3. MDA Analysis
- **Mechanics**: The system records the player's current state (health, inventory, location, story progress) to a persistent storage medium. It often fully restores the player's health and resources upon interaction. In some games, it requires a consumable item (e.g., Ink Ribbons in Resident Evil).
- **Dynamics**: Players will actively seek out these locations, altering their exploration patterns. The distance between save points dictates the tension and pacing of the gameplay loop. Players may engage in "save scumming" or strategic resource management to reach the next point.
- **Aesthetics**: Provides a profound sense of relief, safety, and accomplishment. The save room often features calming music and distinct visual cues (warm lighting) that contrast sharply with the hostile environment outside, creating an emotional sanctuary.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value | Unit |
| --- | --- | --- | --- | --- |
| `activation_radius` | f32 | 1.0 - 5.0 | 2.0 (Metroid Dread v1.0) | meters |
| `heal_amount` | f32 | 0.0 - 100.0 | 100.0 (Hollow Knight v1.5) | percentage |
| `requires_item` | bool | true/false | true (Resident Evil 1 v1.0) | boolean |
| `cooldown_time` | f32 | 0.0 - 60.0 | 0.0 (Super Metroid v1.0) | seconds |
| `enemy_respawn` | bool | true/false | true (Dark Souls v1.0) | boolean |

## 5. Benchmark Data
- **Resident Evil (1996, v1.0)**:
  - `requires_item`: true (Ink Ribbon)
  - `heal_amount`: 0.0 (Requires separate healing items)
  - `enemy_respawn`: false
- **Metroid Dread (2021, v1.0.0)**:
  - `activation_radius`: 2.5 meters
  - `heal_amount`: 100.0 (Fully restores health and ammo)
  - `cooldown_time`: 0.0
- **Dark Souls (2011, v1.0)** (Bonfire):
  - `heal_amount`: 100.0
  - `enemy_respawn`: true
  - `requires_item`: false

## 6. Common Variants
1. **Consumable Save**: Requires a specific, limited item to save (e.g., Ink Ribbons in Resident Evil). Increases tension and resource management.
2. **Rest/Respawn Point**: Not only saves the game but also respawns all enemies in the world and acts as the player's respawn point upon death (e.g., Bonfires in Dark Souls).
3. **Auto-Save Checkpoint**: Invisible triggers that save the game automatically without player interaction, often placed before boss fights or major events.
4. **Mobile Save Point**: An item or ability that allows the player to create a temporary save point anywhere in the world (e.g., Save Tents in some RPGs).
5. **Hub Save**: A central location that the player frequently returns to, which serves as the primary or only save location.

## 7. Compatibility Notes
- **Compatible Atoms**: `atom_inventory_management` (Item boxes often placed near saves), `atom_fast_travel` (Save points often double as fast travel nodes), `atom_healing_fountain` (Save points often heal the player).
- **Incompatible Atoms**: `atom_permadeath` (Fundamentally conflicts with the concept of reloading a previous save state, though "save and quit" is allowed).

## 8. Anti-Patterns
1. **Save Point Starvation**: Placing save points too far apart, leading to massive losses of progress and player frustration upon death.
2. **Unsafe Save Rooms**: Allowing enemies to enter or attack the player while they are interacting with the save point, breaking the established rule of safety.
3. **Softlock Saves**: Allowing the player to save in a state where they have insufficient health or resources to progress or backtrack, effectively ruining their playthrough.
