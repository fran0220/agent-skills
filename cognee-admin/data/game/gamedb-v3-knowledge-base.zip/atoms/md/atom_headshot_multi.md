# Gameplay Atom: Headshot Multiplier

## 1. Identity
- **Atom ID:** `atom_headshot_multi`
- **English Name:** Headshot Multiplier
- **Chinese Name:** 爆头倍率
- **Category:** A (Combat/Damage Mechanics)
- **Definition:** A damage modifier applied when a projectile or attack strikes a specific critical hit volume (typically the head) of a target entity, rewarding precision aiming with increased damage output.

## 2. Core Verb & State Machine
- **Core Verb:** Aim / Shoot
- **State Diagram:**
  [Idle] -> (Aim) -> [Aiming] -> (Fire) -> [Projectile in Flight] -> (Hit Detection) -> [Damage Calculation] -> (Apply Multiplier if Head Hitbox) -> [Damage Applied]
- **States:**
  - `Idle`: Player is not actively engaging.
  - `Aiming`: Player aligns the crosshair with the target.
  - `Firing`: Weapon discharges a projectile or hitscan ray.
  - `Hit_Evaluation`: System determines which hitbox was struck.
  - `Damage_Calculation`: Base damage is multiplied by the headshot multiplier if applicable.
- **Transitions:**
  - `Idle` -> `Aiming`: Triggered by player input (ADS or mouse movement).
  - `Aiming` -> `Firing`: Triggered by attack input.
  - `Firing` -> `Hit_Evaluation`: Triggered by projectile intersection with target bounds.
  - `Hit_Evaluation` -> `Damage_Calculation`: Triggered by successful hit confirmation.

## 3. MDA Analysis
- **Mechanics:** The system checks the specific hitbox intersected by an attack. If the hitbox is tagged as "head", the base damage of the weapon is multiplied by a predefined scalar (the headshot multiplier) before being subtracted from the target's health.
- **Dynamics:** Players are incentivized to aim for a smaller, harder-to-hit target area (the head) rather than the larger center of mass. This creates a risk/reward dynamic where missing the head results in zero damage, but hitting it results in a fast time-to-kill (TTK).
- **Aesthetics:** Creates feelings of mastery, precision, and satisfaction. A successful headshot often provides distinct audio-visual feedback (e.g., a "dink" sound or unique kill feed icon), enhancing the player's sense of achievement.

## 4. Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value (CS:GO v1.38) | Unit |
|---|---|---|---|---|
| `base_multiplier` | f32 | 1.0 - 5.0 | 4.0 (AK-47) | scalar |
| `helmet_reduction` | f32 | 0.0 - 1.0 | 0.5 | scalar |
| `distance_falloff` | f32 | 0.0 - 1.0 | 0.98 | scalar/unit |
| `hitbox_scale` | f32 | 0.5 - 1.5 | 1.0 | scalar |

## 5. Benchmark Data
- **CS:GO (v1.38):**
  - AK-47: Base damage 36, Headshot multiplier 4.0x (144 damage unarmored). With helmet, damage is reduced but still lethal (111 damage).
  - M4A4: Base damage 33, Headshot multiplier 4.0x (132 damage unarmored). With helmet, damage is reduced to 92 (non-lethal).
- **Rainbow Six Siege (Y8S1):**
  - All weapons: Headshot multiplier is effectively infinite (or extremely high, e.g., 50x) resulting in a guaranteed 1-hit kill regardless of weapon base damage or range, provided the projectile penetrates.

## 6. Common Variants
1. **Guaranteed Lethality:** Any headshot is an instant kill, regardless of weapon damage (e.g., Rainbow Six Siege).
2. **Weapon-Specific Multipliers:** Different weapon classes have different multipliers (e.g., Sniper Rifles have 2.5x, SMGs have 1.5x).
3. **Distance-Scaled Multipliers:** The multiplier decreases over distance to prevent cross-map pistol snipes (e.g., Rust, Apex Legends).
4. **Armor-Mitigated Multipliers:** Head armor reduces the multiplier or absorbs the first headshot entirely (e.g., PUBG level 3 helmet, CS:GO helmet).

## 7. Compatibility Notes
- **Commonly Pairs With:** `atom_hitscan_projectile`, `atom_recoil_pattern`, `atom_damage_falloff`, `atom_armor_system`.
- **Conflicts:** `atom_auto_aim` (Lock-on systems often target center of mass, making headshots impossible or random), `atom_splash_damage` (Explosives typically do not calculate headshot multipliers).

## 8. Anti-Patterns
1. **Misaligned Hitboxes:** The visual representation of the head does not match the actual hitbox, leading to frustrating "ghost hits" or unfair deaths.
2. **Over-rewarding Spray:** If recoil patterns randomly kick up to the head, players might be rewarded with accidental headshots without demonstrating precision aiming.
3. **Irrelevant Multipliers:** Setting the multiplier too low (e.g., 1.1x) where it doesn't change the bullets-to-kill (BTK) threshold, making the effort of aiming for the head mathematically pointless.
