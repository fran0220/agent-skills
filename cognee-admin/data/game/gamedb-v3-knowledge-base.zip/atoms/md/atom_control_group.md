# Gameplay Atom: Control Group

## 1. Identity
**Atom ID:** atom_control_group
**English Name:** Control Group
**Chinese Name:** 编队控制
**Category:** G
**Definition:** Control Group is a fundamental real-time strategy (RTS) mechanic that allows players to assign a selection of multiple game entities (usually units or buildings) to a specific hotkey, enabling rapid re-selection and issuing of collective commands without needing to manually locate and box-select them again. This mechanic is essential for managing large armies and complex economies efficiently.

## 2. Core Verb & State Machine
The primary player verb associated with this atom is **Assign / Recall**. Players actively assign units to a group and later recall that group to issue commands.

**State Diagram:**
[Unassigned] --(Select & Assign)--> [Assigned]
[Assigned] --(Recall)--> [Selected]
[Assigned] --(Add to Group)--> [Assigned (Updated)]
[Assigned] --(Remove/Death)--> [Assigned (Reduced)]
[Assigned] --(Clear/Reassign)--> [Unassigned/New Group]

**States and Transitions:**
The system operates through several key states. Initially, entities exist in an `Unassigned` state, meaning they are not bound to any specific control group index. When a player selects a group of entities and presses a binding combination (typically `Ctrl + [Number]`), the entities transition to the `Assigned` state, mapped to that specific number. 

Once assigned, pressing the corresponding number key triggers a transition to the `Selected` state, where the control group becomes the active selection for the player, ready to receive commands. The `Assigned` state can be modified dynamically. If a player selects new units and uses an additive binding (like `Shift + [Number]`), the state becomes `Assigned (Updated)`, appending the new units to the existing group. Conversely, if units within the group are destroyed or manually removed, the state shifts to `Assigned (Reduced)`. Finally, assigning a completely new selection to an already used number, or explicitly clearing the group, returns the previous entities to the `Unassigned` state while establishing a new group.

## 3. MDA Analysis
**Mechanics:** 
At its core, the Control Group mechanic functions by storing an array or list of entity references mapped to an integer key (usually 0-9 on a standard keyboard). When the player presses the designated key, the game engine replaces the current selection state with the stored list of entities. Any subsequent commands issued by the player (such as move, attack, or build) are then broadcast to all valid entities within that active selection. The system must also handle edge cases, such as automatically pruning dead entities from the stored lists to prevent null reference errors and ensuring that UI elements accurately reflect the current composition of each group.

**Dynamics:** 
The implementation of control groups fundamentally alters the pacing and skill ceiling of a game. It encourages players to develop high APM (Actions Per Minute) routines, rapidly switching between different control groups to manage multiple fronts simultaneously. For example, a player might use Group 1 for their main army, Group 2 for a flanking force, and Group 3 for production facilities. This creates a rhythmic flow of play where attention is constantly shifting, allowing for complex macro-management (economy and production) and micro-management (individual unit positioning and ability usage) to occur in tandem. The dynamic interplay between different groups allows for sophisticated strategies like multi-pronged attacks and rapid reinforcements.

**Aesthetics:** 
From an aesthetic standpoint, the Control Group mechanic provides players with a profound sense of mastery, control, and efficiency. As players become more adept at utilizing control groups, they transition from feeling overwhelmed by the chaos of the battlefield to feeling empowered as a commander orchestrating a complex symphony of destruction. The seamless execution of coordinated maneuvers across a large map generates a highly satisfying feeling of competence and strategic dominance.

## 4. Parameter Space
The behavior of control groups can be fine-tuned through several key parameters, which dictate the constraints and affordances provided to the player.

| Parameter Name | Type | Typical Range | Benchmark Value (Game) | Unit |
|---|---|---|---|---|
| `max_groups` | u32 | 9 - 20 | 10 (StarCraft II v5.0) | groups |
| `max_units_per_group` | u32 | 12 - 255 | 255 (StarCraft II v5.0) | units |
| `double_tap_camera_snap` | bool | true/false | true (Age of Empires II: DE) | boolean |
| `steal_action_enabled` | bool | true/false | true (StarCraft II v5.0) | boolean |

## 5. Benchmark Data
To understand how these parameters are applied in practice, we can look at benchmark data from several representative games that heavily feature the Control Group mechanic.

- **StarCraft: Brood War (v1.22):** This classic title is known for its strict limitations, which significantly increase the mechanical difficulty of the game. It features a `max_groups` value of 10 (mapped to keys 1-0) and a notoriously low `max_units_per_group` limit of 12. The `double_tap_camera_snap` feature is enabled, allowing players to quickly jump their camera to the group's location, but `steal_action_enabled` is false, meaning units can exist in multiple groups simultaneously, which can sometimes lead to unintended command overlaps.
- **StarCraft II (v5.0):** The sequel modernized many aspects of the interface. While it maintains a `max_groups` limit of 10, it drastically increases the `max_units_per_group` to 255, allowing players to control massive armies with a single keystroke. It retains the `double_tap_camera_snap` and introduces the `steal_action_enabled` feature (often bound to Alt+[Number]), which automatically removes a unit from its previous group when assigned to a new one, facilitating cleaner army splitting.
- **Age of Empires II: Definitive Edition (Build 101.102):** This game offers a slightly different approach, expanding the `max_groups` to 20 (utilizing additional modifier keys) to accommodate the complex economic and military management required. The `max_units_per_group` is set to 60, striking a balance between the strict limits of Brood War and the massive groups of StarCraft II. It also features `double_tap_camera_snap` but generally operates with `steal_action_enabled` set to false by default.

## 6. Common Variants
The core Control Group mechanic has seen several variations across different titles to suit specific gameplay needs.

1. **Exclusive Groups (Steal):** As seen in modern RTS games, assigning a unit to a new group automatically removes it from any previous groups. This prevents accidental commands being issued to units that were intended to be split off for a specific task.
2. **Overlapping Groups:** The traditional method where a single unit can belong to multiple control groups simultaneously. This allows for complex hierarchical grouping (e.g., Group 1 is the whole army, Group 2 is just the spellcasters within that army).
3. **Building-Specific Groups:** Some games provide dedicated UI elements or specific hotkeys exclusively for production facilities, separating them entirely from military unit groups to streamline macro-management.
4. **Dynamic Squads:** In games like Company of Heroes, groups are often treated as cohesive squads that automatically form or reinforce based on proximity or unit type, rather than requiring explicit, individual unit assignment by the player.
5. **Hero-Centric Groups:** In games with strong hero units (like Warcraft III), the hero is often permanently bound to a specific hotkey (like F1), and control groups are built around supporting that central figure.

## 7. Compatibility Notes
The Control Group atom interacts heavily with other selection and movement mechanics.

- **Compatible Atoms:** It pairs exceptionally well with `atom_box_selection` (for initially gathering units to assign), `atom_waypoint_queue` (allowing players to issue complex paths to a group and then immediately switch attention elsewhere), and `atom_formation_movement` (ensuring the group moves cohesively when commanded).
- **Incompatible Atoms:** It generally conflicts with `atom_single_character_control` (like in an Action RPG or MOBA), where the entire control scheme is dedicated to a single entity, making group management redundant or overly complex.

## 8. Anti-Patterns
When implementing control groups, designers should be wary of several common pitfalls.

1. **Silent Failures on Death:** If all units in a control group are destroyed, pressing the group hotkey might do nothing. If the UI does not clearly indicate that the group is now empty, players may waste valuable APM repeatedly trying to select a non-existent force.
2. **Inconsistent Selection Limits:** Having a box selection limit of 12 but a control group limit of 24 can confuse players. They may struggle to understand how to efficiently fill a control group if the primary method of selection (boxing) is artificially constrained compared to the grouping mechanic.
3. **Lack of Visual Feedback:** Failing to show which units belong to which group on the main screen or minimap forces players to memorize assignments blindly. Good implementations use visual indicators (like numbers next to health bars) to clearly display group affiliations.
