# Multiple Victory Conditions (多种胜利条件)

## 1. Identity
- **Atom ID:** `atom_victory_conditions`
- **English Name:** Multiple Victory Conditions
- **Chinese Name:** 多种胜利条件
- **Category:** G
- **Definition:** A game design pattern where players can achieve the ultimate win state through several distinct, mutually exclusive, or overlapping paths (e.g., military conquest, scientific dominance, cultural influence, or economic supremacy). This allows for diverse playstyles and strategic pivoting during gameplay.

## 2. Core Verb & State Machine
- **Core Verb:** `pursue_victory`
- **State Diagram:**
  [Ongoing] --> (Condition Met) --> [Victory Check]
  [Victory Check] --> (Validated) --> [Game Won]
  [Victory Check] --> (Invalidated) --> [Ongoing]
  [Ongoing] --> (Opponent Wins) --> [Game Lost]
- **States:**
  - `Ongoing`: The game is in progress, and players are accumulating resources towards various victory types.
  - `Victory Check`: A transitional state where the game evaluates if a player has met all requirements for a specific victory condition.
  - `Game Won`: Terminal state where the player has successfully achieved a victory condition.
  - `Game Lost`: Terminal state where another player achieves a victory condition first, or the player fails a critical survival condition.
- **Transitions:**
  - `Ongoing` -> `Victory Check`: Triggered when a player reaches a threshold (e.g., builds a specific wonder, reaches a score limit).
  - `Victory Check` -> `Game Won`: Triggered when the validation confirms no other player won simultaneously with higher priority.
  - `Victory Check` -> `Ongoing`: Triggered if the condition is lost before validation completes (e.g., losing a capital city during the check phase).
  - `Ongoing` -> `Game Lost`: Triggered when an opponent's `Victory Check` is validated.

## 3. MDA Analysis
- **Mechanics:** The system tracks multiple independent progress bars or boolean flags for each player. Each victory type has its own set of rules, resource requirements, and thresholds.
- **Dynamics:** Players must balance advancing their chosen victory path while monitoring and disrupting opponents' progress on different paths. This creates a dynamic where players might pivot their strategy mid-game if their primary path is blocked.
- **Aesthetics:** Provides a sense of freedom, strategic depth, and personalization. Players feel clever when they execute a surprise victory or successfully pivot from a failing strategy to a winning one.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Game) | Unit |
|---|---|---|---|---|
| `victory_types_count` | `u32` | 2 - 6 | 5 (Civilization VI v1.0.12.9) | count |
| `progress_threshold` | `f32` | 1000.0 - 50000.0 | 15000.0 (Stellaris v3.8) | points |
| `pivot_penalty_factor` | `f32` | 0.1 - 0.5 | 0.2 (Endless Legend v1.8.2) | multiplier |
| `global_turn_limit` | `u32` | 100 - 1000 | 500 (Civilization VI v1.0.12.9) | turns |

## 5. Benchmark Data
- **Civilization VI (v1.0.12.9):**
  - `victory_types_count`: 5 (Domination, Science, Culture, Religion, Diplomacy)
  - `global_turn_limit`: 500 (Standard speed)
- **Stellaris (v3.8):**
  - `victory_types_count`: 3 (Score, Crisis, Conquest)
  - `progress_threshold`: 50000.0 (Typical score to win at end year)
- **Endless Legend (v1.8.2):**
  - `victory_types_count`: 6 (Elimination, Expansion, Economic, Diplomatic, Scientific, Wonder)
  - `pivot_penalty_factor`: 0.2 (Cost of switching focus mid-game)

## 6. Common Variants
1. **Hidden Objectives:** Players have secret victory conditions that are only revealed when achieved (e.g., Twilight Imperium).
2. **Asymmetric Victory:** Different factions have entirely unique victory conditions tailored to their lore and mechanics (e.g., Root).
3. **Cooperative Victory:** Players share a common victory condition but might have individual secondary goals (e.g., Spirit Island).
4. **Point Salad:** Multiple paths all contribute to a single unified "Victory Points" score, rather than triggering an immediate win (e.g., 7 Wonders).

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_tech_tree`, `atom_resource_management`, `atom_combat_system`, `atom_diplomacy`.
- **Incompatible Atoms:** `atom_linear_narrative`, `atom_infinite_runner`.

## 8. Anti-Patterns
1. **The Dominant Strategy:** One victory condition is mathematically much easier or faster to achieve than the others, rendering them obsolete.
2. **The Uninteractable Win:** A victory condition that opponents cannot scout, interact with, or prevent (e.g., a pure timer-based win with no counterplay).
3. **The Sunk Cost Trap:** Pivoting between victory conditions is so heavily penalized that players who fall behind early have no chance of recovery.
