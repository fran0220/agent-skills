# Gameplay Atom: Slipstream / Drafting

## 1. Identity
- **Atom ID:** atom_slipstream
- **English Name:** Slipstream / Drafting
- **Chinese Name:** 尾流跟车
- **Category:** A
- **Definition:** Slipstream (or drafting) is an aerodynamic phenomenon where a vehicle moving at high speed creates a region of reduced air pressure and drag behind it. When a trailing vehicle enters this zone, it experiences less air resistance, allowing it to accelerate faster and reach a higher top speed than it could in clean air, often facilitating overtaking maneuvers.

## 2. Core Verb & State Machine
- **Core Verb:** Draft / Follow / Overtake

**State Diagram:**
[Out of Slipstream] --(Enter Wake Zone)--> [In Slipstream]
[In Slipstream] --(Stay in Zone)--> [Drafting/Accelerating]
[Drafting/Accelerating] --(Pull Out)--> [Slingshot/Overtaking]
[Slingshot/Overtaking] --(Pass or Fall Back)--> [Out of Slipstream]

**States:**
- `Out of Slipstream`: Vehicle is experiencing normal aerodynamic drag.
- `In Slipstream`: Vehicle has entered the low-pressure zone behind a leading vehicle.
- `Drafting/Accelerating`: Vehicle is actively gaining speed due to reduced drag.
- `Slingshot/Overtaking`: Vehicle pulls out of the slipstream to use the speed advantage to pass.

**Transitions:**
- `Enter Wake Zone`: Distance to leading vehicle < Wake Length AND Angle < Wake Angle.
- `Stay in Zone`: Maintain position within the wake parameters.
- `Pull Out`: Player steers out of the wake zone while maintaining higher speed.
- `Pass or Fall Back`: Speed advantage dissipates, returning to normal drag state.

## 3. MDA Analysis
- **Mechanics:** The game engine calculates a wake zone behind vehicles based on their speed and shape. If another vehicle enters this zone, its drag coefficient is dynamically reduced, and sometimes engine cooling is also reduced (simulating dirty air).
- **Dynamics:** Players naturally form packs or "trains" to maximize overall speed. Trailing players must balance the speed gain from drafting against the risk of collision or engine overheating. The "slingshot" maneuver emerges as a primary overtaking strategy.
- **Aesthetics:** Creates a sense of tension, anticipation, and tactical depth. The sudden burst of speed when pulling out of the slipstream provides a highly satisfying, visceral thrill (Fellowship in team drafting, Challenge in overtaking).

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (F1 23) | Unit |
|---|---|---|---|---|
| `wake_length` | f32 | 10.0 - 100.0 | 50.0 | meters |
| `wake_width_angle` | f32 | 5.0 - 20.0 | 10.0 | degrees |
| `drag_reduction_max` | f32 | 0.05 - 0.30 | 0.15 | multiplier (0-1) |
| `speed_threshold` | f32 | 20.0 - 50.0 | 30.0 | m/s |
| `dirty_air_downforce_loss` | f32 | 0.0 - 0.40 | 0.25 | multiplier (0-1) |

## 5. Benchmark Data
- **F1 23 (v1.15):**
  - `wake_length`: 60.0m
  - `drag_reduction_max`: 0.18
  - `dirty_air_downforce_loss`: 0.30
- **Gran Turismo 7 (v1.40):**
  - `wake_length`: 40.0m
  - `drag_reduction_max`: 0.25
  - `dirty_air_downforce_loss`: 0.05

## 6. Common Variants
1. **Arcade Boost Drafting:** (e.g., Mario Kart) Drafting for a few seconds grants a sudden, temporary nitrous-like speed boost rather than a continuous physics-based drag reduction.
2. **Team Peloton:** (e.g., Tour de France games) Complex multi-agent drafting where a large pack of riders shares the aerodynamic load, requiring stamina management.
3. **Dirty Air Penalty:** (e.g., F1 series) Drafting on straights gives a speed advantage, but following closely in corners results in a massive loss of downforce and grip.
4. **Drafting Meter:** (e.g., Need for Speed) Drafting fills a visible boost meter that the player can trigger manually at any time.

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_boost`, `atom_cornering`, `atom_stamina`.
- **Incompatible Atoms:** `atom_teleport`.

## 8. Anti-Patterns
1. **Overpowered Slingshot:** Making the drag reduction so extreme that the trailing car can effortlessly pass the leader, making defending impossible and leading to frustrating "rubber-banding" gameplay.
2. **Invisible Wake:** Failing to provide visual or audio feedback (like wind noise or speed lines) when the player enters the slipstream, making the mechanic feel random or unearned.
3. **Ignoring Dirty Air in Simulators:** In realistic racing games, providing the straight-line benefits of drafting without the cornering penalties of dirty air, which breaks the realism and tactical depth of following.
