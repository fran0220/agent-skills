# atom_auction_house

## 1. Identity
- **Atom ID**: atom_auction_house
- **English Name**: Auction House / Market
- **Chinese Name**: 拍卖行/市场
- **Category**: C or D (Economy/Trading)
- **Definition**: A centralized virtual marketplace where players can list items for sale, bid on items, or purchase items directly from other players using in-game currency, facilitating a player-driven economy.

## 2. Core Verb & State Machine
- **Core Verb**: Trade (List, Bid, Buy)
- **State Diagram**:
  [Idle] -> (List Item) -> [Listed]
  [Listed] -> (Bid Placed) -> [Bidding]
  [Bidding] -> (Higher Bid) -> [Bidding]
  [Bidding] -> (Time Expires) -> [Sold]
  [Listed] -> (Buyout) -> [Sold]
  [Listed] -> (Time Expires) -> [Expired]
  [Sold] -> (Claim) -> [Idle]
  [Expired] -> (Claim) -> [Idle]

- **States**: Idle, Listed, Bidding, Sold, Expired
- **Transitions**:
  - Idle -> Listed: Player lists an item with a starting price and duration.
  - Listed -> Bidding: Another player places a bid.
  - Bidding -> Bidding: Another player places a higher bid.
  - Bidding -> Sold: Auction duration expires with at least one bid.
  - Listed -> Sold: A player pays the buyout price.
  - Listed -> Expired: Auction duration expires with no bids.
  - Sold -> Idle: Seller claims currency, buyer claims item.
  - Expired -> Idle: Seller reclaims unsold item.

## 3. MDA Analysis
- **Mechanics**: The system provides an interface for listing items, searching for items, placing bids, and executing transactions. It handles currency escrow, item storage during the auction, and mail delivery of results. It often includes listing fees and transaction taxes to act as currency sinks.
- **Dynamics**: Emergent behaviors include market manipulation (cornering the market), undercutting (listing slightly below lowest price), sniping (bidding at the last second), and arbitrage (buying low and selling high). Prices fluctuate based on supply and demand, patch cycles, and player population.
- **Aesthetics**: Players feel a sense of progression through wealth accumulation. There is excitement in finding a bargain or winning a bidding war, and satisfaction in successfully selling items for a profit. It caters to the "Merchant" player archetype.

## 4. Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value | Unit |
|---|---|---|---|---|
| `listing_fee_percent` | f32 | 0.0 - 0.15 | 0.05 (WoW Classic) | % of vendor price or listing price |
| `transaction_tax_percent` | f32 | 0.0 - 0.30 | 0.05 (WoW Classic) | % of final sale price |
| `max_duration_hours` | u32 | 12 - 168 | 48 (WoW Classic) | Hours |
| `max_listings_per_player` | u32 | 10 - 1000 | 50 (Lost Ark) | Count |
| `bid_increment_percent` | f32 | 0.01 - 0.10 | 0.05 (WoW Classic) | % of current bid |

## 5. Benchmark Data
- **World of Warcraft (Classic 1.13)**:
  - `listing_fee_percent`: 0.05 (5% of vendor sell price per 12 hours)
  - `transaction_tax_percent`: 0.05 (5% cut taken by the neutral AH is 15%, faction AH is 5%)
  - `max_duration_hours`: 48
- **Escape from Tarkov (0.13)**:
  - `listing_fee_percent`: Variable based on item value and listing price (formulaic)
  - `transaction_tax_percent`: Included in listing fee
  - `max_listings_per_player`: Scales with Flea Market reputation (starts at 2)
- **Diablo 3 (Vanilla 1.0.8 - Real Money AH)**:
  - `transaction_tax_percent`: 0.15 (15% for gold AH), $1 USD + 15% cash out fee for RMAH.
  - `max_duration_hours`: 36

## 6. Common Variants
1. **Blind Bidding**: Players submit bids without seeing others' bids; highest wins at the end.
2. **Buyout Only (Flea Market)**: No bidding allowed, items are listed at a fixed price and purchased instantly.
3. **Order Book (Commodities Market)**: Players place buy orders and sell orders for fungible goods (like stocks), and the system automatically matches them (e.g., Guild Wars 2 Trading Post, WoW Retail commodities).
4. **Real Money Auction House (RMAH)**: Transactions are conducted using real-world currency instead of in-game gold.

## 7. Compatibility Notes
- **Compatible Atoms**: `atom_inventory_management`, `atom_crafting_system`, `atom_currency_system`, `atom_mail_system`.
- **Conflicts**: `atom_soulbound_items` (items that cannot be traded), `atom_solo_self_found` (game modes restricting player interaction).

## 8. Anti-Patterns
1. **Lack of Currency Sinks**: Failing to implement transaction taxes, leading to hyperinflation as gold is continuously generated but never removed from the economy.
2. **Poor Search/Filtering**: Making it difficult for players to find specific items or compare prices, leading to frustration and reliance on third-party add-ons.
3. **Vulnerability to Botting**: Not implementing rate limits or CAPTCHAs, allowing automated bots to snipe underpriced items instantly, ruining the experience for legitimate players.
