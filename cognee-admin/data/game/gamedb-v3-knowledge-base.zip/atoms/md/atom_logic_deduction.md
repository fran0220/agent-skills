# Logic Deduction (逻辑推理)

## 1. Identity
**Atom ID:** `atom_logic_deduction`
**English Name:** Logic Deduction
**Chinese Name:** 逻辑推理
**Category:** C/D (Cognitive/Deductive)
**Definition:** Logic Deduction is a cognitive gameplay atom where the player is presented with a set of rules and incomplete information, and must use logical reasoning to infer the missing information, identify patterns, or determine the correct sequence of actions to progress.

## 2. Core Verb & State Machine
**Core Verb:** Deduce (Infer, Conclude, Solve)

**State Machine:**
- `Unsolved`: The initial state where information is incomplete.
- `Hypothesizing`: The player is actively forming and testing hypotheses.
- `Verifying`: The system checks the player's deduced solution against the truth.
- `Solved`: The correct deduction has been made and confirmed.
- `Failed`: An incorrect deduction was submitted (often leading back to `Unsolved` or `Hypothesizing`).

**Transitions:**
- `Unsolved` -> `Hypothesizing`: Player interacts with clues.
- `Hypothesizing` -> `Verifying`: Player submits a solution.
- `Verifying` -> `Solved`: Solution is correct.
- `Verifying` -> `Failed`: Solution is incorrect.
- `Failed` -> `Hypothesizing`: Player retries.

## 3. MDA Analysis
**Mechanics:** The game provides a structured set of rules and a partial dataset (clues, constraints). The system evaluates the player's input against a deterministic logical model.
**Dynamics:** Players engage in trial-and-error, cross-referencing clues, and eliminating impossibilities. This often leads to "aha!" moments when a critical connection is made.
**Aesthetics:** The primary aesthetic is *Discovery* and *Challenge*. Players feel a sense of intellectual accomplishment, clarity, and satisfaction when they successfully unravel a complex logical puzzle.

## 4. Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value | Unit |
|---|---|---|---|---|
| `clue_count` | u32 | 10 - 50 | 25 (Sudoku Hard) | count |
| `grid_size` | u32 | 4 - 16 | 9 (Sudoku) | cells |
| `complexity_level` | f32 | 0.1 - 1.0 | 0.8 (Obra Dinn) | ratio |
| `penalty_on_fail` | bool | true/false | true (Obra Dinn) | boolean |

## 5. Benchmark Data
- **Sudoku (Classic Web Version 1.0):** `clue_count` = 25, `grid_size` = 9, `complexity_level` = 0.5, `penalty_on_fail` = false.
- **Return of the Obra Dinn (v1.0.98):** `clue_count` = 60, `grid_size` = 1, `complexity_level` = 0.9, `penalty_on_fail` = true (requires 3 correct deductions to lock in).

## 6. Common Variants
1. **Spatial Deduction:** Using spatial constraints (e.g., Minesweeper, Picross).
2. **Narrative Deduction:** Piecing together story elements or identities (e.g., Return of the Obra Dinn, Her Story).
3. **Symbolic Logic:** Manipulating abstract symbols based on strict rules (e.g., Baba Is You).
4. **Social Deduction:** Inferring hidden roles of other players (e.g., Among Us, Werewolf).

## 7. Compatibility Notes
**Compatible Atoms:**
- `atom_exploration`: Finding clues in the environment feeds directly into deduction.
- `atom_dialogue_choice`: Interrogating NPCs to gather logical premises.
- `atom_inventory_management`: Combining items as a form of logical puzzle solving.

**Incompatible Atoms:**
- `atom_twitch_reflex`: High-speed reaction requirements often disrupt the slow, deliberate cognitive process needed for deduction.
- `atom_pure_rng`: Randomness undermines the deterministic nature of logical deduction.

## 8. Anti-Patterns
1. **Moon Logic:** Creating puzzles where the solution relies on the designer's subjective leaps of logic rather than objective rules, frustrating the player.
2. **Information Starvation:** Not providing enough clues for a definitive logical conclusion, forcing the player to guess blindly.
3. **Overwhelming Clue Dump:** Presenting too much unstructured information at once, causing cognitive overload rather than a structured deduction process.
