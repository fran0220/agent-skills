# Environmental Storytelling (环境叙事)

## 1. Identity
- **Atom ID:** atom_environmental_storytelling
- **English Name:** Environmental Storytelling
- **Chinese Name:** 环境叙事
- **Category:** E (Exploration/Environment)
- **Definition:** Environmental storytelling is the art of conveying narrative, lore, and context through the design, placement, and state of objects within the game world, rather than through explicit dialogue or text. It relies on the player's observation and deduction to piece together the history and events of a specific location.

## 2. Core Verb & State Machine
- **Core Verb:** Observe / Deduce
- **State Diagram:**
  [Unnoticed] --> (Player approaches) --> [Observed]
  [Observed] --> (Player interacts/analyzes) --> [Analyzed]
  [Analyzed] --> (Player connects clues) --> [Understood]
- **States:**
  - `Unnoticed`: The environmental clue exists in the world but hasn't been seen by the player.
  - `Observed`: The player has visual contact with the clue.
  - `Analyzed`: The player has examined the clue closely (e.g., reading a label, noting bloodstains).
  - `Understood`: The player has integrated the clue into their mental model of the game's narrative.
- **Transitions:**
  - `Unnoticed` -> `Observed`: Triggered by line of sight and proximity.
  - `Observed` -> `Analyzed`: Triggered by player focus or interaction.
  - `Analyzed` -> `Understood`: Triggered by cognitive deduction (internal to player) or explicit game logic (e.g., journal update).

## 3. MDA Analysis
- **Mechanics:** The placement of static meshes, decals (e.g., blood, scorch marks), lighting, and audio cues in specific configurations. The system tracks player discovery of key narrative nodes.
- **Dynamics:** Players naturally slow down their pacing to explore corners, examine objects, and formulate theories about past events. It encourages a more deliberate and observant playstyle.
- **Aesthetics:** Discovery, Mystery, Immersion. Players feel like detectives or archaeologists, experiencing a sense of satisfaction when they "solve" the implicit narrative puzzle.

## 4. Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value (Game) | Unit |
|---|---|---|---|---|
| `clue_density` | f32 | 0.1 - 5.0 | 2.5 (Bioshock v1.0) | clues/room |
| `visibility_radius` | f32 | 1.0 - 50.0 | 15.0 (Gone Home v1.2) | meters |
| `ambiguity_level` | f32 | 0.0 - 1.0 | 0.8 (Dark Souls v1.0) | ratio |
| `interaction_required` | bool | true/false | false (Dark Souls v1.0) | boolean |

## 5. Benchmark Data
- **Dark Souls (v1.0):**
  - `clue_density`: 1.2 clues/room
  - `visibility_radius`: 20.0 meters
  - `ambiguity_level`: 0.9
  - `interaction_required`: false
- **Bioshock (v1.0):**
  - `clue_density`: 3.5 clues/room
  - `visibility_radius`: 10.0 meters
  - `ambiguity_level`: 0.4
  - `interaction_required`: true
- **Gone Home (v1.2):**
  - `clue_density`: 5.0 clues/room
  - `visibility_radius`: 5.0 meters
  - `ambiguity_level`: 0.2
  - `interaction_required`: true

## 6. Common Variants
1. **The Aftermath:** A scene depicting the result of a violent or tragic event (e.g., skeletons in a specific pose, barricaded doors).
2. **The Lived-in Space:** A room that tells the story of its inhabitant through mundane objects (e.g., messy desk, specific books).
3. **The Breadcrumb Trail:** A series of environmental clues leading the player to a secret or a realization.
4. **The Contradiction:** An environment that directly contradicts what the player has been told, creating narrative dissonance and intrigue.

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_exploration`, `atom_lore_collectible`, `atom_detective_vision`, `atom_level_design`.
- **Incompatible Atoms:** `atom_auto_scrolling_level`, `atom_time_attack` (fast-paced modes discourage the slow observation required).

## 8. Anti-Patterns
1. **Over-Exposition:** Placing too many explicit notes or audio logs right next to the environmental storytelling, rendering the visual clues redundant.
2. **Illogical Placement:** Placing objects in ways that make no sense within the world's logic just to convey a message, breaking immersion.
3. **Invisible Clues:** Making the environmental details so small, dark, or obscured that players naturally miss them without a guide.
