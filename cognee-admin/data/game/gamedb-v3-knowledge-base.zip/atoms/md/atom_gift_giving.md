# Identity
- **Atom ID**: atom_gift_giving
- **English Name**: Gift Giving
- **Chinese Name**: 送礼
- **Category**: E
- **Definition**: A social interaction mechanic where a player transfers an item from their inventory to an NPC, resulting in a change in the NPC's relationship points (friendship/affection) based on the NPC's preferences for that specific item.

# Core Verb & State Machine
- **Core Verb**: Give (Item)
- **State Diagram**:
  [Idle] -> (Player initiates interaction) -> [Selecting Gift]
  [Selecting Gift] -> (Player confirms item) -> [Evaluating Preference]
  [Evaluating Preference] -> (Item is Loved/Liked/Neutral/Disliked/Hated) -> [Applying Friendship Change]
  [Applying Friendship Change] -> (NPC reacts) -> [Cooldown/Limit Reached]
  [Cooldown/Limit Reached] -> (Time passes, e.g., next day/week) -> [Idle]

- **States**: Idle, Selecting Gift, Evaluating Preference, Applying Friendship Change, Cooldown/Limit Reached
- **Transitions**:
  - Idle -> Selecting Gift: Triggered by player interacting with NPC while holding a giftable item.
  - Selecting Gift -> Evaluating Preference: Triggered by player confirming the gift selection.
  - Evaluating Preference -> Applying Friendship Change: Automatic transition based on NPC data.
  - Applying Friendship Change -> Cooldown/Limit Reached: Automatic transition after reaction animation/dialogue.
  - Cooldown/Limit Reached -> Idle: Triggered by reset timer (e.g., daily or weekly reset).

# MDA Analysis
- **Mechanics**: The system checks the item ID against the NPC's preference lists (Loved, Liked, Neutral, Disliked, Hated). It applies a corresponding point value to the hidden friendship variable. It also checks and increments daily/weekly gift limits.
- **Dynamics**: Players hoard specific items known to be "Loved" by target NPCs. Players optimize their daily routes to distribute gifts efficiently. Players may experience trial and error to discover preferences if not using a guide.
- **Aesthetics**: Players feel a sense of progression and connection with the NPCs. Discovering a loved gift provides a moment of joy. Reaching relationship milestones feels rewarding.

# Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value (Stardew Valley v1.5) | Unit |
|---|---|---|---|---|
| loved_gift_points | int | 50 - 100 | 80 | points |
| liked_gift_points | int | 20 - 50 | 45 | points |
| neutral_gift_points | int | 10 - 30 | 20 | points |
| disliked_gift_points | int | -30 - -10 | -20 | points |
| hated_gift_points | int | -50 - -20 | -40 | points |
| daily_gift_limit | int | 1 - 3 | 1 | gifts/day |
| weekly_gift_limit | int | 2 - 7 | 2 | gifts/week |
| birthday_multiplier | float | 2.0 - 8.0 | 8.0 | multiplier |

# Benchmark Data
- **Stardew Valley (v1.5)**:
  - loved_gift_points: 80
  - liked_gift_points: 45
  - neutral_gift_points: 20
  - disliked_gift_points: -20
  - hated_gift_points: -40
  - daily_gift_limit: 1
  - weekly_gift_limit: 2
  - birthday_multiplier: 8.0
- **Animal Crossing: New Horizons (v2.0)**:
  - loved_gift_points: 3
  - liked_gift_points: 2
  - neutral_gift_points: 1
  - disliked_gift_points: -2
  - hated_gift_points: -3
  - daily_gift_limit: 1
  - weekly_gift_limit: 7
  - birthday_multiplier: 3.0

# Common Variants
1. **Quality Multipliers**: Higher quality items (e.g., Gold/Iridium star in Stardew Valley) provide a multiplier to the base friendship points.
2. **Wrapping Paper**: Wrapping the gift before giving it adds a flat bonus or multiplier to the points awarded.
3. **Diminishing Returns**: Giving the same gift repeatedly yields fewer points over time.
4. **Reciprocal Gifting**: The NPC may give a gift back immediately or in the mail the next day based on the relationship level.

# Compatibility Notes
- **Compatible Atoms**: atom_friendship_level, atom_inventory_management, atom_item_quality, atom_calendar_events
- **Conflicts**: atom_permadeath

# Anti-Patterns
1. **Opaque Preferences**: Providing no in-game hints about NPC preferences, forcing players to rely entirely on external wikis.
2. **Tedious Animation**: Unskippable, long animations for every single gift given, making the daily routine a chore.
3. **Overpowered Gifts**: A single, easily obtainable item that is universally loved by all NPCs, trivializing the relationship system.
