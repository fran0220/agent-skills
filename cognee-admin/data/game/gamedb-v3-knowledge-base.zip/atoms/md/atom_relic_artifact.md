# Gameplay Atom: Relic / Artifact

## 1. Identity
- **Atom ID:** `atom_relic_artifact`
- **English Name:** Relic / Artifact
- **Chinese Name:** 遗物/神器
- **Category:** C (Progression / Meta-Progression)
- **Definition:** A Relic or Artifact is a collectible item that provides a persistent, passive gameplay modifier or active ability to the player's character for the duration of a run or permanently. These items fundamentally alter the rules of the game, creating synergies with other mechanics and encouraging diverse playstyles and strategic decision-making.

## 2. Core Verb & State Machine
- **Core Verb:** Acquire / Equip / Trigger
- **State Diagram:**
  [Unobtained] --> (Discover/Purchase) --> [Inventory/Equipped]
  [Inventory/Equipped] --> (Condition Met) --> [Active/Triggered]
  [Active/Triggered] --> (Cooldown/Reset) --> [Inventory/Equipped]
  [Inventory/Equipped] --> (Sell/Lose) --> [Unobtained]
- **States:**
  - `Unobtained`: The relic is in the loot pool but not yet acquired by the player.
  - `Inventory/Equipped`: The player possesses the relic, and its passive effects are active or it is ready to be triggered.
  - `Active/Triggered`: The relic's specific conditional effect is currently resolving.
- **Transitions:**
  - `Unobtained` -> `Inventory/Equipped`: Triggered by looting a chest, defeating a boss, or purchasing from a shop.
  - `Inventory/Equipped` -> `Active/Triggered`: Triggered by specific game events (e.g., taking damage, playing a specific card type).
  - `Active/Triggered` -> `Inventory/Equipped`: Triggered after the effect resolves or a cooldown period ends.
  - `Inventory/Equipped` -> `Unobtained`: Triggered by specific events that consume or remove the relic.

## 3. MDA Analysis
- **Mechanics:** Relics modify core game variables (e.g., max health, damage output, resource generation) or introduce new rules (e.g., "whenever you discard a card, deal 3 damage"). They operate via an event-listener architecture, hooking into game state changes.
- **Dynamics:** Players actively seek out specific relics to build synergistic combinations (e.g., combining a relic that damages enemies upon discarding with a relic that draws cards upon discarding). This leads to exponential power scaling and unique "builds" for each playthrough.
- **Aesthetics:** The acquisition of a powerful relic evokes feelings of excitement and discovery (Discovery). Successfully combining multiple relics to create a game-breaking synergy provides a deep sense of intellectual satisfaction and mastery (Expression/Challenge).

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value | Unit |
| :--- | :--- | :--- | :--- | :--- |
| `rarity_weight` | `f32` | 0.01 - 1.0 | 0.1 (Slay the Spire v2.3) | Probability |
| `cost` | `u32` | 50 - 500 | 150 (Slay the Spire v2.3) | Gold/Currency |
| `trigger_chance` | `f32` | 0.0 - 1.0 | 1.0 (Hades v1.38) | Probability |
| `cooldown` | `f32` | 0.0 - 60.0 | 0.0 (Slay the Spire v2.3) | Seconds/Turns |
| `effect_magnitude` | `f32` | 1.0 - 100.0 | 3.0 (Slay the Spire v2.3) | HP/Damage/Stats |

## 5. Benchmark Data
- **Slay the Spire (v2.3):**
  - Relic: *Vajra*
  - `cost`: 150 Gold
  - `effect_magnitude`: 1 (Strength)
  - `trigger_chance`: 1.0 (Passive, always active)
- **Hades (v1.38):**
  - Artifact: *Pom of Power*
  - `cost`: 100 Obols
  - `effect_magnitude`: 1 (Level up a boon)
  - `trigger_chance`: 1.0 (On pickup)

## 6. Common Variants
1. **Consumable Relics:** Relics that provide a powerful effect but are destroyed after a certain number of uses or a specific trigger (e.g., *Lizard Tail* in Slay the Spire).
2. **Cursed Relics:** Relics that provide a significant benefit but come with a severe drawback or penalty, forcing the player to weigh the risks (e.g., *Cursed Key* in Slay the Spire).
3. **Evolving Relics:** Relics that start weak but grow in power as the player completes specific tasks or meets certain conditions (e.g., *Keepsakes* in Hades).
4. **Set Relics:** Relics that gain additional effects when equipped alongside other specific relics from the same set.

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_random_loot_drop` (Relics are often the reward), `atom_status_effect` (Relics frequently apply or modify status effects), `atom_resource_management` (Relics can alter resource generation or costs).
- **Incompatible Atoms:** `atom_strict_linear_progression` (Relics introduce high variance, which conflicts with strictly controlled, predictable progression systems).

## 8. Anti-Patterns
1. **Diluted Loot Pool:** Introducing too many highly situational or weak relics, making it difficult for players to find synergistic pieces and reducing the excitement of discovery.
2. **Invisible Power:** Creating relics with effects that are difficult for the player to track or notice in gameplay, leading to a lack of satisfaction.
3. **Mandatory Synergies:** Designing the game such that winning is impossible without finding a specific combination of relics, reducing strategic diversity and increasing reliance on RNG.
