# Gameplay Atom: Block Rotation / Placement

## 1. Identity
- **Atom ID:** `atom_block_rotation`
- **English Name:** Block Rotation / Placement
- **Chinese Name:** 方块旋转/放置
- **Category:** C/D (Core Mechanics / Dynamics)
- **Definition:** The fundamental mechanic of manipulating a falling or placed geometric shape (block/tetromino) by rotating it around a pivot point and placing it into a grid or playfield to achieve a specific spatial arrangement.

## 2. Core Verb & State Machine
- **Core Verb:** Rotate, Move, Drop, Place
- **State Diagram:**
  ```text
  [Spawn] --> [Falling]
  [Falling] --> [Rotating] (Trigger: Player Input - Rotate)
  [Rotating] --> [Falling] (Trigger: Rotation Complete)
  [Falling] --> [Moving] (Trigger: Player Input - Move Left/Right)
  [Moving] --> [Falling] (Trigger: Movement Complete)
  [Falling] --> [Soft Drop] (Trigger: Player Input - Down)
  [Falling] --> [Hard Drop] (Trigger: Player Input - Hard Drop)
  [Falling] --> [Lock Delay] (Trigger: Collision with Ground/Block)
  [Lock Delay] --> [Locked/Placed] (Trigger: Timer Expires or Hard Drop)
  [Locked/Placed] --> [Spawn] (Trigger: Next Piece)
  ```
- **States:** Spawn, Falling, Rotating, Moving, Soft Drop, Hard Drop, Lock Delay, Locked/Placed.
- **Transitions:**
  - Spawn -> Falling: Automatic upon piece generation.
  - Falling -> Rotating: Player presses rotate button.
  - Falling -> Moving: Player presses directional buttons.
  - Falling -> Lock Delay: Piece touches the stack or floor.
  - Lock Delay -> Locked/Placed: Lock delay timer reaches zero.

## 3. MDA Analysis
- **Mechanics:** The system generates a sequence of blocks. The player can translate and rotate the active block within the confines of the playfield. Collision detection prevents blocks from overlapping. A lock delay system gives players a brief window to make final adjustments before the block is permanently placed.
- **Dynamics:** Players must quickly assess the spatial requirements of the playfield and manipulate the falling block to fit. The increasing speed of falling blocks creates time pressure, leading to emergent strategies like "T-spins" or setting up combos.
- **Aesthetics:** The experience evokes feelings of spatial reasoning, flow, tension (as speed increases), and relief/satisfaction when clearing lines or perfectly placing a block.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Tetris Guideline) | Unit |
|---|---|---|---|---|
| `fall_speed` | f32 | 0.01 - 20.0 | 0.016 | cells/frame |
| `lock_delay` | u32 | 0 - 100 | 30 | frames |
| `das` | u32 | 5 - 20 | 10 | frames |
| `arr` | u32 | 0 - 5 | 2 | frames |
| `soft_drop_multiplier` | f32 | 2.0 - 20.0 | 20.0 | multiplier |

## 5. Benchmark Data
- **Tetris (Guideline standard, e.g., Tetris Effect v1.0):**
  - `lock_delay`: 30 frames (0.5 seconds at 60fps)
  - `das`: 10 frames
  - `arr`: 2 frames
  - `soft_drop_multiplier`: 20.0x normal fall speed
- **Lumines (Remastered v1.0):**
  - `fall_speed`: Tied to BPM of the music track.
  - `rotation_type`: 2x2 block rotation (cycles colors rather than changing shape footprint).

## 6. Common Variants
1. **Super Rotation System (SRS):** Allows blocks to "kick" off walls or other blocks if a simple rotation would result in a collision.
2. **Center-Axis Rotation:** Blocks rotate strictly around a central block (classic arcade style).
3. **Color Cycling:** Instead of changing the physical shape, rotation cycles the colors/properties of the sub-blocks (e.g., Lumines, Columns).
4. **Free-Angle Rotation:** Blocks can be rotated by arbitrary degrees (e.g., Tricky Towers) rather than strict 90-degree increments.

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_grid_movement`, `atom_pattern_matching`, `atom_gravity`, `atom_combo_system`.
- **Incompatible Atoms:** `atom_free_aiming`, `atom_continuous_physics`.

## 8. Anti-Patterns
1. **Lack of Lock Delay:** Forcing the block to lock instantly upon touching the ground at high speeds makes the game unplayable and frustrating.
2. **Inconsistent Rotation Pivot:** If the pivot point changes unpredictably between rotations, players cannot build muscle memory or accurately predict where the block will end up.
3. **Missing Wall Kicks:** In modern grid-based games, failing to implement wall kicks makes rotation near the edges of the board feel clunky and restrictive.
