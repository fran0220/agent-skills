# Identity

The gameplay atom **atom_iframes**, known in English as **Invincibility Frames** and in Chinese as **无敌帧**, belongs to category A. It is defined as a brief window of time during an animation, such as a dodge, roll, or recovery, where the player character is completely immune to damage and hitstun. This mechanic allows the character to pass through enemy attacks unharmed, providing a crucial defensive option in combat-heavy games.

# Core Verb & State Machine

The core verb associated with this atom is **Dodge**, **Roll**, or **Evade**. The state machine for this action involves transitioning from an idle state through the animation phases.

The state diagram can be represented as follows:
[Idle] -> (Input Dodge) -> [Startup] -> (Startup Ends) -> [Active (I-Frames)] -> (Active Ends) -> [Recovery] -> (Recovery Ends) -> [Idle]

The states include `Idle`, where the character is ready to receive input; `Startup`, representing the initial frames of the animation before invincibility begins; `Active (I-Frames)`, the frames where the character is invincible; and `Recovery`, the frames after invincibility ends but before the character can act again.

Transitions occur when the player inputs the dodge command, moving from `Idle` to `Startup`. The transition from `Startup` to `Active` is automatic after a set number of frames or time. Similarly, the transition from `Active` to `Recovery` is automatic after the i-frame duration expires, and `Recovery` to `Idle` happens automatically after the animation completes.

# MDA Analysis

**Mechanics**: The system temporarily disables the character's hurtbox or sets a flag that nullifies incoming damage and hit effects for a specific duration during an animation. This is usually tied to a specific input and consumes a resource like stamina.

**Dynamics**: Players learn enemy attack timings and use i-frames to aggressively phase through attacks rather than just moving out of the way. This leads to close-quarters combat, rhythmic dodging, and a high-risk, high-reward playstyle where positioning and timing are paramount.

**Aesthetics**: The successful execution of an i-frame dodge creates a feeling of mastery, tension, and immense satisfaction. It empowers the player, rewarding precision and deep knowledge of enemy attack patterns, making the combat feel fair and skill-based.

# Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Dark Souls III v1.15) | Unit |
|---|---|---|---|---|
| `startup_frames` | u32 | 0 - 10 | 0 | frames (at 30fps) |
| `active_iframes` | u32 | 5 - 20 | 13 | frames (at 30fps) |
| `recovery_frames` | u32 | 10 - 30 | 12 | frames (at 30fps) |
| `stamina_cost` | f32 | 10.0 - 50.0 | 15.0 | points |

# Benchmark Data

In **Dark Souls III (v1.15)**, the fast roll has 0 startup frames, 13 active i-frames, and 12 recovery frames when running at 30 FPS. This provides a generous window for dodging while requiring precise timing.

In **Monster Hunter: World (v15.11)**, the standard dodge roll provides approximately 7 active i-frames at 30 FPS, which translates to about 0.23 seconds of invincibility. This tighter window demands greater precision from the player compared to Dark Souls.

# Common Variants

**Perfect Dodge / Just Defend**: This variant rewards dodging at the very last possible frame with extra benefits, such as slowing down time (e.g., Witch Time in *Bayonetta*) or providing a temporary damage buff.

**Directional I-Frames**: Invincibility only applies to certain parts of the body or against attacks coming from specific directions, requiring the player to not only time the dodge but also position it correctly.

**Extended I-Frames via Skills**: Players can equip items or skills, such as the Evade Window skill in *Monster Hunter*, to increase the number of active i-frames, allowing them to customize the difficulty of dodging.

**Blink / Teleport**: The character physically disappears from the map during the i-frames, ensuring no collision and often allowing them to pass through solid obstacles or enemies.

# Compatibility Notes

This atom is highly compatible with `atom_stamina_management`, as dodging usually costs stamina to prevent spamming. It also pairs well with `atom_counter_attack`, where triggering a counter after a successful i-frame dodge is a core mechanic. Additionally, `atom_hitstop` can be used to add impact to the dodged attack, emphasizing the close call.

However, it conflicts with `atom_realistic_physics`, as the ability to phase through solid weapons or massive attacks breaks physical realism and immersion in games striving for strict simulation.

# Anti-Patterns

**Misaligned Animation**: A common mistake is when the visual representation of the dodge does not match the actual i-frames. This causes players to get hit when they look safe, leading to frustration and a feeling of unfairness.

**Excessive I-Frames**: Giving too many i-frames makes the game trivial, as players can simply spam the dodge button to remain permanently invincible, removing the need for skill or timing.

**Unclear Feedback**: Failing to provide clear visual or audio cues when an attack is successfully dodged using i-frames leaves the player unsure if they timed it right or if the enemy simply missed, reducing the satisfaction of the mechanic.
