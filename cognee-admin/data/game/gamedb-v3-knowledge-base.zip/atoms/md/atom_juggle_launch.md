# Gameplay Atom: Juggle / Launch (浮空连击)

## 1. Identity
The **atom_juggle_launch** gameplay atom, known in English as **Juggle / Launch** and in Chinese as **浮空连击**, belongs to the **A+B** category. The Juggle or Launch atom refers to a combat mechanic where a character strikes an opponent, sending them airborne and rendering them temporarily defenseless. While the opponent is in the air, the attacker can perform a sequence of follow-up attacks (a juggle combo) before the opponent hits the ground or recovers. This mechanic emphasizes timing, positioning, and combo execution, rewarding players for successfully initiating and maintaining the airborne state.

## 2. Core Verb & State Machine
The primary player verbs are **Launch** (to send the opponent into the air) and **Juggle** (to strike the airborne opponent).

The state machine for this atom involves several key states and transitions. The sequence begins in the **Idle** state, which is the default state of both the attacker and defender. When the attacker performs a move designed to lift the opponent, the system transitions to the **Launching** state. Upon a successful hit, the defender enters the **Opponent Airborne** state, where they are in the air and unable to act or have limited defensive options. 

From the airborne state, if the attacker performs subsequent strikes, the system enters the **Juggling** state. A successful juggle hit returns the defender to the **Opponent Airborne** state. If no follow-up attack occurs, gravity and time cause a transition to the **Falling** state, where the defender descends towards the ground. Finally, upon ground impact, the defender enters the **Grounded/Recovery** state, hitting the ground and entering a recovery phase before returning to Idle.

## 3. MDA Analysis
In terms of **Mechanics**, the system calculates the launch trajectory based on the attack's force and the defender's weight. Each subsequent juggle hit applies additional upward or horizontal force, counteracting gravity. However, this often comes with diminishing returns, such as increased gravity scaling per hit, to prevent infinite combos and ensure gameplay balance.

The **Dynamics** of this atom involve players actively seeking openings to land a launcher. Once successful, they must execute precise inputs to maximize damage while managing the opponent's height and position. Conversely, the defender may have limited mechanics, like combo breakers or air teching, to escape the juggle and regain control.

The **Aesthetics** focus on the player experiencing a sense of mastery, power, and rhythm. Successfully executing a complex juggle combo is highly satisfying and visually spectacular, creating a strong feeling of dominance over the opponent and rewarding skillful play.

## 4. Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value | Unit |
|---|---|---|---|---|
| `launch_velocity_y` | f32 | 10.0 - 30.0 | 15.0 (Tekken 7) | units/sec |
| `gravity_scale` | f32 | 1.0 - 3.0 | 1.2 (Smash Bros Ultimate) | multiplier |
| `hitstun_duration` | f32 | 0.2 - 1.5 | 0.8 (Devil May Cry 5) | seconds |
| `juggle_decay` | f32 | 0.0 - 0.5 | 0.1 (Tekken 7) | multiplier/hit |
| `max_juggle_hits` | u32 | 3 - 20 | 10 (Devil May Cry 5) | count |

## 5. Benchmark Data
In **Tekken 7 (v5.00)**, the `launch_velocity_y` is highly standardized around 15.0 for standard launchers. The `juggle_decay`, often implemented as a pushback or gravity increase, ensures combos naturally drop after 6 to 8 hits, maintaining competitive balance.

For **Devil May Cry 5 (v1.0)**, the `hitstun_duration` is generous, often around 0.8 seconds for standard launchers, allowing for extensive aerial raves. The `max_juggle_hits` is high, limited more by enemy weight and specific attack properties than a hard cap, encouraging creative and lengthy combos.

In **Super Smash Bros. Ultimate (v13.0.1)**, the `gravity_scale` is dynamic and heavily influenced by the defender's damage percentage. A base value of 1.2 is common, but it scales up significantly as damage increases, making juggles progressively harder at high percentages.

## 6. Common Variants
Several variations of this atom exist across different games. The **Wall Bounce Juggle** occurs when the opponent is launched into a wall and bounces back, allowing for continued juggling. The **Ground Bounce (OTG)** variant involves an attack striking a grounded opponent, bouncing them slightly into the air for a juggle extension. 

Another variant is the **Stagger/Crumple Launch**, where the opponent slowly collapses before being launched, providing a larger window for the attacker to confirm the combo. Finally, the **Air-to-Air Juggle** happens when both the attacker and defender are already airborne when the juggle sequence begins.

## 7. Compatibility Notes
This atom pairs well with several others. It is highly compatible with **atom_dash_cancel** for extending combos by closing distance quickly, **atom_wall_bounce** for facilitating corner juggles, and **atom_air_dash** for precise aerial positioning during the juggle.

However, there are known conflicts. It is generally incompatible with **atom_super_armor**, as opponents with active super armor cannot be launched. It also conflicts with **atom_invincibility_frame**, which prevents the initial launch from connecting altogether.

## 8. Anti-Patterns
A common design mistake is allowing **Infinite Juggles**. Failing to implement a decay mechanic, such as gravity scaling or hitstun deterioration, allows players to juggle the opponent indefinitely, ruining the competitive experience.

Another issue is **Inconsistent Launch Heights**. Launchers that yield unpredictable heights make it impossible for players to reliably execute learned combos, leading to frustration. Finally, a **Lack of Defensive Options** in multiplayer games, where excessively long juggles occur without any burst or escape mechanic, can lead to a highly frustrating experience for the defending player.
