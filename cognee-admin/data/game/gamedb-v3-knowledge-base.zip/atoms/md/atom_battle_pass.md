# Gameplay Atom: Battle Pass

## 1. Identity
- **Atom ID:** atom_battle_pass
- **English Name:** Battle Pass
- **Chinese Name:** 战斗通行证
- **Category:** D
- **Definition:** A monetization and progression system that rewards players with in-game items for playing the game and completing specific challenges over a set period (a "season"). It typically features a free tier and a premium tier.

## 2. Core Verb & State Machine
- **Core Verb:** Progress (Earn XP/Levels)

**State Diagram:**
[Inactive] -> (Purchase/Start Season) -> [Active]
[Active] -> (Earn XP) -> [Level Up]
[Level Up] -> (Claim Reward) -> [Active]
[Active] -> (Season Ends) -> [Expired]

**States and Transitions:**
- `Inactive`: The player has not started the season or purchased the pass.
- `Active`: The player is currently participating in the season.
- `Level Up`: The player has reached a new tier/level.
- `Expired`: The season has ended, and no further progress can be made.

## 3. MDA Analysis
- **Mechanics:** Players earn experience points (XP) by playing matches, completing daily/weekly challenges, or participating in events. Accumulating XP increases the Battle Pass level, unlocking rewards at specific milestones.
- **Dynamics:** Players are incentivized to log in regularly to complete time-limited challenges. The dual-track system (free vs. premium) creates a constant comparison, encouraging players to upgrade to the premium track to unlock the rewards they have already "earned" the right to claim.
- **Aesthetics:** A sense of continuous progression, accomplishment, and anticipation. Players feel rewarded for their time investment, and the premium track offers a feeling of exclusivity and high value.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value | Unit |
|---|---|---|---|---|
| `max_level` | u32 | 50 - 100 | 100 (Fortnite v28.00) | Levels |
| `xp_per_level` | u32 | 1000 - 80000 | 80000 (Fortnite v28.00) | XP |
| `season_duration` | u32 | 30 - 90 | 70 (Fortnite v28.00) | Days |
| `premium_cost` | u32 | 500 - 1500 | 950 (Fortnite v28.00) | Premium Currency |
| `total_rewards` | u32 | 50 - 150 | 100 (Fortnite v28.00) | Items |

## 5. Benchmark Data
- **Fortnite (v28.00):**
  - `max_level`: 100
  - `xp_per_level`: 80000
  - `season_duration`: 70
  - `premium_cost`: 950
- **Genshin Impact (v4.3):**
  - `max_level`: 50
  - `xp_per_level`: 1000
  - `season_duration`: 42
  - `premium_cost`: 1000
- **Apex Legends (Season 19):**
  - `max_level`: 110
  - `xp_per_level`: 10000
  - `season_duration`: 90
  - `premium_cost`: 950

## 6. Common Variants
1. **Infinite Tiers:** After reaching the max level, players continue to earn a repeating reward (e.g., currency or loot boxes) for every X amount of XP.
2. **Choose Your Path:** Players earn a currency (like Battle Stars in Fortnite) to unlock rewards in a non-linear order within pages.
3. **Mini-Pass / Event Pass:** A shorter, cheaper (or free) pass tied to a specific 2-3 week event rather than a full season.
4. **Retained Passes:** Passes that do not expire, allowing players to choose which pass their XP goes towards (e.g., Halo Infinite).

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_daily_quest`, `atom_weekly_challenge`, `atom_premium_currency`, `atom_loot_box`, `atom_cosmetic_item`.
- **Incompatible Atoms:** `atom_permadeath` (progress loss conflicts with long-term seasonal progression).

## 8. Anti-Patterns
1. **Unreachable Max Level:** Requiring an unreasonable amount of daily playtime to complete the pass, leading to player burnout and frustration.
2. **Pay-to-Win Rewards:** Including items with significant gameplay advantages in the premium track, alienating free-to-play users.
3. **Empty Tiers:** Having too many levels with no rewards or extremely low-value rewards (e.g., small amounts of common currency), making progression feel unrewarding.
