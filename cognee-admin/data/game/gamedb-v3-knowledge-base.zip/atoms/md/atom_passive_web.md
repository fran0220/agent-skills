# Identity
- **Atom ID**: atom_passive_web
- **English Name**: Passive Skill Web
- **Chinese Name**: 被动技能网
- **Category**: E (Progression/RPG Systems)
- **Definition**: A vast, interconnected network of passive skill nodes where players allocate points earned through leveling or quests to customize their character's stats and abilities, often featuring distinct starting locations based on character class and pathing constraints.

# Core Verb & State Machine
- **Core Verb**: Allocate (Node)
- **State Diagram**:
  [Unallocated] --(Spend Point)--> [Allocated]
  [Allocated] --(Refund Point)--> [Unallocated]
- **States**:
  - `Unallocated`: The node is not active, providing no benefits.
  - `Allocated`: The node is active, providing its stated benefits.
  - `Reachable`: The node is adjacent to an allocated node and can be allocated.
  - `Unreachable`: The node is not adjacent to any allocated node.
- **Transitions**:
  - `Unallocated` -> `Allocated`: Triggered by spending a passive skill point when the node is `Reachable`.
  - `Allocated` -> `Unallocated`: Triggered by spending a refund point or using a respec feature, provided it doesn't break the connection to other allocated nodes.

# MDA Analysis
- **Mechanics**: Players earn passive skill points upon leveling up or completing specific quests. These points are spent on a massive, shared web of nodes. Nodes grant incremental stat boosts (e.g., +10 Strength) or game-changing keystones (e.g., convert all evasion to armor). Pathing requires allocating adjacent nodes.
- **Dynamics**: Players plan complex routes through the web to optimize their build, balancing travel nodes (minor stat boosts) with notable/keystone nodes (major power spikes). The shared web allows for hybrid builds, but pathing inefficiency penalizes overly divergent choices.
- **Aesthetics**: Players experience a sense of profound customization, discovery, and long-term planning. The sheer size of the web can be initially overwhelming but ultimately rewarding as players master its intricacies and realize their unique character vision.

# Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value (PoE 3.23) | Unit |
|---|---|---|---|---|
| `total_points_available` | u32 | 50 - 150 | 123 | points |
| `minor_node_stat_value` | f32 | 5.0 - 20.0 | 10.0 | stat points |
| `notable_node_multiplier` | f32 | 2.0 - 5.0 | 3.0 | multiplier |
| `refund_point_cost` | u32 | 1 - 5 | 1 | currency item |
| `max_distance_from_start` | u32 | 10 - 50 | 35 | nodes |

# Benchmark Data
- **Path of Exile (Version 3.23)**:
  - `total_points_available`: 123
  - `minor_node_stat_value`: 10.0 (e.g., +10 to Intelligence)
  - `notable_node_multiplier`: 3.0 (approximate value relative to minor nodes)
- **Wolcen: Lords of Mayhem (Version 1.1.7)**:
  - `total_points_available`: 90
  - `minor_node_stat_value`: 5.0
  - `notable_node_multiplier`: 2.5

# Common Variants
1. **Rotating Rings (Wolcen)**: The web is divided into concentric rings that can be rotated independently, altering the connections between different sections of the web.
2. **Constellations (Grim Dawn)**: The web is divided into distinct constellations. Completing a constellation grants a powerful ability and affinity points, which unlock higher-tier constellations.
3. **Class-Restricted Webs (Salt and Sanctuary)**: While visually a web, certain sections are heavily gated or practically inaccessible to specific starting classes due to extreme pathing distances.
4. **Board Expansion (Hero Siege)**: Players unlock new, smaller webs (boards) and attach them to their existing web, customizing the overall topology.

# Compatibility Notes
- **Commonly Pairs With**: `atom_xp_level` (Leveling up grants points), `atom_character_class` (Determines starting position on the web), `atom_stat_conversion` (Keystones often convert stats).
- **Conflicts**: `atom_linear_skill_tree` (Fundamentally opposed structures; games usually pick one or the other), `atom_auto_leveling` (Removes the player agency central to the web).

# Anti-Patterns
1. **Illusion of Choice**: The web is massive, but there is only one mathematically viable path for a given build, rendering the rest of the web useless trap options.
2. **Excessive Travel Tax**: Players must spend too many points on uninteresting minor nodes just to reach the nodes relevant to their build, leading to a boring progression experience.
3. **Respec Impossibility**: Making it too difficult or expensive to refund points, punishing players severely for experimentation or early mistakes in a complex system.
