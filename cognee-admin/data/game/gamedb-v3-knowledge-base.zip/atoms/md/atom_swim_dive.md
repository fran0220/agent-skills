# Gameplay Atom: Swim / Dive

## 1. Identity
**Atom ID:** `atom_swim_dive`
**English Name:** Swim / Dive
**Chinese Name:** 游泳/潜水
**Category:** A
**Definition:** The Swim / Dive atom defines the mechanics and physics of a player character moving through a fluid volume (typically water). It encompasses surface swimming, underwater diving, buoyancy, oxygen management, and fluid resistance, providing a distinct movement paradigm compared to terrestrial locomotion.

## 2. Core Verb & State Machine
**Core Verb:** Navigate fluid environments (Swim, Dive, Surface).

**State Diagram:**
```text
[Idle_Land] --> (Enter Water) --> [Surface_Swim]
[Surface_Swim] --> (Dive Input) --> [Underwater_Swim]
[Underwater_Swim] --> (Ascend Input / Buoyancy) --> [Surface_Swim]
[Surface_Swim] --> (Exit Water) --> [Idle_Land]
[Underwater_Swim] --> (Out of Oxygen) --> [Drowning]
```

**States and Transitions:**
- **Surface_Swim:** The character is at the water's surface. Transitions to `Underwater_Swim` upon diving, or `Idle_Land` upon exiting the water.
- **Underwater_Swim:** The character is fully submerged. Transitions to `Surface_Swim` upon reaching the surface, or `Drowning` if oxygen depletes.
- **Drowning:** The character takes damage over time due to lack of oxygen. Transitions to `Underwater_Swim` if oxygen is replenished, or `Death` if health reaches zero.

## 3. MDA Analysis
**Mechanics:** The system applies fluid drag, alters gravity (buoyancy), and introduces a Z-axis movement component. It often includes an oxygen depletion timer when submerged.
**Dynamics:** Players must balance exploration depth with their remaining oxygen. Movement feels heavier and slower, encouraging deliberate pathfinding and resource management.
**Aesthetics:** Creates a sense of weightlessness, isolation, and tension (due to oxygen limits). The visual and audio shifts (muffled sounds, blue tint) enhance immersion.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Subnautica v1.0) | Unit |
|---|---|---|---|---|
| `base_swim_speed` | f32 | 2.0 - 8.0 | 4.5 | m/s |
| `fluid_drag` | f32 | 0.5 - 5.0 | 2.0 | multiplier |
| `buoyancy_force` | f32 | -9.8 - 9.8 | 0.5 | m/s^2 |
| `max_oxygen` | f32 | 30.0 - 300.0 | 45.0 | seconds |
| `oxygen_depletion_rate` | f32 | 0.5 - 2.0 | 1.0 | units/sec |
| `dive_speed` | f32 | 2.0 - 10.0 | 5.0 | m/s |

## 5. Benchmark Data
- **Subnautica (v1.0):** `base_swim_speed` = 4.5 m/s, `max_oxygen` = 45.0 seconds (base tank), `fluid_drag` = 2.0. The game heavily emphasizes oxygen management and vertical exploration.
- **Super Mario Odyssey (v1.3.0):** `base_swim_speed` = 6.0 m/s, `max_oxygen` = 100.0 seconds (represented by a segmented meter), `buoyancy_force` = 1.2 m/s^2. Movement is snappy, and oxygen is easily replenished by collecting coins or finding bubbles.

## 6. Common Variants
1. **Infinite Breath:** The character can stay underwater indefinitely (e.g., games where the protagonist is aquatic or magical).
2. **Currents and Flows:** Water volumes have directional forces that push the player, requiring them to swim against or ride the current.
3. **Stamina-Based Swimming:** Instead of oxygen, swimming depletes stamina. Running out of stamina on the surface causes drowning (e.g., The Legend of Zelda: Breath of the Wild).
4. **Vehicle-Assisted Diving:** Using submarines or underwater scooters to increase speed and oxygen capacity.

## 7. Compatibility Notes
- **Commonly Pairs With:** `atom_jump` (jumping out of water), `atom_dash` (underwater dash/boost), `atom_collectible` (underwater items).
- **Conflicts:** `atom_fall_damage` (water usually negates fall damage), `atom_fire_magic` (fire-based abilities are often disabled underwater).

## 8. Anti-Patterns
1. **Sluggish Controls:** Making underwater movement too slow or unresponsive, leading to player frustration.
2. **Unclear Surface Boundaries:** Failing to clearly indicate where the water surface is, making it difficult for players to catch their breath.
3. **Punishing Oxygen Depletion:** Depleting oxygen too quickly without providing enough replenishment sources, turning exploration into a tedious chore.
