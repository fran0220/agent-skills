# Gameplay Atom: Swipe Gesture

## 1. Identity
- **Atom ID:** atom_swipe_gesture
- **English Name:** Swipe Gesture
- **Chinese Name:** 滑动手势
- **Category:** G (Gestures & Input)
- **Definition:** A continuous directional input mechanic where the player touches the screen, moves their finger across a distance, and releases it within a specific time frame to trigger an action, commonly used for slicing, dodging, or directional movement.

## 2. Core Verb & State Machine
- **Core Verb:** Swipe (Touch, Drag, Release)
- **State Diagram:**
  [Idle] --(Touch Down)--> [Tracking]
  [Tracking] --(Move > Threshold)--> [Swiping]
  [Swiping] --(Release & Time < Max Time)--> [Swipe Registered]
  [Tracking/Swiping] --(Release & Time > Max Time)--> [Idle/Canceled]
- **States:**
  - `Idle`: Waiting for input.
  - `Tracking`: Finger is on the screen, tracking position and time.
  - `Swiping`: Finger has moved beyond the minimum distance threshold.
  - `Swipe Registered`: Valid swipe completed and action triggered.
  - `Canceled`: Swipe failed due to timeout or moving out of bounds.
- **Transitions:**
  - `Idle` -> `Tracking`: Triggered by `Touch Down`.
  - `Tracking` -> `Swiping`: Triggered by `Distance > Min Distance`.
  - `Swiping` -> `Swipe Registered`: Triggered by `Touch Up` AND `Duration < Max Duration`.
  - `Tracking` / `Swiping` -> `Canceled`: Triggered by `Touch Up` AND `Duration >= Max Duration`.

## 3. MDA Analysis
- **Mechanics:** The system records the start coordinates, end coordinates, and the time elapsed between touch down and touch up. It calculates the vector, distance, and velocity of the swipe to determine the direction and validity of the input.
- **Dynamics:** Players learn to optimize their swipe speed and length to perform actions quickly. In fast-paced games, this leads to frantic, continuous swiping or precise, timed flicks depending on the game's constraints.
- **Aesthetics:** Provides a tactile, satisfying feeling of direct physical interaction with the game world (e.g., the visceral satisfaction of slicing fruit or the kinetic rush of dodging obstacles).

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Game) | Unit |
|---|---|---|---|---|
| `min_distance` | f32 | 10.0 - 50.0 | 20.0 (Temple Run v1.0) | pixels/points |
| `max_duration` | f32 | 0.1 - 0.5 | 0.3 (Fruit Ninja v1.0) | seconds |
| `velocity_threshold` | f32 | 100.0 - 1000.0 | 300.0 (Fruit Ninja v1.0) | pixels/second |
| `angle_tolerance` | f32 | 15.0 - 45.0 | 30.0 (Temple Run v1.0) | degrees |

## 5. Benchmark Data
- **Fruit Ninja (v1.0):**
  - `min_distance`: 15.0 pixels
  - `max_duration`: 0.5 seconds
  - `velocity_threshold`: 300.0 pixels/second
  - *Note:* Focuses on high velocity and continuous tracking for slicing mechanics.
- **Temple Run (v1.0):**
  - `min_distance`: 20.0 pixels
  - `max_duration`: 0.3 seconds
  - `angle_tolerance`: 30.0 degrees
  - *Note:* Focuses on quick, discrete directional flicks (Up, Down, Left, Right) with strict angle snapping.

## 6. Common Variants
1. **Continuous Swipe (Slicing):** The swipe leaves a trail that interacts with objects continuously (e.g., Fruit Ninja).
2. **Discrete Directional Swipe (Flick):** The swipe is snapped to the nearest cardinal direction to trigger a specific move (e.g., Temple Run).
3. **Hold and Swipe (Slingshot):** The player holds to aim and swipes back to build tension before releasing (e.g., Angry Birds).
4. **Multi-finger Swipe:** Requires two or more fingers swiping simultaneously for a different action.

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_jump`, `atom_dash`, `atom_slash`, `atom_lane_change`. Swipes are excellent triggers for these movement and attack atoms.
- **Incompatible Atoms:** `atom_virtual_joystick_movement`. Using both a virtual joystick and full-screen swipe gestures simultaneously often leads to input conflicts and poor UX.

## 8. Anti-Patterns
1. **Too Strict Angle Tolerance:** Requiring perfectly straight swipes frustrates players, especially in fast-paced situations.
2. **Ignoring Velocity:** Only checking distance and not velocity can cause slow, accidental drags to be registered as intentional swipes.
3. **Lack of Visual Feedback:** Failing to provide a visual trail or immediate character response makes the swipe feel unresponsive and disconnected.
