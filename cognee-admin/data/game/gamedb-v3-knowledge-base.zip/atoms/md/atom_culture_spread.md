# Culture / Religion Spread (文化/宗教传播)

## 1. Identity
**Atom ID**: atom_culture_spread
**English Name**: Culture / Religion Spread
**Chinese Name**: 文化/宗教传播
**Category**: G/H (Macro-Strategy / Simulation)

The "Culture / Religion Spread" gameplay atom represents the dynamic process by which a set of beliefs, values, or cultural practices expands its influence across a geographic or demographic space. This mechanic often involves competing with other cultures or religions for dominance over populations, cities, or territories. It serves as a foundational system in many macro-strategy and simulation games, providing players with non-military avenues for expansion, control, and victory. By managing resources such as faith, culture points, or specialized agents, players can project soft power, alter the allegiances of foreign populations, and establish ideological hegemony.

## 2. Core Verb & State Machine
The primary player verb in this atom is **Spread** or **Convert**. Players actively or passively direct the flow of cultural or religious influence to alter the state of target entities.

**State Diagram**:
[Unconverted] -> (Exposure) -> [Converting] -> (Threshold Reached) -> [Converted] -> (Decay/Competition) -> [Converting/Reverting]

The entities within this system typically exist in one of three primary states. The `Unconverted` state indicates that a population or territory has no presence or awareness of the specific culture or religion. As influence begins to reach the entity, it transitions into the `Converting` state, where the culture or religion is actively gaining ground but has not yet achieved dominance. Once the accumulated influence surpasses a specific requirement, the entity enters the `Converted` state, signifying that the culture or religion is now the dominant force.

Transitions between these states are driven by specific triggers. The `Exposure` transition is initiated by proximity to already converted nodes, the establishment of trade routes, or the deliberate actions of missionary units. The `Threshold Reached` transition occurs when the accumulated influence exceeds a predefined value, such as 50% of the population or a specific numerical threshold. Finally, the `Decay/Competition` transition can cause a converted entity to revert or begin converting to a different belief system, triggered by the presence of competing cultures, lack of maintenance, or active suppression by rival factions.

## 3. MDA Analysis
**Mechanics**: The underlying mechanics of culture and religion spread involve calculating the flow and accumulation of influence over time and space. The system evaluates factors such as the distance from centers of power (e.g., Holy Cities or Cultural Capitals), the presence of trade connections, baseline religious pressure, and the active efforts of specialized units like missionaries or great artists. Influence is typically treated as a continuous variable that accumulates in target nodes, subject to resistance from local factors, inherent defense values, or competing influences from rival players.

**Dynamics**: The interaction of these mechanics creates complex dynamics where players must constantly balance active expansion with passive growth. Players might choose to invest heavily in producing missionary units for rapid, targeted conversions, or focus on building religious structures that generate slow but steady passive pressure. Borders between competing cultures become dynamic zones of ideological conflict, constantly shifting based on the relative pressure exerted by each side. Emergent behaviors often include "cultural flipping," where a city peacefully defects to another empire due to overwhelming cultural pressure, or the outbreak of religious wars triggered by aggressive conversion efforts in rival territory.

**Aesthetics**: From an aesthetic perspective, this atom evokes a profound sense of ideological conquest and cultural dominance. Players experience the satisfaction of seeing their chosen beliefs take root in foreign lands, often visually represented by shifting border colors, changing city icons, or dynamic map overlays. The slow, inexorable spread of a player's color across the map provides a compelling feedback loop, rewarding long-term planning and strategic placement of cultural hubs. It taps into the fantasy of shaping the world not just through force of arms, but through the power of ideas and cultural superiority.

## 4. Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value (Game) | Unit |
|---|---|---|---|---|
| Base Spread Rate | Float | 0.1 - 5.0 | 1.0 (Civilization VI v1.0.12.9) | Influence/Turn |
| Distance Penalty | Float | 0.0 - 1.0 | 0.5 (Civilization VI v1.0.12.9) | Multiplier/Tile |
| Conversion Threshold | Float | 0.0 - 100.0 | 50.0 (Crusader Kings III v1.8.1) | Percentage |
| Missionary Strength | Float | 10.0 - 1000.0 | 200.0 (Civilization VI v1.0.12.9) | Influence |
| Resistance Factor | Float | 0.0 - 1.0 | 0.2 (Europa Universalis IV v1.34) | Multiplier |

## 5. Benchmark Data
In **Civilization VI (v1.0.12.9)**, the spread of religion is a highly structured system combining passive pressure and active agents. Religious pressure spreads passively to cities within a 10-tile radius. A designated Holy City exerts a base pressure of +8, while any standard city following a religion exerts +1 pressure. Active conversion is handled by units like Missionaries, which apply a sudden burst of 200 religious strength to a target city, directly altering its demographic makeup.

**Crusader Kings III (v1.8.1)** approaches this concept through the lens of medieval rulership, treating cultural acceptance and religious conversion as distinct but interconnected processes. Converting a county's faith is a deliberate action taken by a councilor, requiring a base time of 5 years. This duration is heavily modified by the ruler's learning skill, the fervor of the religion, and the local development level, making conversion a significant time investment rather than an instant action.

**Europa Universalis IV (v1.34)** models religious conversion as a state-sponsored endeavor requiring financial investment. Missionary maintenance costs money from the treasury, and the speed of conversion is determined by the missionary's strength weighed against local unrest and province development. The base conversion speed is set at 2% per month, meaning a standard conversion takes several years and requires sustained economic support.

## 6. Common Variants
The implementation of culture and religion spread varies significantly across different strategy titles, leading to several common variants. The **Passive Radiance** variant, seen in games like Civilization IV, relies on influence automatically radiating from centers of power, gradually decaying over distance and pushing borders outward without direct unit micromanagement. 

Conversely, the **Agent-Based** variant, prominent in the early religious game of Civilization VI, requires players to actively produce and maneuver specific units (like missionaries or merchants) to target locations to spread their influence. 

The **Network-Based** variant restricts the flow of influence to specific paths, such as trade routes, rivers, or road networks, rather than a simple radial spread. This is often utilized in the Total War series, where cultural influence travels along established lines of communication. 

Finally, the **Demographic Conversion** variant, characteristic of Victoria 3, models spread at the population level. Instead of flipping an entire city or province at once, individual population units (POPs) convert one by one based on local conditions, literacy rates, and state policies, creating a highly granular and realistic simulation of cultural shift.

## 7. Compatibility Notes
The Culture / Religion Spread atom exhibits strong synergy with several other gameplay systems. It is highly compatible with `atom_territory_control`, as cultural borders often dictate the physical boundaries of an empire. It also pairs naturally with `atom_trade_routes`, where trade networks serve as conduits for cultural exchange, accelerating the spread of influence. Furthermore, it integrates well with `atom_diplomacy`, as shared religions or cultures typically provide significant bonuses to diplomatic relations and alliance formation.

However, this atom is generally incompatible with `atom_pure_action_combat`. The slow, methodical nature of cultural spread is typically too sluggish for fast-paced action games, where immediate feedback and rapid state changes are required. Additionally, conflicts can arise when pairing this atom with strict `atom_static_borders`. If a game relies on rigid, unchanging territorial lines, a dynamic cultural spread system that is supposed to alter ownership will fundamentally clash with the core design.

## 8. Anti-Patterns
When implementing this atom, designers must be wary of several common pitfalls. The most prevalent is **Snowballing Inevitability**. If the system is designed such that a religion or culture gaining a slight early lead becomes mathematically impossible for others to catch up to, it removes all gameplay tension and renders the mechanic a foregone conclusion.

Another significant issue is **Invisible Mechanics**. If the underlying factors influencing the spread of culture are hidden from the player, the system can feel arbitrary and frustrating. Players need clear feedback on why a city converted or why their influence is failing to take hold, otherwise, they cannot make informed strategic decisions.

Finally, designers should avoid **Tedious Micromanagement**. Forcing the player to manually build, move, and activate hundreds of individual missionary units in the late game, rather than transitioning to or relying on passive spread systems, can turn a strategic mechanic into an exhausting chore that detracts from the overall experience.
