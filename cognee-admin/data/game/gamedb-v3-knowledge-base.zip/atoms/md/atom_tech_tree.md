# Tech Tree (科技树)

## 1. Identity
- **Atom ID:** atom_tech_tree
- **English Name:** Tech Tree
- **Chinese Name:** 科技树
- **Category:** E
- **Definition:** A hierarchical visual representation of possible upgrades or unlocks that a player can research or acquire over the course of a game, typically requiring resources, time, and prerequisite technologies.

## 2. Core Verb & State Machine
- **Core Verb:** Research / Unlock
- **State Diagram:**
  [Locked] --(Prerequisites Met)--> [Available] --(Start Research)--> [Researching] --(Complete)--> [Unlocked]
- **States:**
  - `Locked`: The technology cannot be researched yet because prerequisites are not met.
  - `Available`: Prerequisites are met, and the player can choose to start researching it.
  - `Researching`: The technology is currently being researched, consuming time or resources.
  - `Unlocked`: The technology is fully researched, granting its benefits to the player.
- **Transitions:**
  - `Locked` -> `Available`: Triggered when all parent technologies are `Unlocked`.
  - `Available` -> `Researching`: Triggered when the player allocates resources/points to it.
  - `Researching` -> `Unlocked`: Triggered when the required research points/time are fully accumulated.

## 3. MDA Analysis
- **Mechanics:** Players generate research points (or equivalent resources) and allocate them to specific nodes in a directed acyclic graph (DAG). Nodes have costs and prerequisites.
- **Dynamics:** Players must plan their progression path, balancing short-term needs (e.g., military tech for survival) with long-term goals (e.g., economic tech for late-game dominance). It creates a sense of pacing and strategic branching.
- **Aesthetics:** Anticipation, Discovery, Expression (through chosen playstyle), and Progression. Players feel a sense of growth and empowerment as they unlock new capabilities.

## 4. Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value (Game) | Unit |
|---|---|---|---|---|
| `base_cost` | u32 | 10 - 10000 | 50 (Civilization VI v1.0) | Science Points |
| `cost_multiplier_per_tier` | f32 | 1.2 - 3.0 | 1.5 (Factorio v1.1) | Multiplier |
| `research_speed` | f32 | 0.1 - 100.0 | 1.0 (Stellaris v3.8) | Points/Tick |
| `max_concurrent_research` | u32 | 1 - 5 | 1 (Civilization VI v1.0) | Count |

## 5. Benchmark Data
- **Civilization VI (v1.0.12.9):**
  - Early game tech (e.g., Pottery) costs 25 Science.
  - Mid game tech (e.g., Education) costs 390 Science.
  - Late game tech (e.g., Rocketry) costs 1850 Science.
- **Factorio (v1.1.104):**
  - Automation (Tier 1) requires 10 Automation Science Packs.
  - Advanced Electronics (Tier 3) requires 200 Automation and 200 Logistic Science Packs.
- **Stellaris (v3.8.4):**
  - Tier 1 tech base cost: 2000 Research.
  - Tier 5 tech base cost: 20000 Research.

## 6. Common Variants
1. **Blind/Random Tech Tree:** Players do not see the entire tree; options are drawn randomly from a deck of available techs (e.g., Stellaris).
2. **Web/Radial Tech Tree:** Non-linear progression radiating from a center point, allowing extreme specialization (e.g., Civilization: Beyond Earth).
3. **Mutually Exclusive Branches:** Choosing one technology permanently locks out another branch, forcing hard choices (e.g., StarCraft II campaign).
4. **Era-Gated Tech Tree:** Technologies are grouped into eras; players must unlock a certain number of techs in one era to progress to the next (e.g., Humankind).

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_resource_generation` (generates the points needed), `atom_building_construction` (unlocked by tech), `atom_unit_training` (unlocked by tech).
- **Incompatible Atoms:** Purely skill-based action games without progression systems (e.g., `atom_twitch_combat` without meta-progression).

## 8. Anti-Patterns
1. **Illusion of Choice:** A tech tree where one path is mathematically vastly superior to all others, making the "choices" meaningless.
2. **Snowballing:** Early tech advantages compound too quickly, making it impossible for trailing players to catch up.
3. **Information Overload:** Presenting a massive, complex tree to a new player immediately without any guidance or fog of war, causing analysis paralysis.
