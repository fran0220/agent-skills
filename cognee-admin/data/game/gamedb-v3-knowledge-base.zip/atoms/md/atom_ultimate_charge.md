# Identity
- **Atom ID**: atom_ultimate_charge
- **English Name**: Ultimate Charge
- **Chinese Name**: 大招充能
- **Category**: A
- **Definition**: A resource accumulation system where players perform specific actions (like dealing damage, healing, or waiting over time) to fill a gauge that, when full, allows the execution of a highly impactful "ultimate" ability.

# Core Verb & State Machine
- **Core Verb**: Charge (Accumulate resource)
- **State Diagram**:
  [Empty] --(Passive/Active Gain)--> [Charging]
  [Charging] --(Reach Max)--> [Ready]
  [Ready] --(Activate)--> [Active/Channeling]
  [Active/Channeling] --(End/Interrupt)--> [Empty]
- **States**: Empty, Charging, Ready, Active
- **Transitions**:
  - Empty -> Charging: Triggered by time passing or player actions (damage, healing).
  - Charging -> Ready: Triggered when accumulated charge >= max charge.
  - Ready -> Active: Triggered by player input (pressing the ultimate button).
  - Active -> Empty: Triggered when the ultimate duration ends or is interrupted.

# MDA Analysis
- **Mechanics**: The system tracks a numeric value (charge) that increases based on time (passive) and player actions (active). Once it reaches a threshold, a specific ability becomes available.
- **Dynamics**: Players are incentivized to engage in combat or perform role-specific actions to build their ultimate faster. It creates pacing in matches, leading to "ultimate economy" management where teams coordinate ultimate usage.
- **Aesthetics**: Anticipation as the meter fills, excitement and power fantasy when unleashing the ultimate, and strategic satisfaction when coordinating with teammates.

# Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value (Overwatch 2) | Unit |
|---|---|---|---|---|
| max_charge | f32 | 1000 - 3000 | 2100 | points |
| passive_charge_rate | f32 | 1 - 10 | 5 | points/sec |
| damage_conversion_rate | f32 | 0.5 - 1.5 | 1.0 | points/damage |
| healing_conversion_rate | f32 | 0.5 - 1.5 | 1.0 | points/healing |
| charge_loss_on_death | f32 | 0 - 100 | 0 | % |

# Benchmark Data
- **Overwatch 2 (v2.0)**:
  - Tracer: max_charge = 2100, passive_charge_rate = 5, damage_conversion_rate = 1.0
  - Lucio: max_charge = 2420, passive_charge_rate = 5, healing_conversion_rate = 1.0
- **Valorant (v7.0)**:
  - Jett: max_charge = 7, passive_charge_rate = 0, kill_conversion = 1, orb_conversion = 1

# Common Variants
1. **Kill-based Charge**: Only kills or specific objectives grant charge (e.g., Valorant).
2. **Time-only Charge**: The ultimate charges strictly over time, regardless of player performance.
3. **Shared Team Meter**: The entire team contributes to a single ultimate meter (e.g., some fighting games).
4. **Multi-tier Ultimate**: The meter can be spent at different thresholds for varying levels of power.

# Compatibility Notes
- **Compatible Atoms**: atom_damage_deal, atom_healing_cast, atom_cooldown_timer
- **Incompatible Atoms**: atom_permadeath
- **Conflicts**: Systems that constantly reset player state might conflict with long-term charge accumulation.

# Anti-Patterns
1. **Snowball Effect**: Making the ultimate too easy to get for the winning team, leading to unrecoverable advantages.
2. **Hidden Progress**: Not clearly displaying the charge progress to the player or enemies, leading to unpredictable spikes in power.
3. **Over-reliance on Passive**: Making passive charge too high, discouraging active engagement.
