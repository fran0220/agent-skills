# Gameplay Atom: Mastery / Proficiency

## 1. Identity
- **Atom ID:** `atom_mastery_rank`
- **English Name:** Mastery / Proficiency
- **Chinese Name:** 熟练度/精通
- **Category:** E (Progression)
- **Definition:** A progression system where a player's repeated use of a specific character, weapon, or skill increases their proficiency level with that specific entity, often unlocking new abilities, cosmetic rewards, or statistical bonuses.

## 2. Core Verb & State Machine
- **Core Verb:** Practice / Use
- **State Diagram:**
  [Unranked] --(Gain XP)--> [Leveling] --(Reach Max XP)--> [Max Rank] --(Prestige/Reset)--> [Prestige Leveling]
- **States:**
  - `Unranked`: The player has not yet used the entity or gained any mastery experience.
  - `Leveling`: The player is actively gaining mastery experience and progressing through intermediate ranks.
  - `Max Rank`: The player has reached the maximum possible mastery level for the entity.
  - `Prestige Leveling`: (Optional) The player has reset their rank to gain a special badge or bonus and is leveling again.
- **Transitions:**
  - `Unranked` -> `Leveling`: Triggered by gaining the first mastery XP point.
  - `Leveling` -> `Leveling`: Triggered by gaining XP but not enough to reach the max rank.
  - `Leveling` -> `Max Rank`: Triggered by reaching the XP threshold for the final rank.
  - `Max Rank` -> `Prestige Leveling`: Triggered by player opting to reset their rank for prestige rewards.

## 3. MDA Analysis
- **Mechanics:** The system tracks usage metrics (e.g., damage dealt, matches played, successful actions) for a specific entity and converts them into mastery experience points (XP). Accumulating XP increases the mastery rank based on a predefined curve.
- **Dynamics:** Players are incentivized to specialize and repeatedly use their favorite entities. It creates a secondary progression loop parallel to the main account level, encouraging diverse playstyles if rewards are tied to mastering multiple entities.
- **Aesthetics:** Provides a sense of accomplishment, dedication, and personal identity. Players feel proud to show off their high mastery ranks as a badge of honor and expertise.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Game) | Unit |
|---|---|---|---|---|
| `base_xp_requirement` | `u32` | 100 - 1000 | 500 (Warframe v32) | XP |
| `xp_growth_factor` | `f32` | 1.1 - 2.0 | 1.5 (League of Legends v13) | Multiplier |
| `max_rank` | `u32` | 5 - 30 | 30 (Warframe v32) | Rank |
| `xp_per_action` | `u32` | 1 - 100 | 10 (League of Legends v13) | XP |
| `prestige_multiplier` | `f32` | 1.0 - 3.0 | 1.2 (Call of Duty) | Multiplier |

## 5. Benchmark Data
- **League of Legends (v13.20):**
  - `max_rank`: 7
  - `base_xp_requirement`: 1800 (for Rank 2)
  - `xp_per_action`: ~100-1000 per match based on performance grade (S, A, B, etc.)
- **Warframe (v32.0):**
  - `max_rank`: 30 (for weapons/Warframes)
  - `base_xp_requirement`: 1000
  - `xp_growth_factor`: Quadratic curve (Rank^2 * 1000)

## 6. Common Variants
1. **Global Mastery:** Accumulating mastery across all entities contributes to a global account mastery rank (e.g., Warframe's Mastery Rank).
2. **Skill-based Mastery:** Mastery XP is only awarded for successful or skillful use of the entity, rather than just time played.
3. **Decaying Mastery:** Mastery rank or points decay over time if the entity is not used, requiring maintenance.
4. **Branching Mastery:** Reaching certain mastery levels allows the player to choose between mutually exclusive perks or upgrades.

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_xp_level`, `atom_achievement`, `atom_cosmetic_reward`.
- **Incompatible Atoms:** `atom_permadeath` (Losing all progress on death conflicts with long-term mastery accumulation, unless mastery is inherited).

## 8. Anti-Patterns
1. **Grind over Skill:** Making the mastery system purely a measure of time spent rather than actual proficiency or skill, leading to AFK farming.
2. **Overpowered Mastery Rewards:** Tying significant statistical advantages to high mastery ranks in competitive multiplayer games, creating an unfair advantage for veterans over new players.
3. **Opaque Progression:** Hiding the exact requirements or XP gains for mastery, leaving players confused about how to progress efficiently.
