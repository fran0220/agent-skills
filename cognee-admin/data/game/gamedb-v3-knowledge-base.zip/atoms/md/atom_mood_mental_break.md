# Identity
- **Atom ID**: atom_mood_mental_break
- **English Name**: Mood / Mental Break
- **Chinese Name**: 心情/精神崩溃
- **Category**: H (Human/Character Mechanics)
- **Definition**: A system that tracks a character's psychological well-being over time, triggering negative behavioral states (mental breaks) when their mood falls below specific thresholds due to accumulated stress or negative events.

# Core Verb & State Machine
- **Core Verb**: Manage (stress/mood)
- **State Diagram**:
  [Content] -> [Stressed] -> [Minor Break Risk] -> [Major Break Risk] -> [Extreme Break Risk] -> [Mental Break] -> [Catharsis] -> [Content]
- **States**:
  - Content: Mood is high, character behaves normally.
  - Stressed: Mood is dropping, minor debuffs.
  - Minor Break Risk: Mood below first threshold, chance of minor break.
  - Major Break Risk: Mood below second threshold, chance of major break.
  - Extreme Break Risk: Mood below third threshold, chance of extreme break.
  - Mental Break: Character loses player control, performs negative actions (e.g., hiding, bingeing, attacking).
  - Catharsis: Post-break state with a massive mood buff to prevent immediate chain-breaking.
- **Transitions**:
  - Content -> Stressed: Mood drops below 80%.
  - Stressed -> Minor Break Risk: Mood drops below 35%.
  - Minor Break Risk -> Major Break Risk: Mood drops below 20%.
  - Major Break Risk -> Extreme Break Risk: Mood drops below 5%.
  - Any Risk -> Mental Break: RNG check fails while in a risk state.
  - Mental Break -> Catharsis: Break duration expires.
  - Catharsis -> Content: Catharsis buff expires.

# MDA Analysis
- **Mechanics**: The game tracks a continuous variable (mood) influenced by positive and negative thoughts (memories) with varying durations and magnitudes. When mood crosses thresholds, the game periodically rolls to trigger a mental break state, removing player control.
- **Dynamics**: Players must balance productivity with character needs. Neglecting needs leads to a downward spiral where one character's break causes negative thoughts in others, potentially cascading into colony failure.
- **Aesthetics**: Creates tension, empathy, and emergent storytelling. Players feel responsible for their characters' well-being and experience dramatic moments when characters snap under pressure.

# Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value (RimWorld 1.4) | Unit |
|---|---|---|---|---|
| `base_mood` | f32 | 0.0 - 100.0 | 50.0 | points |
| `minor_break_threshold` | f32 | 0.0 - 50.0 | 35.0 | points |
| `major_break_threshold` | f32 | 0.0 - 30.0 | 20.0 | points |
| `extreme_break_threshold` | f32 | 0.0 - 15.0 | 5.0 | points |
| `catharsis_buff` | f32 | 10.0 - 50.0 | 40.0 | points |
| `catharsis_duration` | f32 | 1.0 - 5.0 | 3.0 | days |
| `mtb_minor_break` | f32 | 0.5 - 5.0 | 3.0 | days |

# Benchmark Data
- **RimWorld (1.4)**:
  - `minor_break_threshold`: 35.0
  - `major_break_threshold`: 20.0
  - `extreme_break_threshold`: 5.0
  - `catharsis_buff`: 40.0
- **Oxygen Not Included (Base Game)**:
  - `stress_break_threshold`: 100.0 (Stress goes up instead of mood going down)
  - `stress_warning_threshold`: 60.0

# Common Variants
1. **Stress Accumulation**: Instead of a mood bar that goes down, a stress bar goes up (e.g., Darkest Dungeon, Oxygen Not Included).
2. **Sanity/Terror**: Thematic variant where low sanity causes hallucinations or permanent negative traits (e.g., Don't Starve, Amnesia).
3. **Morale**: Army or squad-level mood that affects combat effectiveness and retreat probability rather than individual mental breaks (e.g., Total War series).

# Compatibility Notes
- **Compatible Atoms**: `atom_needs_survival` (hunger/sleep directly affect mood), `atom_social_relationships` (friends dying causes massive mood drops), `atom_trait_system` (traits modify thresholds or break types).
- **Incompatible Atoms**: `atom_mindless_drone` (units without psychology shouldn't have mood).

# Anti-Patterns
1. **Death Spirals**: If a mental break causes a massive mood drop for everyone else, one minor issue can instantly end the game without player agency to recover.
2. **Unpredictable Breaks**: If breaks happen instantly when crossing a threshold without warning, players feel cheated.
3. **Irrelevant Mood**: If the penalties for low mood are too minor, players will optimally ignore the system entirely.
