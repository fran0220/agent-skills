# Gameplay Atom: Emote / Gesture

## 1. Identity
- **Atom ID:** `atom_emote_gesture`
- **English Name:** Emote / Gesture
- **Chinese Name:** 表情/手势
- **Category:** E/F (Social / Expressive)
- **Definition:** An Emote or Gesture is a non-verbal communication mechanic that allows players to trigger predefined animations, visual effects, or sounds to express emotions, convey information, or interact socially with other players or NPCs within the game world.

## 2. Core Verb & State Machine
- **Core Verb:** Express (Triggering an emote/gesture)

**State Diagram:**
```text
[Idle] --(Input Command)--> [Startup]
[Startup] --(Time Passes)--> [Active]
[Active] --(Animation Ends)--> [Recovery]
[Active] --(Player Moves/Cancels)--> [Interrupted]
[Recovery] --(Time Passes)--> [Idle]
[Interrupted] --(Immediate)--> [Idle]
```

**States and Transitions:**
- **Idle:** The default state where the player character is not performing any emote.
- **Startup:** The initial frames of the emote animation. Transition from Idle via player input.
- **Active:** The main loop or sequence of the emote. Transition from Startup automatically.
- **Recovery:** The ending frames returning the character to a neutral pose. Transition from Active when the animation finishes.
- **Interrupted:** A state triggered if the player moves, attacks, or takes damage during the emote. Transition from Active or Startup via movement/action input or external force.

## 3. MDA Analysis
- **Mechanics:** The system provides a menu, wheel, or hotkey binding for players to select and play specific animation files associated with their character. It handles animation blending, audio playback, and interruption logic (e.g., canceling the emote upon movement).
- **Dynamics:** Players use emotes to communicate without text or voice chat, leading to emergent social behaviors such as greeting, taunting, celebrating, or organizing impromptu synchronized dances. It can also be used tactically (e.g., third-person camera peeking in some games).
- **Aesthetics:** Fosters a sense of Fellowship and Expression. Players feel connected to others and can showcase their personality, achievements (via rare emotes), or current mood, enhancing immersion and social bonding.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Game) | Unit |
| --- | --- | --- | --- | --- |
| `startup_time` | f32 | 0.0 - 1.0 | 0.1 (Fortnite v28.00) | seconds |
| `duration` | f32 | 1.0 - ∞ | 5.0 (Dark Souls III v1.15) | seconds |
| `cooldown` | f32 | 0.0 - 10.0 | 1.0 (FFXIV v6.5) | seconds |
| `is_cancellable` | bool | true/false | true (Fortnite v28.00) | boolean |
| `cancel_delay` | f32 | 0.0 - 0.5 | 0.0 (Fortnite v28.00) | seconds |
| `looping` | bool | true/false | false (Dark Souls III v1.15) | boolean |

## 5. Benchmark Data
- **Fortnite (v28.00):**
  - `startup_time`: 0.1s
  - `duration`: Infinite (Looping dances)
  - `cooldown`: 0.0s
  - `is_cancellable`: true
  - `cancel_delay`: 0.0s
  - `looping`: true
- **Dark Souls III (v1.15):**
  - `startup_time`: 0.2s
  - `duration`: 3.0s - 5.0s (varies by gesture)
  - `cooldown`: 0.0s
  - `is_cancellable`: true (via rolling/moving)
  - `cancel_delay`: 0.1s
  - `looping`: false
- **Final Fantasy XIV (v6.5):**
  - `startup_time`: 0.0s
  - `duration`: Varies (some infinite, some fixed)
  - `cooldown`: 1.0s (to prevent chat/log spam)
  - `is_cancellable`: true
  - `cancel_delay`: 0.0s
  - `looping`: Varies

## 6. Common Variants
1. **Looping Dances:** Emotes that play continuously until the player moves or cancels them (e.g., Fortnite dances).
2. **Interactive/Multiplayer Emotes:** Emotes that require or allow another player to interact, such as high-fives or paired dances (e.g., Destiny 2, Portal 2).
3. **Toy/Prop Emotes:** Emotes that spawn temporary props or visual effects, sometimes interacting with the environment (e.g., FFXIV fireworks, Overwatch souvenirs).
4. **Tactical Gestures:** Gestures used specifically for non-verbal tactical communication in squad-based games (e.g., pointing, "stop" hand signals in SWAT 4 or PUBG).

## 7. Compatibility Notes
- **Commonly Pairs With:** `atom_social_wheel` (Emote Wheel), `atom_camera_3rd_person` (to see oneself), `atom_cosmetic_equip` (equipping different emotes).
- **Known Conflicts:** `atom_stealth_camo` (emotes usually break stealth), `atom_combat_lockon` (playing an emote during intense combat can lead to unfair deaths or animation lock issues).

## 8. Anti-Patterns
1. **Uncancellable Long Emotes:** Forcing players to watch a 10-second animation without the ability to cancel it, leading to frustration if attacked.
2. **Hitbox Exploitation:** Allowing emotes to drastically change the character's hitbox (e.g., lying flat on the ground) without penalty, which can be exploited in competitive shooters to dodge bullets.
3. **Spamming/Griefing:** Lacking a cooldown or audio-ducking mechanism, allowing players to spam loud emote sounds to annoy others.
