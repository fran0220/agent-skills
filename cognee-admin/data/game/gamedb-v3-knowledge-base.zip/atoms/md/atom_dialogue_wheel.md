# Gameplay Atom: Dialogue Wheel

## 1. Identity
**Atom ID:** atom_dialogue_wheel
**English Name:** Dialogue Wheel
**Chinese Name:** 对话轮盘
**Category:** E (Narrative & Interaction)
**Definition:** The Dialogue Wheel is a radial interface for selecting dialogue options, often categorizing responses by tone or morality. It maps specific directions on the wheel to consistent emotional or moral stances, allowing players to quickly intuit the nature of a response without reading the full text.

## 2. Core Verb & State Machine
**Core Verb:** Select Dialogue

**State Machine Diagram:**
```text
[Idle] --> (NPC initiates dialogue) --> [Listening]
[Listening] --> (NPC finishes speaking) --> [Wheel Active]
[Wheel Active] --> (Player selects option) --> [Speaking]
[Speaking] --> (Player finishes speaking) --> [Listening]
[Speaking] --> (Dialogue ends) --> [Resolution]
```

**States and Transitions:**
- **Idle:** The default state when no dialogue is occurring.
- **Listening:** The player character is listening to an NPC speak. Transitions to Wheel Active when the NPC finishes their line.
- **Wheel Active:** The dialogue wheel is displayed on screen, awaiting player input. Transitions to Speaking when an option is selected.
- **Speaking:** The player character delivers the selected line. Transitions back to Listening if the conversation continues, or to Resolution if it ends.
- **Resolution:** The dialogue sequence concludes, returning the game to the Idle state.

## 3. MDA Analysis
**Mechanics:** The system presents dialogue options in a radial menu, mapping specific directions to consistent tones (e.g., top right for paragon/friendly, bottom right for renegade/aggressive, middle right for neutral). The text displayed on the wheel is often a paraphrase of the actual spoken line.
**Dynamics:** Players learn the spatial mapping of tones and can make rapid, intuitive choices without reading every word. This maintains conversational flow and reduces the cognitive load of parsing long lists of text.
**Aesthetics:** The Dialogue Wheel fosters Expression, Narrative, and Immersion. It allows players to roleplay a specific personality consistently and keeps the pacing of conversations cinematic and engaging.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value | Unit |
|---|---|---|---|---|
| `options_count` | u32 | 2 - 8 | 6 (Mass Effect v1.0) | count |
| `time_limit` | f32 | 0.0 - 60.0 | 0.0 (Dragon Age: Inquisition v1.0) | seconds |
| `interrupt_window` | f32 | 0.0 - 5.0 | 2.0 (Mass Effect 2 v1.0) | seconds |

## 5. Benchmark Data
- **Mass Effect (v1.0):** `options_count` = 6, `time_limit` = 0.0, `interrupt_window` = 0.0. The original implementation that popularized the mechanic, featuring a strict 6-slot layout with consistent moral mapping.
- **Mass Effect 2 (v1.0):** `options_count` = 6, `time_limit` = 0.0, `interrupt_window` = 2.0. Introduced interrupt actions during the Listening state.
- **Dragon Age: Inquisition (v1.0):** `options_count` = 6, `time_limit` = 0.0, `interrupt_window` = 0.0. Added tone icons to the center of the wheel to further clarify the intent of the selected option.

## 6. Common Variants
- **Timed Wheel:** A timer counts down while the wheel is active. If no choice is made, a default action (often silence) is taken. (e.g., Alpha Protocol)
- **Icon-Only Wheel:** The wheel displays only icons representing emotions or actions, rather than text paraphrases.
- **Dynamic Slot Count:** The number of available slots changes based on the context, rather than maintaining a fixed 6 or 8 slot layout.
- **Interrupts:** Special prompts that appear during the Listening state, allowing the player to interrupt the NPC with a specific action.

## 7. Compatibility Notes
**Compatible Atoms:**
- `atom_morality_system`: The wheel naturally maps to moral alignments (e.g., Paragon/Renegade).
- `atom_relationship_meter`: Choices made on the wheel directly impact relationship scores with NPCs.
- `atom_cinematic_camera`: The wheel is often paired with dynamic camera angles during conversations.

**Incompatible Atoms:**
- `atom_text_parser`: Text parsers require typing specific commands, which conflicts with the quick, radial selection of the wheel.

## 8. Anti-Patterns
- **Misleading Paraphrases:** The text on the wheel implies a different tone or meaning than the actual spoken line, leading to player frustration.
- **Inconsistent Mapping:** Changing the spatial mapping of tones between conversations (e.g., putting the aggressive option on the top right instead of the bottom right).
- **Overcrowded Wheel:** Putting too many options on the wheel, making it difficult to select the desired option quickly and accurately.
