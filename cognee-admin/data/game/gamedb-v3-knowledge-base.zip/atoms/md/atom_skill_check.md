# Gameplay Atom: Skill Check / Dice Roll

## 1. Identity
- **Atom ID:** atom_skill_check
- **English Name:** Skill Check / Dice Roll
- **Chinese Name:** 技能检定
- **Category:** E
- **Definition:** A probabilistic evaluation mechanism where a character's inherent attributes or skills are tested against a target difficulty number, often involving a random element (like a dice roll) to determine success or failure.

## 2. Core Verb & State Machine
- **Core Verb:** Roll / Check
- **State Diagram:**
  [Idle] -> (Initiate Check) -> [Rolling] -> (Calculate Result) -> [Success/Failure] -> (Apply Consequences) -> [Idle]
- **States and Transitions:**
  - **Idle:** The default state before a check is triggered.
  - **Rolling:** The state where the random number generation occurs and modifiers are applied.
  - **Success:** The state reached if the final result meets or exceeds the target difficulty.
  - **Failure:** The state reached if the final result is below the target difficulty.
  - **Transitions:**
    - Idle -> Rolling: Triggered by player action or game event requiring a skill check.
    - Rolling -> Success: Triggered when `Roll + Modifiers >= Difficulty Class (DC)`.
    - Rolling -> Failure: Triggered when `Roll + Modifiers < Difficulty Class (DC)`.
    - Success/Failure -> Idle: Triggered after the narrative or mechanical consequences are applied.

## 3. MDA Analysis
- **Mechanics:** The system generates a random number (e.g., 1d20), adds the character's relevant skill modifier, and compares the total to a predetermined Difficulty Class (DC). If the total is greater than or equal to the DC, the check succeeds.
- **Dynamics:** Players will attempt to maximize their chances of success by seeking out buffs, using specific items, or choosing actions that align with their highest skills. This creates a risk-reward dynamic where players must weigh the probability of success against the consequences of failure.
- **Aesthetics:** The anticipation of the roll creates tension and excitement. A successful roll, especially against high odds, elicits feelings of triumph and competence. A failed roll can lead to frustration but also emergent narrative opportunities and dramatic tension.

## 4. Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value (Game/Version) | Unit |
|---|---|---|---|---|
| Base Roll | Integer | 1-20 (d20 system) | 1-20 (Baldur's Gate 3 v4.1) | Points |
| Skill Modifier | Integer | -5 to +15 | +3 (D&D 5e) | Points |
| Difficulty Class (DC) | Integer | 5-30 | 15 (Disco Elysium v1.0) | Points |
| Advantage/Disadvantage | Boolean | True/False | False (Baldur's Gate 3 v4.1) | N/A |
| Critical Success Threshold | Integer | 20 | 20 (D&D 5e) | Points |
| Critical Failure Threshold | Integer | 1 | 1 (D&D 5e) | Points |

## 5. Benchmark Data
- **Baldur's Gate 3 (v4.1):** Uses a d20 system. A typical mid-game DC is 15. A character might have a +3 proficiency bonus and a +4 ability modifier, totaling a +7 bonus. The player needs to roll an 8 or higher on a d20 to succeed.
- **Disco Elysium (v1.0):** Uses a 2d6 system. A typical challenging check might have a target of 12. The player rolls 2d6 and adds their skill level (e.g., +4). They need to roll an 8 or higher on the 2d6 to succeed. Double 6 is always a success, double 1 is always a failure.
- **Dungeons & Dragons 5th Edition (2014):** The foundational d20 system. DC ranges from 5 (Very Easy) to 30 (Nearly Impossible). A level 1 character typically has a +5 bonus in their primary skill.

## 6. Common Variants
- **Dice Pool System:** Instead of rolling one die and adding modifiers, the player rolls a number of dice equal to their skill level and counts the number of "successes" (dice that roll above a certain threshold). (e.g., Vampire: The Masquerade).
- **Percentile System (d100):** The player rolls percentile dice (1-100) and must roll *under* their skill level to succeed. (e.g., Call of Cthulhu).
- **Exploding Dice:** If a die rolls its maximum value, it is rolled again and the new value is added to the total. This allows for theoretically infinite results. (e.g., Savage Worlds).
- **Take 10 / Take 20:** A mechanic where, if not under pressure, a character can assume an average roll (10) or spend extra time to assume a maximum roll (20) instead of actually rolling.
- **Fail Forward:** A narrative variant where a failed roll doesn't stop progress but introduces a complication or cost, ensuring the story continues.

## 7. Compatibility Notes
- **Commonly Pairs With:** `atom_attribute_system` (provides the modifiers), `atom_status_effect` (buffs/debuffs affecting the roll), `atom_dialogue_tree` (skill checks unlocking dialogue options).
- **Known Conflicts:** Can conflict with purely deterministic systems (`atom_puzzle_logic`) where outcomes should be based solely on player deduction rather than randomness.

## 8. Anti-Patterns
- **Save Scumming Incentive:** Making the consequences of failure so severe (e.g., instant death or locking out major content) that players feel compelled to reload their save file until they succeed.
- **Meaningless Checks:** Requiring rolls for trivial actions where failure has no interesting consequences, slowing down gameplay without adding tension.
- **Opaque Probabilities:** Hiding the DC or the modifiers from the player, making it impossible for them to make informed decisions about whether to attempt the check.
