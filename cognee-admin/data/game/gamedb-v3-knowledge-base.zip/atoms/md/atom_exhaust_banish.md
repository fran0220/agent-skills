# Gameplay Atom: Exhaust / Banish Card

## 1. Identity
- **Atom ID:** `atom_exhaust_banish`
- **English Name:** Exhaust / Banish Card
- **Chinese Name:** 消耗/放逐卡牌
- **Category:** C (Card Game Mechanics)
- **Definition:** Exhaust or Banish refers to the mechanic where a card is permanently removed from the player's deck, hand, or discard pile for the remainder of the current combat or encounter after being played, discarded, or triggered. This prevents the card from being drawn or used again until the encounter resets, effectively thinning the deck and managing the power level of high-impact cards.

## 2. Core Verb & State Machine
- **Core Verb:** Exhaust (Remove a card from the active cycle).

**State Diagram:**
```text
[Deck] --> (Draw) --> [Hand]
[Hand] --> (Play/Discard) --> [Discard Pile]
[Discard Pile] --> (Shuffle) --> [Deck]
[Hand/Deck/Discard] --> (Exhaust Trigger) --> [Exhaust Pile]
```

**States:**
- `InDeck`: The card is currently in the draw pile.
- `InHand`: The card is currently held by the player.
- `InDiscard`: The card has been played or discarded and is waiting to be reshuffled.
- `Exhausted`: The card is removed from the active cycle and placed in the exhaust pile.

**Transitions:**
- `Draw`: `InDeck` -> `InHand`
- `Play`: `InHand` -> `InDiscard` (for normal cards)
- `PlayExhaust`: `InHand` -> `Exhausted` (for cards with the Exhaust keyword)
- `ForceExhaust`: `InHand` / `InDeck` / `InDiscard` -> `Exhausted` (via external effects)
- `Recover`: `Exhausted` -> `InHand` (rare effects that retrieve exhausted cards)

## 3. MDA Analysis
- **Mechanics:** The system tracks the location of each card. When an exhaust condition is met (e.g., playing a card with the "Exhaust" keyword, or an enemy applying an exhaust effect), the card is moved to a separate "Exhaust Pile" array. Cards in this array are excluded from the standard deck-reshuffling logic.
- **Dynamics:** Players actively use exhaust mechanics to thin their decks, removing weak starting cards (like basic strikes or defends) to increase the probability of drawing their powerful, synergistic cards in subsequent turns. It also forces players to carefully time the use of powerful one-time-use cards, as playing them too early might leave the player lacking resources later in a prolonged fight.
- **Aesthetics:** The mechanic evokes a sense of strategic sacrifice and optimization. Players feel a satisfying sense of progression and efficiency as their deck becomes leaner and more focused during a battle. It also adds tension when deciding whether to use a powerful exhaust card immediately or save it for a critical moment.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Game) | Unit |
| --- | --- | --- | --- | --- |
| `exhaust_on_play` | bool | true/false | true (Slay the Spire v2.3) | boolean |
| `exhaust_on_discard` | bool | true/false | false (Slay the Spire v2.3) | boolean |
| `exhaust_on_turn_end` | bool | true/false | false (Monster Train v1.2) | boolean |
| `exhaust_damage_multiplier` | f32 | 1.0 - 3.0 | 1.0 (Slay the Spire v2.3) | multiplier |
| `exhaust_energy_gain` | u32 | 0 - 3 | 0 (Slay the Spire v2.3) | energy |

## 5. Benchmark Data
- **Slay the Spire (v2.3):**
  - `exhaust_on_play`: true (for cards like "Adrenaline" or "Offering")
  - `exhaust_on_turn_end`: true (for "Ethereal" cards)
  - `exhaust_energy_gain`: 0 (default, though specific relics like Dead Branch provide random cards upon exhaust)
- **Monster Train (v1.2):**
  - `exhaust_on_play`: true (referred to as "Consume")
  - `exhaust_on_discard`: false
  - `exhaust_damage_multiplier`: 1.0

## 6. Common Variants
1. **Ethereal (Time-based Exhaust):** The card exhausts automatically at the end of the turn if it is in the player's hand and hasn't been played.
2. **Consume (Cost-based Exhaust):** The card is exhausted upon play, often associated with very high-impact spells or abilities that would be game-breaking if played repeatedly.
3. **Purge (Permanent Removal):** A meta-variant where the card is removed not just for the combat, but permanently from the player's deck for the rest of the run.
4. **Targeted Exhaust:** Cards or abilities that allow the player to choose a specific card from their hand or deck to exhaust, primarily used for deck thinning.

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_card_draw` (drawing cards accelerates deck cycling, making exhaust more impactful), `atom_energy_gain` (exhausting cards can trigger energy generation), `atom_status_effect` (exhausting status cards is a common way to cleanse the deck).
- **Incompatible Atoms:** `atom_infinite_loop` (exhausting key combo pieces breaks infinite loops, making them mutually exclusive unless carefully managed).

## 8. Anti-Patterns
1. **Over-Exhaustion:** Providing too many mandatory exhaust effects without giving the player a way to generate new cards or finish the fight quickly, leading to situations where the player runs out of cards and automatically loses.
2. **Lack of Feedback:** Failing to clearly indicate which cards will exhaust upon use, leading to player frustration when a key card unexpectedly disappears from their deck.
3. **Trivializing Deck Building:** Making targeted exhaust too cheap and accessible, which removes the challenge of deck building by allowing players to easily remove all flaws from their deck during every combat.
