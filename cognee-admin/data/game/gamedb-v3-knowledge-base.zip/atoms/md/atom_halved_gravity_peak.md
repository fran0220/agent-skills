# Gameplay Atom: Halved-Gravity Jump Peak

## 1. Identity
- **Atom ID:** `atom_halved_gravity_peak`
- **English Name:** Halved-Gravity Jump Peak
- **Chinese Name:** 跳跃顶点半重力
- **Category:** A
- **Definition:** A platforming mechanic where the player character experiences reduced gravity (typically halved) when their vertical velocity approaches zero near the apex of a jump. This creates a "hang time" effect, granting the player a larger window to make horizontal adjustments, time attacks, or plan their landing, thereby enhancing the overall feel and control of the jump.

## 2. Core Verb & State Machine
- **Core Verb:** Jump (Apex)

**State Diagram:**
```text
[Grounded] --(Jump Input)--> [Rising]
[Rising] --(v_y > -threshold)--> [Apex Hang]
[Apex Hang] --(v_y < threshold)--> [Falling]
[Falling] --(Touch Ground)--> [Grounded]
```

**States and Transitions:**
- **Grounded:** The character is on the ground.
- **Rising:** The character is moving upwards with normal gravity.
- **Apex Hang:** The character's vertical velocity is near zero (e.g., between -40 and 40 units/sec). Gravity is reduced (e.g., multiplied by 0.5).
- **Falling:** The character is moving downwards with normal gravity.

## 3. MDA Analysis
- **Mechanics:** The system continuously monitors the player's vertical velocity (`v_y`). When the absolute value of `v_y` falls below a predefined threshold, the gravity applied to the player is multiplied by a modifier (usually 0.5). Once `v_y` exceeds the threshold (as the player starts falling faster), normal gravity is restored.
- **Dynamics:** Players naturally spend more time at the peak of their jump. This allows for precise horizontal micro-adjustments. It also makes jumping over obstacles or reaching distant platforms feel more forgiving, as the arc of the jump is slightly flattened at the top.
- **Aesthetics:** The mechanic creates a feeling of "floatiness" or "hang time" that feels highly responsive and satisfying. It reduces the frustration of pixel-perfect platforming by giving the human brain a fraction of a second more to react and adjust, contributing to a "tight" and "polished" game feel.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Celeste v1.4) | Unit |
| :--- | :--- | :--- | :--- | :--- |
| `gravity_normal` | `f32` | 500.0 - 1500.0 | 900.0 | units/sec² |
| `gravity_mult` | `f32` | 0.3 - 0.8 | 0.5 | multiplier |
| `apex_threshold` | `f32` | 20.0 - 100.0 | 40.0 | units/sec |

## 5. Benchmark Data
- **Celeste (v1.4.0.0):**
  - `gravity_normal`: 900.0
  - `gravity_mult`: 0.5
  - `apex_threshold`: 40.0
- **Super Meat Boy (v1.2.5):**
  - `gravity_normal`: 1200.0
  - `gravity_mult`: 0.6
  - `apex_threshold`: 50.0
- **Hollow Knight (v1.5.78.11833):**
  - `gravity_normal`: 1000.0
  - `gravity_mult`: 0.7
  - `apex_threshold`: 30.0

## 6. Common Variants
1. **Input-Dependent Hang Time:** The halved gravity only applies if the player continues to hold the jump button at the apex.
2. **Asymmetric Hang Time:** Gravity is reduced more on the rising portion of the apex than on the falling portion.
3. **Attack-Triggered Hang Time:** The hang time is only activated or extended if the player performs an attack at the apex.
4. **Variable Multiplier:** The gravity multiplier scales dynamically based on how close the vertical velocity is to absolute zero, creating a smoother curve rather than a hard threshold.

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_variable_jump_height`, `atom_coyote_time`, `atom_jump_buffer`, `atom_dash`.
- **Incompatible Atoms:** `atom_realistic_physics`, as the artificial hang time violates conservation of momentum and realistic gravity.

## 8. Anti-Patterns
1. **Threshold Too High:** If the `apex_threshold` is set too high, the player spends too much time in the halved-gravity state, making the jump feel "floaty" and unresponsive rather than precise.
2. **Multiplier Too Low:** Setting the `gravity_mult` too close to 0 causes the player to completely stall in the air, breaking the flow of movement.
3. **Lack of Visual/Audio Feedback:** Failing to provide subtle feedback (like a slight animation change or sound) when entering the apex state can make the physics change feel jarring or buggy to the player.
