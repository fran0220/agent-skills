# Gameplay Atom: Daily / Weekly Reset

## 1. Identity
- **Atom ID:** `atom_daily_weekly_reset`
- **English Name:** Daily / Weekly Reset
- **Chinese Name:** 日常/周常重置
- **Category:** E (Economy & Progression)
- **Definition:** A temporal pacing mechanism that limits the frequency of specific rewards or activities by resetting their availability at fixed real-world time intervals (typically daily or weekly). This system encourages regular, habitual engagement while preventing rapid content exhaustion.

## 2. Core Verb & State Machine
- **Core Verb:** "Wait" / "Return"

**State Diagram:**
```text
[Available] --(Player completes activity)--> [Completed/Locked]
[Completed/Locked] --(Server reset time reached)--> [Available]
```

**States:**
- `Available`: The activity can be performed, and rewards can be earned.
- `Completed/Locked`: The activity has been completed for the current cycle, and rewards are no longer available until the next reset.

**Transitions:**
- `Available` -> `Completed/Locked`: Triggered by the player successfully completing the activity or claiming the reward.
- `Completed/Locked` -> `Available`: Triggered automatically by the server reaching the predefined reset time (e.g., 04:00 AM server time).

## 3. MDA Analysis
- **Mechanics:** The game tracks the completion status of specific activities or reward pools. At a globally or locally defined time, this status is cleared, making the activities available again.
- **Dynamics:** Players optimize their play sessions around reset times, often logging in specifically to "clear their dailies." It creates a cyclical rhythm of engagement and can lead to "fear of missing out" (FOMO) if a reset is missed.
- **Aesthetics:** Anticipation, habituation, and sometimes relief (when tasks are done). It provides a structured sense of progression and a predictable routine.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Game) | Unit |
| --- | --- | --- | --- | --- |
| `reset_interval_hours` | u32 | 24, 168 | 24 (Genshin Impact v4.0) | Hours |
| `reset_hour_utc` | u32 | 0 - 23 | 8 (WoW v10.0) | Hour (0-23) |
| `max_accumulated_charges` | u32 | 1 - 7 | 1 (Destiny 2 v7.0) | Charges |
| `missed_penalty_factor` | f32 | 0.0 - 1.0 | 0.0 (Genshin Impact v4.0) | Multiplier |

## 5. Benchmark Data
- **World of Warcraft (v10.0):** Daily resets occur at 08:00 AM PST (15:00 UTC or 16:00 UTC depending on daylight saving). Weekly resets occur on Tuesdays at the same time. `reset_interval_hours` = 24 (daily) / 168 (weekly).
- **Genshin Impact (v4.0):** Daily reset is at 04:00 AM server time. Weekly reset is on Monday at 04:00 AM server time. `max_accumulated_charges` is typically 1 for daily commissions.
- **Destiny 2 (v7.0):** Daily and weekly resets occur at 17:00 UTC. Weekly reset is on Tuesday.

## 6. Common Variants
1. **Rolling Reset:** Instead of a fixed server time, the reset occurs exactly 24 hours after the player last completed the activity.
2. **Accumulating Charges:** If a player misses a day, the activity charge carries over to the next day, up to a maximum cap (e.g., up to 3 days of missed dailies can be done at once).
3. **Rest XP System:** Instead of locking content, missing a reset grants a bonus to future activities (e.g., WoW's rested experience).
4. **Tiered Resets:** Different types of content reset at different frequencies (e.g., daily quests, bi-weekly raids, monthly towers).

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_battle_pass`, `atom_login_reward`, `atom_stamina_energy`, `atom_gacha_pull`.
- **Incompatible Atoms:** `atom_infinite_grind` (direct conflict as resets inherently limit grinding).

## 8. Anti-Patterns
1. **Chore Fatigue:** Having too many daily reset activities that take too long to complete, turning the game into a second job.
2. **Punishing Misses:** Severely penalizing players for missing a single day's reset, leading to burnout and eventual churn.
3. **Inconsistent Reset Times:** Having different systems reset at different times of the day, confusing players and making it hard to optimize play sessions.
