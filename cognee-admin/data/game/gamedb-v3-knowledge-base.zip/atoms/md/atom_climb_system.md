# Climb System (atom_climb_system)

## 1. Identity
- **Atom ID:** atom_climb_system
- **English Name:** Climb System
- **Chinese Name:** 攀爬系统
- **Category:** A+B
- **Definition:** A traversal mechanic that allows the player character to attach to, move along, and detach from vertical or near-vertical surfaces. It transforms obstacles into navigable terrain, often incorporating stamina management or specific surface requirements to create spatial puzzles and pacing.

## 2. Core Verb & State Machine
- **Core Verb:** Climb (Attach, Ascend, Descend, Traverse, Leap)

**State Diagram:**
```text
[Idle/Run/Jump] --> (Attach Trigger) --> [Climbing]
[Climbing] --> (Move Input) --> [Climbing Move]
[Climbing Move] --> (Stop Input) --> [Climbing]
[Climbing] --> (Jump Input) --> [Climb Leap]
[Climbing] --> (Detach Input / Stamina Depleted) --> [Falling]
[Climb Leap] --> (Re-attach) --> [Climbing]
[Climb Leap] --> (Miss) --> [Falling]
```

**States and Transitions:**
- **Idle/Run/Jump:** Default locomotion states.
- **Climbing:** Attached to a surface, stationary.
- **Climbing Move:** Moving along the surface (up, down, left, right).
- **Climb Leap:** A dynamic jump away from or up the surface.
- **Falling:** Detached from the surface, affected by gravity.

## 3. MDA Analysis
- **Mechanics:** The system detects valid climbable surfaces via raycasts or collision volumes. Upon attachment, gravity is typically disabled or modified, and player input is mapped to 2D movement along the surface normal. Stamina is often consumed over time or per action.
- **Dynamics:** Players must evaluate routes, manage stamina resources, and find resting spots. Emergent behaviors include sequence breaking by finding unintended climbable routes or using climb leaps to bypass obstacles.
- **Aesthetics:** Evokes feelings of freedom, exploration, and tension (especially when stamina is low). It empowers the player to conquer the environment, shifting the perspective from horizontal to vertical.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (BotW v1.5.0) | Unit |
| --- | --- | --- | --- | --- |
| `climb_speed_up` | f32 | 1.0 - 5.0 | 2.5 | m/s |
| `climb_speed_down` | f32 | 2.0 - 8.0 | 4.0 | m/s |
| `climb_speed_lateral` | f32 | 1.0 - 5.0 | 2.0 | m/s |
| `stamina_drain_rate` | f32 | 0.0 - 20.0 | 5.0 | pts/s |
| `leap_stamina_cost` | f32 | 10.0 - 50.0 | 25.0 | pts |
| `leap_vertical_force` | f32 | 5.0 - 15.0 | 8.0 | N |
| `attach_cooldown` | f32 | 0.1 - 1.0 | 0.2 | s |

## 5. Benchmark Data
- **The Legend of Zelda: Breath of the Wild (v1.5.0):**
  - `climb_speed_up`: 2.5 m/s
  - `stamina_drain_rate`: 5.0 pts/s
  - `leap_stamina_cost`: 25.0 pts
- **Assassin's Creed Valhalla (v1.7.0):**
  - `climb_speed_up`: 3.5 m/s (faster, more fluid)
  - `stamina_drain_rate`: 0.0 pts/s (no stamina restriction for basic climbing)
  - `leap_vertical_force`: 10.0 N
- **Celeste (v1.4.0.0):**
  - `climb_speed_up`: 45.0 pixels/s
  - `stamina_drain_rate`: 10.0 pts/s (total 110 pts)
  - `leap_stamina_cost`: 27.5 pts

## 6. Common Variants
1. **Free Climbing (BotW):** Can climb almost any surface, limited by a stamina wheel.
2. **Node-Based Climbing (Assassin's Creed):** Character snaps to predefined handholds or ledges.
3. **Grip-Based Climbing (Shadow of the Colossus):** Requires holding a button to maintain grip, heavily tied to physics and stamina.
4. **Static Climbing (Classic Platformers):** Ladders or vines only, fixed movement axes, no stamina.

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_stamina_system` (highly synergistic), `atom_gliding` (natural transition from high points), `atom_stealth` (climbing to avoid detection).
- **Incompatible/Conflict Atoms:** `atom_vehicle_driving` (usually mutually exclusive states), `atom_heavy_encumbrance` (often disables climbing).

## 8. Anti-Patterns
1. **Unclear Affordances:** Players cannot visually distinguish climbable surfaces from non-climbable ones, leading to frustration.
2. **Clunky Edge Transitions:** The transition from climbing to standing on a ledge (or vice versa) is unresponsive or drops the player.
3. **Trivialized Level Design:** Unrestricted climbing without stamina or hazard constraints makes all spatial puzzles and pathfinding irrelevant.
