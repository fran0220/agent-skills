# Gameplay Atom: Melee Combo Chain

## 1. Identity
- **Atom ID:** `atom_melee_combo`
- **English Name:** Melee Combo Chain
- **Chinese Name:** 近战连招链
- **Category:** A
- **Definition:** A sequence of melee attacks that can be chained together by inputting commands within specific timing windows. Successful chaining often results in increased damage, unique animations, or special effects, rewarding player timing and execution.

## 2. Core Verb & State Machine
- **Core Verb:** Attack (Chain)
- **State Diagram:**
  ```text
  [Idle] --(Attack Input)--> [Attack 1 Startup]
  [Attack 1 Startup] --> [Attack 1 Active]
  [Attack 1 Active] --> [Attack 1 Recovery]
  [Attack 1 Recovery] --(Attack Input in Window)--> [Attack 2 Startup]
  [Attack 1 Recovery] --(No Input)--> [Idle]
  [Attack 2 Startup] --> [Attack 2 Active]
  ...
  ```
- **States:**
  - `Idle`: Character is ready to act.
  - `Startup`: The wind-up phase of an attack before it can deal damage.
  - `Active`: The phase where the attack hitbox is active and can hit enemies.
  - `Recovery`: The cool-down phase after the active frames.
  - `Combo Window`: A specific sub-state during or after recovery where the next attack in the chain can be buffered or initiated.
- **Transitions:**
  - `Idle` -> `Startup`: Triggered by initial attack input.
  - `Startup` -> `Active`: Automatic after startup frames elapse.
  - `Active` -> `Recovery`: Automatic after active frames elapse.
  - `Recovery` -> `Startup (Next Attack)`: Triggered by attack input during the combo window.
  - `Recovery` -> `Idle`: Automatic if no input is received within the combo window.

## 3. MDA Analysis
- **Mechanics:** The system tracks the current step in a predefined sequence of attacks. It uses timers to define startup, active, recovery, and combo window frames. Inputs received during the combo window advance the sequence; otherwise, it resets.
- **Dynamics:** Players learn the rhythm of the attacks to maximize damage output and keep enemies staggered. They must decide whether to commit to a full combo (risking counterattack) or stop early to dodge/block.
- **Aesthetics:** Provides a sense of rhythm, flow, and mastery. Successfully executing a long or complex combo feels empowering and visually spectacular.

## 4. Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value (Game) | Unit |
|---|---|---|---|---|
| `startup_frames` | u32 | 3 - 15 | 5 (Devil May Cry 5 v1.0) | frames |
| `active_frames` | u32 | 2 - 10 | 3 (Devil May Cry 5 v1.0) | frames |
| `recovery_frames` | u32 | 10 - 30 | 15 (Devil May Cry 5 v1.0) | frames |
| `combo_window_start` | u32 | 5 - 20 | 10 (Devil May Cry 5 v1.0) | frames |
| `combo_window_end` | u32 | 15 - 40 | 25 (Devil May Cry 5 v1.0) | frames |
| `damage_multiplier` | f32 | 1.0 - 3.0 | 1.2 (God of War 2018 v1.33) | multiplier |

## 5. Benchmark Data
- **Devil May Cry 5 (v1.0):**
  - `startup_frames`: 5
  - `active_frames`: 3
  - `recovery_frames`: 15
  - `combo_window_start`: 10
  - `combo_window_end`: 25
- **God of War 2018 (v1.33):**
  - `startup_frames`: 8
  - `active_frames`: 5
  - `recovery_frames`: 20
  - `combo_window_start`: 12
  - `combo_window_end`: 30
  - `damage_multiplier`: 1.2 per successive hit

## 6. Common Variants
1. **Dial-a-Combo:** Inputs can be buffered rapidly in advance, and the character will play out the sequence (e.g., Mortal Kombat).
2. **Rhythm-based Combo:** Requires precise timing matching the animation or a beat to continue the chain or gain bonuses (e.g., Batman: Arkham series).
3. **Branching Combos:** Different inputs (Light vs. Heavy) at different stages of the chain lead to different combo finishers (e.g., Bayonetta, Dynasty Warriors).
4. **Pause Combos:** Waiting for a specific pause during the recovery phase before inputting the next attack triggers a different branch (e.g., Devil May Cry).

## 7. Compatibility Notes
- **Commonly Pairs With:** `atom_dodge_cancel` (allowing players to break out of recovery), `atom_hit_stop` (adding impact to each hit in the chain), `atom_enemy_stagger` (keeping enemies locked down during the combo).
- **Known Conflicts:** `atom_stamina_drain` (if stamina cost is too high per swing, long combos become unviable), `atom_heavy_knockback` (if early hits knock the enemy too far away, subsequent hits will miss).

## 8. Anti-Patterns
1. **Overly Strict Timing:** Making the combo window too small, causing players to drop combos frequently and feel frustrated rather than challenged.
2. **Lack of Cancels:** Forcing players to commit to long recovery animations without the ability to dodge, making combos too risky against aggressive enemies.
3. **Poor Visual Feedback:** Failing to clearly indicate when the combo window is open or when a hit has successfully connected, making the rhythm hard to learn.
