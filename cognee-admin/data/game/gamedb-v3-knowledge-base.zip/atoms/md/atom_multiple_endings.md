# Gameplay Atom: Multiple Endings

## 1. Identity
- **Atom ID:** `atom_multiple_endings`
- **English Name:** Multiple Endings
- **Chinese Name:** 多结局
- **Category:** E (Narrative & Progression)
- **Definition:** A narrative and structural design pattern where the game's conclusion varies based on player choices, performance, or specific conditions met during gameplay. This atom encourages replayability, player agency, and deeper engagement with the game's world and characters by ensuring that decisions have meaningful, long-term consequences.

## 2. Core Verb & State Machine
- **Core Verb:** `decide` / `branch`

**State Diagram:**
```text
[Start] --> [Playing]
[Playing] --(Choice A)--> [Branch A]
[Playing] --(Choice B)--> [Branch B]
[Branch A] --(Condition Met)--> [Ending 1]
[Branch B] --(Condition Met)--> [Ending 2]
[Playing] --(Fail State)--> [Bad Ending]
```

**States:**
- `Start`: The initial state of the game.
- `Playing`: The main gameplay loop where choices are presented.
- `Branch_X`: Intermediate states representing divergent narrative paths.
- `Ending_X`: Terminal states representing the various conclusions.

**Transitions:**
- `Start` -> `Playing`: Game begins.
- `Playing` -> `Branch_X`: Player makes a significant choice or meets a hidden condition.
- `Branch_X` -> `Ending_X`: Player completes the final sequence of the branch.
- `Playing` -> `Bad Ending`: Player fails a critical objective or makes a detrimental choice.

## 3. MDA Analysis
- **Mechanics:** The system tracks player choices, morality scores, completion percentages, or specific item acquisitions. At predetermined narrative nodes, the game evaluates these variables to route the player to different content branches or final cutscenes.
- **Dynamics:** Players may actively seek out specific endings by optimizing their choices, leading to "save scumming" or multiple playthroughs. Emergent behaviors include community collaboration to discover hidden or "true" endings.
- **Aesthetics:** Provides a sense of agency, consequence, and discovery. Players feel that their actions matter, leading to emotional investment, satisfaction, or sometimes regret, depending on the outcome.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value | Unit | Description |
| --- | --- | --- | --- | --- | --- |
| `ending_count` | `u32` | 2 - 26 | 5 (Undertale v1.0) | count | Total number of distinct endings available. |
| `branch_points` | `u32` | 1 - 50 | 15 (Chrono Trigger SNES) | count | Number of critical decision points affecting the ending. |
| `true_ending_req` | `f32` | 0.0 - 1.0 | 1.0 (Nier Automata v1.0) | ratio | Proportion of prerequisites needed for the "true" ending. |
| `morality_threshold` | `f32` | -1.0 - 1.0 | 0.5 | score | Threshold for good/bad ending divergence. |

## 5. Benchmark Data
- **Nier Automata (v1.0):**
  - `ending_count`: 26 (Endings A-Z)
  - `branch_points`: 5 (Main narrative branches)
  - `true_ending_req`: 1.0 (Requires completing Endings A, B, C, and D to unlock E)
- **Chrono Trigger (SNES):**
  - `ending_count`: 13
  - `branch_points`: 15 (Time periods and specific boss defeat timings)
- **Undertale (v1.0):**
  - `ending_count`: 3 (Main: Neutral, Pacifist, Genocide, with numerous Neutral variations)
  - `morality_threshold`: 1.0 (Pacifist requires 0 kills, Genocide requires max kills)

## 6. Common Variants
1. **Binary Choice:** A single, explicit choice at the very end of the game determines the outcome (e.g., Deus Ex: Human Revolution).
2. **Morality Slider:** Endings are tied to a continuous alignment or karma system (e.g., Mass Effect, Fallout).
3. **Completionist:** The "best" ending is locked behind 100% completion or finding specific hidden items (e.g., Batman: Arkham Knight).
4. **Time-Based:** Endings depend on when the player completes the game or defeats the final boss (e.g., Chrono Trigger).
5. **Permadeath/Failure:** Unique endings for failing at specific points or losing key characters (e.g., Heavy Rain).

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_dialogue_tree`, `atom_morality_system`, `atom_new_game_plus`, `atom_hidden_collectibles`.
- **Incompatible Atoms:** `atom_linear_progression`, `atom_infinite_runner` (Conflicts with the concept of a definitive conclusion).

## 8. Anti-Patterns
1. **Illusion of Choice:** Presenting numerous choices throughout the game, but ultimately funneling the player into a single binary choice at the end, rendering previous decisions meaningless.
2. **Obscure Requirements:** Locking the "true" ending behind illogical or overly obscure requirements without adequate hints, forcing players to rely on external guides.
3. **Punishing Experimentation:** Making "bad" endings overly punitive or uninteresting, discouraging players from exploring different narrative paths.
