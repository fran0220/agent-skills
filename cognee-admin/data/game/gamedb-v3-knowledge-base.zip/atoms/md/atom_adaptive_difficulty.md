# Identity
- **Atom ID**: atom_adaptive_difficulty
- **English Name**: Adaptive Difficulty
- **Chinese Name**: 自适应难度
- **Category**: G (Gameplay Systems)
- **Definition**: A system that dynamically adjusts the game's difficulty in real-time based on the player's performance, ensuring the player remains in a state of flow by balancing challenge and skill.

# Core Verb & State Machine
- **Core Verb**: Adjust (difficulty)
- **State Diagram**:
  [Idle] -> (Player Action) -> [Evaluate Performance]
  [Evaluate Performance] -> (Performance High) -> [Increase Difficulty]
  [Evaluate Performance] -> (Performance Low) -> [Decrease Difficulty]
  [Evaluate Performance] -> (Performance Normal) -> [Maintain Difficulty]
  [Increase/Decrease/Maintain Difficulty] -> [Apply Changes] -> [Idle]
- **States**: Idle, Evaluate Performance, Increase Difficulty, Decrease Difficulty, Maintain Difficulty, Apply Changes
- **Transitions**:
  - Idle -> Evaluate Performance: Triggered by player action or time interval
  - Evaluate Performance -> Increase Difficulty: Triggered when player performance metric > upper threshold
  - Evaluate Performance -> Decrease Difficulty: Triggered when player performance metric < lower threshold
  - Evaluate Performance -> Maintain Difficulty: Triggered when player performance metric is within thresholds
  - Increase/Decrease/Maintain Difficulty -> Apply Changes: Automatic
  - Apply Changes -> Idle: Automatic

# MDA Analysis
- **Mechanics**: The system tracks player metrics (e.g., hit rate, damage taken, time to complete tasks) and compares them against predefined thresholds. It then modifies game parameters (e.g., enemy health, spawn rate, item drop rate) accordingly.
- **Dynamics**: Players experience fluctuating levels of challenge. If they struggle, the game becomes more forgiving, allowing them to progress. If they excel, the game ramps up the challenge, preventing boredom.
- **Aesthetics**: Players feel a sense of competence and flow. The game feels tailored to their individual skill level, reducing frustration and maintaining engagement.

# Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value (Game + Version) | Unit |
|---|---|---|---|---|
| `evaluation_interval` | f32 | 1.0 - 60.0 | 10.0 (Left 4 Dead v1.0) | seconds |
| `performance_upper_threshold` | f32 | 0.5 - 1.0 | 0.8 (RE4 v1.0) | ratio |
| `performance_lower_threshold` | f32 | 0.0 - 0.5 | 0.3 (RE4 v1.0) | ratio |
| `difficulty_increase_step` | f32 | 0.01 - 0.2 | 0.05 (RE4 v1.0) | multiplier |
| `difficulty_decrease_step` | f32 | 0.01 - 0.2 | 0.1 (RE4 v1.0) | multiplier |
| `max_difficulty_multiplier` | f32 | 1.0 - 5.0 | 2.0 (Left 4 Dead v1.0) | multiplier |
| `min_difficulty_multiplier` | f32 | 0.1 - 1.0 | 0.5 (Left 4 Dead v1.0) | multiplier |

# Benchmark Data
- **Resident Evil 4 (v1.0)**: Uses a hidden "Rank" system (1-10). `performance_upper_threshold` is roughly equivalent to taking no damage and landing high accuracy shots (0.8 ratio). `difficulty_increase_step` is +1 Rank. `difficulty_decrease_step` is -1 Rank (e.g., upon death).
- **Left 4 Dead (v1.0)**: "AI Director". `evaluation_interval` is dynamic but averages around 10 seconds during combat. `max_difficulty_multiplier` affects horde size and special infected spawn rates, capping at roughly 2.0x base intensity.

# Common Variants
1. **Rubber Banding**: Commonly used in racing games where AI opponents speed up if the player is far ahead and slow down if the player is behind.
2. **Dynamic Item Drops**: Adjusting the frequency and quality of health/ammo drops based on the player's current inventory and health status (e.g., RE4).
3. **Pacing Directors**: Systems that manage the emotional pacing of a level by alternating between high-intensity combat and low-intensity exploration (e.g., Left 4 Dead).
4. **Knowledge Tracing**: Used in educational games (e.g., Duolingo) to adjust the difficulty of questions based on the user's past correct/incorrect answers.

# Compatibility Notes
- **Compatible Atoms**: `atom_enemy_spawning`, `atom_loot_drop`, `atom_health_system`
- **Conflicts**: `atom_fixed_difficulty`, `atom_speedrun_timer` (can cause inconsistencies in competitive environments)

# Anti-Patterns
1. **Noticeable Adjustments**: Making the difficulty changes too obvious, which can break immersion and make players feel manipulated.
2. **Punishing Success**: Ramping up difficulty so quickly that players feel they are being punished for playing well.
3. **Exploitable Systems**: Designing the system in a way that players can intentionally play poorly to trigger easier sections, then breeze through them.
