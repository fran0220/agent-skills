# Identity
- **Atom ID**: atom_flanking_bonus
- **English Name**: Flanking Bonus
- **Chinese Name**: 侧翼加成
- **Category**: A
- **Definition**: Flanking Bonus is a tactical combat mechanic where an attacker gains a significant advantage, such as increased accuracy or damage, by attacking a target from a specific angle or position that bypasses the target's primary defenses or cover.

# Core Verb & State Machine
The primary player verb is **Flank**, which involves maneuvering a unit into an advantageous position relative to an enemy unit.

State Diagram:
[Idle] -> (Move) -> [Positioning]
[Positioning] -> (Reach Flank Position) -> [Flanking]
[Flanking] -> (Attack) -> [Resolving Attack with Bonus]
[Resolving Attack with Bonus] -> (Complete) -> [Idle]

States and Transitions:
- **Idle**: The unit is waiting for orders.
- **Positioning**: The unit is moving towards a target location.
- **Flanking**: The unit has reached a position that qualifies as a flank against a specific enemy.
- **Resolving Attack with Bonus**: The unit is executing an attack with the flanking modifiers applied.

# MDA Analysis
- **Mechanics**: The system calculates the angle between the attacker's position, the target's position, and the target's facing direction or cover orientation. If the angle falls within a specific range (e.g., behind the target or bypassing cover), the attacker receives a statistical bonus (e.g., +20% Critical Hit Chance, +50% Accuracy).
- **Dynamics**: Players are encouraged to use mobility and positioning rather than purely relying on brute force. It creates a dynamic battlefield where units are constantly maneuvering to secure flanks while protecting their own vulnerable sides.
- **Aesthetics**: Players experience a sense of tactical mastery and satisfaction when successfully executing a flanking maneuver. It rewards spatial awareness and strategic planning, making combat feel more realistic and rewarding.

# Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value | Unit |
|---|---|---|---|---|
| `flank_angle_threshold` | f32 | 90.0 - 180.0 | 120.0 (Divinity: Original Sin 2 v3.6) | Degrees |
| `accuracy_bonus` | f32 | 0.0 - 1.0 | 0.4 (XCOM 2 v1.0) | Percentage |
| `critical_chance_bonus` | f32 | 0.0 - 1.0 | 0.33 (XCOM: Enemy Unknown v1.0) | Percentage |
| `damage_multiplier` | f32 | 1.0 - 2.0 | 1.5 (Divinity: Original Sin 2 v3.6) | Multiplier |
| `ignores_cover` | bool | true/false | true (XCOM 2 v1.0) | Boolean |

# Benchmark Data
- **XCOM 2 (v1.0)**: `accuracy_bonus` = 0.4 (40% aim bonus), `critical_chance_bonus` = 0.33 (33% crit bonus), `ignores_cover` = true.
- **Divinity: Original Sin 2 (v3.6)**: `damage_multiplier` = 1.5 (Backstab damage), `flank_angle_threshold` = 120.0 degrees.

# Common Variants
1. **Backstab Only**: The bonus is only applied if the attacker is directly behind the target (e.g., a 60-degree cone).
2. **Elevation Flank**: Gaining a height advantage provides a similar bonus, sometimes stacking with positional flanking.
3. **Surrounded Penalty**: Instead of a bonus to the attacker, the target receives a defense penalty for each adjacent enemy beyond the first.
4. **Cover Negation**: The flank doesn't provide a direct stat boost but completely negates the target's cover bonuses.

# Compatibility Notes
- **Compatible Atoms**: `atom_cover_system` (Flanking naturally interacts with and counters cover), `atom_action_points` (Movement costs AP, making flanking a strategic investment), `atom_overwatch` (Overwatch can be used to punish flanking attempts).
- **Incompatible Atoms**: `atom_omnidirectional_defense` (If a unit defends equally from all sides, flanking becomes irrelevant).

# Anti-Patterns
1. **Trivial Flanking**: Making movement too cheap or maps too open, allowing players to flank effortlessly every turn, which removes the tactical challenge.
2. **Insignificant Bonus**: Providing a flanking bonus that is too small to justify the risk or cost of maneuvering into position.
3. **Unclear Flanking Rules**: Failing to provide clear UI feedback on what constitutes a flank, leading to player frustration when expected bonuses are not applied.
