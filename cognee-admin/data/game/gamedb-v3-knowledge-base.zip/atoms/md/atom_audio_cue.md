# Identity
- **Atom ID**: atom_audio_cue
- **English Name**: Audio Cue / Spatial Sound
- **Chinese Name**: 音频提示/空间音效
- **Category**: G/H (Audio/Sensory)
- **Definition**: A gameplay mechanic where spatialized audio signals provide critical information to the player about their environment, enemy positions, or upcoming events, requiring auditory attention and interpretation to succeed.

# Core Verb & State Machine
- **Core Verb**: Listen / Locate
- **State Diagram**:
  [Idle] -> (Sound Triggered) -> [Playing]
  [Playing] -> (Player Moves/Turns) -> [Updating Spatialization]
  [Updating Spatialization] -> (Sound Ends) -> [Idle]
  [Playing] -> (Sound Ends) -> [Idle]
- **States**:
  - `Idle`: No significant audio cue is currently playing.
  - `Playing`: The audio cue is actively emitting from a source.
  - `Updating Spatialization`: The audio engine recalculates volume, panning, and occlusion based on player movement.
- **Transitions**:
  - `Idle` to `Playing`: Triggered by an event (e.g., enemy step, distant gunshot).
  - `Playing` to `Updating Spatialization`: Triggered by player or source movement.
  - `Updating Spatialization` to `Idle`: Triggered when the sound clip finishes or falls below the hearing threshold.

# MDA Analysis
- **Mechanics**: The system emits sound waves from specific 3D coordinates, applying attenuation over distance, occlusion from obstacles, and HRTF (Head-Related Transfer Function) for directional perception.
- **Dynamics**: Players actively stop moving to reduce their own noise, rotate their camera to pinpoint sound origins, and make tactical decisions based on the perceived distance and type of sound.
- **Aesthetics**: Creates a sense of tension, immersion, and paranoia (especially in horror games), rewarding players for heightened sensory awareness and patience.

# Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value (Hunt: Showdown v1.10) | Unit |
|---|---|---|---|---|
| `max_hearing_distance` | f32 | 10.0 - 500.0 | 150.0 | meters |
| `attenuation_rolloff` | f32 | 0.5 - 5.0 | 2.0 | factor |
| `occlusion_muffling` | f32 | 0.0 - 1.0 | 0.6 | ratio |
| `doppler_level` | f32 | 0.0 - 1.0 | 0.0 | ratio |
| `spatial_blend` | f32 | 0.0 - 1.0 | 1.0 | ratio |

# Benchmark Data
- **Hunt: Showdown (v1.10)**:
  - `max_hearing_distance`: 150.0 (for footsteps), up to 1000.0 (for gunshots)
  - `occlusion_muffling`: 0.6 (heavy low-pass filter applied through walls)
- **Dead by Daylight (v6.0.0)**:
  - `max_hearing_distance`: 32.0 (Terror Radius)
  - `attenuation_rolloff`: Linear interpolation within the radius.

# Common Variants
1. **Heartbeat/Terror Radius**: A non-diegetic or semi-diegetic sound that grows louder as danger approaches (e.g., Dead by Daylight).
2. **Echolocation/Sonar**: Active pinging where the player emits a sound to reveal the environment or enemies (e.g., The Last of Us Listen Mode).
3. **Decoy Sounds**: Throwable items that create fake audio cues to distract enemies (e.g., Metal Gear Solid empty magazines).
4. **Deafening/Tinnitus**: Temporary loss of hearing or ringing effect after a loud explosion, altering the audio landscape (e.g., Call of Duty).

# Compatibility Notes
- **Commonly Pairs With**: `atom_stealth`, `atom_line_of_sight`, `atom_distraction`.
- **Conflicts**: `atom_fast_paced_combat` (where audio cues might be drowned out by constant noise), `atom_isometric_camera` (where 3D spatial audio is less effective).

# Anti-Patterns
1. **Poor Occlusion**: Sounds playing at full volume through solid walls, confusing the player about the source's actual pathing distance.
2. **Overcrowded Mix**: Too many high-priority audio cues playing simultaneously, making it impossible to distinguish critical threats.
3. **Inconsistent Attenuation**: Sounds dropping off too abruptly, failing to give the player enough warning time to react.
