# Gameplay Atom: Monthly Card / Subscription

## 1. Identity
**Atom ID:** `atom_monthly_card`
**English Name:** Monthly Card / Subscription
**Chinese Name:** 月卡/订阅
**Category:** C (Monetization / Retention)
**Definition:** A monetization and retention mechanic where players pay a relatively small upfront real-money cost to receive a large total amount of premium currency or resources, distributed in daily increments over a fixed period (typically 30 days). This mechanic incentivizes daily logins and provides a high return on investment (ROI) compared to direct currency purchases, serving as a foundational conversion tool for low-spending players.

## 2. Core Verb & State Machine
**Core Verb:** Claim (daily rewards)

**State Diagram:**
```text
[Inactive] --(Purchase)--> [Active_Unclaimed]
[Active_Unclaimed] --(Claim)--> [Active_Claimed]
[Active_Claimed] --(Daily Reset)--> [Active_Unclaimed]
[Active_Unclaimed] --(Expire)--> [Inactive]
[Active_Claimed] --(Expire)--> [Inactive]
```

**States:**
- `Inactive`: The player does not have an active monthly card.
- `Active_Unclaimed`: The monthly card is active, and today's reward has not been claimed.
- `Active_Claimed`: The monthly card is active, and today's reward has been claimed.

**Transitions:**
- `Purchase`: Player buys the monthly card (transitions from `Inactive` to `Active_Unclaimed`, or extends duration if already active).
- `Claim`: Player logs in and claims the daily reward (transitions from `Active_Unclaimed` to `Active_Claimed`).
- `Daily Reset`: The server resets the daily state (transitions from `Active_Claimed` to `Active_Unclaimed`).
- `Expire`: The 30-day duration ends (transitions from `Active_*` to `Inactive`).

## 3. MDA Analysis
**Mechanics:** The system grants an immediate upfront reward (usually premium currency) upon purchase, followed by a fixed daily reward that must be claimed by logging in. If a player fails to log in on a given day, that day's reward is typically forfeited. The duration is usually 30 days, and multiple purchases can often stack the duration (up to a limit) but not the daily reward amount.

**Dynamics:** Players are strongly motivated to log in every day to avoid "losing" the value they paid for. This creates a habitual daily engagement loop. The steady influx of premium currency allows players to plan their spending over time, often aligning with gacha banner cycles or battle pass seasons.

**Aesthetics:** Players experience a sense of "smart spending" or high value, as the total yield far exceeds direct purchases. There is also a mild sense of obligation (loss aversion) to log in daily, which transforms into a comforting routine. When the card expires, players often feel a sudden scarcity, prompting renewal.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Genshin Impact v4.0) | Unit |
| :--- | :--- | :--- | :--- | :--- |
| `duration_days` | u32 | 28 - 30 | 30 | Days |
| `upfront_reward` | u32 | 0 - 500 | 300 | Premium Currency |
| `daily_reward` | u32 | 50 - 100 | 90 | Premium Currency |
| `max_stack_days` | u32 | 30 - 180 | 180 | Days |
| `price_usd` | f32 | 4.99 - 9.99 | 4.99 | USD |

## 5. Benchmark Data
- **Genshin Impact (v4.0):** "Blessing of the Welkin Moon" costs $4.99. Grants 300 Genesis Crystals upfront and 90 Primogems daily for 30 days. Total value: 3000 premium currency. Max stack: 180 days.
- **Honkai: Star Rail (v1.0):** "Express Supply Pass" costs $4.99. Grants 300 Oneiric Shards upfront and 90 Stellar Jades daily for 30 days. Total value: 3000 premium currency. Max stack: 180 days.
- **Arknights (v3.0):** "Monthly Card" costs $4.99. Grants 6 Originite Prime upfront, and 200 Orundum + 1x 60-Sanity Potion daily for 30 days.

## 6. Common Variants
1. **Resource-Specific Cards:** Instead of premium currency, the card provides stamina, upgrade materials, or gacha tickets daily.
2. **Tiered Subscriptions:** Offering multiple tiers (e.g., Silver, Gold) with increasing costs and rewards, sometimes allowing both to be active simultaneously.
3. **Retroactive Claiming:** Allowing players to pay a small in-game fee to claim missed days, reducing the strictness of the daily login requirement.
4. **Lifetime Card:** A one-time purchase that provides a smaller daily reward permanently.
5. **Ad-Supported "Card":** Players watch an ad daily to receive a reward, mimicking the monthly card structure without real-money cost.

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_gacha_banner` (provides the currency needed), `atom_battle_pass` (often purchased together as the "low spender bundle"), `atom_daily_missions` (synergizes with the daily login requirement).
- **Incompatible Atoms:** `atom_paywall_progression` (if the game requires massive immediate spending, the slow drip of a monthly card feels useless).

## 8. Anti-Patterns
1. **Overly Punishing Missed Days:** Completely deleting the reward if a player misses a day can lead to churn if a player is forced to miss a few days due to real-life events.
2. **Low ROI:** If the total value of the monthly card is not at least 5x-10x the value of a direct currency purchase, players will not see the value in waiting 30 days.
3. **Uncapped Stacking:** Allowing players to buy 10 years' worth of monthly cards at once can lead to regret and refund requests.
