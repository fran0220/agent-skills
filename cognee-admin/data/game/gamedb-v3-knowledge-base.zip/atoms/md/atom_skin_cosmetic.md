# Identity
- **Atom ID**: atom_skin_cosmetic
- **English Name**: Skin / Cosmetic Unlock
- **Chinese Name**: 皮肤/外观解锁
- **Category**: E/F (Economy/Progression or Monetization)
- **Definition**: A system that allows players to acquire, equip, and display non-stat-altering visual modifications for their characters, weapons, or other in-game assets, primarily serving as a means of self-expression and monetization.

# Core Verb & State Machine
- **Core Verb**: Equip / Unlock
- **State Diagram**:
  [Locked] --(Purchase/Earn)--> [Unlocked] --(Equip)--> [Equipped] --(Unequip)--> [Unlocked]
- **States**:
  - Locked: The cosmetic is not owned by the player.
  - Unlocked: The cosmetic is owned but not currently active.
  - Equipped: The cosmetic is currently active and visible in-game.
- **Transitions**:
  - Locked -> Unlocked: Triggered by purchasing with currency, completing a challenge, or receiving as a drop.
  - Unlocked -> Equipped: Triggered by player selecting the cosmetic in the loadout/inventory.
  - Equipped -> Unlocked: Triggered by player equipping a different cosmetic in the same slot or explicitly unequipping.

# MDA Analysis
- **Mechanics**: The system tracks ownership of cosmetic IDs per player account. It provides interfaces for previewing, purchasing, and equipping these items. During gameplay, the system swaps default models/textures with the equipped cosmetic assets.
- **Dynamics**: Players engage in specific activities (grinding, spending real money) to acquire desired cosmetics. They frequently change their appearance based on mood, social context, or to show off rare items.
- **Aesthetics**: Self-expression, status, and fantasy. Players feel a sense of uniqueness and pride when displaying rare or visually appealing cosmetics.

# Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value | Unit |
|---|---|---|---|---|
| rarity_tier | u32 | 1 - 5 | 3 (Epic in Fortnite v28.00) | Tier |
| price_premium | u32 | 500 - 3000 | 1500 (V-Bucks in Fortnite v28.00) | Currency |
| price_freemium | u32 | 1000 - 10000 | 6300 (Blue Essence in LoL v14.1) | Currency |
| is_limited_time | bool | true/false | false | Boolean |
| visual_effects_level | u32 | 0 - 3 | 2 (Legendary in LoL v14.1) | Level |

# Benchmark Data
- **Fortnite (v28.00)**:
  - Epic Skin Price: 1500 V-Bucks
  - Legendary Skin Price: 2000 V-Bucks
  - Rarity Tiers: Uncommon (1), Rare (2), Epic (3), Legendary (4)
- **League of Legends (v14.1)**:
  - Epic Skin Price: 1350 RP
  - Legendary Skin Price: 1820 RP
  - Ultimate Skin Price: 3250 RP

# Common Variants
1. **Loot Box Cosmetics**: Cosmetics are acquired randomly from purchased or earned containers (e.g., Overwatch).
2. **Battle Pass Cosmetics**: Cosmetics are unlocked sequentially by earning XP during a specific season (e.g., Fortnite).
3. **Achievement Cosmetics**: Cosmetics are awarded only for completing difficult in-game tasks (e.g., World of Warcraft mounts).
4. **Evolving Cosmetics**: Cosmetics that change appearance based on in-game actions or milestones (e.g., LoL Ultimate skins).

# Compatibility Notes
- **Compatible Atoms**: atom_virtual_currency (Virtual Currency), atom_battle_pass (Battle Pass), atom_loot_box (Loot Box), atom_achievement (Achievement).
- **Incompatible Atoms**: Atoms that strictly enforce uniform visual identity for gameplay clarity (e.g., strict competitive modes where hitboxes might be perceived differently).

# Anti-Patterns
1. **Pay-to-Win Camouflage**: Designing cosmetics that blend too well with the environment, giving players an unfair advantage.
2. **Hitbox Mismatch**: Creating cosmetic models that significantly deviate from the character's actual hitbox, leading to frustrating gameplay experiences.
3. **Visual Clutter**: Over-designing cosmetics with excessive particle effects that obscure gameplay readability for the player and opponents.
