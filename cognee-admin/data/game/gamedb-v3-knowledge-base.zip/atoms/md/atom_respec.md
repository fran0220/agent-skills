# Gameplay Atom: Respec / Skill Reset

## 1. Identity
- **Atom ID:** atom_respec
- **English Name:** Respec / Skill Reset
- **Chinese Name:** 洗点/重置
- **Category:** F (Character Building)
- **Definition:** The ability for a player to reset their character's allocated skill points, attributes, or talents, allowing them to reallocate these resources to try different builds or correct mistakes without starting a new character.

## 2. Core Verb & State Machine
**Primary Player Verb:** Reallocate

**State Diagram:**
[Active Build] -> (Initiate Respec) -> [Unallocated State] -> (Assign Points) -> [Active Build]

**States and Transitions:**
- **Active Build:** The default state where points are allocated and skills are active.
- **Unallocated State:** The transitional state where points are refunded and waiting to be spent.
- **Transition 1 (Active Build -> Unallocated State):** Triggered by consuming a specific respec item, paying a currency cost at a designated NPC, or clicking a reset button.
- **Transition 2 (Unallocated State -> Active Build):** Triggered by the player confirming their new point allocation, locking in the choices.

## 3. MDA Analysis
- **Mechanics:** The system tracks the total earned progression points and the currently allocated points. Upon initiating a respec, the allocated points are set to zero (or reduced by a specific amount), and the available unallocated points are increased accordingly. A cost (currency, item, or time) is usually deducted from the player's inventory.
- **Dynamics:** Players are encouraged to experiment with different builds. It creates a resource sink for late-game economies. Players often optimize for fast-leveling builds early in the game and then respec into specialized endgame builds later.
- **Aesthetics:** 
  - *Forgiveness:* Relieving the anxiety of making permanent, build-ruining mistakes.
  - *Expression:* Providing the freedom to try new playstyles and customize the character.
  - *Discovery:* Encouraging players to find optimal or fun combinations of skills.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value | Unit |
|---|---|---|---|---|
| `base_cost` | f32 | 0 - 10000 | 100 (WoW v1.12) | Gold/Currency |
| `cost_multiplier` | f32 | 1.0 - 5.0 | 5.0 (WoW v1.12) | Multiplier |
| `max_cost` | f32 | 0 - 50000 | 50000 (WoW v1.12) | Gold/Currency |
| `refund_points_per_use` | u32 | 1 - 120 | 1 (PoE v3.20) | Points |

## 5. Benchmark Data
- **World of Warcraft (v1.12):** Gold cost increases with each use (1g, 5g, 10g, up to a cap of 50g). The cost decays over time if the player does not respec for a month.
- **Path of Exile (v3.20):** Uses an item called "Orb of Regret". Consuming 1 Orb grants 1 Refund Point, allowing the player to unallocate a single node on the passive skill tree.
- **Diablo III (v2.7):** Respec is completely free and fluid. Players can swap skills and runes at any time as long as they are not in active combat or in a Greater Rift.

## 6. Common Variants
1. **Free and Fluid:** Players can swap skills anytime outside of combat without any cost (e.g., Diablo III).
2. **Item-Based:** Requires specific, sometimes rare, consumable items to refund points individually or entirely (e.g., Path of Exile's Orb of Regret).
3. **Escalating Currency Cost:** Costs in-game currency, with the price increasing each time to discourage constant swapping and act as a gold sink (e.g., World of Warcraft Classic).
4. **Partial Respec:** Only the last few points spent or specific branches can be refunded, rather than the entire skill tree (e.g., Grim Dawn).

## 7. Compatibility Notes
- **Compatible with:** `atom_skill_tree`, `atom_leveling`, `atom_attributes`. These atoms provide the underlying progression systems that `atom_respec` modifies.
- **Conflicts:** `atom_strict_permadeath` (While not strictly incompatible, games with harsh permadeath often lean towards permanent build choices to emphasize consequence).

## 8. Anti-Patterns
1. **Prohibitive Costs:** Making the respec process so expensive that players find it more efficient to simply create a new character, defeating the feature's purpose.
2. **Economy Disruption:** Allowing completely free respecs in a game with a deep trading economy, which can reduce the need for multiple characters and lower the demand for diverse gear sets.
3. **UI Friction:** Forcing players to unclick hundreds of individual nodes one by one without offering a "refund all" or "clear tree" button.
