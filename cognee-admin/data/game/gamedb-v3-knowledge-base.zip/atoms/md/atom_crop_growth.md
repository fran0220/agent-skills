# Gameplay Atom: Crop Growth Stages

## 1. Identity
- **Atom ID:** atom_crop_growth
- **English Name:** Crop Growth Stages
- **Chinese Name:** 作物生长阶段
- **Category:** G (Simulation/Farming)
- **Definition:** The progression of a plant entity through distinct visual and functional stages over time, typically requiring specific conditions (e.g., water, sunlight, season) to advance, culminating in a harvestable state.

## 2. Core Verb & State Machine
- **Core Verb:** Nurture / Wait
- **State Diagram:**
  [Seed] -> [Sprout] -> [Seedling] -> [Mature] -> [Harvestable] -> [Dead/Withered]
- **States:**
  - `Seed`: Initial planted state.
  - `Sprout`: First visible growth.
  - `Seedling`: Intermediate growth stage.
  - `Mature`: Fully grown but not yet producing (for multi-harvest crops) or ready to harvest.
  - `Harvestable`: Ready to be collected by the player.
  - `Dead/Withered`: Failed state due to lack of care or season change.
- **Transitions:**
  - `Seed` -> `Sprout`: Requires 1 day + Watered.
  - `Sprout` -> `Seedling`: Requires X days + Watered.
  - `Seedling` -> `Mature`: Requires Y days + Watered.
  - `Mature` -> `Harvestable`: Requires Z days + Watered.
  - `Any State` -> `Dead/Withered`: Season change or lack of water for N days.

## 3. MDA Analysis
- **Mechanics:** The system tracks the age and health of each crop entity. Daily updates check for watering status, seasonal compatibility, and apply growth increments.
- **Dynamics:** Players must optimize their daily routines to ensure all crops are watered, balancing energy and time constraints. Emergent behaviors include crop rotation planning and prioritizing high-value crops.
- **Aesthetics:** Anticipation and reward. Players feel a sense of accomplishment watching their farm transform from bare soil to a bountiful harvest.

## 4. Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value (Stardew Valley v1.5) | Unit |
|---|---|---|---|---|
| `growth_days` | u32 | 3 - 28 | 4 (Parsnip) | Days |
| `water_required` | bool | true/false | true | Boolean |
| `multi_harvest` | bool | true/false | false (Parsnip) | Boolean |
| `regrowth_days` | u32 | 0 - 14 | 0 | Days |
| `season` | string | Spring/Summer/Fall/Winter | Spring | Season |

## 5. Benchmark Data
- **Stardew Valley (v1.5):**
  - Parsnip: 4 days to grow, single harvest, Spring only.
  - Blueberry: 13 days to grow, regrows every 4 days, Summer only.
- **Harvest Moon: Friends of Mineral Town (v1.0):**
  - Turnip: 4 days to grow, single harvest, Spring only.
  - Pineapple: 20 days to grow, regrows every 5 days, Summer only.

## 6. Common Variants
1. **Real-Time Growth:** Crops grow based on real-world time (e.g., Animal Crossing).
2. **Fertilizer Boosts:** Growth time can be reduced or yield increased by applying items.
3. **Weed/Pest Interference:** Crops can be destroyed or stunted by external factors if not protected.
4. **Cross-Breeding:** Planting specific crops adjacently can yield new hybrid seeds.

## 7. Compatibility Notes
- **Commonly Pairs With:** `atom_watering`, `atom_harvesting`, `atom_seasons`, `atom_inventory_management`.
- **Conflicts:** May conflict with fast-paced action atoms if the growth cycle requires too much real-time waiting without alternative activities.

## 8. Anti-Patterns
1. **Excessive Waiting:** Making growth times too long without providing the player with other engaging activities.
2. **Hidden Mechanics:** Not clearly indicating whether a crop has been watered or is dead, leading to player frustration.
3. **Punishing Failures:** Instantly killing crops if missed watering for one day, rather than stunting growth.
