# Gameplay Atom: Special Piece Generation

## 1. Identity
- **Atom ID:** `atom_special_piece`
- **English Name:** Special Piece Generation
- **Chinese Name:** 特殊块生成
- **Category:** C/D (Match-3 / Puzzle Mechanics)
- **Definition:** The generation of a special game piece or block, typically triggered by a specific player action (such as matching more than the minimum required pieces or clearing specific patterns), which possesses enhanced abilities or unique behaviors compared to standard pieces.

## 2. Core Verb & State Machine
- **Core Verb:** Generate / Match / Activate

**State Diagram:**
```text
[Idle] --> (Match 4+) --> [Generating]
[Generating] --> (Animation Complete) --> [Special Piece Idle]
[Special Piece Idle] --> (Match with Special / Swap) --> [Activating]
[Activating] --> (Effect Applied) --> [Destroyed]
```

**States and Transitions:**
- `Idle`: The board is waiting for player input.
- `Generating`: A special piece is being created at the location of the match or a designated spawn point.
- `Special Piece Idle`: The special piece rests on the board, waiting to be used.
- `Activating`: The special piece is triggered, executing its unique logic (e.g., clearing a row, exploding).
- `Destroyed`: The special piece is removed from the board after its effect concludes.

## 3. MDA Analysis
- **Mechanics:** The system monitors player matches. If a match exceeds the standard threshold (e.g., 4 or 5 pieces instead of 3) or forms a specific shape (e.g., T-shape, L-shape), the system replaces the matched pieces with a single special piece.
- **Dynamics:** Players shift from simply looking for any match to actively setting up complex patterns to farm special pieces. This introduces planning, delayed gratification, and chain-reaction setups.
- **Aesthetics:** Players experience a sense of accomplishment, anticipation, and explosive satisfaction when a hard-earned special piece clears a massive portion of the board.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value | Unit | Description |
| --- | --- | --- | --- | --- | --- |
| `match_threshold` | u32 | 4 - 5 | 4 (Candy Crush Saga v1.0) | pieces | Minimum pieces required to generate a special piece. |
| `effect_radius` | f32 | 1.0 - 3.0 | 1.0 (Candy Crush Saga v1.0) | tiles | The blast radius for bomb-type special pieces. |
| `spawn_delay` | f32 | 0.1 - 0.5 | 0.2 (Tetris Effect v1.0) | seconds | Delay before the special piece becomes interactable. |
| `score_multiplier` | f32 | 1.5 - 5.0 | 2.0 (Candy Crush Saga v1.0) | multiplier | Score bonus applied when the special piece is activated. |

## 5. Benchmark Data
- **Candy Crush Saga (v1.240):**
  - `match_threshold`: 4 (Striped Candy), 5 (Color Bomb)
  - `effect_radius`: 1.0 (Wrapped Candy explosion radius)
  - `score_multiplier`: 3.0
- **Tetris Effect (v1.0.0):**
  - `match_threshold`: 4 (Tetris line clear triggers special state/zone mechanics)
  - `spawn_delay`: 0.0 (Instant)
  - `score_multiplier`: 1.5

## 6. Common Variants
1. **Directional Clearers:** Clears an entire row or column depending on the direction of the match that created it (e.g., Striped Candy).
2. **Area Bombs:** Destroys all pieces within a specific radius (e.g., Wrapped Candy).
3. **Color Wipes:** Destroys all pieces of a specific color currently on the board (e.g., Color Bomb).
4. **Transformative Pieces:** Turns adjacent normal pieces into special pieces before activating.
5. **Persistent Specials:** Special pieces that require multiple hits or activations to be fully destroyed.

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_chain_reaction` (combining special pieces), `atom_gravity_fall` (special pieces falling into place), `atom_obstacle_damage` (using specials to clear blockers).
- **Incompatible Atoms:** `atom_strict_order` (if the game forces a strict sequence of moves, random special piece generation can break the puzzle logic).

## 8. Anti-Patterns
1. **Over-generation:** Making special pieces too easy to create, which trivializes the core puzzle and clutters the board with too many effects.
2. **Unpredictable Spawns:** Spawning the special piece in a random location rather than at the focal point of the player's match, leading to frustration.
3. **Weak Payoff:** Designing a special piece whose activation effect is barely stronger than a normal match, failing to reward the player's setup effort.
