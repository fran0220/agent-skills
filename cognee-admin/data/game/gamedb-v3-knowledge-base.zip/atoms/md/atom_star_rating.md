# Atom: Star Rating (星级评分)

## 1. Identity
- **Atom ID:** `atom_star_rating`
- **English Name:** Star Rating
- **Chinese Name:** 星级评分
- **Category:** E (Evaluation)
- **Definition:** A discrete performance evaluation system that awards players a rating, typically from 1 to 3 stars, based on their score, completion time, or other performance metrics within a specific level or challenge. It serves as both a reward mechanism and a gating system for future content.

## 2. Core Verb & State Machine
- **Core Verb:** Achieve / Earn
- **State Diagram:**
  [Unplayed] --> [Playing]
  [Playing] --> [Failed] (0 stars)
  [Playing] --> [Completed] (1, 2, or 3 stars)
  [Completed] --> [Playing] (Replay for better rating)
- **States:**
  - `Unplayed`: The level has not been attempted.
  - `Playing`: The player is currently attempting the level.
  - `Failed`: The player did not meet the minimum requirements to pass.
  - `Completed_1_Star`: Passed with minimum requirements.
  - `Completed_2_Stars`: Passed with good performance.
  - `Completed_3_Stars`: Passed with excellent/perfect performance.
- **Transitions:**
  - `Start Level`: Unplayed -> Playing
  - `Fail Condition Met`: Playing -> Failed
  - `Pass Condition Met (Score < Threshold 2)`: Playing -> Completed_1_Star
  - `Pass Condition Met (Threshold 2 <= Score < Threshold 3)`: Playing -> Completed_2_Stars
  - `Pass Condition Met (Score >= Threshold 3)`: Playing -> Completed_3_Stars
  - `Retry`: Failed / Completed_* -> Playing

## 3. MDA Analysis
- **Mechanics:** The system tracks player performance (e.g., score, time, moves left) and compares it against predefined thresholds at the end of a level to award 1, 2, or 3 stars.
- **Dynamics:** Players may replay levels multiple times to achieve a 3-star rating, optimizing their strategies. It creates a secondary goal beyond just completing the level.
- **Aesthetics:** Provides a sense of mastery, completionism, and satisfaction. It can also induce frustration if the 3-star threshold is too punishing.

## 4. Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value (Game) | Unit |
|---|---|---|---|---|
| `star_1_threshold` | u32 | 1000 - 5000 | 1000 (Candy Crush Saga v1.2) | Score |
| `star_2_threshold` | u32 | 2000 - 10000 | 2500 (Candy Crush Saga v1.2) | Score |
| `star_3_threshold` | u32 | 3000 - 20000 | 5000 (Candy Crush Saga v1.2) | Score |
| `max_stars` | u8 | 3 - 5 | 3 (Angry Birds v1.0) | Stars |

## 5. Benchmark Data
- **Candy Crush Saga (v1.2):**
  - `star_1_threshold`: 1000
  - `star_2_threshold`: 2500
  - `star_3_threshold`: 5000
  - `max_stars`: 3
- **Angry Birds (v1.0):**
  - `star_1_threshold`: 30000
  - `star_2_threshold`: 45000
  - `star_3_threshold`: 60000
  - `max_stars`: 3

## 6. Common Variants
1. **Time-Based Stars:** Stars are awarded based on how quickly the level is completed (e.g., Trackmania).
2. **Objective-Based Stars:** Each star is tied to a specific, distinct objective (e.g., "Collect all coins", "Take no damage") rather than a single score threshold (e.g., Super Mario 64).
3. **Dynamic Thresholds:** Star thresholds adjust based on the player's historical performance or global leaderboards.
4. **Fractional/Continuous Rating:** Instead of discrete stars, a percentage or letter grade (S, A, B, C) is given.

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_score_system`, `atom_level_gating`, `atom_leaderboard`, `atom_combo_multiplier`.
- **Incompatible Atoms:** `atom_endless_mode` (Stars usually require a discrete end state).

## 8. Anti-Patterns
1. **Opaque Thresholds:** Not showing the player how close they are to the next star during gameplay, leading to frustration.
2. **Unreachable 3-Star:** Setting the 3-star threshold so high that it requires extreme luck or pay-to-win mechanics rather than skill.
3. **Meaningless Stars:** Awarding stars but not tying them to any meta-progression (like unlocking new worlds), making them feel useless.
