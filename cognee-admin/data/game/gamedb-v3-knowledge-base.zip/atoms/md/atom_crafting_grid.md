# 1. Identity
- **Atom ID**: atom_crafting_grid
- **English Name**: Crafting Grid
- **Chinese Name**: 合成网格
- **Category**: C
- **Definition**: A structured interface where players place specific ingredients in a specific spatial arrangement to produce a new item or entity.

# 2. Core Verb & State Machine
- **Core Verb**: Craft
- **State Diagram**:
  [Empty Grid] -> (Place Item) -> [Partially Filled Grid]
  [Partially Filled Grid] -> (Place Item) -> [Valid Recipe Matched]
  [Valid Recipe Matched] -> (Extract Result) -> [Empty Grid / Partially Filled Grid]
- **States**: Empty Grid, Partially Filled Grid, Valid Recipe Matched, Invalid Recipe Matched
- **Transitions**:
  - Empty Grid -> Partially Filled Grid: Triggered by placing an item in a slot.
  - Partially Filled Grid -> Valid Recipe Matched: Triggered by placing the final item that matches a recipe.
  - Valid Recipe Matched -> Empty Grid: Triggered by extracting the crafted item (consuming ingredients).

# 3. MDA Analysis
- **Mechanics**: The system checks the spatial arrangement of items in a grid (e.g., 2x2 or 3x3) against a database of recipes. If a match is found, the output slot displays the result.
- **Dynamics**: Players experiment with item placements, memorize common recipes, and optimize their inventory to carry essential crafting materials.
- **Aesthetics**: Discovery (finding new recipes), Expression (building complex items), and Satisfaction (converting raw materials into useful tools).

# 4. Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value | Unit |
|---|---|---|---|---|
| grid_width | u32 | 2-4 | 3 (Minecraft 1.20) | slots |
| grid_height | u32 | 2-4 | 3 (Minecraft 1.20) | slots |
| shapeless_support | bool | true/false | true (Minecraft 1.20) | N/A |
| craft_time | f32 | 0.0-10.0 | 0.0 (Minecraft 1.20) | seconds |

# 5. Benchmark Data
- **Minecraft (1.20)**: grid_width = 3, grid_height = 3, shapeless_support = true, craft_time = 0.0
- **Vintage Story (1.18)**: grid_width = 3, grid_height = 3, shapeless_support = true, craft_time = 0.0

# 6. Common Variants
- **2x2 Inventory Grid**: A smaller grid available without a crafting station (e.g., Minecraft player inventory).
- **3x3 Station Grid**: Requires a specific block (e.g., Crafting Table) to access.
- **Shapeless Crafting**: The arrangement of items doesn't matter, only the presence of the correct ingredients.
- **Time-delayed Grid**: The crafting process takes time to complete after the recipe is matched and initiated.

# 7. Compatibility Notes
- **Compatible Atoms**: atom_inventory_slot, atom_item_durability, atom_recipe_unlock.
- **Incompatible Atoms**: atom_auto_crafting (usually replaces manual grid crafting).

# 8. Anti-Patterns
- **Overly Complex Recipes**: Requiring too many nested crafting steps that frustrate the player.
- **Unintuitive Shapes**: Recipe shapes that don't logically resemble the output item.
- **Lack of Recipe Book**: Forcing players to memorize hundreds of recipes without in-game reference.
