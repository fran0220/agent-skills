# Gameplay Atom: Temperature / Exposure

## 1. Identity
- **Atom ID:** `atom_temperature_exposure`
- **English Name:** Temperature / Exposure
- **Chinese Name:** 温度/暴露
- **Category:** G/H (Survival / Environmental Hazards)
- **Definition:** The Temperature / Exposure atom represents a systemic environmental hazard where the player character's body temperature is continuously affected by ambient temperature, weather conditions, clothing insulation, and heat sources. It forces players to manage their thermal state to avoid negative status effects such as freezing, heatstroke, or gradual health depletion, thereby driving exploration, resource gathering, and shelter-seeking behaviors.

## 2. Core Verb & State Machine
- **Core Verb:** Regulate (temperature), Seek (shelter/heat), Equip (clothing)

**State Diagram:**
```text
[Comfortable] <--> [Chilly/Warm] <--> [Freezing/Overheating] --> [Taking Damage] --> [Death]
```

**States:**
- `Comfortable`: Body temperature is stable. No negative effects.
- `Chilly/Warm`: Body temperature is dropping/rising. Warning indicators appear.
- `Freezing/Overheating`: Body temperature has reached critical thresholds. Stamina or movement penalties apply.
- `Taking Damage`: Extreme temperature state. Health continuously depletes.
- `Death`: Health reaches zero due to exposure.

**Transitions:**
- `Comfortable` -> `Chilly/Warm`: Ambient temperature drops below/rises above comfort zone threshold.
- `Chilly/Warm` -> `Freezing/Overheating`: Exposure time exceeds safe duration or ambient temperature worsens.
- `Freezing/Overheating` -> `Taking Damage`: Core body temperature reaches critical minimum/maximum.
- `Taking Damage` -> `Death`: Health reaches 0.
- Any State -> `Comfortable`: Player enters a safe zone, equips appropriate gear, or consumes temperature-regulating items.

## 3. MDA Analysis
- **Mechanics:** The system continuously calculates the player's core temperature based on ambient temperature, wind chill, wetness, clothing insulation values, and proximity to heat sources (e.g., campfires). It applies buffs or debuffs based on the current temperature state.
- **Dynamics:** Players naturally develop routines of moving between safe zones (heat sources/shelters). They prioritize crafting or finding better clothing before venturing into extreme biomes. Emergent behaviors include lighting emergency fires during blizzards or traveling only during warmer times of the day.
- **Aesthetics:** Evokes feelings of vulnerability, urgency, and relief. The harshness of the environment makes the warmth of a campfire feel genuinely comforting and rewarding. It grounds the player in the game world, enhancing immersion and survival tension.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Game) | Unit |
| --- | --- | --- | --- | --- |
| `ambient_temp` | f32 | -50.0 to 50.0 | -15.0 (The Long Dark v2.0) | Celsius |
| `body_temp` | f32 | 30.0 to 40.0 | 37.0 (The Long Dark v2.0) | Celsius |
| `insulation_value` | f32 | 0.0 to 30.0 | 12.5 (The Long Dark v2.0) | Celsius |
| `temp_change_rate` | f32 | 0.1 to 5.0 | 1.2 (Breath of the Wild v1.5) | Celsius/min |
| `damage_tick_rate` | f32 | 1.0 to 10.0 | 5.0 (Breath of the Wild v1.5) | HP/sec |
| `wind_chill_factor` | f32 | 0.0 to 20.0 | 5.0 (The Long Dark v2.0) | Celsius |

## 5. Benchmark Data
- **The Long Dark (v2.0):**
  - Base body temperature is 37°C.
  - Freezing begins when the "Feels Like" temperature (Ambient - Wind Chill + Insulation) drops below 0°C.
  - Condition (Health) drains at approximately 20% per in-game hour when freezing.
- **The Legend of Zelda: Breath of the Wild (v1.5):**
  - Temperature is simplified into discrete zones (Cold, Neutral, Hot, Scorching).
  - Level 1 Cold requires 1 piece of cold-resistance gear or a warming meal.
  - Taking damage in unmitigated Cold depletes 1/4 heart every few seconds.

## 6. Common Variants
1. **Discrete Tiered System:** (e.g., Breath of the Wild) Temperature is not a continuous float but discrete levels (Level 1 Cold, Level 2 Cold). Gear provides discrete points of resistance.
2. **Continuous Simulation:** (e.g., The Long Dark) Highly granular simulation where every degree matters, influenced by wind direction, wetness, and exertion.
3. **Proximity-Based:** (e.g., Don't Starve) Temperature drops rapidly away from a fire source, making the fire radius a strict safe zone.
4. **Time-of-Day Dependent:** (e.g., Minecraft deserts/snow biomes in some mods) Temperature swings drastically between day and night, forcing diurnal gameplay patterns.

## 7. Compatibility Notes
- **Commonly Pairs With:** `atom_weather_system` (Weather directly impacts ambient temp), `atom_clothing_equipment` (Gear provides insulation), `atom_stamina_management` (Freezing reduces max stamina).
- **Known Conflicts:** Can conflict with fast-paced combat systems (`atom_combo_combat`) if temperature management requires constant menu pausing or interrupts the flow of action.

## 8. Anti-Patterns
1. **Invisible Death:** Failing to provide clear visual or auditory feedback (e.g., screen frosting, shivering sounds) before the player starts taking damage.
2. **Unavoidable Damage:** Placing critical path objectives in extreme temperature zones without providing the player access to necessary mitigating gear or resources beforehand.
3. **Tedious Micromanagement:** Requiring the player to constantly swap gear every few steps when crossing biome borders, breaking gameplay flow.
