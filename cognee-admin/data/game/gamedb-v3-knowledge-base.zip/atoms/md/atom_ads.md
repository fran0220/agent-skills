# Identity

**Atom ID**: atom_ads
**English Name**: Aim Down Sights
**Chinese Name**: 举枪瞄准
**Category**: A

Aim Down Sights (ADS) is a fundamental and ubiquitous combat mechanic in modern first-person and third-person shooters. It represents the action where a player character transitions from a relaxed or hip-fire stance to actively looking directly down the weapon's iron sights, optical scope, or holographic reflex sight. This action is not merely a visual change; it fundamentally alters the player's interaction with the game world and their weapon. By engaging ADS, the player typically experiences a reduction in movement speed and a narrowing of the field of view (FOV), which simulates the focus required to aim precisely. In exchange for these penalties to mobility and situational awareness, the player is rewarded with significantly increased weapon accuracy, reduced bullet spread, and often a more manageable recoil pattern. This creates a constant, dynamic trade-off between mobility and precision that forms the core loop of many tactical and arcade shooters alike.

# Core Verb & State Machine

The primary player verb associated with this atom is **Aim**. This verb encapsulates the intentional act of focusing on a target to deliver precise damage, contrasting with the more reactive and less accurate act of firing from the hip.

The state machine for the Aim Down Sights mechanic is relatively straightforward but crucial for game feel. It involves transitioning between a resting state and an active aiming state, with intermediate states to handle the animation and mechanical blending.

**State Diagram**:
[HipFire] <--(Release ADS)--- (Press ADS)--> [TransitioningToADS] ---> [FullyADS] ---> (Release ADS) ---> [TransitioningToHipFire] ---> [HipFire]

**States**:
- `HipFire`: This is the default state of the weapon when the player is navigating the world without actively engaging a target. The weapon is held lower on the screen, providing maximum visibility and allowing for full movement speed.
- `TransitioningToADS`: This is a transient state that occurs immediately after the player inputs the command to aim. During this state, the weapon model is animated moving up to the center of the screen, the camera's FOV begins to narrow, and the mechanical benefits (like reduced spread) begin to interpolate towards their final values.
- `FullyADS`: The player is now fully aiming down the sights. The weapon is centered, the FOV is at its minimum intended value for the equipped optic, and the player receives the maximum accuracy benefits while suffering the maximum movement penalties.
- `TransitioningToHipFire`: Another transient state triggered when the player releases the aim input. The weapon lowers, the FOV expands back to normal, and the mechanical states interpolate back to their hip-fire defaults.

**Transitions**:
- `HipFire` to `TransitioningToADS`: This transition is triggered by the player pressing and holding (or toggling, depending on settings) the designated ADS input, typically the right mouse button or the left trigger on a gamepad.
- `TransitioningToADS` to `FullyADS`: This transition happens automatically once the predefined ADS transition time (often dictated by weapon weight and attachments) has elapsed.
- `FullyADS` to `TransitioningToHipFire`: This is triggered by the player releasing the ADS input (in hold mode) or pressing it again (in toggle mode).
- `TransitioningToHipFire` to `HipFire`: This transition completes automatically once the weapon has fully returned to its resting position.

# MDA Analysis

**Mechanics**:
At a mechanical level, the ADS system interacts with several core player controllers. When activated, it applies a scalar multiplier to the player's base movement speed, effectively slowing them down. Simultaneously, it adjusts the camera's Field of View (FOV) to a lower value, creating a zoom effect that makes distant targets appear larger. Crucially, it modifies the weapon's ballistic properties: it drastically reduces or entirely eliminates base weapon spread (bloom), ensuring bullets travel exactly where the reticle points. It may also alter the recoil pattern, sometimes making it more predictable or visually easier to control since the camera is locked to the weapon's sights.

**Dynamics**:
The dynamics of ADS emerge from the constant decision-making it forces upon the player. Because ADS restricts movement and peripheral vision, players must carefully choose when to engage it. Engaging enemies at a medium to long distance almost always necessitates ADS for reliable hits. However, in close-quarters combat (CQC), the time it takes to transition to ADS might result in losing a gunfight to an opponent who fires immediately from the hip. Furthermore, the reduced movement speed makes the aiming player an easier target for others. This creates a dynamic dance of positioning, pre-aiming corners, and deciding whether to commit to an engagement or remain mobile.

**Aesthetics**:
The aesthetic experience of ADS is one of intense focus, tension, and precision. The visual narrowing of the screen, often accompanied by a depth-of-field effect that blurs the periphery, draws the player's complete attention to the target. Audio cues, such as the rustle of clothing or the click of the weapon being raised, enhance the tactile satisfaction of the action. The resulting gameplay feels deliberate and lethal, rewarding players who can anticipate enemy movements and manage their spatial awareness despite the restricted view.

# Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Game) | Unit |
|---|---|---|---|---|
| `ads_time` | f32 | 0.1 - 0.6 | 0.25 (Call of Duty: Modern Warfare 2019) | seconds |
| `movement_speed_multiplier` | f32 | 0.3 - 0.9 | 0.5 (Call of Duty: Modern Warfare 2019) | multiplier |
| `fov_multiplier` | f32 | 0.5 - 0.9 | 0.8 (Battlefield V) | multiplier |
| `spread_multiplier` | f32 | 0.0 - 0.5 | 0.1 (Call of Duty: Modern Warfare 2019) | multiplier |
| `recoil_multiplier` | f32 | 0.5 - 1.0 | 0.8 (Battlefield V) | multiplier |

# Benchmark Data

**Call of Duty: Modern Warfare (2019)**:
In this title, the ADS mechanics are highly tuned to provide a snappy, responsive feel. For a standard assault rifle, the `ads_time` is typically around 0.25 seconds, allowing for quick reactions. The `movement_speed_multiplier` is heavily penalized, often dropping to 0.5x or lower, emphasizing the commitment required to aim. The `spread_multiplier` is extremely low, often 0.1x or even 0.0x, meaning bullets go exactly where the sight is pointing, rewarding precise aim over luck.

**Battlefield V (1.0)**:
Battlefield V takes a slightly different approach, often with slightly longer engagement distances. The `ads_time` for similar weapons might be around 0.3 seconds. The `fov_multiplier` is a key factor here, often set around 0.8x for iron sights, providing a noticeable but not overwhelming zoom. The `recoil_multiplier` is also significant, often around 0.8x, meaning the weapon still kicks, but the visual representation of that kick is easier to manage while looking down the sights.

# Common Variants

1. **Toggle vs. Hold**: The most common variant is how the input is handled. While holding the button is standard for fast-paced shooters, many games offer a toggle option where a single click engages ADS and another disengages it. This is often preferred by players for long-range sniping or those with accessibility needs.
2. **Progressive ADS**: In more realistic or tactical shooters, the benefits of ADS do not snap into place instantly. Instead, the accuracy and FOV changes scale linearly or along a curve during the `TransitioningToADS` phase. This means firing halfway through the animation results in partial accuracy, adding a layer of skill to timing shots.
3. **Scope Glint**: A specific variant applied to high-magnification optics, particularly sniper rifles. Games like Battlefield and Call of Duty implement a visible glint or lens flare that is visible to enemies when a player is in ADS with these scopes. This serves as a balancing mechanic to counter the extreme range and lethality of these weapons, giving targets a chance to react.
4. **Stamina Drain**: In hardcore survival or tactical games, holding ADS might slowly drain a stamina bar or introduce weapon sway over time, simulating the physical fatigue of holding a heavy weapon steady.

# Compatibility Notes

**Compatible Atoms**:
- `atom_sprint`: Often interacts closely; sprinting usually cancels ADS, and there is a specific "sprint-to-fire" delay before ADS can be engaged again.
- `atom_crouch` / `atom_prone`: These posture changes often stack with ADS, further reducing movement speed but providing even greater bonuses to recoil control and stability.
- `atom_lean`: Leaning around corners is almost exclusively done while in ADS in tactical shooters, allowing players to expose minimal hitboxes while maintaining accuracy.

**Incompatible Atoms**:
- `atom_blind_fire`: By definition, blind firing involves shooting without looking down the sights, making it mutually exclusive with ADS.

**Conflicts**:
The most common conflict arises with movement mechanics. Actions like vaulting, sliding, or taking significant damage (aim punch) will often forcefully transition the player out of the `FullyADS` state back to `HipFire` to simulate a loss of control or focus.

# Anti-Patterns

1. **Instantaneous ADS**: Removing the transition time entirely (setting `ads_time` to 0.0) makes the mechanic feel weightless and arcade-like. It removes the tactical vulnerability of aiming and allows players to instantly gain perfect accuracy, which can disrupt the balance of engagement pacing.
2. **No Movement Penalty**: Allowing players to maintain their full base movement speed while in ADS negates the purpose of hip-fire. If there is no penalty for aiming, players will simply walk around the map permanently in ADS, making combat feel floaty and removing the dynamic decision-making process.
3. **Misaligned Sights**: A critical technical error where the visual reticle, iron sights, or red dot does not perfectly align with the actual center of the screen or the calculated trajectory of the projectile. This leads to immense player frustration, as shots that appear to be perfectly aimed will miss their target.
