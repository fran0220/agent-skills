# Gameplay Atom: Swerve / Dodge Obstacles

## 1. Identity
- **Atom ID:** `atom_swerve_dodge`
- **English Name:** Swerve / Dodge Obstacles
- **Chinese Name:** 闪避障碍
- **Category:** G (Movement / Navigation)
- **Definition:** The core gameplay mechanic where a player character continuously moves forward (often automatically) and the player must provide lateral inputs (left, right, up, down) to avoid incoming obstacles, gaps, or hazards. This mechanic tests player reaction time, pattern recognition, and spatial awareness under time pressure.

## 2. Core Verb & State Machine
- **Core Verb:** Dodge (Swerve, Jump, Roll)

**State Diagram:**
```text
[Idle/Running] --(Input Left/Right)--> [Swerving]
[Idle/Running] --(Input Up)--> [Jumping]
[Idle/Running] --(Input Down)--> [Rolling/Sliding]
[Swerving] --(Complete)--> [Idle/Running]
[Jumping] --(Land)--> [Idle/Running]
[Rolling/Sliding] --(Complete)--> [Idle/Running]
[Any State] --(Collide with Obstacle)--> [Stumble/Dead]
```

**States:**
- `Running`: The default state where the character moves forward automatically.
- `Swerving`: The character is transitioning between lateral lanes.
- `Jumping`: The character is in the air to avoid low obstacles.
- `Rolling/Sliding`: The character is lowering their hitbox to avoid high obstacles.
- `Stumble`: The character hit a minor obstacle, reducing speed or losing a life buffer.
- `Dead`: The character hit a major obstacle or fell, ending the run.

**Transitions:**
- `Running` -> `Swerving`: Triggered by lateral swipe or directional input.
- `Running` -> `Jumping`: Triggered by upward swipe or jump button.
- `Running` -> `Rolling`: Triggered by downward swipe or crouch button.
- `Swerving/Jumping/Rolling` -> `Running`: Triggered automatically upon action completion.
- `Any` -> `Stumble/Dead`: Triggered by collision detection with hazard hitboxes.

## 3. MDA Analysis
- **Mechanics:** The game spawns obstacles in predefined lanes or patterns along a track. The player has a limited set of discrete or continuous movement options to change their position relative to the track. Speed often increases over time, reducing the window for reaction.
- **Dynamics:** Players develop a rhythm and rely on peripheral vision and muscle memory. The increasing speed creates a flow state where players anticipate obstacle patterns rather than reacting to individual hazards. Risk-reward dynamics emerge when collectibles are placed near dangerous obstacles.
- **Aesthetics:** Tension, thrill, and flow. The player feels a sense of speed and adrenaline. Successfully navigating a complex sequence of obstacles provides a strong sense of mastery and relief.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Subway Surfers v3.14) | Unit |
|---|---|---|---|---|
| `forward_speed_base` | f32 | 10.0 - 20.0 | 15.0 | units/sec |
| `forward_speed_max` | f32 | 30.0 - 60.0 | 45.0 | units/sec |
| `lane_width` | f32 | 2.0 - 5.0 | 3.0 | units |
| `swerve_duration` | f32 | 0.1 - 0.3 | 0.15 | seconds |
| `jump_height` | f32 | 2.0 - 5.0 | 3.5 | units |
| `jump_duration` | f32 | 0.4 - 0.8 | 0.6 | seconds |
| `roll_duration` | f32 | 0.4 - 0.8 | 0.6 | seconds |
| `obstacle_spawn_rate` | f32 | 0.5 - 3.0 | 1.2 | obstacles/sec |

## 5. Benchmark Data
- **Subway Surfers (v3.14):**
  - `forward_speed_base`: 15.0 units/sec
  - `lane_width`: 3.0 units (3 discrete lanes)
  - `swerve_duration`: 0.15 seconds (very snappy, almost instantaneous feel)
  - `jump_duration`: 0.6 seconds
- **Temple Run 2 (v1.100):**
  - `forward_speed_base`: 12.0 units/sec
  - `lane_width`: Continuous analog movement (tilt-based) within a ~6.0 unit wide path
  - `swerve_duration`: Analog, depends on device tilt
  - `jump_duration`: 0.7 seconds

## 6. Common Variants
1. **Discrete Lanes (Subway Surfers):** The track is divided into 3-5 distinct lanes. Swerving instantly snaps the character to the adjacent lane.
2. **Continuous/Analog Swerve (Temple Run):** The player uses tilt or analog stick to smoothly move left and right across a continuous path.
3. **Cylindrical Track (Minion Rush):** The lanes wrap around a cylinder, allowing infinite lateral movement in one direction.
4. **Rhythm-Based Dodge (Geometry Dash):** Obstacles are synced to music, and dodging requires precise timing rather than pure reaction.
5. **Vehicle Dodge (Traffic Rider):** Player controls a vehicle weaving through traffic, often with acceleration/braking mechanics added to the swerve.

## 7. Compatibility Notes
- **Compatible Atoms:**
  - `atom_collectible_magnet`: Pulls items while dodging, reducing risk.
  - `atom_speed_boost`: Temporarily increases speed and often grants invincibility, bypassing the dodge requirement.
  - `atom_double_jump`: Extends the jump state to clear longer obstacles.
- **Incompatible/Conflicting Atoms:**
  - `atom_complex_combat`: Deep combat mechanics conflict with the high-speed reaction focus of swerving.
  - `atom_free_exploration`: Swerve/dodge relies on forced forward movement, which contradicts free-roaming exploration.

## 8. Anti-Patterns
1. **Blind Jumps/Swerves:** Placing obstacles immediately after a blind corner or drop, giving the player zero reaction time.
2. **Overlapping Hitboxes:** Making the player's hitbox too large or the obstacle's hitbox extend beyond its visual representation, leading to unfair deaths.
3. **Inconsistent Input Buffering:** Failing to buffer inputs, causing players to miss a swerve if they swipe slightly before landing from a jump.
