# Identity
- **Atom ID**: atom_air_dash
- **English Name**: Air Dash
- **Chinese Name**: 空中冲刺
- **Category**: A
- **Definition**: A mid-air maneuver that propels the player character rapidly in a specific direction, temporarily overriding normal aerial movement and gravity.

# Core Verb & State Machine
- **Core Verb**: Dash (in air)
- **State Diagram**:
  [Airborne] -> (Dash Input) -> [Dashing]
  [Dashing] -> (Duration Ends / Collision) -> [Airborne / Falling]
  [Dashing] -> (Wall Collision) -> [Wall Slide / Cling]
- **States**: Airborne, Dashing, Falling, Wall Slide
- **Transitions**:
  - Airborne to Dashing: Triggered by Dash Input when dash is available.
  - Dashing to Falling: Triggered when dash duration expires or dash is canceled.
  - Dashing to Wall Slide: Triggered upon collision with a vertical surface.

# MDA Analysis
- **Mechanics**: The system applies a fixed or high-velocity impulse in the input direction, suspending gravity for a set duration. It may also grant temporary invincibility (i-frames) or deal damage to enemies.
- **Dynamics**: Players use the air dash to cross large gaps, dodge incoming attacks, correct platforming mistakes, or engage enemies quickly. It creates a rhythm of jump-dash-land.
- **Aesthetics**: Provides a sense of speed, agility, and empowerment. It feels snappy and responsive, enhancing the fluidity of movement.

# Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value (Celeste v1.4) | Unit |
|---|---|---|---|---|
| dash_speed | f32 | 10.0 - 30.0 | 24.0 | units/sec |
| dash_duration | f32 | 0.1 - 0.5 | 0.15 | seconds |
| cooldown | f32 | 0.0 - 2.0 | 0.0 (resets on ground) | seconds |
| gravity_multiplier | f32 | 0.0 - 1.0 | 0.0 | multiplier |
| i_frames | f32 | 0.0 - 0.5 | 0.0 | seconds |

# Benchmark Data
- **Celeste (v1.4.0.0)**: dash_speed = 240.0 pixels/sec, dash_duration = 0.15s, gravity_multiplier = 0.0.
- **Mega Man X (SNES)**: dash_speed = 3.5 pixels/frame, dash_duration = 20 frames.
- **Hades (v1.38246)**: dash_speed = 1500.0 units/sec, dash_duration = 0.2s, i_frames = 0.15s.

# Common Variants
1. **Omnidirectional Dash**: Can dash in 8 directions (e.g., Celeste).
2. **Horizontal-Only Dash**: Restricted to left or right (e.g., Mega Man X).
3. **Damage Dash**: Deals damage to enemies passed through (e.g., Hades).
4. **Blink/Teleport**: Instantaneous translation rather than physical movement over time.
5. **Chained Dash**: Allows multiple dashes before touching the ground if specific conditions are met.

# Compatibility Notes
- **Compatible Atoms**: atom_double_jump, atom_wall_jump, atom_hover.
- **Conflicts**: atom_heavy_fall (may conflict if both are triggered simultaneously or if dash cancels heavy fall awkwardly).

# Anti-Patterns
1. **Unclear Refresh Rules**: Not making it obvious to the player when the air dash is available again (e.g., lacking visual cues like hair color change in Celeste).
2. **Momentum Loss**: Instantly halting all momentum after the dash ends, making the movement feel stiff instead of preserving some velocity.
3. **Overpowered I-Frames**: Providing too many invincibility frames, trivializing combat encounters.
