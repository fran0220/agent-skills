# Identity
- **Atom ID**: atom_traffic_sim
- **English Name**: Traffic Simulation
- **Chinese Name**: 交通模拟
- **Category**: G/H
- **Definition**: A system that models the movement of vehicles and pedestrians along a network of paths, managing congestion, routing, and flow dynamics to create realistic or challenging transportation scenarios.

# Core Verb & State Machine
- **Core Verb**: Route / Manage Flow
- **State Diagram**:
  [Idle] -> (Spawn) -> [Moving]
  [Moving] -> (Encounter Intersection/Obstacle) -> [Waiting]
  [Waiting] -> (Clear Path) -> [Moving]
  [Moving] -> (Reach Destination) -> [Despawn]
- **States**: Idle, Moving, Waiting, Despawn
- **Transitions**:
  - Idle to Moving: Spawn trigger
  - Moving to Waiting: Encounter Intersection/Obstacle
  - Waiting to Moving: Clear Path
  - Moving to Despawn: Reach Destination

# MDA Analysis
- **Mechanics**: The system calculates paths for individual agents (vehicles/pedestrians) using algorithms like A* or Dijkstra, updates their positions based on speed and traffic rules, and handles collisions or queuing at intersections.
- **Dynamics**: Traffic jams emerge from high density or poor road layouts. Players observe bottlenecks and adjust infrastructure (e.g., adding lanes, changing signals) to optimize flow.
- **Aesthetics**: Players feel a sense of satisfaction and control when traffic flows smoothly, and frustration or challenge when gridlock occurs. It appeals to the desire for order and efficiency.

# Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value (Cities: Skylines v1.15) | Unit |
|---|---|---|---|---|
| max_speed | f32 | 10.0 - 130.0 | 50.0 | km/h |
| acceleration | f32 | 1.0 - 10.0 | 3.0 | m/s^2 |
| braking_deceleration | f32 | 2.0 - 15.0 | 5.0 | m/s^2 |
| vehicle_length | f32 | 2.0 - 20.0 | 4.5 | meters |
| safe_following_distance | f32 | 1.0 - 10.0 | 2.0 | meters |
| pathfinding_weight_distance | f32 | 0.0 - 1.0 | 0.5 | ratio |
| pathfinding_weight_traffic | f32 | 0.0 - 1.0 | 0.5 | ratio |

# Benchmark Data
- **Cities: Skylines (v1.15)**:
  - max_speed: 50.0 km/h (standard road)
  - vehicle_length: 4.5 meters
  - safe_following_distance: 2.0 meters
- **SimCity 4 (v1.1.641)**:
  - max_speed: 40.0 km/h
  - vehicle_length: 4.0 meters
  - safe_following_distance: 1.5 meters

# Common Variants
1. **Agent-Based Simulation**: Every vehicle is simulated individually with its own path and logic (e.g., Cities: Skylines).
2. **Flow-Based Simulation**: Traffic is simulated as a fluid or statistical flow along edges, rather than individual agents (e.g., SimCity 4).
3. **Abstract Routing**: Traffic is represented purely as numbers on a graph without visual representation of individual vehicles (e.g., Mini Metro).

# Compatibility Notes
- **Compatible Atoms**: atom_road_building, atom_zoning, atom_public_transit, atom_economy
- **Conflicts**: atom_gridless_movement (traffic usually requires strict networks), atom_instant_travel (negates the need for traffic simulation)

# Anti-Patterns
1. **Over-Simulation**: Simulating every single agent's micro-decisions in a massive city, leading to severe CPU bottlenecks.
2. **Unpredictable Pathfinding**: Agents choosing bizarre or highly suboptimal routes, breaking player immersion and trust in the system.
3. **Deadlocks**: Vehicles getting stuck in a permanent gridlock loop that the player cannot resolve without destroying infrastructure.
