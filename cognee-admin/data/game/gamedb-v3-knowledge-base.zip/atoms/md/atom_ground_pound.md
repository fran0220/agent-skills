# Gameplay Atom: Ground Pound

## 1. Identity
- **Atom ID:** `atom_ground_pound`
- **English Name:** Ground Pound
- **Chinese Name:** 下砸
- **Category:** A
- **Definition:** A mid-air maneuver where the player character rapidly descends vertically to strike the ground, often dealing damage to enemies below, breaking obstacles, or triggering switches. It temporarily halts horizontal momentum and accelerates downward velocity.

## 2. Core Verb & State Machine
- **Core Verb:** Smash downward
- **States:** `Idle`, `Airborne`, `Stalling`, `Descending`, `Impact`, `Recovery`.
- **Transitions:**
  - `Airborne` -> `Stalling`: Triggered by player input (e.g., Down + Action).
  - `Stalling` -> `Descending`: Automatic after stall duration ends.
  - `Descending` -> `Impact`: Triggered by collision with the ground or an enemy.
  - `Impact` -> `Recovery`: Automatic upon landing.
  - `Recovery` -> `Idle`: Automatic after recovery duration ends.

## 3. MDA Analysis
- **Mechanics:** The system overrides normal gravity, applying a high downward velocity. It may include a brief stall in the air to allow aiming. Upon hitting the ground, it generates a hitbox (often an AoE shockwave) and applies camera shake.
- **Dynamics:** Players use it to quickly escape aerial vulnerability, attack enemies directly below, or access lower areas faster. It can also be used to cancel other aerial states.
- **Aesthetics:** Conveys a sense of weight, power, and impact. The brief pause before the rapid descent builds anticipation, while the landing provides satisfying kinetic feedback.

## 4. Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value (Super Mario 64) | Unit |
|---|---|---|---|---|
| `stall_duration` | f32 | 0.1 - 0.5 | 0.25 | seconds |
| `descent_velocity` | f32 | 20.0 - 50.0 | 35.0 | m/s |
| `impact_radius` | f32 | 0.0 - 5.0 | 2.0 | meters |
| `damage` | u32 | 1 - 100 | 10 | HP |
| `recovery_duration` | f32 | 0.1 - 1.0 | 0.4 | seconds |

## 5. Benchmark Data
- **Super Mario 64 (v1.0):** `stall_duration` = 0.25s, `descent_velocity` = 35.0 m/s, `recovery_duration` = 0.4s. The move is primarily used for breaking blocks and defeating enemies.
- **Hollow Knight (v1.5.0.0):** (Desolate Dive / Descending Dark) `stall_duration` = 0.3s, `descent_velocity` = 45.0 m/s, `impact_radius` = 3.5m. Grants brief invincibility frames (i-frames) during descent and recovery.

## 6. Common Variants
1. **Shockwave Pound:** Generates a horizontal shockwave upon landing that damages grounded enemies (e.g., Super Smash Bros. Bowser).
2. **Bouncing Pound:** Automatically bounces the player back into the air upon hitting an enemy, allowing for chained attacks (e.g., Shovel Knight's downward thrust).
3. **Charged Pound:** The longer the player falls, the larger the impact radius and damage (e.g., Spider-Man games).
4. **Homing Pound:** Slightly adjusts the horizontal trajectory during descent to lock onto a target below (e.g., Sonic Unleashed).

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_jump`, `atom_double_jump`, `atom_dash` (can be used to position before pounding).
- **Incompatible Atoms:** `atom_glide` (usually cancels gliding), `atom_wall_cling` (cannot be initiated while clinging).

## 8. Anti-Patterns
1. **Lack of Anticipation:** Removing the stall duration makes the move feel weightless and hard to aim.
2. **Overly Long Recovery:** Punishing the player with too much recovery time makes the move risky and frustrating to use in fast-paced combat.
3. **Unclear Hitboxes:** If the visual effect of the impact doesn't match the actual damage radius, players will feel cheated when they miss or get hit.
