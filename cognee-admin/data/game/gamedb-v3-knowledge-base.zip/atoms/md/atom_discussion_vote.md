# Gameplay Atom: Discussion & Voting

## 1. Identity
- **Atom ID:** `atom_discussion_vote`
- **English Name:** Discussion & Voting
- **Chinese Name:** 讨论与投票
- **Category:** F (Social / Interaction)
- **Definition:** A structured social interaction phase where players communicate to share information, form alliances, or deceive others, followed by a formal voting process to make a collective decision, typically resulting in the elimination or penalization of a selected player.

## 2. Core Verb & State Machine
- **Core Verb:** Discuss, Vote

**State Diagram:**
[Idle] -> (Trigger Event) -> [Discussion Phase] -> (Time Up / Skip) -> [Voting Phase] -> (All Voted / Time Up) -> [Resolution Phase] -> [Idle]

**States and Transitions:**
- **Idle:** Normal gameplay state.
- **Discussion Phase:** Players can communicate via text or voice.
  - *Transition:* Triggered by an event (e.g., finding a body, calling an emergency meeting).
- **Voting Phase:** Players cast their votes for a target or choose to skip.
  - *Transition:* Triggered when the discussion timer expires or all players agree to proceed.
- **Resolution Phase:** Votes are tallied, and the outcome is executed (e.g., player ejected).
  - *Transition:* Triggered when all players have voted or the voting timer expires.

## 3. MDA Analysis
- **Mechanics:** The system pauses normal gameplay, enables a communication channel, starts a timer, and provides an interface for players to select another player or "skip". It then counts the votes and applies the result based on majority rules.
- **Dynamics:** Players use social deduction, persuasion, and deception to influence the vote. Alliances are formed and broken. Information asymmetry leads to emergent strategies like bluffing or framing.
- **Aesthetics:** Tension, suspicion, camaraderie, and the thrill of deception or discovery. Players feel a strong sense of agency and social engagement.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Among Us v2021) | Unit |
| --- | --- | --- | --- | --- |
| `discussion_time` | u32 | 15 - 120 | 45 | seconds |
| `voting_time` | u32 | 15 - 120 | 60 | seconds |
| `anonymous_votes` | bool | true/false | false | boolean |
| `emergency_meetings` | u32 | 1 - 5 | 1 | count per player |
| `votes_required_to_eject` | f32 | 0.5 - 1.0 | 0.5 (majority) | ratio |

## 5. Benchmark Data
- **Among Us (v2021.6.15):**
  - `discussion_time`: 45 seconds
  - `voting_time`: 60 seconds
  - `anonymous_votes`: false (configurable, but default is false)
  - `emergency_meetings`: 1 per player
- **Town of Salem (v3.3.4):**
  - `discussion_time`: 45 seconds (Day phase)
  - `voting_time`: 30 seconds (Voting phase) + 20 seconds (Defense)
  - `anonymous_votes`: false
  - `emergency_meetings`: N/A (structured daily phases)

## 6. Common Variants
1. **Anonymous Voting:** Votes are tallied without revealing who voted for whom, increasing deception.
2. **Weighted Voting:** Certain roles or items give a player's vote more weight (e.g., Mayor in Town of Salem).
3. **Plurality vs. Majority:** Plurality ejects the player with the most votes, while Majority requires more than 50% of total votes.
4. **Defense Phase:** A nominated player gets a dedicated time window to defend themselves before the final vote.
5. **Secret Ballot:** Players vote secretly, and the results are only revealed at the end of the game.

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_hidden_roles` (Hidden Roles), `atom_player_elimination` (Player Elimination), `atom_social_deduction` (Social Deduction).
- **Incompatible Atoms:** `atom_fast_paced_combat` (Fast-Paced Combat) - The pause required for discussion disrupts high-speed action flows.

## 8. Anti-Patterns
1. **Excessive Timers:** Setting discussion or voting times too long can lead to boredom and pacing issues.
2. **Lack of Information:** Forcing a vote when players have absolutely no information leads to random, frustrating eliminations.
3. **Unclear Resolution:** Failing to clearly communicate the results of the vote and who voted for whom (unless intentionally anonymous) causes confusion.
