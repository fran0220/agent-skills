# Gameplay Atom: Weight-Based Inventory

## 1. Identity
- **Atom ID:** `atom_inventory_weight`
- **English Name:** Weight-Based Inventory
- **Chinese Name:** 负重背包
- **Category:** C (Character/Core Mechanics)
- **Definition:** A system where items possess a weight attribute, and the player character has a maximum carrying capacity. Exceeding this capacity typically results in movement penalties, inability to fast travel, or other debuffs, forcing the player to manage their inventory and prioritize which items to keep or discard.

## 2. Core Verb & State Machine
- **Core Verb:** Carry / Manage Inventory
- **State Diagram:**
  [Normal] <--> [Encumbered] <--> [Over-Encumbered]
- **States:**
  - `Normal`: Total weight is below the encumbrance threshold. No penalties.
  - `Encumbered`: Total weight exceeds the first threshold but is below the absolute maximum. Movement speed is reduced, and stamina regeneration may be penalized.
  - `Over-Encumbered`: Total weight exceeds the absolute maximum. The player cannot move, or can only walk extremely slowly, and cannot fast travel.
- **Transitions:**
  - `Normal` -> `Encumbered`: Player picks up an item that pushes total weight over the encumbrance threshold.
  - `Encumbered` -> `Normal`: Player drops, consumes, or stores items to reduce weight below the threshold.
  - `Encumbered` -> `Over-Encumbered`: Player picks up items exceeding the maximum capacity.
  - `Over-Encumbered` -> `Encumbered`: Player reduces weight below the maximum capacity.

## 3. MDA Analysis
- **Mechanics:** Each item has a `weight` value. The character has a `max_carry_weight` derived from stats (e.g., Strength). The system continuously calculates `current_weight` = sum of all item weights. If `current_weight` > `max_carry_weight`, penalties are applied.
- **Dynamics:** Players must constantly evaluate the value-to-weight ratio of loot. They may need to make mid-dungeon decisions to drop low-value heavy items to make room for high-value loot. It encourages frequent trips to merchants or storage stashes.
- **Aesthetics:** Creates a sense of realism and physical presence in the world. It can induce tension when the player finds a rare item but is already at the weight limit, forcing a difficult choice. It also adds a layer of resource management and strategic planning.

## 4. Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value (Skyrim v1.9) | Unit |
|---|---|---|---|---|
| `base_carry_weight` | f32 | 100.0 - 300.0 | 300.0 | kg/lbs/units |
| `weight_per_strength` | f32 | 1.0 - 10.0 | 5.0 | units/point |
| `encumbered_speed_mult` | f32 | 0.1 - 0.8 | 0.0 | multiplier |
| `over_encumbered_speed_mult` | f32 | 0.0 - 0.5 | 0.0 | multiplier |
| `encumbrance_threshold` | f32 | 0.5 - 1.0 | 1.0 | ratio |

## 5. Benchmark Data
- **The Elder Scrolls V: Skyrim (v1.9):**
  - `base_carry_weight`: 300
  - `encumbrance_threshold`: 1.0 (Penalties only apply when exceeding max weight)
  - Penalty: Cannot run, cannot fast travel.
- **Dark Souls (v1.06):**
  - `base_carry_weight`: Derived from Endurance stat.
  - `encumbrance_thresholds`: 0.25 (Fast roll), 0.5 (Mid roll), 1.0 (Fat roll), >1.0 (Overburdened, walk only).
  - Focuses on equipped weight rather than total inventory weight, but the principle of weight thresholds affecting movement applies.
- **Baldur's Gate 3 (v4.1):**
  - `base_carry_weight`: Derived from Strength score.
  - `encumbrance_thresholds`: Encumbered, Heavily Encumbered.
  - Penalties: Reduced movement speed in combat, disadvantage on physical checks.

## 6. Common Variants
1. **Equipped Weight Only:** Only items currently equipped (armor, weapons) count towards the weight limit (e.g., Dark Souls). Inventory is bottomless or slot-based.
2. **Slot + Weight Hybrid:** Inventory is limited by both a grid/slot system and a total weight limit (e.g., Escape from Tarkov).
3. **Soft Cap vs Hard Cap:** Soft cap applies gradual penalties (slower movement), while a hard cap completely prevents picking up new items (e.g., The Witcher 3).
4. **Volume/Size Based:** Items have size/volume instead of or in addition to weight, requiring spatial management (e.g., Resident Evil 4).

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_stat_strength` (Strength increases capacity), `atom_item_durability` (Heavy items might be more durable), `atom_fast_travel` (Weight limits often restrict fast travel).
- **Incompatible Atoms:** `atom_infinite_inventory` (Direct contradiction), `atom_arcade_movement` (Weight penalties disrupt fast-paced arcade movement).

## 8. Anti-Patterns
1. **Tedious Micro-Management:** Setting the weight limit too low, forcing the player to spend more time managing inventory than playing the game.
2. **Meaningless Weight:** Giving items negligible weight or providing a massive base capacity, making the system irrelevant and just a UI clutter.
3. **Unclear Feedback:** Failing to clearly notify the player when they become encumbered, leading to confusion about why their character is suddenly moving slowly.
