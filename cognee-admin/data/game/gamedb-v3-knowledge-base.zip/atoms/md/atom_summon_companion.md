# Gameplay Atom: Summon / Companion (召唤/伙伴)

## 1. Identity
- **Atom ID:** `atom_summon_companion`
- **English Name:** Summon / Companion
- **Chinese Name:** 召唤/伙伴
- **Category:** A+B (Action + Behavior)
- **Definition:** The ability for a player to instantiate, call forth, or recruit an autonomous or semi-autonomous entity (companion, pet, minion, or summon) that assists them in combat, exploration, or puzzle-solving. This entity typically has its own stats, behaviors, and lifecycle, acting as an extension of the player's agency within the game world.

## 2. Core Verb & State Machine
- **Core Verb:** Summon (Call forth an entity)

**State Diagram:**
```text
[Unsummoned] --(Summon Action)--> [Summoning]
[Summoning] --(Duration/Animation Complete)--> [Active]
[Active] --(Attack/Defend/Follow)--> [Active]
[Active] --(HP Depleted)--> [Defeated]
[Active] --(Duration Expired)--> [Despawning]
[Active] --(Player Dismisses)--> [Despawning]
[Defeated] --(Cooldown/Revive)--> [Unsummoned]
[Despawning] --(Animation Complete)--> [Unsummoned]
```

**States:**
- `Unsummoned`: The companion is not present in the game world.
- `Summoning`: The transitional state where the companion is being instantiated.
- `Active`: The companion is present and performing its designated behaviors.
- `Defeated`: The companion has lost all health or been destroyed.
- `Despawning`: The transitional state where the companion is leaving the game world.

**Transitions:**
- `Unsummoned` -> `Summoning`: Triggered by player input (e.g., casting a spell, using an item).
- `Summoning` -> `Active`: Triggered by the completion of the summoning animation or cast time.
- `Active` -> `Defeated`: Triggered when the companion's HP reaches 0.
- `Active` -> `Despawning`: Triggered by a timer expiring or the player manually dismissing the companion.
- `Defeated` -> `Unsummoned`: Triggered after a cooldown period or a specific revive action.
- `Despawning` -> `Unsummoned`: Triggered by the completion of the despawn animation.

## 3. MDA Analysis
- **Mechanics:** The system handles the instantiation of a new AI-driven entity, managing its health, stats, aggro generation, and behavior tree. It also manages the resource cost (Mana, Stamina, Items) and cooldowns associated with the summoning action.
- **Dynamics:** Players use summons to draw enemy aggro (tanking), deal supplemental damage (DPS), or provide utility (healing, buffs). This creates emergent strategies where players can focus on positioning or other tasks while the companion handles immediate threats.
- **Aesthetics:** Players feel a sense of companionship, mastery, and strategic depth. It fulfills the fantasy of being a commander, beastmaster, or powerful spellcaster, reducing feelings of isolation in single-player games.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Game) | Unit |
| --- | --- | --- | --- | --- |
| `summon_cost` | f32 | 10.0 - 100.0 | 25.0 (Diablo III v2.7.4) | Mana/Resource |
| `cast_time` | f32 | 0.0 - 5.0 | 1.5 (World of Warcraft v10.0) | Seconds |
| `duration` | f32 | 10.0 - Infinite | Infinite (Pokemon Scarlet v1.3.0) | Seconds |
| `cooldown` | f32 | 5.0 - 300.0 | 60.0 (Persona 5 Royal v1.0) | Seconds |
| `max_hp_ratio` | f32 | 0.1 - 2.0 | 0.5 (Diablo II Resurrected v2.4) | % of Player HP |
| `damage_ratio` | f32 | 0.1 - 1.5 | 0.3 (Elden Ring v1.09) | % of Player Damage |
| `aggro_multiplier` | f32 | 0.5 - 3.0 | 2.0 (Final Fantasy XIV v6.4) | Multiplier |
| `max_active_summons` | u32 | 1 - 10 | 1 (Pokemon) | Count |

## 5. Benchmark Data
- **Diablo III (v2.7.4) - Necromancer Command Skeletons:**
  - `summon_cost`: 50 Essence
  - `max_active_summons`: 7
  - `damage_ratio`: 0.3 (30% of weapon damage per skeleton)
  - `duration`: Infinite (until killed)
- **Elden Ring (v1.09) - Spirit Ashes (Lone Wolf Ashes):**
  - `summon_cost`: 55 FP
  - `max_active_summons`: 3
  - `cast_time`: ~2.0 seconds
  - `duration`: Infinite (until boss defeated or killed)
- **Pokemon Scarlet/Violet (v1.3.0) - Sending out a Pokemon:**
  - `cast_time`: ~1.5 seconds
  - `max_active_summons`: 1 (in standard battles)
  - `duration`: Infinite (until fainted or recalled)

## 6. Common Variants
1. **The Swarm:** Summoning many weak, short-lived entities that overwhelm enemies (e.g., Necromancer skeletons in Diablo, Pikmin).
2. **The Guardian/Tank:** A single, highly durable companion designed specifically to draw aggro and absorb damage (e.g., Warlock Voidwalker in WoW).
3. **The Turret:** A stationary summon that deals damage or provides buffs in a specific area (e.g., Engineer turrets in Team Fortress 2 or Guild Wars 2).
4. **The Mount/Vehicle:** A companion that the player can ride or enter, changing their movement and combat capabilities (e.g., Titanfall, Darksiders).
5. **The Utility Pet:** A companion that doesn't fight but gathers loot, provides light, or solves puzzles (e.g., Torchlight pets, Zelda companions).

## 7. Compatibility Notes
- **Compatible Atoms:**
  - `atom_aggro_management`: Summons often interact heavily with enemy threat systems.
  - `atom_buff_debuff`: Companions can apply buffs to the player or debuffs to enemies.
  - `atom_command_issue`: Players can issue specific orders (attack, defend, move) to their summons.
- **Incompatible/Conflicting Atoms:**
  - `atom_stealth`: Summons often break stealth or have poor AI for avoiding detection, leading to conflicts in stealth-focused gameplay.
  - `atom_lone_wolf_bonus`: Mechanics that reward the player for having no companions directly conflict with summoning.

## 8. Anti-Patterns
1. **Dumb AI:** The companion frequently gets stuck on terrain, fails to attack enemies, or pulls unwanted aggro, frustrating the player.
2. **Stat Scaling Failure:** The companion's stats do not scale properly with the player's progression, making them overpowered in the early game and useless in the late game.
3. **Screen Clutter:** Allowing too many summons or giving them overly flashy effects obscures the player's vision and makes combat unreadable.
