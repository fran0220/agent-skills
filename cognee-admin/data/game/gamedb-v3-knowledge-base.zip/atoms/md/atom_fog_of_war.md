# Gameplay Atom: Fog of War

## 1. Identity
- **Atom ID:** atom_fog_of_war
- **English Name:** Fog of War
- **Chinese Name:** 战争迷雾
- **Category:** G (Game Mechanics)
- **Definition:** Fog of War is a game mechanic that obscures areas of the game map that are not currently within the vision range of a player's units or structures. It creates uncertainty by hiding enemy movements, terrain details, and resource locations, forcing players to actively scout and gather information to make strategic decisions.

## 2. Core Verb & State Machine
- **Core Verb:** Scout / Reveal
- **State Diagram:**
  [Unexplored] --(Scout)--> [Revealed/Visible]
  [Revealed/Visible] --(Unit Leaves)--> [Explored/Fogged]
  [Explored/Fogged] --(Scout)--> [Revealed/Visible]
- **States:**
  - `Unexplored`: The area has never been seen. Terrain and units are completely hidden (often depicted as black).
  - `Revealed/Visible`: The area is currently within the vision range of a friendly unit. Terrain, resources, and enemy units are fully visible.
  - `Explored/Fogged`: The area was previously seen but is no longer in vision range. Terrain is visible, but enemy unit movements and state changes are hidden (often depicted as a grey overlay).
- **Transitions:**
  - `Unexplored` -> `Revealed/Visible`: Triggered when a unit's vision radius overlaps the area.
  - `Revealed/Visible` -> `Explored/Fogged`: Triggered when no friendly units have vision over the area.
  - `Explored/Fogged` -> `Revealed/Visible`: Triggered when a unit's vision radius overlaps the area again.

## 3. MDA Analysis
- **Mechanics:** The system calculates line of sight (LOS) for all units based on their position, vision radius, and terrain obstacles. It updates a grid or mesh representing the map's visibility state for each player or team.
- **Dynamics:** Players must balance resource allocation between economy, military, and scouting. It encourages emergent behaviors like ambushes, feints, and map control battles. Information becomes a valuable resource.
- **Aesthetics:** Creates feelings of tension, paranoia, and discovery. The unknown builds suspense, while revealing the map provides a sense of mastery and relief.

## 4. Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value (StarCraft II v5.0) | Unit |
|---|---|---|---|---|
| `vision_radius` | f32 | 5.0 - 20.0 | 9.0 (Marine) | Grid Cells |
| `reveal_delay` | f32 | 0.0 - 1.0 | 0.0 | Seconds |
| `fog_fade_time` | f32 | 0.1 - 2.0 | 0.5 | Seconds |
| `high_ground_advantage` | bool | true/false | true | Boolean |
| `x-ray_vision` | bool | true/false | false | Boolean |

## 5. Benchmark Data
- **StarCraft II (v5.0.11):**
  - Marine Vision Radius: 9.0
  - Sensor Tower Radar Range: 30.0
  - High ground blocks vision from low ground.
- **Age of Empires II: Definitive Edition (Update 81058):**
  - Militia Line of Sight: 4
  - Outpost Line of Sight: 6 (Dark Age)
  - Elevation provides a slight vision bonus.
- **Civilization VI (v1.0.12.9):**
  - Scout Sight Range: 2 hexes
  - Hills and Woods block vision unless the unit is on a Hill.

## 6. Common Variants
1. **True Sight:** Certain units or structures can reveal stealthed or invisible units within the fog or their vision range (e.g., Observer in StarCraft).
2. **Radar/Sensor Blips:** Units in the fog are not fully visible but appear as blips or pings on the minimap or main screen (e.g., Sensor Tower in StarCraft II).
3. **Shared Vision:** Allied players share their fog of war state, allowing them to see what their teammates see.
4. **Line of Sight Blockers:** Specific terrain features (tall grass, walls) block vision completely, creating localized fog of war even in otherwise revealed areas (e.g., Brush in League of Legends).
5. **Amnesia Fog:** Explored areas slowly revert to Unexplored if not visited for a long time.

## 7. Compatibility Notes
- **Commonly Pairs With:** `atom_stealth` (Stealth/Invisibility), `atom_terrain_elevation` (High Ground Advantage), `atom_minimap` (Minimap).
- **Conflicts:** `atom_perfect_information` (Perfect Information games like Chess inherently cannot have Fog of War).

## 8. Anti-Patterns
1. **Overly Restrictive Vision:** Making vision radii too small across the board, leading to frustrating gameplay where players constantly bump into enemies without warning.
2. **Performance Heavy LOS:** Calculating line of sight too frequently or with too high resolution, causing severe performance drops in late-game scenarios with many units.
3. **Inconsistent Blocking:** Terrain that looks like it should block vision but doesn't, or vice versa, leading to player confusion and unfair ambushes.
