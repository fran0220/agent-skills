# Identity
- **Atom ID**: atom_tool_upgrade
- **English Name**: Tool Upgrade
- **Chinese Name**: 工具升级
- **Category**: E/F
- **Definition**: A progression mechanic where players invest resources and time to improve the efficiency, durability, or capability of their core interactive tools, enabling access to new areas or more efficient resource gathering.

# Core Verb & State Machine
- **Core Verb**: Upgrade (Invest, Wait, Retrieve)
- **State Diagram**:
  [Base Tool] -> (Gather Resources) -> [Ready for Upgrade] -> (Submit to NPC/Station) -> [Upgrading (Wait)] -> (Retrieve) -> [Upgraded Tool]
- **States**:
  - `Base`: The tool is in its current functional state.
  - `Ready`: Player has sufficient resources and currency to upgrade.
  - `Upgrading`: The tool is temporarily unavailable while being processed.
  - `Upgraded`: The tool has reached the next tier.
- **Transitions**:
  - `Base` -> `Ready`: Triggered by accumulating required materials and currency.
  - `Ready` -> `Upgrading`: Triggered by player interaction with the upgrade station/NPC.
  - `Upgrading` -> `Upgraded`: Triggered by the passage of in-game time (e.g., 2 days).
  - `Upgraded` -> `Base`: The upgraded tool becomes the new base for the next tier.

# MDA Analysis
- **Mechanics**: Players collect specific resources (e.g., ores, wood, currency) and submit their current tool to an NPC or crafting station. The tool is removed from the player's inventory for a set duration. Upon return, the tool has improved stats (e.g., wider area of effect, less stamina consumption, ability to break harder obstacles).
- **Dynamics**: Players must plan their upgrades carefully, as losing access to a core tool (like a watering can) for several days can disrupt their daily routine. This creates a strategic layer of timing upgrades during downtime (e.g., winter or rainy days).
- **Aesthetics**: Anticipation and satisfaction. The wait time builds anticipation, and the first use of the upgraded tool provides a strong sense of reward and increased power (Empowerment).

# Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value (Stardew Valley v1.5) | Unit |
|---|---|---|---|---|
| `cost_currency` | u32 | 1000 - 25000 | 2000 | Gold |
| `cost_materials` | u32 | 5 - 20 | 5 | Items |
| `upgrade_duration` | u32 | 1 - 3 | 2 | Days |
| `efficiency_multiplier` | f32 | 1.0 - 5.0 | 2.0 | Multiplier |
| `stamina_reduction` | f32 | 0.0 - 0.5 | 0.1 | Percentage |

# Benchmark Data
- **Stardew Valley (v1.5)**:
  - Copper Watering Can: 2000 Gold, 5 Copper Bars, 2 Days wait. Increases capacity and allows watering 3 tiles in a line.
  - Steel Pickaxe: 5000 Gold, 5 Iron Bars, 2 Days wait. Breaks large boulders.
- **Harvest Moon: Friends of Mineral Town (GBA)**:
  - Silver Hoe: 2000 G, Silver Ore, 3 Days wait. Tills a 1x3 area.

# Common Variants
1. **Instant Upgrade**: Tools are upgraded instantly at a workbench without wait time (e.g., Minecraft).
2. **Durability Reset**: Upgrading a tool also fully repairs its durability (e.g., Animal Crossing: New Horizons).
3. **Branching Paths**: Tools can be upgraded into different specialized forms (e.g., a fast pickaxe vs. a high-yield pickaxe).
4. **Enchantment/Socketing**: Instead of a linear tier upgrade, tools receive modular upgrades via gems or enchantments.

# Compatibility Notes
- **Compatible Atoms**: `atom_resource_gathering`, `atom_stamina_system`, `atom_time_management`
- **Conflicts**: `atom_weapon_degradation`

# Anti-Patterns
1. **Overly Punishing Wait Times**: Making the wait time so long that the player cannot perform core gameplay loops, leading to boredom.
2. **Trivial Upgrades**: The upgraded tool doesn't feel significantly better than the previous tier, making the resource investment feel wasted.
3. **Hidden Requirements**: Not clearly communicating what resources are needed for the next tier, forcing players to use external wikis.
