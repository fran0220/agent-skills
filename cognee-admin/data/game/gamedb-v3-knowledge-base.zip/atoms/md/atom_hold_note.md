# Gameplay Atom: Hold Note

## 1. Identity
- **Atom ID:** `atom_hold_note`
- **English Name:** Hold Note
- **Chinese Name:** 长按音符
- **Category:** Rhythm games (G/H Category)
- **Definition:** A fundamental rhythm game mechanic where the player must press and hold a specific input for a continuous duration corresponding to a sustained musical note, releasing it precisely at the end of the duration to achieve maximum score.

## 2. Core Verb & State Machine
**Core Verb:** Hold (Press, Sustain, Release)

**State Diagram:**
```text
[Idle] --(Press on start time)--> [Holding]
[Holding] --(Release on end time)--> [Completed]
[Holding] --(Release early)--> [Missed/Dropped]
[Idle] --(Miss start time)--> [Missed]
```

**States:**
- `Idle`: The note is approaching the hit line, waiting for player input.
- `Holding`: The player has successfully pressed the note and is currently holding the input.
- `Completed`: The player has successfully held the note for the required duration and released it at the correct time.
- `Missed/Dropped`: The player failed to press the note initially, or released the input prematurely before the required duration was met.

**Transitions:**
- `Idle` -> `Holding`: Triggered by the player pressing the input within the acceptable timing window of the note's start time.
- `Holding` -> `Completed`: Triggered by the player releasing the input within the acceptable timing window of the note's end time.
- `Holding` -> `Missed/Dropped`: Triggered by the player releasing the input before the acceptable end timing window.
- `Idle` -> `Missed`: Triggered by the note passing the hit line without the player pressing the input.

## 3. MDA Analysis
- **Mechanics:** The system tracks the start time, end time, and current state of the note. It evaluates the player's initial press timing against the start time window, continuously checks for sustained input during the hold duration, and evaluates the release timing against the end time window. Scoring is often divided into the initial hit, continuous holding (sometimes via "ticks"), and the final release.
- **Dynamics:** Players must manage their physical stamina and finger independence, especially when hold notes overlap with other notes (e.g., tapping other notes while holding one). The visual feedback of a shrinking or depleting hold bar creates a sense of anticipation for the release timing.
- **Aesthetics:** The mechanic evokes a feeling of sustained tension and musical connection, mirroring the experience of playing a sustained note on a physical instrument like a piano or violin. It provides a satisfying sense of completion upon a perfectly timed release.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Game) | Unit |
| :--- | :--- | :--- | :--- | :--- |
| `start_timing_window` | `f32` | 0.02 - 0.10 | 0.05 (Osu!mania) | seconds |
| `end_timing_window` | `f32` | 0.05 - 0.15 | 0.10 (Osu!mania) | seconds |
| `tick_interval` | `f32` | 0.05 - 0.25 | 0.10 (Beatmania IIDX) | seconds |
| `minimum_hold_duration` | `f32` | 0.10 - 0.50 | 0.20 (Arcaea) | seconds |
| `drop_tolerance` | `f32` | 0.00 - 0.20 | 0.10 (Chunithm) | seconds |

## 5. Benchmark Data
- **Osu!mania (v2023):** `start_timing_window` = 0.05s, `end_timing_window` = 0.10s. The game is known for strict initial hit timings but slightly more lenient release timings.
- **Arcaea (v4.0):** `minimum_hold_duration` = 0.20s. Arcaea's "Arc" notes function similarly to hold notes but add spatial movement. The minimum duration ensures the note is perceivable as a hold rather than a tap.
- **Chunithm (New Plus):** `drop_tolerance` = 0.10s. Chunithm allows a brief moment where the player can accidentally lift their finger and press again without dropping the combo, accommodating for touch panel inaccuracies.

## 6. Common Variants
1. **Slider (Osu! Standard):** The player must hold the input while simultaneously moving the cursor along a predefined path.
2. **Arc Note (Arcaea):** The hold note moves across a 3D space, requiring the player to track its position while holding.
3. **Scratch Hold (Beatmania IIDX):** The player must continuously spin a turntable for the duration of the note.
4. **Flick Hold (Project Sekai):** A hold note that requires a directional flick motion precisely at the moment of release.
5. **Multi-finger Hold (Chunithm):** A wide hold note that requires multiple fingers or the entire hand to cover its width.

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_tap_note` (often played simultaneously with the other hand), `atom_flick_note` (can be placed at the end of a hold note), `atom_combo_multiplier` (hold notes often contribute significantly to combo building via ticks).
- **Incompatible Atoms:** `atom_rapid_mash` (placing a rapid mash sequence on the same input channel as a hold note is physically impossible and creates conflicting inputs).

## 8. Anti-Patterns
1. **Overly Strict Release Windows:** Making the release timing window as strict as the initial hit window can cause immense frustration, as releasing a button precisely is physically more difficult than pressing it.
2. **Indistinguishable Visuals:** Failing to clearly visually distinguish a short hold note from a regular tap note, leading to players treating it as a tap and dropping their combo.
3. **Excessive Duration without Feedback:** Having extremely long hold notes without intermediate scoring "ticks" or visual/audio feedback, making the player unsure if their input is still registering.
