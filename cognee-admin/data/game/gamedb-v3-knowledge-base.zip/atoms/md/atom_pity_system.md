# Gameplay Atom: Pity System

## 1. Identity
**Atom ID:** `atom_pity_system`
**English Name:** Pity System
**Chinese Name:** 保底系统
**Category:** Category C (Progression & Monetization)

The Pity System is a deterministic fallback mechanism embedded within probabilistic reward structures (such as loot boxes or gacha systems) designed to guarantee a specific high-value reward after a predetermined number of unsuccessful attempts. By capping the maximum possible bad luck a player can experience, it mitigates frustration, encourages sustained engagement, and provides a clear, predictable ceiling for monetary or time investment.

## 2. Core Verb & State Machine
**Core Verb:** Pull / Roll / Draw

**State Diagram:**
```text
[Idle] --(Pull)--> [Rolling]
[Rolling] --(Success)--> [Reset Counter] --> [Idle]
[Rolling] --(Failure)--> [Increment Counter]
[Increment Counter] --(Counter < Soft Pity)--> [Idle]
[Increment Counter] --(Counter >= Soft Pity & Counter < Hard Pity)--> [Boost Probability] --> [Idle]
[Increment Counter] --(Counter == Hard Pity)--> [Guarantee Success] --> [Reset Counter] --> [Idle]
```

**States:**
- **Idle:** The player is waiting to initiate a pull.
- **Rolling:** The system is calculating the outcome of the pull.
- **Increment Counter:** The system adds to the cumulative count of unsuccessful pulls.
- **Boost Probability:** The system applies an increased success rate (Soft Pity).
- **Guarantee Success:** The system forces a successful outcome (Hard Pity).
- **Reset Counter:** The system resets the cumulative count to zero after a success.

**Transitions:**
- `Idle` to `Rolling`: Triggered by the player spending currency to pull.
- `Rolling` to `Reset Counter`: Triggered by a naturally successful pull.
- `Rolling` to `Increment Counter`: Triggered by a failed pull.
- `Increment Counter` to `Idle`: Triggered when the counter is below the soft pity threshold.
- `Increment Counter` to `Boost Probability`: Triggered when the counter reaches the soft pity threshold.
- `Increment Counter` to `Guarantee Success`: Triggered when the counter reaches the hard pity threshold.

## 3. MDA Analysis
**Mechanics:**
The system tracks the number of consecutive pulls without a high-tier reward. It defines a "Hard Pity" threshold where the reward is guaranteed (100% probability) and often a "Soft Pity" threshold where the base probability of success incrementally increases with each subsequent pull until the hard pity is reached. Upon receiving the high-tier reward, the counter resets to zero.

**Dynamics:**
Players alter their spending and pulling behavior based on their current pity count. As they approach the soft or hard pity thresholds, the perceived value of each subsequent pull increases, leading to the "sunk cost fallacy" and encouraging players to spend premium currency to reach the guarantee. Players may also "build pity" on less desirable banners to save the guaranteed drop for a highly desired future reward.

**Aesthetics:**
The system generates a mix of anticipation, relief, and calculated strategy. Early successes feel exceptionally rewarding (lucky), while reaching hard pity provides a sense of relief and fairness, preventing the despair of unbounded bad luck. It transforms a purely gambling experience into a predictable investment, fostering trust between the player and the game.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Genshin Impact v4.0) | Unit |
| :--- | :--- | :--- | :--- | :--- |
| `base_probability` | f32 | 0.001 - 0.05 | 0.006 | percentage (decimal) |
| `hard_pity_threshold` | u32 | 50 - 100 | 90 | pulls |
| `soft_pity_threshold` | u32 | 40 - 80 | 74 | pulls |
| `soft_pity_increment` | f32 | 0.01 - 0.10 | 0.06 | percentage (decimal) |
| `fifty_fifty_chance` | bool | true/false | true | boolean |

## 5. Benchmark Data
- **Genshin Impact (v4.0):**
  - Base Probability for 5-Star: 0.6%
  - Soft Pity Threshold: 74 pulls (probability increases by ~6% per pull thereafter)
  - Hard Pity Threshold: 90 pulls (100% chance)
  - 50/50 System: The first 5-star obtained has a 50% chance to be the promotional character. If failed, the next 5-star is 100% guaranteed to be the promotional character.
- **Honkai: Star Rail (v1.0):**
  - Base Probability for 5-Star: 0.6%
  - Soft Pity Threshold: 74 pulls
  - Hard Pity Threshold: 90 pulls
  - 50/50 System: Identical to Genshin Impact.
- **Arknights (v3.0):**
  - Base Probability for 6-Star: 2%
  - Soft Pity Threshold: 50 pulls
  - Hard Pity Threshold: 99 pulls (probability increases by 2% per pull after 50)

## 6. Common Variants
1. **Soft Pity + Hard Pity:** The standard model where probability ramps up before a hard guarantee (e.g., Genshin Impact).
2. **Sparking / Mileage System:** Players earn a specific currency (e.g., "sparks") for each pull. After accumulating enough currency, they can directly purchase the desired character from a shop. The currency may expire when the banner ends (e.g., Granblue Fantasy).
3. **Escalating Odds Only:** The probability increases with each failure, but there is no absolute 100% hard pity cap, though it practically reaches 100% eventually (e.g., Fire Emblem Heroes).
4. **Guaranteed Rarity per Multi-Pull:** Performing a 10-pull guarantees at least one item of a specific mid-tier rarity (e.g., a 4-star), independent of the high-tier pity.
5. **Shared Pity:** The pity counter carries over between different promotional banners of the same type, allowing players to save their progress.

## 7. Compatibility Notes
**Compatible Atoms:**
- `atom_loot_box`: The foundational probabilistic reward system that pity modifies.
- `atom_premium_currency`: The resource consumed to perform pulls, driving monetization.
- `atom_daily_login_reward`: Provides free pulls or currency to slowly build pity over time.

**Incompatible Atoms:**
- `atom_pure_skill_check`: Systems relying entirely on player skill conflict with deterministic probabilistic rewards.
- `atom_fixed_price_shop`: Direct purchase models bypass the need for a pity system entirely.

## 8. Anti-Patterns
1. **Hidden Pity Counters:** Failing to display the player's current pity count or pull history, leading to uncertainty, mistrust, and reliance on third-party tracking tools.
2. **Resetting Pity on Banner Change:** Clearing the pity counter when a limited-time banner ends without converting it to a permanent resource, causing immense frustration for players who narrowly missed the threshold.
3. **Overly Punishing Hard Pity:** Setting the hard pity threshold so high that it requires an unreasonable financial or time investment, making the "guarantee" feel exploitative rather than protective.
