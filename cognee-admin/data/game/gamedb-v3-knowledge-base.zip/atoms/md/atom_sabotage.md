# Gameplay Atom: Sabotage / Betrayal

## 1. Identity
**Atom ID:** atom_sabotage
**English Name:** Sabotage / Betrayal
**Chinese Name:** 破坏/背叛
**Category:** F (Social / Deception)
**Definition:** The Sabotage / Betrayal atom introduces a mechanic where one or more players secretly work against the collective goals of the group. It creates an environment of paranoia and deduction, as the saboteurs attempt to disrupt progress, eliminate other players, or cause critical failures without revealing their true identity to the rest of the participants.

## 2. Core Verb & State Machine
**Core Verb:** Sabotage (to secretly disrupt or destroy)

**State Diagram:**
[Idle] -> (Trigger Sabotage) -> [Active Sabotage]
[Active Sabotage] -> (Fixed by Crew) -> [Idle]
[Active Sabotage] -> (Time Expires) -> [Critical Failure / Game Over]
[Idle] -> (Kill Action) -> [Cooldown]
[Cooldown] -> (Time Passes) -> [Idle]

**States and Transitions:**
- **Idle:** The saboteur is blending in, with all abilities available.
- **Active Sabotage:** A disruptive event is currently ongoing, requiring immediate attention from the group.
- **Critical Failure:** The sabotage was not resolved in time, resulting in a win for the saboteurs.
- **Cooldown:** The saboteur has recently performed an action and must wait before acting again.

## 3. MDA Analysis
**Mechanics:** The system assigns hidden roles to players. Saboteurs are granted specific abilities, such as triggering map-wide emergencies, locking doors, or eliminating other players. These abilities operate on cooldowns and often require proximity or specific conditions to activate.
**Dynamics:** The emergent behavior revolves around deception, alibi creation, and social deduction. Saboteurs must coordinate silently or use the chaos of their own sabotages to isolate targets. Innocent players must balance completing their objectives with monitoring others' behavior and responding to emergencies.
**Aesthetics:** The primary feelings evoked are paranoia, tension, and the thrill of deception. Innocent players feel a constant sense of vulnerability and suspicion, while saboteurs experience the adrenaline of pulling off a successful deception and the fear of being discovered.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Among Us v2021.6.15) | Unit |
| :--- | :--- | :--- | :--- | :--- |
| `sabotage_cooldown` | f32 | 10.0 - 60.0 | 30.0 | seconds |
| `kill_cooldown` | f32 | 10.0 - 60.0 | 45.0 | seconds |
| `emergency_duration` | f32 | 15.0 - 90.0 | 30.0 | seconds |
| `saboteur_ratio` | f32 | 0.1 - 0.3 | 0.2 | ratio |
| `vision_reduction` | f32 | 0.1 - 0.9 | 0.5 | multiplier |

## 5. Benchmark Data
- **Among Us (v2021.6.15):** `sabotage_cooldown` = 30.0s, `kill_cooldown` = 45.0s, `emergency_duration` = 30.0s. The game relies heavily on map-wide disruptions to force player movement.
- **Project Winter (v1.1.94):** `sabotage_cooldown` = 60.0s, `saboteur_ratio` = 0.25. Sabotage is more focused on resource destruction and delaying the escape rather than immediate game-ending emergencies.
- **Town of Salem (v3.3.4):** `kill_cooldown` = 1.0 (per night phase). The sabotage is turn-based rather than real-time, focusing entirely on the social deduction aspect.

## 6. Common Variants
- **Resource Sabotage:** Instead of causing immediate emergencies, the saboteur slowly drains the group's resources (e.g., food, fuel), forcing them to take riskier actions.
- **Information Sabotage:** The saboteur can disrupt communications, alter objective markers, or feed false information to the group, creating confusion without direct physical harm.
- **Infection/Conversion:** The saboteur does not just eliminate players but converts them to their side, gradually shifting the balance of power.
- **Delayed Effect:** Sabotages do not trigger immediately but are planted as traps that activate later, making it harder to trace back to the saboteur.

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_social_deduction`, `atom_hidden_roles`, `atom_voting_elimination`, `atom_task_completion`. These atoms naturally synergize to create a complete social deduction loop.
- **Incompatible Atoms:** `atom_perfect_information`, `atom_pure_coop`. Sabotage relies on hidden information and conflicting goals, which directly contradict these atoms.

## 8. Anti-Patterns
- **Overpowered Sabotages:** Making sabotages too difficult to resolve or too frequent, leading to frustration for the innocent players and an inevitable win for the saboteurs.
- **Lack of Counterplay:** Failing to provide innocent players with tools or information to deduce the saboteur's identity, turning the game into a random guessing game.
- **Snowballing:** Allowing early successful sabotages to disproportionately advantage the saboteurs, making a comeback impossible for the rest of the group.
