# Identity
- **Atom ID**: atom_one_tap
- **English Name**: One-Tap Control
- **Chinese Name**: 单键控制
- **Category**: G (Input/Control)
- **Definition**: A control scheme where the player interacts with the game using a single input action, typically a tap or click, to trigger the primary mechanic, often resulting in a binary state change or an impulse force.

# Core Verb & State Machine
- **Core Verb**: Tap / Click
- **State Diagram**:
  [Idle] --(Tap)--> [Action/Impulse]
  [Action/Impulse] --(Gravity/Time)--> [Falling/Cooldown]
  [Falling/Cooldown] --(Tap)--> [Action/Impulse]
  [Falling/Cooldown] --(Ground/Obstacle)--> [Dead]
- **States**:
  - `Idle`: Waiting for the first input.
  - `Action/Impulse`: The state immediately following a tap, usually applying an upward force or changing direction.
  - `Falling/Cooldown`: The state where gravity or a timer takes over before the next tap is allowed or effective.
  - `Dead`: The failure state upon hitting an obstacle or boundary.
- **Transitions**:
  - `Idle` -> `Action/Impulse`: Triggered by Tap.
  - `Action/Impulse` -> `Falling/Cooldown`: Triggered by physics (gravity) or time elapsed.
  - `Falling/Cooldown` -> `Action/Impulse`: Triggered by Tap.
  - `Falling/Cooldown` -> `Dead`: Triggered by collision.

# MDA Analysis
- **Mechanics**: The system registers a single boolean input (tap/no tap). Upon registering a tap, it applies a predefined impulse vector to the player character or toggles a movement state (e.g., changing direction). Gravity or constant forward movement is usually applied automatically.
- **Dynamics**: Players must time their taps precisely to navigate through obstacles. The frequency of taps determines the character's altitude or path. This creates a rhythm-like gameplay loop of tension and release.
- **Aesthetics**: The player experiences a sense of challenge, frustration, and ultimately mastery. The simplicity of the control scheme makes it highly accessible, while the precise timing required provides deep engagement and a "just one more try" feeling.

# Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value | Unit |
|---|---|---|---|---|
| `tap_impulse` | f32 | 200.0 - 600.0 | 400.0 (Flappy Bird v1.0) | pixels/sec |
| `gravity` | f32 | 500.0 - 1500.0 | 1000.0 (Flappy Bird v1.0) | pixels/sec^2 |
| `max_fall_speed` | f32 | 300.0 - 800.0 | 500.0 (Flappy Bird v1.0) | pixels/sec |
| `cooldown` | f32 | 0.0 - 0.5 | 0.0 (Crossy Road v1.0) | seconds |

# Benchmark Data
- **Flappy Bird (v1.0)**:
  - `tap_impulse`: 400.0
  - `gravity`: 1000.0
  - `max_fall_speed`: 500.0
- **Crossy Road (v1.0)**:
  - `tap_impulse`: 1.0 (grid unit forward)
  - `cooldown`: 0.1 (short delay between hops)

# Common Variants
1. **Flap/Jump**: Tapping applies an upward vertical impulse against constant gravity (e.g., Flappy Bird).
2. **Direction Toggle**: Tapping changes the character's movement direction, often in a zig-zag pattern (e.g., ZigZag).
3. **Hold to Rise, Release to Fall**: A variation where the duration of the tap matters (e.g., Jetpack Joyride), though strictly speaking, pure one-tap ignores duration.
4. **Lane Switch**: Tapping instantly moves the character to an adjacent lane (e.g., simple endless runners).

# Compatibility Notes
- **Compatible Atoms**: `atom_endless_runner` (Endless scrolling), `atom_obstacle_generation` (Procedural obstacles), `atom_score_counter` (Score tracking).
- **Incompatible Atoms**: `atom_dual_stick_shooter` (Requires complex directional input), `atom_complex_inventory` (Requires multiple buttons to manage).

# Anti-Patterns
1. **Input Lag**: Any delay between the tap and the action ruins the tight feedback loop required for this mechanic.
2. **Unpredictable Physics**: If the impulse or gravity varies randomly, players cannot learn the rhythm, leading to unfair deaths.
3. **Overly Long Cooldowns**: Restricting taps too much can make the game feel unresponsive and frustrating.
