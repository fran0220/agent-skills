# Identity
- **Atom ID**: atom_distraction
- **English Name**: Distraction / Lure
- **Chinese Name**: 分散注意力/引诱
- **Category**: A+B
- **Definition**: The act of drawing an AI entity's attention away from its current patrol path or objective by creating a localized stimulus (sound, visual, or physical object), allowing the player to bypass or ambush the entity.

# Core Verb & State Machine
- **Core Verb**: Distract
- **State Diagram**:
  [Idle/Patrol] --(Stimulus Detected)--> [Investigating]
  [Investigating] --(Nothing Found & Timeout)--> [Returning]
  [Returning] --(Reached Original Path)--> [Idle/Patrol]
  [Investigating] --(Player Spotted)--> [Alert/Combat]
- **States**:
  - `Idle/Patrol`: The AI is in its default state, following a set path or standing guard.
  - `Investigating`: The AI moves towards the source of the distraction to inspect it.
  - `Returning`: The AI returns to its original position or path after finding nothing.
  - `Alert/Combat`: The AI has spotted the player and engages.
- **Transitions**:
  - `Idle/Patrol` -> `Investigating`: Triggered when a distraction stimulus (e.g., a thrown coin, a whistle) enters the AI's sensory radius.
  - `Investigating` -> `Returning`: Triggered when the AI reaches the stimulus location, finds no threat, and a specific timeout duration elapses.
  - `Returning` -> `Idle/Patrol`: Triggered when the AI successfully navigates back to its original post.
  - `Investigating` -> `Alert/Combat`: Triggered if the AI detects the player during the investigation phase.

# MDA Analysis
- **Mechanics**: The system provides the player with tools (e.g., throwable objects, sound emitters) that generate a stimulus at a specific location. AI entities have sensory radii (visual and auditory). When a stimulus occurs within a radius, the AI's state machine transitions to an investigation state, overriding its default behavior.
- **Dynamics**: Players use distractions to manipulate AI positioning, creating temporary safe zones or openings for stealth takedowns. This leads to emergent gameplay where players can chain distractions or use them to group enemies together.
- **Aesthetics**: The player feels a sense of mastery, cunning, and tension. Successfully manipulating the AI provides satisfaction and reinforces the fantasy of being a stealthy infiltrator.

# Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value (Game) | Unit |
|---|---|---|---|---|
| `stimulus_radius` | f32 | 5.0 - 20.0 | 15.0 (Hitman 3 v3.150) | meters |
| `investigation_time` | f32 | 3.0 - 10.0 | 5.0 (Metal Gear Solid V v1.12) | seconds |
| `movement_speed_modifier` | f32 | 0.5 - 1.5 | 0.8 (Hitman 3 v3.150) | multiplier |
| `cooldown` | f32 | 0.0 - 30.0 | 0.0 (Metal Gear Solid V v1.12) | seconds |
| `suspicion_increase` | f32 | 0.0 - 50.0 | 10.0 (Hitman 3 v3.150) | percentage |

# Benchmark Data
- **Hitman 3 (v3.150)**:
  - `stimulus_radius`: 15.0 meters (Coin throw auditory range)
  - `investigation_time`: 6.0 seconds
  - `movement_speed_modifier`: 0.8 (Guards walk slightly slower when investigating)
- **Metal Gear Solid V: The Phantom Pain (v1.12)**:
  - `stimulus_radius`: 20.0 meters (Empty magazine throw)
  - `investigation_time`: 5.0 seconds
  - `cooldown`: 0.0 seconds (Can throw consecutively)

# Common Variants
1. **Visual Lure**: An object that must be seen rather than heard (e.g., a shiny object, a decoy hologram).
2. **Chain Distraction**: A distraction that triggers multiple times or moves, drawing the AI along a path (e.g., a wind-up toy).
3. **Suspicious Distraction**: A distraction that immediately raises the AI's alert level upon investigation (e.g., a broken camera, a dead body).
4. **Area of Effect (AoE) Distraction**: A loud noise that distracts all enemies within a large radius (e.g., an explosion).

# Compatibility Notes
- **Compatible Atoms**: `atom_stealth_takedown` (distract to isolate for takedown), `atom_cover_movement` (distract to move between cover), `atom_line_of_sight` (manipulate vision cones).
- **Incompatible Atoms**: `atom_forced_combat` (distractions are useless if combat is mandatory).

# Anti-Patterns
1. **Overpowered Distractions**: Distractions with infinite range or no cooldown, trivializing stealth encounters.
2. **Unpredictable AI Response**: AI ignoring distractions randomly or investigating locations other than the stimulus source, leading to player frustration.
3. **Lack of Feedback**: Not providing clear visual or auditory cues that the AI has registered the distraction.
