# Gameplay Atom: Vehicle / Mount Riding

## 1. Identity
**Atom ID:** atom_vehicle_mount
**English Name:** Vehicle / Mount Riding
**Chinese Name:** 载具/坐骑骑乘
**Category:** A+B
**Definition:** The Vehicle / Mount Riding atom defines the mechanics and dynamics of a player character temporarily taking control of a secondary entity (a vehicle or a living mount) to traverse the game world. This entity typically possesses its own distinct physics, movement parameters, health pool, and control scheme, fundamentally altering the player's interaction with the environment and enemies while mounted.

## 2. Core Verb & State Machine
**Core Verb:** Ride / Drive

**State Diagram:**
[Unmounted] --(Interact)--> [Mounting]
[Mounting] --(Complete)--> [Mounted_Idle]
[Mounted_Idle] --(Input)--> [Mounted_Moving]
[Mounted_Moving] --(Stop Input)--> [Mounted_Idle]
[Mounted_Moving] --(Damage/Collision)--> [Staggered/Damaged]
[Staggered/Damaged] --(Recover)--> [Mounted_Idle]
[Mounted_Idle/Moving] --(Dismount Input)--> [Dismounting]
[Dismounting] --(Complete)--> [Unmounted]
[Any Mounted State] --(Mount Health Depleted)--> [Forced Dismount/Ragdoll]

**States and Transitions:**
- **Unmounted:** The default player state.
- **Mounting:** The transitional animation state where the player boards the vehicle or climbs onto the mount.
- **Mounted_Idle:** The player is on the mount but stationary.
- **Mounted_Moving:** The mount is actively traversing the environment (walking, galloping, driving).
- **Staggered/Damaged:** A temporary state triggered by taking damage or hitting an obstacle, potentially interrupting movement.
- **Dismounting:** The transitional state of leaving the mount voluntarily.
- **Forced Dismount/Ragdoll:** An involuntary exit from the mount due to extreme damage, mount death, or severe collision.

## 3. MDA Analysis
**Mechanics:** The system swaps the player's default movement controller with the mount's controller. It introduces new variables such as acceleration, top speed, turn radius, and stamina/fuel. The camera often pulls back to accommodate the larger entity and higher speeds. The mount may have its own hitbox and health, absorbing damage meant for the player.

**Dynamics:** Players use mounts to bypass tedious travel, escape dangerous encounters, or engage in specialized vehicular combat. The increased speed creates a dynamic of risk versus reward, as higher speeds make navigation more difficult and collisions more punishing. Resource management (stamina for horses, fuel for cars) emerges as a secondary loop during travel.

**Aesthetics:** The primary aesthetic is **Sensation** and **Fantasy**. Riding a fast mount provides a thrilling sense of speed and freedom. It also fulfills specific fantasies, such as being a cowboy on horseback or a racer in a high-performance car. There is often a feeling of empowerment as the player covers vast distances effortlessly.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value | Unit |
| :--- | :--- | :--- | :--- | :--- |
| `max_speed` | f32 | 10.0 - 50.0 | 25.0 (Mario Kart 8) | m/s |
| `acceleration` | f32 | 2.0 - 15.0 | 8.0 (GTA V) | m/s² |
| `turn_speed` | f32 | 30.0 - 180.0 | 90.0 (Breath of the Wild) | deg/s |
| `mount_health` | f32 | 50.0 - 1000.0 | 150.0 (Breath of the Wild) | HP |
| `stamina_capacity` | f32 | 3.0 - 10.0 | 5.0 (Breath of the Wild) | spurs/units |
| `mount_time` | f32 | 0.5 - 3.0 | 1.2 (GTA V) | seconds |
| `dismount_time` | f32 | 0.5 - 2.0 | 0.8 (GTA V) | seconds |
| `collision_damage_multiplier` | f32 | 0.0 - 5.0 | 2.0 (GTA V) | multiplier |

## 5. Benchmark Data
- **Mario Kart 8 Deluxe (v2.4.0):** Focuses heavily on `max_speed` (approx 25.0 m/s for medium karts) and `acceleration`. The handling model emphasizes drifting, making `turn_speed` highly variable based on state.
- **The Legend of Zelda: Breath of the Wild (v1.6.0):** Horses have distinct stats. A mid-tier horse has a `max_speed` of roughly 15.0 m/s, `stamina_capacity` of 4 spurs, and `turn_speed` of 90.0 deg/s. `mount_health` is a critical factor, typically around 150 HP.
- **Grand Theft Auto V (v1.67):** Cars have high `max_speed` (up to 40.0+ m/s) and `acceleration` (8.0 m/s²). The `collision_damage_multiplier` is significant, as crashing at high speeds can eject the player or destroy the vehicle.

## 6. Common Variants
1. **The Living Mount (e.g., Horses in RDR2):** Features autonomy. The mount might refuse to jump off cliffs, get spooked by predators, and requires bonding/feeding.
2. **The Arcade Vehicle (e.g., Mario Kart):** Highly responsive, physics-defying handling. Focuses on drifting, boosting, and item usage rather than realistic simulation.
3. **The Simulation Vehicle (e.g., Forza, SnowRunner):** Deep physics simulation including tire friction, suspension travel, and weight distribution.
4. **The Combat Mech (e.g., Titanfall):** A mount that fundamentally changes the combat paradigm, offering massive firepower and armor but reduced agility.
5. **The Glider/Flying Mount (e.g., WoW Flying Mounts):** Adds verticality, completely bypassing ground-based obstacles and enemies.

## 7. Compatibility Notes
**Commonly Pairs With:**
- `atom_ranged_combat` (Drive-by shooting, mounted archery)
- `atom_inventory_system` (Vehicles acting as mobile storage)
- `atom_fast_travel` (Mounts bridging the gap between fast travel points)

**Known Conflicts:**
- `atom_stealth_mechanics`: Mounts are typically loud and large, making stealth difficult or impossible while mounted.
- `atom_platforming`: Complex jumping puzzles are usually incompatible with the bulky movement of vehicles/mounts.

## 8. Anti-Patterns
1. **The Clunky Mount:** Designing a mount with a turn radius so wide or acceleration so slow that players prefer walking.
2. **The Invincible Tank:** Making the mount completely immune to damage in a game where combat is frequent, trivializing encounters.
3. **The Velcro Rider:** Failing to implement forced dismounts on heavy impacts, leading to immersion-breaking scenarios where a horse crashes into a wall at full speed and the rider remains perfectly seated.
