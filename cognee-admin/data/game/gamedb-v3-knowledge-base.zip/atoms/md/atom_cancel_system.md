# Gameplay Atom: Animation Cancel

## 1. Identity
- **Atom ID:** `atom_cancel_system`
- **English Name:** Animation Cancel
- **Chinese Name:** 动画取消
- **Category:** A
- **Definition:** A core action game mechanic that allows players to interrupt an ongoing animation (typically the recovery phase of an attack) with another action, such as a dodge, jump, or another attack. This reduces vulnerability time, increases game pace, and enables complex combo sequences.

## 2. Core Verb & State Machine
- **Core Verb:** Cancel

**State Diagram:**
```text
[Idle] --> (Attack Input) --> [Startup] --> [Active] --> [Recovery] --> [Idle]
                                              |              |
                                              v              v
                                        (Cancel Input during Window)
                                              |              |
                                              +------> [Cancelled] --> (New Action)
```

**States and Transitions:**
- **Idle:** The default state. Transitions to Startup upon attack input.
- **Startup:** The preparation phase of an attack. Rarely cancellable.
- **Active:** The phase where the attack deals damage. Sometimes cancellable (e.g., jump cancel on hit).
- **Recovery:** The cooldown phase after an attack. Often cancellable to bypass vulnerability.
- **Cancelled:** A transient state reached when a valid cancel input is received during a cancel window. Immediately transitions to the new action's state.

## 3. MDA Analysis
- **Mechanics:** The system defines specific time windows during an animation where alternative inputs are accepted. If an input is received, the current animation is aborted, and the new action begins immediately, sometimes consuming a resource.
- **Dynamics:** Players learn to time their inputs precisely to maximize damage per second (DPS) and maintain safety. This leads to emergent combo structures and aggressive playstyles, as players can overextend and use cancels to retreat safely.
- **Aesthetics:** Creates a feeling of mastery, fluidity, and high-speed expression. Players feel empowered and skillful when executing complex, rapid sequences that bypass normal game restrictions.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (DMC5 v1.0) | Unit |
| --- | --- | --- | --- | --- |
| `cancel_window_start` | f32 | 0.1 - 0.8 | 0.4 | normalized_time |
| `cancel_window_end` | f32 | 0.3 - 1.0 | 0.9 | normalized_time |
| `cost` | f32 | 0.0 - 100.0 | 0.0 | resource |
| `hit_stop_duration` | f32 | 0.0 - 0.5 | 0.1 | seconds |

## 5. Benchmark Data
- **Devil May Cry 5 (v1.0):** `cancel_window_start` = 0.4, `cancel_window_end` = 0.9, `cost` = 0.0. Enemy step (jump cancel) is available almost immediately upon hit.
- **Street Fighter V (Champion Edition):** `cancel_window_start` = 0.2, `cancel_window_end` = 0.5, `cost` = 0.0. Normal attacks can be cancelled into special moves during their active frames upon hitting the opponent.
- **Guilty Gear Strive (v1.0):** Roman Cancel system allows cancelling almost any state. `cost` = 50.0 (Tension), `cancel_window_start` = 0.0, `cancel_window_end` = 1.0.

## 6. Common Variants
1. **Jump Cancel (Enemy Step):** Cancelling an attack by jumping off an enemy. Resets aerial options.
2. **Dash Cancel:** Cancelling an attack's recovery with a dash to close distance or retreat.
3. **Special Cancel:** Cancelling a normal attack into a special attack (common in fighting games).
4. **Resource Cancel:** Spending a specific meter to cancel an animation that is normally uncancellable (e.g., Roman Cancel in Guilty Gear).
5. **Block Cancel:** Cancelling an attack startup or recovery by raising a shield.

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_combo_system` (relies heavily on cancels), `atom_dodge_roll` (often used as the cancelling action), `atom_hit_stop` (hit stop provides a larger real-time window to input the cancel).
- **Incompatible Atoms:** `atom_turn_based_combat` (fundamentally incompatible with real-time animation cancels), `atom_queue_based_actions` (strict queuing systems often conflict with immediate cancels).

## 8. Anti-Patterns
1. **Over-cancellability:** Making everything cancellable at any time without cost can trivialize commitment, making the game feel weightless and reducing the importance of positioning.
2. **Unclear Windows:** Lacking visual or auditory feedback for when a cancel window is active, making the mechanic feel inconsistent or frustrating to learn.
3. **Infinite Loops:** Failing to implement diminishing returns or resource costs, allowing players to trap enemies in infinite, inescapable combos.
