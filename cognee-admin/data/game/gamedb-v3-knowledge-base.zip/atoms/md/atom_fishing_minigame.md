# Gameplay Atom: Fishing Minigame

## 1. Identity
- **Atom ID:** `atom_fishing_minigame`
- **English Name:** Fishing Minigame
- **Chinese Name:** 钓鱼小游戏
- **Category:** Category C (Minigames & Sub-systems)
- **Definition:** The Fishing Minigame is a self-contained gameplay loop embedded within a larger game, where the player engages in a sequence of actions to catch aquatic creatures or items. It typically involves casting a line, waiting for a bite, and executing a skill-based or timing-based challenge to successfully reel in the catch. This atom provides a change of pace, economic benefits, and collection incentives.

## 2. Core Verb & State Machine
- **Core Verb:** "Fish" (Cast, Wait, Hook, Reel)

**State Diagram:**
```text
[Idle] --> (Cast Line) --> [Waiting]
[Waiting] --> (Fish Bites) --> [Biting]
[Biting] --> (Player Hooks) --> [Reeling]
[Biting] --> (Timeout) --> [Escaped] --> [Idle]
[Reeling] --> (Success) --> [Caught] --> [Idle]
[Reeling] --> (Failure) --> [Escaped] --> [Idle]
```

**States and Transitions:**
- **Idle:** The player is standing near a body of water with a fishing rod equipped.
- **Waiting:** The bobber is in the water. The system waits for a randomized timer to trigger a bite.
- **Biting:** A fish has interacted with the bait. The player has a short window to react.
- **Reeling:** The active minigame phase where the player must balance tension, keep a target in a zone, or mash buttons.
- **Caught:** The minigame is won, and the reward is granted.
- **Escaped:** The minigame is lost, either by missing the hook window or failing the reeling phase.

## 3. MDA Analysis
- **Mechanics:** The system utilizes random number generation for bite timers and fish selection based on location, time, and bait. The reeling phase employs physics-like variables such as line tension, fish stamina, and player input force.
- **Dynamics:** Players learn to optimize their fishing spots, bait choices, and reaction times. The tension mechanic creates a push-and-pull dynamic where players must alternate between aggressive reeling and cautious waiting to avoid snapping the line.
- **Aesthetics:** The atom evokes feelings of relaxation during the waiting phase, followed by sudden excitement and focus during the biting and reeling phases. It satisfies the player's desire for collection, completionism, and mastery of a distinct skill.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Stardew Valley v1.5) | Unit |
| :--- | :--- | :--- | :--- | :--- |
| `bite_delay_min` | `f32` | 1.0 - 5.0 | 2.0 | Seconds |
| `bite_delay_max` | `f32` | 5.0 - 20.0 | 10.0 | Seconds |
| `hook_window` | `f32` | 0.3 - 1.5 | 0.75 | Seconds |
| `fish_speed` | `f32` | 10.0 - 100.0 | 40.0 | Units/sec |
| `bar_size` | `f32` | 10.0 - 50.0 | 25.0 | Percentage |
| `tension_increase_rate` | `f32` | 5.0 - 30.0 | 15.0 | Units/sec |
| `tension_decrease_rate` | `f32` | 10.0 - 40.0 | 20.0 | Units/sec |
| `max_tension` | `f32` | 100.0 | 100.0 | Points |

## 5. Benchmark Data
- **Stardew Valley (v1.5):**
  - The minigame uses a "keep the fish in the bar" mechanic.
  - `hook_window`: ~0.75 seconds.
  - `max_tension` (Progress Bar): 100 points to catch, drops to 0 to lose.
  - Fish behavior profiles dictate movement patterns (e.g., Dart, Smooth, Sinker).
- **The Legend of Zelda: Ocarina of Time (v1.0):**
  - Uses a tension-based reeling mechanic.
  - `bite_delay`: Highly variable based on fish proximity to the lure.
  - `line_tension_limit`: Exceeding this causes the line to snap instantly.
- **Animal Crossing: New Horizons (v2.0):**
  - Purely timing and audio-visual based.
  - `hook_window`: Varies by fish rarity, often as tight as 0.3 seconds for rare fish.
  - No reeling phase; hooking successfully guarantees the catch.

## 6. Common Variants
1. **The Bar-Keeper (Stardew Valley):** The player controls a vertical bar and must keep the moving fish icon inside it to build progress.
2. **The Tension Manager (Final Fantasy XV):** The player reels in the fish but must stop when the line tension gets too high or the fish changes direction.
3. **The Quick-Time Event (Animal Crossing):** A simple reaction test where the player presses a button exactly when the bobber goes under, with no subsequent struggle.
4. **The Rhythm/Mash (Persona 5):** The player must mash buttons or hit specific inputs in time to reduce the fish's stamina.

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_inventory_management`, `atom_crafting_system`, `atom_economy_trading`, `atom_day_night_cycle` (fish availability changes by time).
- **Incompatible Atoms:** `atom_fast_paced_combat` (fishing requires the player to be stationary and focused, which conflicts with high-mobility combat unless separated into a safe zone).

## 8. Anti-Patterns
1. **Overly Punishing RNG:** Making the bite timer too long or the fish appearance rate too low, leading to player boredom and frustration.
2. **Unclear Feedback:** Failing to provide clear visual or audio cues for when the line is about to snap or when the hook window is active.
3. **Lack of Progression:** Keeping the difficulty static throughout the game without offering better rods, bait, or skills to tackle harder challenges.
