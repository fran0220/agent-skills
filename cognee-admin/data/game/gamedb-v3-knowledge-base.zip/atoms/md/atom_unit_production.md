# Unit Production Queue (单位生产队列)

## 1. Identity
The **atom_unit_production** gameplay atom, known in English as the Unit Production Queue and in Chinese as 单位生产队列, belongs to the G/H category of gameplay mechanics, which typically encompasses resource management and base building. This atom defines a system where players spend accumulated resources to queue the creation of units over a specified period of time. By managing production capacity and timing, players can strategically build an army or workforce to achieve their objectives.

## 2. Core Verb & State Machine
The primary player verbs associated with this atom are **Queue** and **Cancel**. Players interact with production facilities to issue these commands, driving the state machine of the production queue.

The state diagram can be visualized as follows:
[Idle] --(Queue Unit)--> [Producing]
[Producing] --(Time Elapsed)--> [Completed] --> [Idle]
[Producing] --(Cancel)--> [Idle]
[Producing] --(Queue Another)--> [Producing (Queued)]

The system operates across several distinct states. The `Idle` state indicates that the production facility is inactive and ready to receive orders. When a player queues a unit, the facility enters the `Producing` state, actively building the requested unit. If additional units are queued while one is already in production, they enter the `Queued` state, waiting in line for their turn. Finally, the `Completed` state is reached when a unit is finished and spawned into the game world.

Transitions between these states are triggered by specific events. The transition from `Idle` to `Producing` is initiated by the player queuing a unit, which requires the necessary resources to be available and deducted. The transition from `Producing` to `Completed` occurs automatically when the production timer reaches zero. If a player decides to halt production, they can trigger the transition from `Producing` to `Idle` by canceling the current order, often resulting in a partial or full refund of resources. Queuing additional units while in the `Producing` state triggers the transition to `Queued`.

## 3. MDA Analysis
From a **Mechanics** perspective, the Unit Production Queue system requires players to select a production building, choose a specific unit type to build, pay the associated resource cost upfront, and wait for a predetermined duration. Units are produced sequentially, meaning that only one unit can be actively built at a time per facility, while others wait in the queue.

The **Dynamics** of this system emerge from the need for players to balance their economy, specifically resource gathering, with their production capacity. Queuing too many units at once ties up valuable resources that could potentially be used elsewhere, such as for upgrades or expanding the base. Conversely, leaving production queues empty wastes potential production time, putting the player at a disadvantage against opponents who are constantly building their forces.

The **Aesthetics** of the Unit Production Queue evoke feelings of anticipation, strategic planning, and the ultimate satisfaction of amassing a large, powerful force. Players experience a sense of progression and accomplishment as they watch their army grow from a few basic units to a formidable military machine.

## 4. Parameter Space
The following table outlines the tunable parameters that govern the behavior of the Unit Production Queue atom:

| Parameter Name | Type | Typical Range | Benchmark Value | Unit |
|---|---|---|---|---|
| `build_time` | f32 | 5.0 - 120.0 | 12.0 (StarCraft II Marine) | seconds |
| `cost_minerals` | u32 | 25 - 400 | 50 (StarCraft II Marine) | resources |
| `cost_gas` | u32 | 0 - 300 | 0 (StarCraft II Marine) | resources |
| `max_queue_size` | u32 | 1 - 15 | 5 (StarCraft II Barracks) | units |
| `refund_ratio` | f32 | 0.0 - 1.0 | 1.0 (StarCraft II) | ratio |

## 5. Benchmark Data
To provide concrete examples of how this atom is implemented in successful games, we can look at benchmark data from representative titles.

In **StarCraft II (v5.0)**, the production of a basic Marine unit requires 50 Minerals and takes 12 seconds to build. The Barracks, the facility responsible for producing Marines, has a maximum queue size of 5. If a player cancels a unit in production or in the queue, they receive a 100% refund of the resources spent.

Similarly, in **Age of Empires II: Definitive Edition (v101.102)**, producing a Militia unit costs 60 Food and 20 Gold, with a build time of 21 seconds. The Barracks in this game allows for a larger maximum queue size of 15 units. As with StarCraft II, canceling a queued unit provides a full 100% refund of the resources.

## 6. Common Variants
The Unit Production Queue atom can be adapted and modified to create various gameplay experiences. Some common variants include:

**Parallel Production**: In some games, such as Supreme Commander, multiple units can be produced simultaneously from a single building, provided the player has sufficient resources and energy to support the parallel construction.

**Continuous Production (Rally Points)**: This variant allows units to be automatically queued and produced as long as the player has the necessary resources available. This reduces the micromanagement required to keep production facilities active.

**Batch Production**: Games like StarCraft, specifically with the Zerg race's larvae mechanic, allow players to produce multiple units at once for a discounted time or cost, encouraging burst production strategies.

**Global Queue**: Instead of managing production on a per-building basis, some games, like the Command & Conquer series, utilize a global production queue where players manage all unit creation from a centralized interface.

## 7. Compatibility Notes
The Unit Production Queue atom pairs exceptionally well with several other gameplay systems. It is highly compatible with the `atom_resource_gathering` system, as the resources collected are directly used to fuel unit production. It also integrates seamlessly with the `atom_tech_tree` system, where unlocking new technologies grants access to more advanced units to queue. Furthermore, it works in tandem with the `atom_population_cap` system, which limits the total number of units a player can have at any given time, adding another layer of strategic resource management.

However, this atom may conflict with certain design paradigms. It is generally incompatible with instant-spawn systems, where units appear immediately upon purchase without a build time. It also clashes with deck-building mechanics, where units are played directly from a hand of cards rather than being produced over time from a facility.

## 8. Anti-Patterns
When implementing the Unit Production Queue atom, designers should be wary of several common pitfalls:

**Hidden Queues**: Failing to clearly communicate to the player what is currently being produced, how long it will take, and what is waiting in the queue can lead to frustration and a lack of strategic control.

**No Cancel Option**: Forcing players to commit to a long production time without the ability to change their mind and recover resources can be overly punishing and discourage experimentation or adapting to changing battlefield conditions.

**Infinite Queues**: Allowing players to queue an unlimited number of units can lead to massive resource hoarding and a lack of active management, detracting from the core gameplay loop of balancing economy and production.
