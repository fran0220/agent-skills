# Gameplay Atom: Branching Dialogue

## 1. Identity
The **atom_branching_dialogue** (English Name: Branching Dialogue, Chinese Name: 分支对话) belongs to the E or F category, representing a core narrative and interaction mechanic. Branching Dialogue is a narrative mechanic where the player is presented with multiple dialogue options during a conversation, and their choices determine the flow of the conversation, the information revealed, and potentially the outcome of the interaction or the broader game state. This atom forms the backbone of player agency in narrative-driven games, allowing players to express their character's personality, gather information selectively, and influence the game world through social interaction rather than physical action.

## 2. Core Verb & State Machine
The primary player verb associated with this atom is **Choose** (Select a dialogue option). The player actively evaluates the presented text options and makes a selection that drives the conversation forward.

The state diagram for a branching dialogue system can be conceptualized as follows:
`Idle` -> `Listening` -> `Choosing` -> `Listening` -> `End`

The system operates through several distinct states. The `Idle` state represents the default condition before any conversation has been initiated. Once a conversation begins, the system transitions to the `Listening` state, where the player is passively receiving information from the non-player character (NPC) through text, audio, or both. Following the NPC's delivery, the system enters the `Choosing` state, presenting the player with a set of available responses. The player evaluates these options and makes a selection. This selection triggers a transition back to the `Listening` state as the NPC responds to the chosen dialogue. Alternatively, if the player selects an option designed to terminate the conversation, the system transitions to the `End` state, concluding the interaction and returning the player to the standard gameplay loop.

## 3. MDA Analysis
**Mechanics**: At its core, the branching dialogue system presents a list of text options to the player. Each option is intrinsically linked to a specific node within a larger, often complex, dialogue tree data structure. When the player selects an option, the system traverses the tree to the corresponding node. This traversal triggers new NPC dialogue, updates internal game variables (such as relationship scores, quest progression states, or morality alignments), and potentially unlocks or locks future dialogue branches. The mechanics rely heavily on conditional logic to determine which options are available based on the player's previous choices, character stats, or inventory items.

**Dynamics**: The mechanics of branching dialogue give rise to several emergent player behaviors. Players actively evaluate the presented options based on their understanding of the NPC's personality, their own overarching goals, and the potential short-term and long-term consequences of their words. This evaluation process often leads to behaviors such as "save scumming" (saving the game before a conversation and reloading if the outcome is undesirable) to explore different narrative branches. Furthermore, players often engage in role-playing, consistently choosing options that align with a specific character archetype (e.g., the noble hero, the ruthless mercenary) rather than simply choosing the most mechanically advantageous option. Players also learn to carefully manage relationships with multiple NPCs, balancing their responses to appease different factions or individuals.

**Aesthetics**: The primary aesthetic evoked by branching dialogue is Narrative (Drama) and Expression. Players feel a profound sense of agency and immersion as they actively shape the story and express their character's unique personality through their choices. The system can evoke a wide range of emotions, from the satisfaction of successfully persuading a hostile NPC to the tension of navigating a delicate political negotiation. Furthermore, the system can generate feelings of regret or guilt when a seemingly innocuous choice leads to unforeseen negative consequences, reinforcing the weight of the player's decisions within the game world.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Game) | Unit |
| :--- | :--- | :--- | :--- | :--- |
| `max_options` | u32 | 2 - 6 | 6 (Mass Effect Legendary Edition) | count |
| `time_limit` | f32 | 0.0 - 30.0 | 0.0 (Baldur's Gate 3 v4.1) | seconds |
| `skill_check_threshold` | u32 | 1 - 20 | 10 (Disco Elysium The Final Cut) | points |
| `relationship_impact` | f32 | -10.0 - 10.0 | 5.0 (Dragon Age: Origins) | points |
| `default_option_index` | u32 | 0 - 5 | 0 (The Witcher 3: Wild Hunt) | index |

## 5. Benchmark Data
In **Mass Effect (Legendary Edition)**, the `max_options` parameter is typically set to 6. The game utilizes a distinctive "dialogue wheel" interface, where options are mapped to specific positions on the wheel. For instance, "Paragon" (diplomatic/heroic) options are consistently placed in the top right position, while "Renegade" (aggressive/ruthless) options are placed in the bottom right. This spatial consistency allows players to quickly identify the tone of an option without reading the full text.

**Disco Elysium (The Final Cut)** heavily relies on the `skill_check_threshold` parameter. While the threshold varies wildly depending on the specific situation and the player's current stats, a standard medium difficulty check might be set around 10. The game distinguishes itself by integrating hidden rolls and passive skill checks directly into the dialogue flow, often revealing new information or altering the available options without explicit player input.

In **Baldur's Gate 3 (v4.1)**, the `time_limit` parameter is universally set to 0.0. Conversations are entirely untimed, allowing players an indefinite amount of time to carefully consider their options, consult with their party members, and even utilize multiplayer voting systems to reach a consensus on the best course of action. This design choice prioritizes strategic decision-making and cooperative play over high-pressure, split-second reactions.

## 6. Common Variants
**Timed Choices**: In this variant, the player is given a strictly limited amount of time to select a dialogue option. If the timer expires before a selection is made, the game typically defaults to silence or a neutral response. This variant adds significant pressure to conversations, simulating the real-time nature of actual dialogue and forcing players to rely on instinct rather than careful calculation. A prominent example is *The Walking Dead* series by Telltale Games.

**Tone Indicators**: To mitigate the risk of players misinterpreting the intent behind a dialogue option, some games accompany the text with icons or explicit labels indicating the tone of the response (e.g., aggressive, sarcastic, diplomatic, flirtatious). This ensures that the player character's delivery matches the player's expectations. *Dragon Age II* is well-known for its use of tone icons in the center of its dialogue wheel.

**Interruption**: This variant allows the player to interrupt an NPC mid-sentence by triggering a specific action or selecting a time-sensitive dialogue choice. This mechanic can be used to abruptly end a conversation, seize the initiative in an argument, or perform a sudden physical action. The "interrupt" prompts in *Mass Effect 2* and *Mass Effect 3* are classic examples of this variant.

**Skill-Gated Options**: In many role-playing games, certain dialogue options are only visible or selectable if the player character meets specific statistical or skill requirements. For example, a "Persuasion" option might require a high Charisma score, while a "Tech" option might require a high Intelligence score. This variant rewards players for investing in specific character builds and encourages diverse approaches to problem-solving. *Fallout: New Vegas* extensively utilizes skill-gated dialogue options.

## 7. Compatibility Notes
The Branching Dialogue atom is highly compatible with several other core systems. It pairs naturally with `atom_relationship_system`, as dialogue choices are the primary method for influencing NPC affinity and unlocking romance or rivalry paths. It is also deeply intertwined with `atom_quest_system`, where dialogue choices frequently serve as the triggers for advancing quest stages, accepting new tasks, or resolving conflicts. Furthermore, it is often linked to `atom_morality_system`, where specific choices contribute to the player character's overall moral alignment (e.g., good vs. evil, law vs. chaos).

Conversely, Branching Dialogue is fundamentally incompatible with `atom_linear_cutscene`. If a narrative sequence is designed to be entirely pre-determined and unalterable by the player, the inclusion of branching options is logically impossible. The two atoms represent opposing approaches to narrative delivery: interactive agency versus authored cinematic presentation.

## 8. Anti-Patterns
**False Choices**: One of the most common and frustrating anti-patterns is presenting the player with multiple dialogue options that all ultimately lead to the exact same outcome and identical NPC response. This design flaw breaks the illusion of player agency, making the choices feel meaningless and the interaction superficial.

**Unclear Consequences**: Another significant issue arises when the text of a dialogue option does not accurately reflect what the player character will actually say or do. If a player selects an option expecting a mild disagreement but the character delivers a furious insult, the resulting disconnect can lead to severe player frustration and a breakdown of immersion.

**Overwhelming Options**: Presenting the player with an excessive number of dialogue choices at once can cause "analysis paralysis." When faced with too many options, players may struggle to evaluate the nuances of each choice, slowing down the pacing of the narrative and transforming a dynamic conversation into a tedious reading exercise.
