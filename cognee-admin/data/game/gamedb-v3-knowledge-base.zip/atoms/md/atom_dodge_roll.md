# Gameplay Atom: Dodge Roll / Dash

## 1. Identity
- **Atom ID**: atom_dodge_roll
- **English Name**: Dodge Roll / Dash
- **Chinese Name**: 翻滚/闪避
- **Category**: A (Core Movement/Combat)
- **Definition**: A rapid, short-distance movement mechanic that typically grants temporary invulnerability (i-frames) or repositioning advantages, allowing the player to evade incoming attacks or traverse hazards.

## 2. Core Verb & State Machine
- **Core Verb**: Evade (Dodge/Dash)
- **State Diagram**:
  [Idle/Moving] -> (Input Dodge) -> [Startup] -> [Active (I-frames)] -> [Recovery] -> [Idle/Moving]
- **States**:
  - **Idle/Moving**: The default state where the player can initiate the dodge.
  - **Startup**: A brief pre-action phase before the invulnerability or rapid movement begins.
  - **Active (I-frames)**: The core phase where the character moves rapidly and is typically immune to damage.
  - **Recovery**: The post-action phase where the character decelerates and is vulnerable before returning to the default state.
- **Transitions**:
  - Idle/Moving -> Startup: Triggered by the dodge input (e.g., pressing the dodge button).
  - Startup -> Active: Automatic transition after the startup duration elapses.
  - Active -> Recovery: Automatic transition after the active duration elapses.
  - Recovery -> Idle/Moving: Automatic transition after the recovery duration elapses.

## 3. MDA Analysis
- **Mechanics**: The system applies a velocity vector in the input direction, temporarily disables hurtboxes (granting i-frames), and locks out other inputs (except specific cancels) for a set duration. It may consume a resource like stamina or have a cooldown.
- **Dynamics**: Players learn enemy attack timings to trigger the dodge at the precise moment, creating a rhythm of baiting attacks and punishing during the enemy's recovery. It encourages aggressive positioning.
- **Aesthetics**: Creates a feeling of mastery, tension, and relief. Successfully dodging a massive attack by a fraction of a second feels highly rewarding and empowering.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Dark Souls III v1.15) | Unit |
| --- | --- | --- | --- | --- |
| `startup_frames` | u32 | 0 - 10 | 0 | frames (at 60fps) |
| `active_frames` | u32 | 5 - 20 | 13 | frames (at 60fps) |
| `recovery_frames` | u32 | 10 - 30 | 21 | frames (at 60fps) |
| `distance` | f32 | 2.0 - 10.0 | 4.5 | meters |
| `stamina_cost` | f32 | 0.0 - 50.0 | 15.0 | points |
| `cooldown` | f32 | 0.0 - 2.0 | 0.0 | seconds |

## 5. Benchmark Data
- **Dark Souls III (v1.15)**:
  - `startup_frames`: 0
  - `active_frames`: 13 (Fast Roll, <30% equip load)
  - `recovery_frames`: 21
  - `stamina_cost`: 15.0
- **Hades (v1.38290)**:
  - `startup_frames`: 0
  - `active_frames`: ~10 (Dash)
  - `recovery_frames`: ~5
  - `distance`: ~4.0
  - `cooldown`: 0.0 (can chain up to 2 dashes)
- **Bayonetta (PC Port)**:
  - `startup_frames`: 0
  - `active_frames`: 15
  - `recovery_frames`: 10
  - `distance`: 5.0
  - Note: Triggers "Witch Time" if executed perfectly.

## 6. Common Variants
1. **Directional Dash**: A quick translation without changing the character's facing direction, common in 2D platformers or top-down shooters (e.g., Hades).
2. **Perfect Dodge**: Grants additional benefits (like slowing time or buffing damage) if timed exactly with an incoming attack (e.g., Bayonetta's Witch Time, Zelda: Breath of the Wild's Flurry Rush).
3. **Blink/Teleport**: Instantaneous repositioning without traveling through the intermediate space, bypassing physical obstacles or hitboxes entirely (e.g., Tracer in Overwatch).
4. **Weight-Based Roll**: The effectiveness (i-frames, distance, recovery) scales inversely with the character's equipment load (e.g., Dark Souls series).

## 7. Compatibility Notes
- **Compatible Atoms**: `atom_melee_attack` (dodge attacks), `atom_stamina_system` (resource management), `atom_parry` (alternative defensive option).
- **Incompatible Atoms**: `atom_heavy_armor_lock` (mechanics that strictly forbid rapid movement), `atom_turn_based_grid` (unless adapted to grid snapping).

## 8. Anti-Patterns
1. **Excessive I-frames**: Making the active window too large trivializes enemy encounters, removing the need for precise timing.
2. **Lack of Recovery**: Allowing players to spam the dodge infinitely without a stamina cost or recovery frames breaks the combat loop and positioning challenges.
3. **Unclear Visual Feedback**: Failing to visually communicate when the character is invulnerable versus vulnerable leads to player frustration when they get hit "unfairly."
