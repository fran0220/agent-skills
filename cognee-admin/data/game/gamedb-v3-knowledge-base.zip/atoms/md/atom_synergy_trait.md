# Gameplay Atom: Synergy / Trait System (羁绊/特质系统)

## 1. Identity
- **Atom ID:** atom_synergy_trait
- **English Name:** Synergy / Trait System
- **Chinese Name:** 羁绊/特质系统
- **Category:** E or F (Progression / Meta-Game)
- **Definition:** A system where combining multiple distinct entities (such as characters, items, or cards) that share a common attribute (trait, faction, class) unlocks cumulative bonuses or new mechanics, encouraging strategic composition building.

## 2. Core Verb & State Machine
- **Core Verb:** Collect & Combine (收集与组合)
- **State Diagram:**
  - [Inactive] -> (Add entity with trait) -> [Active Tier 1]
  - [Active Tier 1] -> (Add more entities) -> [Active Tier 2]
  - [Active Tier 2] -> (Remove entity) -> [Active Tier 1]
  - [Active Tier X] -> (Remove all entities) -> [Inactive]
- **States:**
  - `Inactive`: The trait has no effect because the minimum threshold of entities is not met.
  - `Active Tier N`: The trait provides a specific level of bonus based on the number of unique entities present.
- **Transitions:**
  - `Add Entity`: Increases the count of a specific trait. If a threshold is reached, transitions to a higher active tier.
  - `Remove Entity`: Decreases the count of a specific trait. If the count falls below a threshold, transitions to a lower active tier or inactive state.

## 3. MDA Analysis
- **Mechanics:** The game tracks the presence of unique entities on the board or in the player's inventory. Each entity possesses one or more tags (traits). The system aggregates these tags and checks them against predefined thresholds. When a threshold is met, a global or local buff is applied to the player's units.
- **Dynamics:** Players are driven to draft or collect specific combinations of units rather than just picking the individually strongest ones. This creates a dynamic puzzle of optimizing board space, managing economy to find specific pieces, and pivoting strategies based on what entities are available (RNG).
- **Aesthetics:** 
  - *Discovery:* Finding new and powerful combinations.
  - *Expression:* Building a unique team composition.
  - *Challenge:* Balancing short-term survival with long-term synergy goals.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (TFT Set 9) | Unit |
| :--- | :--- | :--- | :--- | :--- |
| `trait_thresholds` | Array of Int | [2, 9] | [3, 5, 7, 9] (Demacia) | Count |
| `bonus_magnitude` | Float | [0.05, 2.0] | 0.15 (15% Armor/MR) | Multiplier |
| `unique_requirement` | Boolean | True/False | True | Boolean |
| `max_traits_per_entity` | Int | [1, 3] | 2 | Count |

## 5. Benchmark Data
- **Teamfight Tactics (TFT) Set 9:**
  - *Trait:* Demacia
  - *Thresholds:* 3, 5, 7, 9
  - *Effect:* Grants Elite status to strongest Demacians, providing Radiant items and Armor/MR.
- **Dota Underlords (Version 1.0):**
  - *Trait:* Knight
  - *Thresholds:* 2, 4, 6
  - *Effect:* Knights take 15%, 20%, 25% less physical and magic damage, increased when standing next to another Knight.

## 6. Common Variants
1. **Threshold-Based (Auto Battlers):** Requires exact numbers of unique units (e.g., 3/6/9) to unlock tiers of power.
2. **Set Bonuses (RPGs):** Equipping 2, 4, or 6 pieces of the same armor set grants escalating passive bonuses (e.g., Diablo III, World of Warcraft).
3. **Combo Mechanics (Card Games):** Playing cards of the same suit or faction in sequence triggers additional effects (e.g., Gwent, Slay the Spire).
4. **Adjacency Synergy (Strategy Games):** Placing buildings or units next to each other grants bonuses based on their types (e.g., Civilization VI districts).

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_drafting` (Drafting System), `atom_inventory_management` (Inventory Management), `atom_unit_placement` (Grid Placement).
- **Incompatible Atoms:** `atom_lone_wolf` (Systems that heavily penalize having multiple units or reward having only one).

## 8. Anti-Patterns
1. **Forced Compositions:** Making synergies so powerful that players are forced to play specific, rigid compositions, reducing strategic variety.
2. **Hidden Information:** Not clearly displaying which units have which traits or what the synergy bonuses are, leading to player frustration.
3. **Over-Complexity:** Having too many traits with overlapping or confusing effects, making it impossible for players to parse the board state.
