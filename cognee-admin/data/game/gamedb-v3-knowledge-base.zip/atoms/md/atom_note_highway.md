# Gameplay Atom: Note Highway (音符轨道)

## 1. Identity
**Atom ID:** `atom_note_highway`
**English Name:** Note Highway
**Chinese Name:** 音符轨道
**Category:** Rhythm / Timing (G/H)
**Definition:** A scrolling interface where visual indicators (notes) move along a fixed path toward a target zone, requiring the player to perform specific actions in sync with the music when the notes reach the target.

## 2. Core Verb & State Machine
**Core Verb:** `Hit` / `Tap` / `Hold` (in time with the music)

**State Diagram:**
```text
[Idle] --> (Note Spawns) --> [Approaching]
[Approaching] --> (Player Hits in Time) --> [Hit Success]
[Approaching] --> (Player Misses/Time Expires) --> [Miss]
[Hit Success] --> (Despawn) --> [Idle]
[Miss] --> (Despawn) --> [Idle]
```

**States and Transitions:**
- **Idle:** The highway is empty or waiting for the next note.
- **Approaching:** A note has spawned and is moving toward the hit zone.
- **Hit Success:** The player successfully interacted with the note within the timing window.
- **Miss:** The player failed to interact with the note, or interacted outside the timing window.

## 3. MDA Analysis
**Mechanics:** The system spawns notes at specific timestamps corresponding to musical cues. These notes travel at a set speed along a track. The system evaluates player input based on timing accuracy relative to the note's position in the hit zone.
**Dynamics:** Players learn to read upcoming patterns, anticipate rhythms, and develop muscle memory. The increasing speed and density of notes create a flow state and physical tension.
**Aesthetics:** A sense of musical performance, rhythmic satisfaction, and kinetic feedback. Players feel like they are actively creating or participating in the music.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value | Unit |
|---|---|---|---|---|
| `scroll_speed` | f32 | 1.0 - 10.0 | 5.0 (Guitar Hero III) | units/sec |
| `hit_window_perfect` | f32 | 16.0 - 50.0 | 33.0 (Beat Saber v1.20) | ms |
| `hit_window_good` | f32 | 50.0 - 150.0 | 100.0 (OSU! Standard) | ms |
| `note_density` | f32 | 1.0 - 20.0 | 8.0 (Guitar Hero III) | notes/sec |
| `highway_length` | f32 | 10.0 - 50.0 | 20.0 (Beat Saber v1.20) | units |

## 5. Benchmark Data
- **Guitar Hero III (v1.0):** `scroll_speed` = 5.0 units/sec, `note_density` = 8.0 notes/sec. The game uses a fixed perspective 3D highway.
- **Beat Saber (v1.20):** `hit_window_perfect` = 33.0 ms, `highway_length` = 20.0 units. The highway is in VR space, emphasizing physical movement.
- **OSU! (Standard):** `hit_window_good` = 100.0 ms. While not a traditional linear highway, the approach circles serve the exact same mechanical purpose of telegraphing timing.

## 6. Common Variants
1. **Vertical Scrolling (DDR, Mania):** Notes fall from top to bottom or rise from bottom to top.
2. **3D Perspective (Guitar Hero, Rock Band):** The highway extends into the screen, giving a sense of depth and foreshortening.
3. **Curved/Dynamic Highway (Cytus, Phigros):** The track itself moves, rotates, or changes shape during gameplay.
4. **VR Spatial Highway (Beat Saber):** Notes fly directly at the player's head/body in 3D space.

## 7. Compatibility Notes
**Compatible Atoms:**
- `atom_combo_multiplier`: Rewards consecutive successful hits.
- `atom_health_bar`: Depletes on misses, regenerates on hits.
- `atom_fever_mode`: A temporary state of increased scoring triggered by sustained performance.

**Incompatible Atoms:**
- `atom_turn_based_combat`: The real-time, continuous nature of the note highway directly conflicts with discrete, turn-based pacing.

## 8. Anti-Patterns
1. **Poor Readability:** Using colors or shapes that blend into the background, making it impossible for players to anticipate notes.
2. **Unfair Timing Windows:** Setting the `hit_window_perfect` smaller than the hardware input latency or display refresh rate allows.
3. **Desynchronization:** Visual note arrival not perfectly matching the audio cues, destroying the core rhythmic feedback loop.
