# Gameplay Atom: Swap Match-3

## 1. Identity
The `atom_swap_match3` gameplay atom, known in English as "Swap Match-3" and in Chinese as "交换三消", belongs to Category C. It is defined as a core puzzle mechanic where the player swaps the positions of two adjacent elements on a grid to form a line (horizontal or vertical) of three or more identical elements. This action causes the matched elements to disappear, allowing new elements to fall into place from above.

## 2. Core Verb & State Machine
The core verb of this atom is **Swap**. The state machine governing this mechanic involves several distinct states and transitions.

**State Diagram:**
```text
[Idle] --(Player selects element A)--> [Element A Selected]
[Element A Selected] --(Player selects adjacent element B)--> [Swapping]
[Swapping] --(Match found)--> [Matching]
[Swapping] --(No match found)--> [Reverting Swap]
[Reverting Swap] --(Animation ends)--> [Idle]
[Matching] --(Elements destroyed)--> [Falling]
[Falling] --(Grid settled)--> [Checking Cascades]
[Checking Cascades] --(Match found)--> [Matching]
[Checking Cascades] --(No match found)--> [Idle]
```

The system begins in the **Idle** state. When the player inputs a selection, it transitions to **Element A Selected**. Selecting a valid adjacent element triggers the **Swapping** state. From here, the game logic checks for a valid match of three or more elements. If a match is found, the state becomes **Matching**; otherwise, it enters **Reverting Swap**, which returns to **Idle** upon completion of the revert animation. The **Matching** state leads to the destruction of elements, transitioning to **Falling** as gravity settles the remaining elements. Once settled, the system enters **Checking Cascades**. If new matches are formed, it loops back to **Matching**; if not, it returns to the **Idle** state.

## 3. MDA Analysis
**Mechanics:** The system defines a grid filled with elements of various types. The player can swap adjacent elements. If a swap results in a line of three or more identical elements, they are removed, a score is awarded, and elements above fall down to fill the gaps. This falling action can potentially create chain reactions, commonly referred to as cascades.

**Dynamics:** Players learn to look for patterns and potential cascades. They may set up complex chain reactions by carefully planning their swaps. The random nature of falling elements introduces unpredictability and excitement, encouraging strategic thinking and pattern recognition.

**Aesthetics:** The aesthetic experience is driven by Sensation, Challenge, and Discovery. Sensation is provided through satisfying visual and audio feedback from matches and cascades. Challenge arises from solving the puzzle within move or time limits. Discovery is experienced when players find hidden patterns or successfully execute complex chain reactions.

## 4. Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value (Game/Version) | Unit |
|---|---|---|---|---|
| `grid_width` | u32 | 5 - 10 | 9 (Candy Crush Saga v1.2) | cells |
| `grid_height` | u32 | 5 - 10 | 9 (Candy Crush Saga v1.2) | cells |
| `element_types` | u32 | 4 - 7 | 6 (Candy Crush Saga v1.2) | types |
| `swap_duration` | f32 | 0.1 - 0.5 | 0.25 (Bejeweled Blitz v1.0) | seconds |
| `fall_speed` | f32 | 5.0 - 20.0 | 10.0 (Candy Crush Saga v1.2) | cells/second |
| `match_score` | u32 | 10 - 100 | 60 (Candy Crush Saga v1.2) | points |

## 5. Benchmark Data
In **Candy Crush Saga (v1.2)**, the standard grid is 9x9 cells with 6 different element types. The swap animation takes 0.3 seconds, and elements fall at a speed of 10.0 cells per second. Each basic match awards 60 points.

In **Bejeweled Blitz (v1.0)**, the grid is slightly smaller at 8x8 cells, but features 7 element types. The gameplay is faster, with a swap duration of 0.25 seconds and a fall speed of 15.0 cells per second. A basic match in this game awards 10 points.

## 6. Common Variants
Several variations of this core atom exist in different games. **Diagonal Swapping** allows players to swap elements diagonally as well as orthogonally. **Free Swapping** permits swapping any two elements on the board, not just adjacent ones, though this is often limited by a cooldown or resource. **Gravity Variations** involve elements falling in different directions, such as upwards, sideways, or towards the center. **Hexagonal Grids** change the adjacency rules entirely by using a hexagonal layout instead of a square one. Finally, **Match-4/5 Specials** create special power-up elements when matching four or five elements instead of simply clearing them.

## 7. Compatibility Notes
This atom pairs exceptionally well with several other mechanics. It is highly compatible with `atom_powerup_creation`, `atom_score_multiplier`, `atom_time_limit`, `atom_move_limit`, and `atom_obstacle_block`.

However, it has known conflicts with certain mechanics. It is generally incompatible with `atom_physics_simulation`, as the strict grid-based logic conflicts with free-form physics. It also conflicts with `atom_continuous_movement`, which disrupts the discrete, turn-based nature of the swapping mechanic.

## 8. Anti-Patterns
When implementing this atom, designers should avoid several common mistakes. **Too Many Element Types** makes it statistically unlikely to find matches, leading to frustration and dead ends. **Slow Animations** for swapping, matching, or falling break the flow of the game and make it feel unresponsive. Lastly, **Unpredictable Cascades** can be problematic; while cascades are fun, if they are entirely random and cannot be planned for, the game feels less like a puzzle and more like a slot machine.
