# Gameplay Atom: Crouch Slide

## 1. Identity
- **Atom ID:** `atom_crouch_slide`
- **English Name:** Crouch Slide
- **Chinese Name:** 蹲滑
- **Category:** A
- **Definition:** A movement mechanic where the player character transitions from a running or sprinting state into a low-profile sliding state, maintaining or temporarily increasing momentum while reducing their vertical hitbox.

## 2. Core Verb & State Machine
- **Core Verb:** Slide
- **State Diagram:**
  ```text
  [Idle/Walk] --(Sprint)--> [Sprint]
  [Sprint] --(Crouch Input)--> [Slide]
  [Slide] --(Velocity < Threshold)--> [Crouch]
  [Slide] --(Jump Input)--> [Jump]
  [Slide] --(Release Crouch)--> [Sprint/Run]
  ```
- **States:**
  - `Sprint`: High-speed ground movement.
  - `Slide`: Low-profile movement with decreasing velocity over time (or sustained on slopes).
  - `Crouch`: Low-profile stationary or slow movement.
  - `Jump`: Airborne state.
- **Transitions:**
  - `Sprint` -> `Slide`: Triggered by pressing the crouch button while sprinting.
  - `Slide` -> `Crouch`: Triggered when sliding velocity drops below a minimum threshold.
  - `Slide` -> `Jump`: Triggered by pressing the jump button while sliding.
  - `Slide` -> `Sprint/Run`: Triggered by releasing the crouch button before velocity drops.

## 3. MDA Analysis
- **Mechanics:** The system lowers the character's collision capsule height and applies an initial velocity boost or maintains current velocity, followed by ground friction deceleration. Slope angles often modify acceleration.
- **Dynamics:** Players use sliding to evade enemy fire, navigate under low obstacles, or chain movements (like slide-jumping) to traverse the environment faster and unpredictably.
- **Aesthetics:** Creates a sense of fluidity, speed, and mastery. Players feel agile and tactical when successfully executing slide maneuvers in combat or traversal.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Apex Legends v1.0) | Unit |
| --- | --- | --- | --- | --- |
| `initial_velocity_boost` | f32 | 0.0 - 5.0 | 2.0 | m/s |
| `friction_coefficient` | f32 | 0.1 - 1.0 | 0.2 | N/A |
| `slope_acceleration` | f32 | 1.0 - 10.0 | 5.0 | m/s² |
| `min_sprint_time_to_slide` | f32 | 0.0 - 1.0 | 0.1 | seconds |
| `hitbox_height_multiplier` | f32 | 0.3 - 0.7 | 0.5 | N/A |
| `slide_cooldown` | f32 | 0.0 - 3.0 | 1.5 | seconds |

## 5. Benchmark Data
- **Apex Legends (v1.0):**
  - `initial_velocity_boost`: 2.0 m/s
  - `friction_coefficient`: 0.2 (flat ground)
  - `hitbox_height_multiplier`: 0.5
  - `slide_cooldown`: 1.5 seconds
- **Mega Man 3 (NES):**
  - `slide_duration`: 0.5 seconds (fixed duration rather than physics-based)
  - `slide_speed`: 2.5 units/frame
  - `hitbox_height_multiplier`: 0.5

## 6. Common Variants
1. **Physics-Driven Slide:** Velocity depends heavily on terrain slopes (e.g., Apex Legends).
2. **Fixed-Duration Slide:** The slide lasts for a specific time regardless of momentum (e.g., Mega Man).
3. **Attack Slide:** The slide itself deals damage to enemies (e.g., Dead Cells).
4. **Infinite Slide:** Sliding down a slope can be maintained indefinitely as long as the slope continues.

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_sprint`, `atom_jump` (enables slide-jumping), `atom_shoot` (shooting while sliding).
- **Incompatible Atoms:** `atom_prone` (usually mutually exclusive states), `atom_block` (blocking often requires a planted stance).

## 8. Anti-Patterns
1. **No Cooldown or Speed Penalty:** Allowing players to spam slide repeatedly to move faster than normal sprinting without any downside (often called "slide canceling" exploit if unintended).
2. **Unresponsive Hitbox Changes:** The visual model slides, but the collision capsule remains standing, leading to unfair hits.
3. **Frictionless Flat Ground:** Making the slide last too long on flat surfaces, which removes the tactical timing aspect of the mechanic.
