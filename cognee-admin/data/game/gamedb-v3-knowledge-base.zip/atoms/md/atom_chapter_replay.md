# Gameplay Atom: Chapter Replay

## 1. Identity
- **Atom ID:** `atom_chapter_replay`
- **English Name:** Chapter Replay
- **Chinese Name:** 章节重玩
- **Category:** G/H (Meta-Progression / Narrative Structure)
- **Definition:** Chapter Replay is a structural gameplay mechanic that allows players to revisit previously completed segments or chapters of a game. This enables players to explore alternative narrative branches, improve their scores, collect missed items, or experience different gameplay approaches without restarting the entire game from the beginning.

## 2. Core Verb & State Machine
- **Core Verb:** Replay / Revisit

**State Diagram:**
[Locked] -> (Complete Chapter) -> [Unlocked]
[Unlocked] -> (Select Chapter) -> [Replaying]
[Replaying] -> (Finish/Abort) -> [Unlocked]

**States and Transitions:**
- **Locked:** The chapter has not been reached or completed yet.
- **Unlocked:** The chapter is available for replay in the menu.
- **Replaying:** The player is currently playing the selected chapter.
- **Transitions:**
  - *Complete Chapter:* Moving from Locked to Unlocked upon first-time completion.
  - *Select Chapter:* Moving from Unlocked to Replaying via the chapter selection interface.
  - *Finish/Abort:* Returning to the Unlocked state after completing the replay or manually aborting it.

## 3. MDA Analysis
- **Mechanics:** The system records the player's progress and unlocks discrete narrative or gameplay chunks. It provides an interface to load these chunks with specific initial states (e.g., inventory, stats) based on either the first playthrough or a standardized template.
- **Dynamics:** Players actively seek out divergent paths, experiment with risky strategies, or optimize their performance (speedrunning, high scores) knowing they can easily retry specific sections. It encourages a trial-and-error approach to narrative choices.
- **Aesthetics:** Fosters a sense of mastery, curiosity, and completionism. Players feel empowered to explore "what if" scenarios without the anxiety of permanently ruining their main save file.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Game) | Unit |
|---|---|---|---|---|
| `unlock_condition` | enum | Completion, Discovery | Completion (Detroit: Become Human v1.0) | N/A |
| `state_inheritance` | enum | Strict, Loose, None | Strict (Detroit: Become Human v1.0) | N/A |
| `score_retention` | bool | True, False | True (Hitman 3 v3.10) | N/A |
| `max_replays` | u32 | 1 - Infinite | Infinite (Hitman 3 v3.10) | Count |
| `checkpoint_granularity` | f32 | 1.0 - 10.0 | 5.0 (Detroit: Become Human v1.0) | Minutes |

## 5. Benchmark Data
- **Detroit: Become Human (v1.0):** Features a highly granular flowchart system. `checkpoint_granularity` is roughly every 5-10 minutes of gameplay. `state_inheritance` is strict, meaning choices made in a replayed chapter overwrite subsequent chapter states if the player continues playing from that point.
- **Hitman 3 (v3.10):** Focuses on systemic replayability. `score_retention` is true, allowing players to accumulate mastery levels. `max_replays` is infinite, encouraging players to find new assassination methods.

## 6. Common Variants
1. **Flowchart Replay:** Visualizes narrative branches and allows jumping to specific decision nodes (e.g., *Detroit: Become Human*).
2. **Score Attack Replay:** Focuses on replaying levels to achieve higher ranks or better times (e.g., *Devil May Cry* series).
3. **Isolated Replay:** Replaying a chapter does not affect the main story progression or subsequent chapters; it exists in a vacuum (e.g., *Uncharted* series).
4. **New Game Plus Replay:** Chapters are replayed with late-game equipment and abilities, often at a higher difficulty.

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_branching_narrative`, `atom_scoring_system`, `atom_collectible_hunt`, `atom_multiple_endings`.
- **Incompatible Atoms:** `atom_permadeath` (inherently conflicts with the ability to undo mistakes), `atom_linear_strict_progression`.

## 8. Anti-Patterns
1. **Inconsistent State Saving:** Failing to clearly communicate to the player whether their actions during a replay will overwrite their main save file, leading to frustration and lost progress.
2. **Poor Checkpointing:** Forcing players to replay long, unskippable sequences just to reach the specific branching point or gameplay segment they want to retry.
3. **Lack of Meaningful Variation:** Offering chapter replay in a game where choices or gameplay approaches do not significantly alter the outcome, making the replay feel tedious and unrewarding.
