# Gameplay Atom: Recoil Pattern

## 1. Identity
- **Atom ID:** atom_recoil_pattern
- **English Name:** Recoil Pattern
- **Chinese Name:** 后坐力模式
- **Category:** A (Core Combat Mechanics)
- **Definition:** A deterministic or semi-deterministic sequence of weapon movements (pitch and yaw) applied to the player's camera or crosshair during continuous automatic fire. It requires players to learn and counter the pattern by moving their input device in the opposite direction to maintain accuracy.

## 2. Core Verb & State Machine
- **Core Verb:** "Control" or "Compensate" (Pulling down/sideways to counter recoil).

**State Diagram:**
```text
[Idle] --(Fire Pressed)--> [Firing]
[Firing] --(Continue Fire)--> [Recoil Accumulating]
[Recoil Accumulating] --(Fire Released)--> [Recovery]
[Recovery] --(Time Passed)--> [Idle]
[Recoil Accumulating] --(Max Recoil Reached)--> [Max Recoil Sustained]
[Max Recoil Sustained] --(Fire Released)--> [Recovery]
```

**States:**
- `Idle`: Weapon is ready, no recoil applied.
- `Firing`: The initial shot is fired, recoil begins.
- `Recoil Accumulating`: Continuous firing progresses through the recoil pattern sequence.
- `Max Recoil Sustained`: The pattern reaches its end or loops, maintaining maximum displacement.
- `Recovery`: Firing stops, and the crosshair/camera returns to the original or a new resting position.

**Transitions:**
- `Idle` -> `Firing`: Triggered by player pressing the fire button.
- `Firing` -> `Recoil Accumulating`: Triggered by holding the fire button.
- `Recoil Accumulating` -> `Recovery`: Triggered by releasing the fire button.
- `Recovery` -> `Idle`: Triggered by the recovery timer completing.

## 3. MDA Analysis
- **Mechanics:** The system applies a predefined 2D vector (pitch and yaw) to the player's aim per shot or per frame during continuous fire. It may include a random variance (spread) on top of the deterministic pattern.
- **Dynamics:** Players learn the specific patterns of different weapons and practice "spray control" (moving the mouse in the exact opposite path of the recoil). This creates a high skill ceiling for weapon mastery.
- **Aesthetics:** Provides a sense of physical power and weight to the weapons. Mastering a pattern gives players a feeling of accomplishment, mastery, and competitive superiority (Challenge and Expression).

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (CS:GO v1.38) | Unit |
|---|---|---|---|---|
| `vertical_recoil_base` | f32 | 0.5 - 5.0 | 2.1 | degrees/shot |
| `horizontal_recoil_base` | f32 | -3.0 - 3.0 | 0.8 | degrees/shot |
| `recoil_variance` | f32 | 0.0 - 2.0 | 0.4 | degrees |
| `recovery_time` | f32 | 0.1 - 1.5 | 0.45 | seconds |
| `pattern_length` | u32 | 5 - 50 | 30 | shots |
| `recovery_curve` | enum | Linear, Exp | Exponential | N/A |

## 5. Benchmark Data
- **CS:GO (v1.38.7.9) - AK-47:**
  - `pattern_length`: 30 shots
  - `vertical_recoil_base`: High initial vertical climb for the first 7-9 shots.
  - `horizontal_recoil_base`: Shifts right, then sharply left, then back right.
  - `recovery_time`: ~0.45 seconds to fully reset.
- **Valorant (v7.04) - Vandal:**
  - `pattern_length`: 25 shots
  - `vertical_recoil_base`: Climbs for the first 7-9 shots, then caps out.
  - `horizontal_recoil_base`: Randomly sways left and right after the vertical climb, indicated by the weapon model's barrel movement.
  - `recovery_time`: ~0.375 seconds.

## 6. Common Variants
1. **Fully Deterministic (CS:GO):** The pattern is exactly the same every time, with only minor bullet spread (inaccuracy) added on top.
2. **Semi-Deterministic with Sway (Valorant):** The initial climb is consistent, but the horizontal recoil eventually turns into a randomized left/right sway that the player must react to visually.
3. **Procedural/Randomized (PUBG):** Recoil is generated procedurally based on base values and attachments, making exact memorization impossible; relies more on reactive compensation.
4. **Camera vs. Crosshair Recoil:** Some games move the entire camera (Rust), while others move the crosshair independently of the center of the screen (CS:GO).

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_bullet_spread` (Inaccuracy), `atom_aim_down_sights` (ADS), `atom_weapon_attachments` (Grips/Compensators that modify the pattern), `atom_movement_penalty` (Moving increases variance).
- **Incompatible Atoms:** `atom_auto_aim` (Strong aim assist conflicts with manual recoil compensation), `atom_hitscan_laser` (Weapons with zero recoil/spread).

## 8. Anti-Patterns
1. **Excessive Randomness:** Adding too much variance to a pattern makes it feel uncontrollable and removes the skill expression of learning the pattern.
2. **Unreadable Visual Feedback:** If the crosshair or camera doesn't accurately represent where the bullets are going, players cannot learn to compensate.
3. **Instant Recovery:** If the weapon recovers instantly upon releasing the trigger, players can bypass the pattern entirely by rapidly clicking (macro abuse) instead of learning the pattern.
