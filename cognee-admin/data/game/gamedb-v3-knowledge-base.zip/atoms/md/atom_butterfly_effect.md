# Gameplay Atom: Butterfly Effect

## 1. Identity
- **Atom ID:** atom_butterfly_effect
- **English Name:** Butterfly Effect
- **Chinese Name:** 蝴蝶效应
- **Category:** E (Narrative & Choices)
- **Definition:** The Butterfly Effect is a narrative and systemic gameplay mechanic where seemingly minor or inconsequential choices made by the player early in the game cascade into significant, often unforeseen consequences later in the story or gameplay state. It emphasizes the interconnectedness of events and the weight of player agency in shaping the game world.

## 2. Core Verb & State Machine
- **Core Verb:** Choose (Make a decision that alters a hidden or visible variable).

**State Diagram:**
[Idle] --(Trigger Event)--> [Decision Point]
[Decision Point] --(Choice A)--> [State A]
[Decision Point] --(Choice B)--> [State B]
[State A] --(Time/Progression)--> [Consequence A]
[State B] --(Time/Progression)--> [Consequence B]

**States:**
- `Idle`: The default state where the player is exploring or progressing without immediate narrative pressure.
- `Decision Point`: A moment where the player must make a choice (dialogue, action, or inaction).
- `Variable Updated`: The internal state where the game records the choice (often hidden from the player).
- `Consequence Triggered`: The state where the delayed effect of the choice manifests in the game world.

**Transitions:**
- `Idle` -> `Decision Point`: Triggered by reaching a specific narrative node or interacting with an object/NPC.
- `Decision Point` -> `Variable Updated`: Triggered by the player confirming a choice or a timer expiring.
- `Variable Updated` -> `Consequence Triggered`: Triggered by reaching a downstream narrative node that checks the variable.

## 3. MDA Analysis
- **Mechanics:** The system tracks player choices using boolean flags, integer counters, or relationship meters. Later events check these variables to determine which branch of the narrative or gameplay to load.
- **Dynamics:** Players often try to predict the outcomes of their choices, leading to cautious decision-making or deliberate experimentation. The delayed feedback loop creates suspense and encourages multiple playthroughs to explore different branches.
- **Aesthetics:** The primary aesthetic is *Narrative* and *Discovery*. Players feel a sense of agency, responsibility, and sometimes regret or surprise when the consequences of their actions are finally revealed.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Game) | Unit |
|---|---|---|---|---|
| `decision_timer` | f32 | 3.0 - 15.0 | 5.0 (Detroit: Become Human v1.0) | Seconds |
| `impact_delay` | u32 | 1 - 50 | 10 (Until Dawn v1.0) | Scenes/Chapters |
| `visibility_flag` | bool | true/false | true (Until Dawn v1.0) | N/A |
| `relationship_change` | f32 | -1.0 - 1.0 | 0.1 (Detroit: Become Human v1.0) | Normalized Value |

## 5. Benchmark Data
- **Detroit: Become Human (v1.0):**
  - `decision_timer`: 5.0 seconds for high-tension choices.
  - `visibility_flag`: true (often shows a flowchart after the chapter).
  - `relationship_change`: +/- 0.1 to 0.2 per significant interaction.
- **Until Dawn (v1.0):**
  - `impact_delay`: Can range from 1 scene to the entire game (e.g., finding a weapon early affects survival late game).
  - `visibility_flag`: true (shows "Butterfly Effect updated" UI prompt).

## 6. Common Variants
1. **The Illusion of Choice:** Choices are presented, but they ultimately funnel back to the same outcome (often used to manage scope while maintaining the feeling of agency).
2. **Cumulative Consequences:** Minor choices don't have individual major impacts, but their sum determines the outcome (e.g., a "morality" or "chaos" meter).
3. **Immediate vs. Delayed:** Some choices have immediate, visible consequences, while others are purely delayed.
4. **Hidden Variables:** The game tracks actions the player didn't even realize were choices (e.g., taking too long to explore a room).

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_dialogue_wheel`, `atom_morality_system`, `atom_multiple_endings`, `atom_qte` (Quick Time Events often serve as the execution method for a choice).
- **Incompatible Atoms:** `atom_linear_progression` (Strictly linear games cannot support branching consequences), `atom_procedural_generation` (Highly procedural games struggle with authored narrative branches).

## 8. Anti-Patterns
1. **Untelegraphed Consequences:** If a consequence feels completely disconnected or illogical based on the choice, players will feel cheated rather than responsible.
2. **Too Many Branches:** Creating too many significant branches can lead to exponential scope creep, resulting in rushed or low-quality content for each branch.
3. **Meaningless Choices:** Presenting choices that have no impact on the narrative or gameplay, breaking the promise of the Butterfly Effect.
