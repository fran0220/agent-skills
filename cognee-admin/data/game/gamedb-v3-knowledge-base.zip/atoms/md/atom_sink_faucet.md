# Gameplay Atom: Sink / Faucet Economy

## 1. Identity
- **Atom ID:** `atom_sink_faucet`
- **English Name:** Sink / Faucet Economy
- **Chinese Name:** 水槽/水龙头经济
- **Category:** C
- **Definition:** The Sink / Faucet Economy is a foundational macroeconomic system in multiplayer games where resources are continuously generated (faucets) and consumed or removed from the game (sinks) to maintain economic stability and prevent hyperinflation.

## 2. Core Verb & State Machine
- **Core Verb:** Earn / Spend
- **State Diagram:**
  [Resource Generation] --> [Player Inventory] --> [Resource Consumption]
- **States:**
  - `Generating`: The state where the game system produces resources (e.g., mob drops, daily quests).
  - `Holding`: The state where resources are stored in the player's inventory or bank.
  - `Consuming`: The state where resources are permanently removed from the economy (e.g., repair costs, auction house fees).
- **Transitions:**
  - `Generating` -> `Holding`: Player collects the generated resource.
  - `Holding` -> `Consuming`: Player spends the resource on a sink mechanism.

## 3. MDA Analysis
- **Mechanics:** The game defines specific sources (faucets) that inject currency or items into the economy and specific drains (sinks) that remove them. The balance between the two determines the inflation rate.
- **Dynamics:** Players optimize their time to maximize faucet output while minimizing mandatory sink expenditures. If faucets outpace sinks, currency devalues, leading to inflation. If sinks are too aggressive, players feel impoverished and frustrated.
- **Aesthetics:** A well-balanced sink/faucet system creates a sense of rewarding progression and economic stability. Players feel their time investment retains value.

## 4. Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value (WoW Classic) | Unit |
|---|---|---|---|---|
| `faucet_rate` | f32 | 10.0 - 1000.0 | 50.0 | gold/hour |
| `sink_rate` | f32 | 5.0 - 800.0 | 30.0 | gold/hour |
| `tax_rate` | f32 | 0.01 - 0.15 | 0.05 | multiplier |
| `repair_cost_ratio` | f32 | 0.05 - 0.20 | 0.10 | multiplier |

## 5. Benchmark Data
- **World of Warcraft (Version: Classic 1.13):**
  - `faucet_rate`: ~50 gold/hour (farming/questing at max level)
  - `sink_rate`: ~30 gold/hour (repairs, consumables, respecs)
  - `tax_rate`: 0.05 (5% Auction House cut)
- **EVE Online (Version: 2023.1):**
  - `faucet_rate`: ~100M ISK/hour (ratting/missions)
  - `sink_rate`: ~40M ISK/hour (LP store, broker fees, taxes)
  - `tax_rate`: 0.08 (8% market tax base)

## 6. Common Variants
1. **Durability Sink:** Items degrade over time and require currency to repair (e.g., WoW).
2. **Taxation Sink:** A percentage of player-to-player transactions is removed from the economy (e.g., EVE Online broker fees).
3. **Cosmetic Sink:** High-cost, non-power-affecting items that drain excess wealth from veteran players (e.g., expensive mounts).
4. **Consumable Sink:** Resources that must be continuously purchased and used for optimal gameplay (e.g., potions, flasks).

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_auction_house`, `atom_crafting_system`, `atom_durability`
- **Incompatible Atoms:** `atom_infinite_wealth`

## 8. Anti-Patterns
1. **Runaway Faucets:** Introducing new, highly lucrative farming methods without corresponding sinks, leading to rapid hyperinflation.
2. **Punishing Sinks:** Making mandatory sinks (like repair costs) so high that average players cannot afford to play the game normally.
3. **Wealth Hoarding:** Failing to provide attractive optional sinks for the wealthiest players, causing currency to stagnate and lose value.
