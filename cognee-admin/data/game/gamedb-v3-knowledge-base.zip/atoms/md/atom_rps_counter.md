# Gameplay Atom: Rock-Paper-Scissors Counter

## 1. Identity
- **Atom ID:** `atom_rps_counter`
- **English Name:** Rock-Paper-Scissors Counter
- **Chinese Name:** 剪刀石头布克制
- **Category:** A+B
- **Definition:** A fundamental combat or interaction mechanic where different unit types, abilities, or elements have cyclical advantages and disadvantages against each other, ensuring that no single option is universally dominant and encouraging strategic diversity and adaptation.

## 2. Core Verb & State Machine
- **Core Verb:** Counter / Select
- **State Diagram:**
  ```text
  [Idle] --> (Select Unit/Action) --> [Engaging]
  [Engaging] --> (Advantageous Matchup) --> [Dominating]
  [Engaging] --> (Disadvantageous Matchup) --> [Struggling]
  [Engaging] --> (Neutral Matchup) --> [Trading]
  [Dominating] / [Struggling] / [Trading] --> (Combat Ends) --> [Idle]
  ```
- **States:**
  - `Idle`: Waiting for player input or encounter.
  - `Engaging`: Initiating interaction with an opponent.
  - `Dominating`: Dealing bonus damage or receiving reduced damage due to a favorable matchup.
  - `Struggling`: Dealing reduced damage or receiving bonus damage due to an unfavorable matchup.
  - `Trading`: Engaging in a neutral matchup with no specific modifiers.
- **Transitions:**
  - `Idle` -> `Engaging`: Triggered by encountering an enemy or selecting an action.
  - `Engaging` -> `Dominating`: Triggered when player's type counters the enemy's type.
  - `Engaging` -> `Struggling`: Triggered when enemy's type counters the player's type.
  - `Engaging` -> `Trading`: Triggered when both types are neutral to each other.

## 3. MDA Analysis
- **Mechanics:** The system applies damage multipliers or specific effects based on the interaction between predefined types (e.g., Type A deals 150% damage to Type B, but 50% to Type C).
- **Dynamics:** Players must constantly scout, anticipate opponent choices, and adapt their composition or actions to maintain a favorable matchup, leading to dynamic shifts in strategy and counter-strategy.
- **Aesthetics:** Creates feelings of intellectual satisfaction when successfully predicting and countering an opponent, as well as tension and urgency when caught in an unfavorable matchup.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (StarCraft II v5.0) | Unit |
| --- | --- | --- | --- | --- |
| `bonus_damage_multiplier` | f32 | 1.2 - 3.0 | 1.5 | multiplier |
| `penalty_damage_multiplier` | f32 | 0.3 - 0.8 | 1.0 (often neutral) | multiplier |
| `armor_type_reduction` | f32 | 0.0 - 0.5 | 0.0 | multiplier |
| `movement_speed_modifier` | f32 | 0.8 - 1.5 | 1.0 | multiplier |

## 5. Benchmark Data
- **StarCraft II (v5.0):**
  - Immortal vs Armored: Base damage 20, Bonus damage +30 (Total 50, `bonus_damage_multiplier` effectively 2.5x).
  - Marauder vs Armored: Base damage 10, Bonus damage +10 (Total 20, `bonus_damage_multiplier` effectively 2.0x).
- **Age of Empires II: Definitive Edition (v101.102):**
  - Pikeman vs Cavalry: Base damage 4, Bonus damage +22 against Cavalry (`bonus_damage_multiplier` effectively 6.5x).
  - Skirmisher vs Archer: Base damage 2, Bonus damage +4 against Archers (`bonus_damage_multiplier` effectively 3.0x).

## 6. Common Variants
1. **Soft Counters:** Small statistical advantages (e.g., +20% damage) that can be overcome by sheer numbers or micro-management.
2. **Hard Counters:** Extreme advantages (e.g., +300% damage or complete immunity) where the countered unit is practically useless.
3. **Complex Webs:** Instead of a simple triangle (A > B > C > A), the game features multiple overlapping types (e.g., Pokémon type chart with 18 types and dual-typing).
4. **Economic Counters:** Counters that focus on resource efficiency rather than direct combat stats (e.g., a cheap unit that trades cost-effectively against an expensive one).
5. **Utility Counters:** Counters based on abilities rather than stats (e.g., a unit with an EMP ability countering units reliant on energy or shields).

## 7. Compatibility Notes
- **Commonly Pairs With:** `atom_fog_of_war` (scouting is essential to know what to counter), `atom_tech_tree` (unlocking specific counters), `atom_resource_management` (balancing the cost of counter units).
- **Known Conflicts:** `atom_hero_unit_dominance` (if a single hero unit can defeat all types, the RPS system breaks down).

## 8. Anti-Patterns
1. **Overly Hard Counters:** Making counters so extreme that the game becomes purely about composition rather than positioning or skill, leading to "auto-win" or "auto-loss" scenarios.
2. **Lack of Scouting Tools:** Implementing an RPS system without giving players adequate means to scout the opponent, turning the game into a blind guessing match.
3. **Inaccessible Counters:** Placing crucial counter units too high up the tech tree, leaving players defenseless against early rushes of a specific type.
