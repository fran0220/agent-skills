# Gameplay Atom: Collection Log / Codex (收藏图鉴)

## 1. Identity
- **Atom ID:** `atom_collection_log`
- **English Name:** Collection Log / Codex
- **Chinese Name:** 收藏图鉴
- **Category:** E (Exploration/Engagement) or F (Progression/Feedback)
- **Definition:** A persistent system that tracks, records, and displays the various entities, items, enemies, or achievements a player has encountered or acquired throughout their gameplay experience. It serves as a long-term meta-goal, providing structure to exploration and rewarding completionist behavior.

## 2. Core Verb & State Machine
- **Core Verb:** "Discover" / "Collect"

**State Diagram:**
```text
[Undiscovered] --(Encounter/Acquire)--> [Discovered/Unlocked] --(Complete Requirements)--> [Mastered/Completed]
```

**States:**
- `Undiscovered`: The entity is unknown to the player, often represented as a silhouette or question mark.
- `Discovered/Unlocked`: The player has encountered or acquired the entity at least once. Basic information is revealed.
- `Mastered/Completed`: The player has fully engaged with the entity (e.g., caught multiple times, defeated a certain number of times, or fully upgraded). All lore and stats are revealed.

**Transitions:**
- `Undiscovered` -> `Discovered/Unlocked`: Triggered by the first encounter, capture, or acquisition of the entity.
- `Discovered/Unlocked` -> `Mastered/Completed`: Triggered by meeting specific mastery thresholds (e.g., catching 10 of the same Pokemon, or defeating a monster 50 times).

## 3. MDA Analysis
- **Mechanics:** The system maintains a database of all collectible entities. It listens for specific game events (item pickup, enemy kill, location visited) and updates the status of the corresponding entry in the database. It often provides rewards (currency, items, titles) upon reaching certain milestones.
- **Dynamics:** Players alter their behavior to seek out missing entries. They may revisit old areas, use different strategies, or engage in repetitive tasks (grinding) specifically to fill out the log rather than to progress the main story.
- **Aesthetics:** 
  - *Discovery:* The thrill of finding something new.
  - *Submission/Completion:* The satisfaction of filling a progress bar or completing a set.
  - *Expression:* Showing off a completed codex as a badge of honor.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Game) | Unit |
| :--- | :--- | :--- | :--- | :--- |
| `total_entries` | `u32` | 50 - 1000+ | 151 (Pokemon Red/Blue) | count |
| `milestone_intervals` | `u32` | 10 - 100 | 10 (Genshin Impact) | count |
| `reward_multiplier` | `f32` | 1.0 - 5.0 | 1.5 (Monster Hunter World) | multiplier |
| `mastery_threshold` | `u32` | 1 - 100 | 10 (Pokemon Legends: Arceus) | count |
| `completion_bonus` | `u32` | 100 - 10000 | 1000 (Genshin Impact) | currency |

## 5. Benchmark Data
- **Pokemon Red/Blue (v1.0):**
  - `total_entries`: 151
  - `mastery_threshold`: 1 (Catching once is enough for full entry)
- **Monster Hunter: World (v15.11):**
  - `total_entries`: 71 (Large Monsters)
  - `mastery_threshold`: Varies by research level (typically 3-6 levels of research per monster)
- **Genshin Impact (v4.0):**
  - `total_entries`: 800+ (Archive entries including wildlife, enemies, materials)
  - `milestone_intervals`: Varies, but regional exploration often rewards at 20%, 40%, 60%, etc.

## 6. Common Variants
1. **The Bestiary:** Focuses exclusively on enemies. Often reveals weaknesses, drop tables, and lore after defeating the enemy a certain number of times (e.g., *Hollow Knight* Hunter's Journal).
2. **The Item Compendium:** Tracks all weapons, armor, and consumables acquired. Often tied to crafting systems (e.g., *Terraria*).
3. **The Location/Lore Log:** Tracks visited landmarks, read books, or discovered audio logs. Heavily tied to narrative and world-building (e.g., *Horizon Zero Dawn*).
4. **The Catch-and-Release Log:** Specifically for fishing or bug catching mini-games, tracking size and weight records (e.g., *Animal Crossing*).

## 7. Compatibility Notes
- **Commonly Pairs With:**
  - `atom_exploration_fog` (Fog of War): Discovering areas often unlocks codex entries.
  - `atom_crafting_recipe`: Codex entries often reveal what items can be crafted from a material.
  - `atom_achievement_system`: Completing sections of the codex usually grants achievements.
- **Known Conflicts:**
  - `atom_permadeath`: If the codex resets on death, it can be extremely frustrating. Usually, codex progress is kept persistent across runs in roguelikes to provide meta-progression.

## 8. Anti-Patterns
1. **The Impossible Entry:** Including entries that are permanently missable due to story progression or limited-time events, frustrating completionists.
2. **Meaningless Grind:** Requiring an absurd number of repetitive actions (e.g., "Kill 10,000 Boars") just to unlock a basic lore entry, leading to burnout.
3. **Lack of Utility:** A codex that only provides text and no actionable gameplay information (like elemental weaknesses or drop locations) often gets ignored by players.
