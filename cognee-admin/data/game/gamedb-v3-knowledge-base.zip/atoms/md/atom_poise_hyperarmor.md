# Gameplay Atom: Poise / Hyper Armor

## 1. Identity
- **Atom ID:** `atom_poise_hyperarmor`
- **English Name:** Poise / Hyper Armor
- **Chinese Name:** 韧性/霸体
- **Category:** A (Core Combat Mechanics)
- **Definition:** Poise or Hyper Armor is a combat mechanic that determines a character's resistance to being staggered or interrupted by incoming attacks. It allows a character to complete their current action (such as an attack animation) even while taking damage, provided the incoming attack's stagger value does not exceed the character's current poise health or hyper armor threshold.

## 2. Core Verb & State Machine
**Core Verb:** Endure (withstand incoming attacks without interruption).

**State Diagram:**
```text
[Idle] --> (Initiate Attack) --> [Active Hyper Armor]
[Active Hyper Armor] --> (Take Damage < Poise Limit) --> [Active Hyper Armor] (Action Continues)
[Active Hyper Armor] --> (Take Damage >= Poise Limit) --> [Staggered] (Action Interrupted)
[Active Hyper Armor] --> (Action Completes) --> [Recovery] --> [Idle]
[Staggered] --> (Recovery Time Elapsed) --> [Idle]
```

**States and Transitions:**
- **Idle:** The default state where the character is not performing any action that grants hyper armor.
- **Active Hyper Armor:** The state during specific frames of an animation (usually attacks) where the character gains increased resistance to staggering.
- **Staggered:** The state entered when the character's poise is broken, interrupting their current action and playing a hit reaction animation.
- **Recovery:** The cooldown phase after an action completes before returning to Idle.

## 3. MDA Analysis
- **Mechanics:** The system assigns a "poise damage" value to incoming attacks and a "poise health" or "hyper armor multiplier" to the defending character. When an attack connects, the system subtracts the poise damage from the poise health. If poise health drops to zero or below, the character is staggered. Poise health typically regenerates over time or resets after an action.
- **Dynamics:** Players learn to trade hits strategically. A player with a slow, heavy weapon relies on hyper armor to ensure their attack lands even if the faster opponent strikes first. This creates a dynamic of timing and spacing, where players must calculate whether their attack's hyper armor frames will activate in time to absorb the opponent's hit.
- **Aesthetics:** The mechanic evokes feelings of power, resilience, and calculated risk. Successfully trading a hit using hyper armor feels satisfying and rewarding, emphasizing the weight and momentum of heavy combat styles. It reinforces the fantasy of being an unstoppable juggernaut.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Game) | Unit |
| :--- | :--- | :--- | :--- | :--- |
| `base_poise` | Float | 0.0 - 100.0 | 50.0 (Dark Souls III v1.15) | Points |
| `poise_damage` | Float | 10.0 - 150.0 | 30.0 (Dark Souls III v1.15) | Points |
| `hyper_armor_multiplier` | Float | 0.0 - 1.0 | 0.5 (Dark Souls III v1.15) | Multiplier |
| `poise_reset_time` | Float | 1.0 - 10.0 | 5.0 (Elden Ring v1.10) | Seconds |
| `stagger_duration` | Float | 0.2 - 1.5 | 0.8 (Monster Hunter: World v15.11) | Seconds |

## 5. Benchmark Data
- **Dark Souls III (v1.15):** A standard straight sword R1 attack deals approximately 14 poise damage. A player wearing medium armor might have 30 base poise. During the active frames of a greatsword attack, a hyper armor multiplier of 0.5 is applied, effectively doubling their poise health against incoming attacks, allowing them to withstand the straight sword hit without staggering.
- **Elden Ring (v1.10):** Poise functions on a health-like system that regenerates to full after a set period of avoiding damage (typically around 5-10 seconds depending on the action). Passive poise allows withstanding light attacks even while idle, while active hyper armor during heavy weapon swings provides massive temporary boosts to poise health.
- **Monster Hunter: World (v15.11):** The Great Sword's "Tackle" move grants absolute hyper armor (often referred to as super armor in this context), reducing incoming damage and completely negating stagger from almost all monster attacks, allowing the player to power through roars and physical strikes to deliver a counter-offensive.

## 6. Common Variants
1. **Passive Poise:** The character constantly has a poise value based on their equipment, allowing them to resist staggers even when simply walking or standing still (e.g., Dark Souls 1).
2. **Active Hyper Armor:** Poise is only granted during specific animation frames, usually the startup and active frames of heavy attacks (e.g., Dark Souls 3).
3. **Super Armor:** A stronger variant that completely negates all stagger, regardless of the incoming attack's power, often tied to specific ultimate abilities or highly committal moves (e.g., Fighting games, Monster Hunter Tackle).
4. **Armor Break / Guard Crush:** Specific attacks are designed to ignore poise entirely or deal massive multiplier damage to poise health, forcing a stagger regardless of the defender's state.

## 7. Compatibility Notes
- **Commonly Pairs With:** `atom_heavy_attack` (Heavy attacks need hyper armor to be viable), `atom_damage_reduction` (Hyper armor often comes with a percentage damage reduction to make trading hits favorable), `atom_stamina_consumption` (Moves with hyper armor usually cost significant stamina).
- **Known Conflicts:** `atom_dodge_roll` (Hyper armor encourages taking the hit, while dodging avoids it entirely; balancing the two is crucial so one doesn't invalidate the other), `atom_stealth` (Poise is irrelevant if the player is not being attacked).

## 8. Anti-Patterns
1. **Infinite Passive Poise:** Allowing players to stack so much passive poise that they can ignore all enemy mechanics and simply spam attacks without consequence, trivializing the combat system.
2. **Unclear Hyper Armor Frames:** Failing to provide visual or audio feedback when hyper armor is active, leading to player frustration when they are staggered during an animation they thought was protected.
3. **Useless Heavy Weapons:** Designing heavy, slow weapons without adequate hyper armor, making them completely unviable against fast enemies who can constantly interrupt the slow attack animations.
