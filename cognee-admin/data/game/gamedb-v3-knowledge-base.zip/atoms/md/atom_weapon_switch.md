# Real-Time Weapon Switch (实时武器切换)

## 1. Identity
- **Atom ID:** `atom_weapon_switch`
- **English Name:** Real-Time Weapon Switch
- **Chinese Name:** 实时武器切换
- **Category:** A
- **Definition:** Real-Time Weapon Switch is a core combat mechanic that allows players to seamlessly transition between different equipped weapons during active gameplay without pausing or entering a menu. This mechanic enables dynamic combo creation, situational adaptability, and continuous offensive pressure by linking the unique properties of multiple weapons into a cohesive combat flow.

## 2. Core Verb & State Machine
- **Core Verb:** Switch (切换)

**State Diagram:**
[Idle/Attack State] --(Switch Input)--> [Switching State] --(Switch Complete)--> [Idle/Attack State (New Weapon)]

**States:**
- `Idle`: The player is not performing any action, holding the current weapon.
- `Attacking`: The player is in the middle of an attack animation with the current weapon.
- `Switching`: The transitional state where the current weapon is being unequipped and the new weapon is being equipped.
- `Cooldown`: A brief period after a switch where another switch cannot be initiated.

**Transitions:**
- `Idle` -> `Switching`: Triggered by the player pressing the weapon switch button.
- `Attacking` -> `Switching`: Triggered by the player pressing the weapon switch button during an attack's cancel window.
- `Switching` -> `Idle`: Triggered automatically when the switch animation duration completes.
- `Switching` -> `Attacking`: Triggered if the player inputs an attack command that buffers during the switch, executing immediately after the switch completes.

## 3. MDA Analysis
- **Mechanics:** The system monitors player input for weapon switching. Upon receiving the input, it checks if the current state allows for a switch (e.g., not in a hard hitstun or uncancelable animation). If valid, it swaps the active weapon data, plays a transitional animation (often very brief or blended), and applies any relevant cooldowns or buffs.
- **Dynamics:** Players learn to memorize weapon sequences and switch timings to extend combos beyond the limitations of a single weapon. They adapt to enemy types on the fly by switching to the most effective weapon type (e.g., heavy weapon for shielded enemies, fast weapon for agile enemies) without breaking the flow of combat.
- **Aesthetics:** The mechanic fosters a sense of mastery, fluidity, and empowerment. Players feel like highly skilled combatants capable of overwhelming opponents with a relentless and varied barrage of attacks. The visual and auditory feedback of rapidly changing weapons adds to the kinetic thrill of the game.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Game) | Unit |
| :--- | :--- | :--- | :--- | :--- |
| `switch_duration` | `f32` | 0.0 - 0.5 | 0.1 (Devil May Cry 5 v1.0) | seconds |
| `switch_cooldown` | `f32` | 0.0 - 1.0 | 0.0 (Nier Automata v1.0) | seconds |
| `cancel_window_start` | `f32` | 0.1 - 0.8 | 0.3 (Devil May Cry 5 v1.0) | normalized time (0-1) |
| `invincibility_frames` | `u32` | 0 - 15 | 0 (Devil May Cry 5 v1.0) | frames (at 60fps) |
| `buffer_window` | `f32` | 0.05 - 0.2 | 0.15 (Nier Automata v1.0) | seconds |

## 5. Benchmark Data
- **Devil May Cry 5 (v1.0):**
  - `switch_duration`: 0.1s (Nearly instantaneous, allowing for rapid combo weaving).
  - `switch_cooldown`: 0.0s (No artificial limit, gated only by animation frames).
  - `cancel_window_start`: Varies heavily by attack, but generally early (e.g., 0.3) to allow for fluid transitions.
- **Nier Automata (v1.0):**
  - `switch_duration`: 0.2s (Slightly more deliberate visual swap, but functionally very fast).
  - `switch_cooldown`: 0.0s (Allows for immediate swapping between weapon sets).
  - `buffer_window`: 0.15s (Generous buffering to ensure inputs aren't dropped during frantic combat).

## 6. Common Variants
1. **Set Switching:** Instead of cycling through individual weapons, the player switches between pre-defined loadouts or "sets" of weapons (e.g., Nier Automata's Weapon Set 1 and Set 2).
2. **Stance Switching:** The weapon remains the same, but the character's grip or fighting style changes, altering the moveset (e.g., Nioh's High, Mid, and Low stances).
3. **Transforming Weapons:** The weapon itself physically morphs into a different form with a distinct moveset, often incorporating the transformation into an attack (e.g., Bloodborne's Trick Weapons).
4. **Wheel/Radial Menu Slowdown:** Opening the weapon selection slows down time significantly rather than pausing completely, allowing for tactical choices without entirely breaking the real-time flow (e.g., Doom Eternal).

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_combo_system` (Combo System), `atom_animation_canceling` (Animation Canceling), `atom_enemy_weakness` (Enemy Weakness System), `atom_dodge_roll` (Dodge Roll).
- **Incompatible Atoms:** `atom_turn_based_combat` (Turn-Based Combat), `atom_heavy_commitment_attacks` (Heavy Commitment Attacks - if they completely lock out switching, it reduces the fluidity).

## 8. Anti-Patterns
1. **Excessive Switch Duration:** Making the switch animation too long breaks the flow of combat and discourages players from utilizing multiple weapons dynamically.
2. **Lack of Input Buffering:** If switch inputs are easily dropped during chaotic moments or other animations, the system feels unresponsive and frustrating.
3. **Overly Restrictive Cancel Windows:** Preventing weapon switching during most attack animations limits player expression and makes the combat feel stiff rather than fluid.
