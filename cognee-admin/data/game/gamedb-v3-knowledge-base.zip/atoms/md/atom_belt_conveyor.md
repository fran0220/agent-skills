# Gameplay Atom: Belt / Conveyor System

## 1. Identity
- **Atom ID:** `atom_belt_conveyor`
- **English Name:** Belt / Conveyor System
- **Chinese Name:** 传送带系统
- **Category:** G/H (Logistics / Automation)
- **Definition:** A continuous transport mechanism that automatically moves items or entities along a predefined path at a constant or variable speed, forming the backbone of automated logistics and factory building games.

## 2. Core Verb & State Machine
- **Core Verb:** Transport / Route
- **State Diagram:**
  [Empty] --(Item Enters)--> [Transporting] --(Item Reaches End)--> [Blocked/Waiting] --(Item Exits)--> [Empty]
- **States:**
  - `Empty`: The conveyor segment has no items on it.
  - `Transporting`: The conveyor is actively moving an item along its length.
  - `Blocked`: The item has reached the end of the segment but cannot proceed to the next segment or inventory.
- **Transitions:**
  - `Empty` -> `Transporting`: Triggered when an item is placed onto the conveyor.
  - `Transporting` -> `Blocked`: Triggered when the item reaches the end of the conveyor and the next slot is occupied.
  - `Blocked` -> `Empty`: Triggered when the item is successfully moved to the next segment or picked up.
  - `Transporting` -> `Empty`: Triggered if an item is picked up midway.

## 3. MDA Analysis
- **Mechanics:** The system moves items from point A to point B at a specific speed. It handles item spacing, collision (or lack thereof), and routing (splitters, mergers).
- **Dynamics:** Players create complex networks, balancing throughput, managing bottlenecks, and optimizing spatial layouts. Emergent behaviors include main buses, sushi belts, and buffer loops.
- **Aesthetics:** Satisfaction of order from chaos, the visual appeal of moving items (the "factory must grow" feeling), and the intellectual reward of solving logistical puzzles.

## 4. Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value (Factorio 1.1) | Unit |
|---|---|---|---|---|
| `speed` | f32 | 1.0 - 60.0 | 15.0 | items/second |
| `capacity_per_tile` | u32 | 1 - 8 | 4 | items |
| `length` | f32 | 1.0 - 100.0 | 1.0 | tiles/meters |
| `power_consumption` | f32 | 0.0 - 100.0 | 0.0 | kW |
| `max_incline` | f32 | 0.0 - 90.0 | 0.0 | degrees |

## 5. Benchmark Data
- **Factorio (v1.1):**
  - Transport Belt: Speed = 15 items/sec, Capacity = 8 items/tile (2 lanes).
  - Fast Transport Belt: Speed = 30 items/sec.
  - Express Transport Belt: Speed = 45 items/sec.
- **Satisfactory (Update 8):**
  - Mk.1 Conveyor Belt: Speed = 60 items/min (1 item/sec).
  - Mk.3 Conveyor Belt: Speed = 270 items/min (4.5 items/sec).
  - Mk.5 Conveyor Belt: Speed = 780 items/min (13 items/sec).

## 6. Common Variants
1. **Multi-lane Belts:** Belts that have distinct lanes (e.g., Factorio's left and right lanes) allowing different items to travel side-by-side without mixing.
2. **Vertical Conveyors / Lifts:** Conveyors designed specifically to move items vertically between different elevations (e.g., Satisfactory's Conveyor Lifts).
3. **Sushi Belts:** A dynamic variant where multiple item types are mixed on a single belt, requiring complex sorting logic to prevent jamming.
4. **Powered Belts:** Belts that require electricity to function, adding a layer of power management to logistics.

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_inserter` (Robotic Arms), `atom_splitter`, `atom_merger`, `atom_storage_container`, `atom_crafter` (Assemblers).
- **Incompatible Atoms:** `atom_fluid_pipe` (Fluids typically require pipes, not belts, though some games abstract this).

## 8. Anti-Patterns
1. **Hidden Bottlenecks:** Designing the system such that throughput limits are opaque to the player, leading to frustrating and hard-to-diagnose factory stalls.
2. **Overly Punishing Jamming:** Making belts permanently break or require manual clearing when backed up, rather than simply pausing transport.
3. **Physics-Heavy Simulation:** Simulating each item on the belt as a full physics object, which drastically limits the scale of the factory due to CPU constraints.
