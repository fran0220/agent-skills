# Gameplay Atom: Day/Night Cycle

## 1. Identity
- **Atom ID**: atom_day_night_cycle
- **English Name**: Day/Night Cycle
- **Chinese Name**: 日夜循环
- **Category**: G/H (World/Environment)
- **Definition**: A systemic mechanic that simulates the passage of time within the game world, typically altering lighting, NPC schedules, enemy spawns, and resource availability based on the current time of day.

## 2. Core Verb & State Machine
- **Core Verb**: Wait / Pass Time / Sleep
- **State Diagram**:
  [Dawn] -> [Day] -> [Dusk] -> [Night] -> [Dawn]
- **States**:
  - `Dawn`: Transition period from night to day. Lighting increases.
  - `Day`: Primary active period. Maximum visibility, safe environment.
  - `Dusk`: Transition period from day to night. Lighting decreases.
  - `Night`: Primary inactive or dangerous period. Minimum visibility, altered spawns.
- **Transitions**:
  - `Dawn` to `Day`: Triggered when time >= 06:00.
  - `Day` to `Dusk`: Triggered when time >= 18:00.
  - `Dusk` to `Night`: Triggered when time >= 20:00.
  - `Night` to `Dawn`: Triggered when time >= 04:00.

## 3. MDA Analysis
- **Mechanics**: The game maintains a continuous internal clock that advances at a set rate relative to real-world time. This clock dictates the current state (Day, Night, etc.) and triggers events or changes in the environment, such as lighting adjustments, NPC behavior shifts, and enemy spawn table swaps.
- **Dynamics**: Players must plan their activities around the cycle. For example, they might gather resources during the day and seek shelter or fight specific enemies at night. Time management becomes a crucial part of the gameplay loop.
- **Aesthetics**: Creates a sense of immersion and a living, breathing world. It evokes feelings of safety and productivity during the day, and tension, fear, or mystery during the night.

## 4. Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value (Game) | Unit |
|---|---|---|---|---|
| `real_seconds_per_game_day` | f32 | 600 - 3600 | 1200 (Minecraft 1.19) | seconds |
| `day_duration_ratio` | f32 | 0.5 - 0.8 | 0.5 (Minecraft 1.19) | ratio |
| `night_duration_ratio` | f32 | 0.2 - 0.5 | 0.33 (Minecraft 1.19) | ratio |
| `dawn_dusk_duration_ratio` | f32 | 0.05 - 0.15 | 0.083 (Minecraft 1.19) | ratio |
| `time_scale_multiplier` | f32 | 1.0 - 100.0 | 72.0 (Minecraft 1.19) | multiplier |

## 5. Benchmark Data
- **Minecraft (v1.19)**:
  - `real_seconds_per_game_day`: 1200 seconds (20 minutes)
  - `day_duration_ratio`: 0.5 (10 minutes)
  - `night_duration_ratio`: 0.33 (7 minutes)
  - `dawn_dusk_duration_ratio`: 0.083 (1.5 minutes each)
- **Stardew Valley (v1.5)**:
  - `real_seconds_per_game_day`: 860 seconds (14 minutes 20 seconds)
  - `day_duration_ratio`: 0.7 (06:00 to 20:00)
  - `night_duration_ratio`: 0.3 (20:00 to 02:00)
- **The Legend of Zelda: Breath of the Wild (v1.5.0)**:
  - `real_seconds_per_game_day`: 1440 seconds (24 minutes)
  - `day_duration_ratio`: 0.6
  - `night_duration_ratio`: 0.4

## 6. Common Variants
1. **Real-Time Sync**: The game clock is synchronized with the real-world clock of the player's device (e.g., Animal Crossing).
2. **Player-Driven Time**: Time only advances when the player performs specific actions or moves (e.g., Superhot, though not strictly day/night, the concept applies to time progression).
3. **Static Time**: The time of day is fixed per level or area and does not progress naturally (e.g., many traditional linear RPGs).
4. **Accelerated Night**: The night passes much faster than the day to minimize downtime if the player cannot sleep (e.g., some survival games).
5. **Seasonal Cycles**: The day/night cycle length varies depending on the current in-game season (e.g., Don't Starve).

## 7. Compatibility Notes
- **Compatible Atoms**:
  - `atom_weather_system`: Weather often interacts with the time of day (e.g., morning fog).
  - `atom_npc_schedule`: NPCs need a time reference to perform daily routines.
  - `atom_stealth_mechanics`: Darkness at night naturally enhances stealth gameplay.
- **Incompatible Atoms**:
  - `atom_strict_time_limit`: If a level has a strict 3-minute timer, a full day/night cycle is usually irrelevant and distracting.

## 8. Anti-Patterns
1. **Excessive Darkness**: Making the night so dark that the game becomes unplayable or frustrating without providing adequate light sources.
2. **Boring Nights**: Forcing the player to wait out the night in a safe zone without providing meaningful activities to do during that time.
3. **Desynchronized Events**: Having NPC schedules or enemy spawns that do not align properly with the visual lighting changes of the day/night cycle.
