# Gameplay Atom: Shared Draft (Carousel)

## 1. Identity
**Atom ID:** `atom_shared_draft`
**English Name:** Shared Draft / Carousel
**Chinese Name:** 旋转选秀
**Category:** C (Catch-up / Comeback Mechanics)
**Definition:** The Shared Draft, commonly known as the Carousel, is a simultaneous or sequential drafting mechanic where players select from a shared pool of resources (typically characters, items, or combinations thereof) that move in a circular path. It serves as a primary catch-up mechanism by granting selection priority to players with lower health or standing, thereby balancing the game's competitive economy and introducing strategic trade-offs between immediate power and long-term synergy.

## 2. Core Verb & State Machine
**Core Verb:** `select_moving_target` (Select a moving target from a shared pool)

**State Diagram:**
```text
[Idle] --> (Draft Starts) --> [Spawning]
[Spawning] --> (Items Generated) --> [Rotating]
[Rotating] --> (Gates Open for Lowest HP) --> [Selecting]
[Selecting] --> (Player Collides with Item) --> [Acquired]
[Acquired] --> (All Players Selected or Timeout) --> [Resolution]
[Resolution] --> (Draft Ends) --> [Idle]
```

**States and Transitions:**
- **Idle:** The default state before the draft phase begins.
- **Spawning:** The system generates the entities (champions + items) to be drafted.
- **Rotating:** The entities move in a circular path at a set speed. Players are locked behind barriers.
- **Selecting:** Barriers open sequentially based on player ranking (lowest health first). Players can move their avatars.
- **Acquired:** A player's avatar collides with an entity, claiming it and removing it from the pool.
- **Resolution:** Remaining unselected entities are cleared, and players are returned to their boards.

## 3. MDA Analysis
**Mechanics:** The system generates a fixed number of composite rewards (e.g., a unit holding an item) and places them on a rotating carousel. Players are released in pairs or individually based on their current health deficit, with the lowest health players released first. Collision detection between the player's avatar and the reward entity determines acquisition.
**Dynamics:** Players must constantly evaluate the board state to determine their drafting priorities. The moving targets create a spatial challenge, leading to body-blocking or "sniping" where a player intentionally takes a resource another player needs. The catch-up mechanic forces winning players to adapt to suboptimal choices, while losing players can pivot their strategy around a high-value acquisition.
**Aesthetics:** The Shared Draft evokes feelings of tension, anticipation, and occasional frustration or triumph. The physical act of moving an avatar to grab a contested item adds a layer of real-time action to an otherwise asynchronous or turn-based strategy game, creating memorable moments of direct player interaction.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (TFT Set 9) | Unit |
| :--- | :--- | :--- | :--- | :--- |
| `carousel_radius` | `f32` | 5.0 - 15.0 | 10.0 | meters |
| `rotation_speed` | `f32` | 15.0 - 45.0 | 30.0 | degrees/sec |
| `entity_count` | `u32` | 7 - 12 | 9 | count |
| `release_interval` | `f32` | 2.0 - 5.0 | 3.5 | seconds |
| `selection_timeout` | `f32` | 10.0 - 20.0 | 15.0 | seconds |
| `player_move_speed` | `f32` | 4.0 - 8.0 | 6.0 | meters/sec |
| `collision_radius` | `f32` | 0.5 - 2.0 | 1.2 | meters |

## 5. Benchmark Data
- **Teamfight Tactics (TFT) - Set 9:**
  - `entity_count`: 9 (to ensure the last player has a choice between two options).
  - `release_interval`: 3.5 seconds between pairs of players.
  - `rotation_speed`: Approximately 30 degrees per second.
- **Dota Underlords - Version 1.0 (Contraption Draft):**
  - Note: Underlords used a static selection rather than a rotating carousel, but the catch-up priority was similar.
  - `selection_timeout`: 10 seconds per player.
- **Auto Chess (Drodo) - Season 1:**
  - Did not feature a carousel, highlighting the distinct design choice of TFT to include this specific atom for catch-up.

## 6. Common Variants
1. **Static Draft:** Entities do not rotate; they are placed in a line or grid. Reduces the action/spatial element.
2. **Blind Draft:** The contents of the draft are partially or fully hidden until selected.
3. **Bidding Draft:** Instead of turn order based on health, players use a secondary currency to bid on items.
4. **Component-Only Carousel:** Only items are drafted, not units, reducing the impact on team composition.
5. **Anvil Selection:** A modern TFT variant where players choose from a personal armory rather than a shared pool, removing the direct competition aspect.

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_health_pool` (Health determines turn order), `atom_item_combination` (Drafted items are used in recipes), `atom_unit_upgrade` (Drafted units contribute to star levels).
- **Incompatible Atoms:** `atom_pure_rng_loot` (Directly conflicts with the deterministic catch-up nature of the draft), `atom_simultaneous_turns` (If all players act at once, the catch-up mechanic is nullified).

## 8. Anti-Patterns
1. **Over-Punishing the Leader:** If the draft contains overwhelmingly powerful items that only the losing players can access, it disincentivizes winning early rounds.
2. **Clunky Collision Detection:** If the hitboxes for selecting entities are too small or poorly aligned with the visual models, players will accidentally select the wrong item, leading to severe frustration.
3. **Insufficient Options:** If `entity_count` is exactly equal to the number of players, the last player has no agency. There should always be at least `player_count + 1` entities.
