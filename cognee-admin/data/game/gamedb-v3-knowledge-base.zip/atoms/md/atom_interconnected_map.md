# Interconnected Map (互联地图)

## 1. Identity
- **Atom ID:** `atom_interconnected_map`
- **English Name:** Interconnected Map
- **Chinese Name:** 互联地图
- **Category:** G (World/Level Design)
- **Definition:** A level design structure where multiple distinct areas are woven together through a complex network of paths, shortcuts, and loops. Instead of a linear progression, players navigate a cohesive, continuous world where exploration often leads back to familiar locations, creating a profound sense of spatial awareness and discovery.

## 2. Core Verb & State Machine
- **Core Verb:** Explore / Navigate

**State Diagram:**
```text
[Unexplored] --> (Discover) --> [Explored_DeadEnd]
[Unexplored] --> (Discover) --> [Explored_Path]
[Explored_Path] --> (Unlock Shortcut) --> [Connected_Hub]
[Connected_Hub] --> (Traverse) --> [Explored_Path]
```

**States and Transitions:**
- `Unexplored`: The player has not yet visited this area.
- `Explored_DeadEnd`: The player has visited the area but cannot progress further without a specific ability or key.
- `Explored_Path`: The player has traversed the area and can move through it.
- `Connected_Hub`: A central or significant area that links multiple paths together.
- **Transitions:**
  - *Discover*: Moving into an `Unexplored` area changes its state to `Explored_DeadEnd` or `Explored_Path`.
  - *Unlock Shortcut*: Opening a locked door, kicking down a ladder, or activating an elevator that connects an `Explored_Path` back to a `Connected_Hub` or previous area.
  - *Traverse*: Moving between known areas.

## 3. MDA Analysis
- **Mechanics:** The game world is divided into zones with multiple entry and exit points. Progression is gated by physical locks, one-way doors, or missing abilities (Metroidvania style). Shortcuts can be opened from one side to permanently alter the traversal graph.
- **Dynamics:** Players naturally form mental maps of the environment. They experience tension when venturing deep into unknown territory and immense relief when discovering a shortcut back to a safe zone (e.g., a bonfire or bench).
- **Aesthetics:** Evokes feelings of discovery, mastery, and awe. The realization that a new, dangerous area loops back to a familiar, safe starting point is a highly rewarding "aha!" moment.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Game/Version) | Unit |
|---|---|---|---|---|
| `nodes_count` | u32 | 10 - 100 | 42 (Dark Souls v1.0) | zones |
| `shortcuts_per_zone` | f32 | 0.5 - 3.0 | 1.5 (Hollow Knight v1.5) | count |
| `loop_length_avg` | f32 | 5.0 - 20.0 | 12.5 (Dark Souls v1.0) | minutes |
| `hub_connectivity` | u32 | 3 - 10 | 5 (Hollow Knight v1.5) | paths |

## 5. Benchmark Data
- **Dark Souls (v1.0):**
  - `nodes_count`: 42 distinct named zones/sub-zones.
  - `loop_length_avg`: ~12.5 minutes of cautious exploration before finding a shortcut back to Firelink Shrine or a major bonfire.
- **Hollow Knight (v1.5):**
  - `shortcuts_per_zone`: ~1.5 (breakable walls, switches, stag stations).
  - `hub_connectivity`: 5 main paths branching from Dirtmouth/Forgotten Crossroads.
- **Super Metroid (v1.0):**
  - `nodes_count`: ~30 major map sectors.
  - `hub_connectivity`: 4 major elevators connecting to Crateria.

## 6. Common Variants
1. **Spoke-and-Hub:** A central safe zone with linear paths radiating outward that eventually loop back (e.g., Demon's Souls, though less interconnected than Dark Souls).
2. **Ability-Gated (Metroidvania):** Interconnectivity relies on acquiring new movement abilities (double jump, dash) rather than just physical keys or switches.
3. **Vertical Slice:** The map is built vertically, with gravity acting as a one-way traversal mechanic until elevators or flight are unlocked.
4. **Overworld/Underworld:** Two parallel interconnected maps that map 1:1, where obstacles in one can be bypassed by traversing the other (e.g., Zelda: A Link to the Past).

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_safe_room` (Bonfires/Save Rooms), `atom_ability_gate` (Metroidvania progression), `atom_environmental_storytelling`.
- **Incompatible Atoms:** `atom_procedural_generation` (Highly authored interconnected maps conflict with random generation, though games like Dead Cells attempt a hybrid), `atom_linear_corridor`.

## 8. Anti-Patterns
1. **The Useless Shortcut:** Unlocking a shortcut that takes longer to traverse than the main path, or connects two areas the player has no reason to revisit.
2. **Over-Gating:** Requiring too many specific keys or abilities to traverse the map, turning exploration into a tedious checklist rather than an organic discovery.
3. **Navigational Spaghetti:** Creating too many connections without distinct landmarks, causing the player's mental map to collapse into confusion.
