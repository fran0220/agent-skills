# Identity
- **Atom ID**: atom_escape_room
- **English Name**: Escape Room Puzzle
- **Chinese Name**: 密室逃脱谜题
- **Category**: C
- **Definition**: A confined space where players must discover clues, solve interconnected puzzles, and unlock mechanisms to escape within a given context or time limit.

# Core Verb & State Machine
- **Core Verb**: Investigate / Solve
- **State Diagram**:
  [Locked In] -> (Find Clue) -> [Investigating]
  [Investigating] -> (Solve Puzzle) -> [Puzzle Solved]
  [Puzzle Solved] -> (Unlock Door) -> [Escaped]
- **States**: Locked In, Investigating, Puzzle Solved, Escaped
- **Transitions**:
  - Locked In -> Investigating: Triggered by finding a clue.
  - Investigating -> Puzzle Solved: Triggered by solving a puzzle.
  - Puzzle Solved -> Escaped: Triggered by unlocking the final door.

# MDA Analysis
- **Mechanics**: The system provides a locked room with hidden objects, clues, and locks. Players interact with objects to gather information and input solutions.
- **Dynamics**: Players explore the room, piece together information, and experience moments of realization as they connect clues to puzzles.
- **Aesthetics**: Intellectual challenge, mystery, tension (if timed), and the satisfaction of discovery and escape.

# Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value | Unit |
|---|---|---|---|---|
| time_limit | f32 | 0.0 - 3600.0 | 3600.0 (Zero Escape: VLR) | seconds |
| puzzle_count | u32 | 3 - 15 | 5 (The Room 1) | count |
| hint_cooldown | f32 | 30.0 - 300.0 | 60.0 (The Room 3) | seconds |

# Benchmark Data
- **The Room (v1.0)**: puzzle_count = 5, hint_cooldown = 60.0
- **Zero Escape: Virtue's Last Reward (v1.0)**: time_limit = 3600.0, puzzle_count = 10

# Common Variants
1. **Timed Escape**: A strict countdown timer adds pressure (e.g., Zero Escape).
2. **Narrative Escape**: Puzzles are deeply integrated into the story and environment (e.g., The Room).
3. **Co-op Escape**: Players are separated and must communicate clues to each other (e.g., We Were Here).

# Compatibility Notes
- **Compatible Atoms**: atom_inventory_system, atom_dialogue_tree, atom_hidden_object
- **Conflicts**: atom_fast_paced_combat (breaks the slow, methodical pacing of puzzles)

# Anti-Patterns
1. **Moon Logic**: Puzzles that require illogical or overly obscure leaps of reasoning.
2. **Pixel Hunting**: Making crucial clues too small or hard to see, leading to frustration rather than challenge.
3. **Lack of Feedback**: Not providing clear indications when a puzzle is solved or a mechanism is activated.
