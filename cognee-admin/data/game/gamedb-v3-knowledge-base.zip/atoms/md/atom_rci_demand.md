# RCI Demand Balance (RCI需求平衡)

## 1. Identity
- **Atom ID:** atom_rci_demand
- **English Name:** RCI Demand Balance
- **Chinese Name:** RCI需求平衡
- **Category:** G (Gameplay Systems)
- **Definition:** The RCI (Residential, Commercial, Industrial) Demand Balance is a core macro-management system in city-building games that simulates the interdependent economic needs of a virtual population. It drives player expansion by dynamically calculating the demand for housing, shopping/services, and jobs based on population demographics, education levels, land value, and available resources.

## 2. Core Verb & State Machine
- **Primary Player Verb:** Zone (Allocate land for specific uses)
- **State Diagram:**
  [Idle] --> (Demand Increases) --> [High Demand]
  [High Demand] --> (Player Zones Area) --> [Zoned]
  [Zoned] --> (Conditions Met) --> [Developing]
  [Developing] --> (Construction Complete) --> [Active]
  [Active] --> (Conditions Fail) --> [Abandoned]
  [Abandoned] --> (Bulldozed/Re-zoned) --> [Idle]
- **States:** Idle, High Demand, Zoned, Developing, Active, Abandoned.
- **Transitions:**
  - Idle -> High Demand: Triggered by population growth or economic shifts.
  - High Demand -> Zoned: Triggered by player action (zoning).
  - Zoned -> Developing: Triggered by road access, power, and water availability.
  - Developing -> Active: Triggered by time elapsed and construction completion.
  - Active -> Abandoned: Triggered by lack of services, high taxes, or pollution.
  - Abandoned -> Idle: Triggered by player bulldozing the abandoned building.

## 3. MDA Analysis
- **Mechanics:** The system calculates three interconnected variables (R, C, I). High R increases demand for C (shopping) and I (jobs). High C and I increase demand for R (workers). Taxes, land value, and education act as modifiers.
- **Dynamics:** Players experience a continuous cycle of balancing. Zoning too much of one type crashes its demand and spikes the others. The city organically expands in waves as the player chases the shifting RCI bars.
- **Aesthetics:** Provides a sense of *Discovery* (watching the city grow) and *Challenge* (maintaining equilibrium). Players feel like a macro-manager orchestrating a complex, living organism.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (SimCity 4) | Unit |
|---|---|---|---|---|
| `base_r_demand` | f32 | -6000 to 6000 | 1000 | Demand Units |
| `base_c_demand` | f32 | -6000 to 6000 | 500 | Demand Units |
| `base_i_demand` | f32 | -6000 to 6000 | 500 | Demand Units |
| `tax_penalty_multiplier` | f32 | 0.0 to 2.0 | 1.2 | Multiplier |
| `education_modifier` | f32 | 0.5 to 1.5 | 1.0 | Multiplier |
| `unemployment_tolerance` | f32 | 0.0 to 0.2 | 0.05 | Percentage |

## 5. Benchmark Data
- **SimCity 4 (v1.1.641):**
  - R demand is heavily segmented by wealth (R$, R$$, R$$$).
  - Default tax rate neutral point is 9.0%. Above 9%, demand decreases.
  - Ratio of R:C:I jobs is roughly 2:1:1 in early game.
- **Cities: Skylines (v1.16.1-f2):**
  - R demand is driven by the ratio of available workers to total jobs.
  - C demand is driven by the ratio of available goods to citizen shopping needs.
  - I demand is driven by unemployment (need for jobs).
  - Neutral tax rate is 12%.

## 6. Common Variants
1. **RCAO (Residential, Commercial, Agricultural, Office):** Splits Industrial into Agricultural (low education) and Office (high education). Seen in Cities: Skylines.
2. **Class-Based RCI:** Demand is strictly separated by wealth classes (Low, Medium, High) that do not easily intermix. Seen in SimCity 4.
3. **Resource-Driven RCI:** Industrial demand is tied to specific extractable resources on the map (Oil, Ore) rather than generic jobs.
4. **Service-Heavy RCI:** Commercial is split into Goods (retail) and Services (entertainment, tourism), requiring different zoning strategies.

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_taxation_system`, `atom_land_value`, `atom_traffic_flow`, `atom_pollution_spread`.
- **Incompatible Atoms:** `atom_fixed_narrative_progression` (RCI is inherently sandbox and emergent, conflicting with strict linear storytelling).

## 8. Anti-Patterns
1. **Death Spirals:** If a slight imbalance in RCI causes mass abandonment, which lowers tax income, preventing the player from fixing the issue, leading to a game over.
2. **Opaque Demand Drivers:** Hiding the reasons *why* a demand bar is low (e.g., not telling the player that C demand is low because of lack of educated workers, not lack of population).
3. **Instantaneous Feedback:** If zoning immediately fulfills demand without a construction delay, the simulation feels artificial and lacks weight.
