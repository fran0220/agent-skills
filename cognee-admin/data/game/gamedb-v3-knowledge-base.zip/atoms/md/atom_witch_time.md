# Gameplay Atom: Witch Time / Slow-Mo Dodge

## 1. Identity
- **Atom ID:** `atom_witch_time`
- **English Name:** Witch Time / Slow-Mo Dodge
- **Chinese Name:** 魔女时间/慢动作闪避
- **Category:** A+B (Action & Combat)
- **Definition:** A defensive combat mechanic where performing a dodge or evasion maneuver at the precise moment before an enemy attack connects triggers a temporary state of extreme slow motion for all entities except the player character. This rewards high-risk, high-skill timing with a window of opportunity for uncontested counterattacks, repositioning, or recovery.

## 2. Core Verb & State Machine
**Core Verb:** Perfect Dodge (Evade)

**State Diagram:**
[Normal Combat] --(Enemy Attack Initiated)--> [Incoming Attack Window]
[Incoming Attack Window] --(Dodge Too Early)--> [Normal Dodge]
[Incoming Attack Window] --(Dodge Too Late)--> [Hit/Damage Taken]
[Incoming Attack Window] --(Perfect Dodge)--> [Witch Time Active]
[Witch Time Active] --(Duration Expires)--> [Normal Combat]

**States and Transitions:**
- **Normal Combat:** The default state where time flows normally.
- **Incoming Attack Window:** A brief period (often measured in frames) just before an enemy hitbox intersects the player's hurtbox.
- **Normal Dodge:** The player evades the attack but does not trigger the slow-motion effect because the timing was outside the perfect window.
- **Hit/Damage Taken:** The player fails to evade and receives damage.
- **Witch Time Active:** The slow-motion state. The player moves at normal or slightly accelerated speed, while enemies and the environment are drastically slowed down.

## 3. MDA Analysis
- **Mechanics:** The system monitors the distance and time-to-impact of incoming enemy attacks. If the player inputs a dodge command within a specific frame window (e.g., 2-5 frames before impact), a global time scale modifier is applied to enemies and environmental hazards, while the player's time scale remains at 1.0.
- **Dynamics:** Players are incentivized to wait until the last possible moment to dodge, increasing risk. This leads to a rhythm of baiting attacks, executing precise dodges, and unleashing burst damage during the slow-motion window. It transforms defensive play into an aggressive offensive strategy.
- **Aesthetics:** The mechanic evokes feelings of mastery, empowerment, and cinematic flair. The sudden shift in time scale, often accompanied by visual filters and audio distortion, provides intense sensory feedback and a rush of adrenaline, making the player feel like an untouchable badass.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Bayonetta v1.0) | Unit |
| --- | --- | --- | --- | --- |
| `perfect_dodge_window` | `f32` | 0.033 - 0.150 | 0.083 (approx 5 frames at 60fps) | Seconds |
| `slow_motion_scale` | `f32` | 0.05 - 0.30 | 0.10 | Multiplier |
| `witch_time_duration` | `f32` | 1.5 - 4.0 | 2.5 | Seconds |
| `cooldown` | `f32` | 0.0 - 5.0 | 0.0 | Seconds |
| `player_speed_multiplier` | `f32` | 1.0 - 1.5 | 1.1 | Multiplier |

## 5. Benchmark Data
- **Bayonetta (v1.0):**
  - `perfect_dodge_window`: 0.083s (5 frames at 60fps)
  - `slow_motion_scale`: 0.10x
  - `witch_time_duration`: 2.5s (varies slightly by enemy attack type)
- **The Legend of Zelda: Breath of the Wild (v1.5.0) [Flurry Rush]:**
  - `perfect_dodge_window`: 0.100s (3 frames at 30fps)
  - `slow_motion_scale`: 0.05x
  - `witch_time_duration`: 3.0s (effectively, until flurry rush sequence ends)
- **Max Payne 3 (v1.0.0.114) [Shootdodge]:**
  - `perfect_dodge_window`: N/A (Triggered on demand during dodge)
  - `slow_motion_scale`: 0.20x
  - `witch_time_duration`: Until landing

## 6. Common Variants
1. **On-Demand Slow-Mo (Max Payne):** Instead of requiring a perfect dodge, the player can trigger the slow-motion dive at will, consuming a resource meter.
2. **Counter-Attack Prompt (Breath of the Wild):** The perfect dodge doesn't just slow time; it explicitly prompts a specialized, high-damage counter-attack sequence (Flurry Rush).
3. **Area of Effect Slow-Mo:** The slow-motion effect is localized to a bubble or specific radius around the player, rather than affecting the entire world.
4. **Perfect Parry Slow-Mo:** Triggered by a perfect block or parry rather than a dodge, often leaving the enemy in a staggered state.

## 7. Compatibility Notes
- **Commonly Pairs With:** `atom_combo_system` (allows extending combos safely), `atom_stamina_meter` (limits the number of dodge attempts), `atom_resource_generation` (successful Witch Time generates magic/special meter).
- **Known Conflicts:** `atom_multiplayer_sync` (global time scaling is notoriously difficult to implement fairly in synchronous PvP multiplayer).

## 8. Anti-Patterns
1. **Overly Generous Window:** Making the perfect dodge window too large removes the risk, turning the game into a trivial slow-motion simulator where the player is never threatened.
2. **Lack of Visual/Audio Cues:** Failing to provide clear telegraphing for enemy attacks or distinct feedback when Witch Time activates makes the mechanic feel random and unsatisfying.
3. **Disruptive Pacing:** If Witch Time lasts too long or occurs too frequently, it can ruin the overall pacing and flow of combat, making encounters feel sluggish rather than dynamic.
