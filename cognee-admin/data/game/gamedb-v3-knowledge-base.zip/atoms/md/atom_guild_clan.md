# Gameplay Atom: Guild / Clan System

## 1. Identity
- **Atom ID**: atom_guild_clan
- **English Name**: Guild / Clan System
- **Chinese Name**: 公会/氏族系统
- **Category**: E (Social / Multiplayer)
- **Definition**: A structured social organization system that allows players to form persistent groups, share resources, communicate privately, and participate in collective activities or progression.

## 2. Core Verb & State Machine
- **Core Verb**: Join / Manage / Contribute
- **State Diagram**:
  - [Unaffiliated] -> (Apply/Create) -> [Pending/Active]
  - [Pending] -> (Accept) -> [Active]
  - [Pending] -> (Reject) -> [Unaffiliated]
  - [Active] -> (Leave/Kick) -> [Unaffiliated]
  - [Active] -> (Promote/Demote) -> [Active (Role Changed)]
- **States**: Unaffiliated, Pending, Active
- **Transitions**:
  - Unaffiliated -> Pending: Player applies to a guild.
  - Unaffiliated -> Active: Player creates a new guild.
  - Pending -> Active: Guild leadership accepts the application.
  - Pending -> Unaffiliated: Guild leadership rejects the application.
  - Active -> Unaffiliated: Player leaves or is kicked from the guild.
  - Active -> Active: Player's role within the guild changes.

## 3. MDA Analysis
- **Mechanics**: Systems for creating a group, inviting members, setting roles/permissions, shared chat channels, shared storage (guild bank), and collective progression (guild levels/perks).
- **Dynamics**: Players cooperate to achieve shared goals, form hierarchies and social bonds, pool resources for mutual benefit, and sometimes engage in inter-group competition (GvG).
- **Aesthetics**: Fellowship (social interaction), Expression (guild identity/tabard), and Challenge (tackling group-only content).

## 4. Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value | Unit |
|---|---|---|---|---|
| max_members | u32 | 50 - 1000 | 50 (Clash of Clans) | players |
| creation_cost | u32 | 0 - 10000 | 10000 (WoW Classic) | gold/currency |
| min_level_to_create | u32 | 1 - max_level | 10 (WoW) | level |
| inactivity_kick_days | u32 | 7 - 365 | 30 (Destiny 2) | days |
| max_roles | u32 | 3 - 10 | 4 (Clash of Clans) | roles |

## 5. Benchmark Data
- **World of Warcraft (Retail v10.0)**: max_members = 1000, creation_cost = 10 gold, min_level_to_create = 10.
- **Clash of Clans (v15.0)**: max_members = 50, creation_cost = 40000 gold, max_roles = 4 (Member, Elder, Co-leader, Leader).
- **Destiny 2 (Lightfall)**: max_members = 100, creation_cost = 0, inactivity_kick_days = 30 (often manually enforced).

## 6. Common Variants
- **Micro-Guilds**: Small, intimate groups with low member caps (e.g., 4-8 players) focused on tight-knit co-op.
- **Mega-Alliances**: Systems allowing multiple guilds to form a larger alliance for massive scale PvP or territory control (e.g., EVE Online).
- **Progression-Only Guilds**: Guilds that exist primarily to unlock passive buffs or shared rewards, with minimal social interaction required.
- **Faction-Restricted Guilds**: Guilds where all members must belong to the same overarching game faction (e.g., Horde/Alliance in WoW).

## 7. Compatibility Notes
- **Compatible Atoms**: atom_chat_system, atom_gvg_combat, atom_shared_storage, atom_group_finder.
- **Conflicts**: atom_solo_ironman (players restricted from trading/grouping usually cannot fully participate in guilds).

## 8. Anti-Patterns
- **Ghost Towns**: Setting the member cap too high without tools to manage inactive players, leading to dead guilds.
- **Leader Burnout**: Failing to provide adequate delegation tools, forcing the guild leader to micromanage everything.
- **Forced Socialization**: Tying critical progression exclusively to guild membership, alienating solo players.
