# Gameplay Atom: Jump Buffering

## 1. Identity
- **Atom ID:** `atom_jump_buffer`
- **English Name:** Jump Buffering
- **Chinese Name:** 跳跃预输入
- **Category:** A (Core Movement)
- **Definition:** Jump buffering is a game feel and input leniency mechanic that allows a player's jump input to be registered and held for a short duration (the buffer window) before the character is actually eligible to jump (e.g., before landing on the ground). If the character becomes eligible to jump within this window, the jump is executed on the exact frame they become eligible. This prevents players from missing jumps due to inputting the command slightly too early, significantly improving the perceived responsiveness and fluidity of the game's controls.

## 2. Core Verb & State Machine
- **Core Verb:** Jump (Input)

**State Diagram:**
```text
[Airborne] --(Jump Input)--> [Buffer Active]
[Buffer Active] --(Land on Ground)--> [Jump Executed]
[Buffer Active] --(Timer Expires)--> [Airborne]
[Grounded] --(Jump Input)--> [Jump Executed]
```

**States:**
- `Airborne`: The character is in the air and not eligible to jump (assuming no double jump).
- `Buffer Active`: A jump input has been received, and the buffer timer is counting down.
- `Grounded`: The character is on the ground and eligible to jump.
- `Jump Executed`: The character successfully initiates a jump.

**Transitions:**
- `Airborne` -> `Buffer Active`: Triggered when the player presses the jump button while in the air.
- `Buffer Active` -> `Jump Executed`: Triggered if the character lands on the ground while the buffer timer is greater than zero.
- `Buffer Active` -> `Airborne`: Triggered if the buffer timer reaches zero before the character lands.
- `Grounded` -> `Jump Executed`: Triggered when the player presses the jump button while on the ground.

## 3. MDA Analysis
- **Mechanics:** The system records the timestamp or frame of a jump input. Each frame, it checks if the character is grounded. If grounded and the time since the last jump input is less than or equal to the `buffer_window`, a jump is triggered.
- **Dynamics:** Players can press the jump button slightly before hitting the ground to guarantee a frame-perfect jump upon landing. This encourages faster, more aggressive playstyles and reduces the cognitive load of timing inputs perfectly.
- **Aesthetics:** Creates a feeling of fairness, responsiveness, and fluidity. Players feel like the game "listens" to their intentions rather than strictly punishing minor timing errors. It reduces frustration and enhances the sense of mastery.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Celeste v1.4.0.0) | Unit |
| :--- | :--- | :--- | :--- | :--- |
| `buffer_window` | `f32` | 0.05 - 0.15 | 0.083 (5 frames at 60fps) | seconds |
| `allow_buffer_in_air` | `bool` | true/false | true | boolean |
| `consume_on_jump` | `bool` | true/false | true | boolean |

## 5. Benchmark Data
- **Celeste (v1.4.0.0):**
  - `buffer_window`: 5 frames (approx. 0.083 seconds at 60 FPS). Celeste is known for its incredibly tight yet forgiving controls, and a 5-frame buffer is a key component of this.
- **Hollow Knight (v1.5.78.11833):**
  - `buffer_window`: Approx. 0.1 seconds. Hollow Knight uses a slightly more generous buffer to accommodate its combat-heavy platforming, ensuring players can reliably jump out of attacks or falls.

## 6. Common Variants
1. **Action Buffering:** Instead of just jumping, any action (attack, dash) can be buffered.
2. **Variable Buffer Window:** The buffer window changes based on the character's state (e.g., longer buffer when recovering from a heavy attack).
3. **Negative Edge Buffering:** The buffer is triggered upon releasing the button rather than pressing it.
4. **Visual/Audio Cue Buffering:** The game provides subtle feedback when an input is successfully buffered.

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_coyote_time` (Coyote Time), `atom_wall_jump` (Wall Jump), `atom_dash` (Dash). Jump buffering pairs exceptionally well with Coyote Time to create a highly forgiving platforming experience.
- **Incompatible Atoms:** `atom_strict_rhythm_input` (Strict Rhythm Input). If a game relies on exact rhythm matching, buffering inputs can undermine the core challenge.

## 8. Anti-Patterns
1. **Excessively Long Buffer:** A buffer window that is too long (e.g., > 0.3 seconds) can lead to accidental jumps if the player changes their mind after pressing the button early.
2. **Buffering During Uninterruptible Animations:** Allowing a jump to buffer during a long, uninterruptible animation (like a heavy attack) and then executing it immediately after can feel disconnected from the player's current intent.
3. **Inconsistent Buffer Windows:** Having different buffer windows for different actions without clear communication can confuse players and make the controls feel inconsistent.
