# Gameplay Atom: Wave System

## 1. Identity
- **Atom ID:** atom_wave_system
- **English Name:** Wave System
- **Chinese Name:** 波次系统
- **Category:** G/H (Tower Defense, Horde modes)
- **Definition:** A wave system is a structural pacing mechanism that organizes enemy spawns or challenges into discrete, sequential phases (waves) separated by brief periods of respite. It controls the flow of difficulty, giving players predictable intervals to prepare, build, or recover before facing escalating threats.

## 2. Core Verb & State Machine
- **Core Verb:** Survive / Prepare
- **State Diagram:**
  [Idle/Preparation] --> (Trigger/Timer) --> [Spawning] --> (All enemies spawned) --> [Combat/Clearing] --> (All enemies defeated) --> [Idle/Preparation]
- **States:**
  - `Preparation`: Players can build defenses, heal, or upgrade. No active threats.
  - `Spawning`: Enemies are actively entering the play area based on wave definitions.
  - `Combat`: Spawning has finished, but enemies remain alive. Players must eliminate them.
  - `Completed`: All waves are finished.
- **Transitions:**
  - `Preparation` -> `Spawning`: Triggered by player action or a countdown timer reaching zero.
  - `Spawning` -> `Combat`: Triggered when the wave's spawn queue is empty.
  - `Combat` -> `Preparation`: Triggered when all active enemies are defeated.
  - `Combat` -> `Completed`: Triggered when the final wave's enemies are defeated.

## 3. MDA Analysis
- **Mechanics:** The system defines a sequence of waves, each specifying enemy types, quantities, spawn locations, and spawn intervals. It manages timers and tracks the number of active enemies to transition between states.
- **Dynamics:** Players experience a rhythmic cycle of tension and release. The escalating difficulty forces players to optimize their strategies and resource management during preparation phases. Emergent behaviors include "stalling" (keeping one weak enemy alive to extend preparation time if the transition is kill-based).
- **Aesthetics:** The system evokes feelings of anticipation, pressure, and relief. Players feel a sense of accomplishment after surviving a difficult wave and enjoy the strategic satisfaction of preparing for the next one.

## 4. Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value (Game) | Unit |
|---|---|---|---|---|
| `wave_count` | u32 | 5 - 100 | 20 (Bloons TD 6 v38.0) | waves |
| `prep_time` | f32 | 5.0 - 60.0 | 15.0 (Plants vs. Zombies v1.0) | seconds |
| `spawn_interval` | f32 | 0.1 - 5.0 | 1.0 (Vampire Survivors v1.5) | seconds |
| `difficulty_multiplier` | f32 | 1.0 - 5.0 | 1.15 (Risk of Rain 2 v1.2) | multiplier |
| `max_active_enemies` | u32 | 10 - 500 | 300 (Vampire Survivors v1.5) | entities |

## 5. Benchmark Data
- **Bloons TD 6 (v38.0):**
  - `wave_count`: 40 (Easy), 60 (Medium), 80 (Hard)
  - `prep_time`: Manual trigger (or auto-start with 0s delay)
  - `spawn_interval`: Varies heavily per wave, typically 0.5s to 2.0s for standard bloons.
- **Vampire Survivors (v1.5):**
  - `wave_count`: 30 (each minute is a "wave")
  - `prep_time`: 0.0s (continuous flow)
  - `spawn_interval`: 0.5s (scales down as time progresses)
  - `max_active_enemies`: 300
- **Plants vs. Zombies (v1.0):**
  - `wave_count`: 2-4 major "flags" per level
  - `prep_time`: ~15.0s initial, then continuous with pacing
  - `spawn_interval`: ~5.0s to 10.0s between individual zombies

## 6. Common Variants
1. **Endless Waves:** No maximum `wave_count`. Difficulty scales infinitely until the player is defeated (e.g., Call of Duty: Zombies).
2. **Time-Based Waves:** Waves transition strictly based on a timer, regardless of whether previous enemies are defeated, leading to potential overwhelming situations (e.g., Vampire Survivors).
3. **Triggered Waves:** The next wave only starts when the player explicitly triggers it, allowing unlimited preparation time (e.g., Bloons TD 6 with auto-start off).
4. **Director-Controlled Waves:** An AI director dynamically adjusts wave composition and timing based on player performance and stress levels (e.g., Left 4 Dead).

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_tower_defense`, `atom_resource_generation`, `atom_tech_tree`, `atom_boss_encounter`.
- **Incompatible Atoms:** `atom_stealth_mechanics` (waves usually force direct confrontation), `atom_open_world_exploration` (waves restrict movement to a specific defense area).

## 8. Anti-Patterns
1. **Monotonous Pacing:** Making every wave exactly the same length and difficulty, removing the tension/release cycle.
2. **Unpredictable Spikes:** Introducing a massive difficulty spike in a single wave without adequate telegraphing or preparation time.
3. **Infinite Stalling:** Allowing players to keep a single harmless enemy alive indefinitely to farm resources or wait for cooldowns, breaking the intended pacing.
