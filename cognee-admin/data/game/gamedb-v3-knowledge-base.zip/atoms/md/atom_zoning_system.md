# Zoning System (分区系统)

## 1. Identity
- **Atom ID:** atom_zoning_system
- **English Name:** Zoning System
- **Chinese Name:** 分区系统
- **Category:** G (Simulation/Management)
- **Definition:** The Zoning System is a core gameplay mechanic in city-building and management simulation games where players designate specific areas of land for particular types of development (such as residential, commercial, or industrial) rather than constructing individual buildings directly. The game's simulation engine then populates these zones with appropriate structures based on underlying systemic factors like land value, demand, and infrastructure access.

## 2. Core Verb & State Machine
- **Core Verb:** Zone (Designate land use)

**State Diagram:**
[Unzoned] --(Player Zones)--> [Zoned (Empty)]
[Zoned (Empty)] --(Demand + Access)--> [Developing]
[Developing] --(Time + Resources)--> [Developed (Level 1)]
[Developed (Level 1)] --(High Land Value + Services)--> [Developed (Level 2+)]
[Developed (Level X)] --(Lack of Services/Abandonment)--> [Abandoned]
[Abandoned] --(Recovery/Bulldoze)--> [Zoned (Empty)]
[Any State] --(Player De-zones)--> [Unzoned]

**States:**
- `Unzoned`: Raw land with no designated purpose.
- `Zoned (Empty)`: Land designated for a specific use but currently unoccupied.
- `Developing`: Construction is actively occurring on the zoned land.
- `Developed (Level X)`: Fully functional buildings operating at a specific density or wealth level.
- `Abandoned`: Buildings that have been vacated due to poor conditions (e.g., high crime, lack of workers, pollution).

**Transitions:**
- `Player Zones`: The player uses a zoning tool to paint a designation over unzoned land.
- `Demand + Access`: The simulation detects demand for the zone type and confirms road/infrastructure access, triggering construction.
- `Time + Resources`: The construction process completes over time.
- `High Land Value + Services`: Favorable conditions cause the building to upgrade to a higher density or wealth level.
- `Lack of Services/Abandonment`: Negative conditions cause the occupants to leave.
- `Recovery/Bulldoze`: The player manually clears the abandoned building, or new occupants move in.
- `Player De-zones`: The player removes the zoning designation, returning the land to its raw state.

## 3. MDA Analysis
- **Mechanics:** The system tracks macro-level demand for different zone types (RCI - Residential, Commercial, Industrial). Players paint zones on a grid or navmesh. The simulation evaluates each zoned cell's desirability (based on pollution, crime, land value, traffic) and spawns buildings if demand and desirability thresholds are met.
- **Dynamics:** Players must balance the spatial relationship between different zones. For example, placing industrial zones far from residential zones reduces pollution impact but increases commute times, leading to traffic congestion. This creates a continuous feedback loop of zoning, observing traffic/demand, and adjusting infrastructure.
- **Aesthetics:** The system evokes a sense of "gardening" or indirect control (Discovery and Expression). Players feel like macro-managers guiding organic growth rather than micro-managers placing every brick. Watching a city skyline organically rise from empty zones provides a strong sense of satisfaction and progression.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Game) | Unit |
| :--- | :--- | :--- | :--- | :--- |
| `zone_desirability_threshold` | f32 | 0.0 - 100.0 | 45.0 (Cities: Skylines v1.16) | Points |
| `construction_time` | f32 | 5.0 - 60.0 | 15.0 (SimCity 4) | Seconds |
| `abandonment_time_limit` | f32 | 30.0 - 300.0 | 120.0 (Cities: Skylines v1.16) | Seconds |
| `density_upgrade_threshold` | f32 | 50.0 - 100.0 | 75.0 (SimCity 4) | Land Value |
| `pollution_tolerance` | f32 | 0.0 - 100.0 | 20.0 (Res), 80.0 (Ind) | Pollution Units |

## 5. Benchmark Data
- **Cities: Skylines (v1.16):**
  - Residential demand is driven by available jobs and current population. Desirability threshold for initial spawning is relatively low (around 30/100), but upgrading to Level 5 requires high land value (80+), full service coverage (fire, police, health, deathcare), and high education levels.
  - Abandonment occurs if a building lacks water or power for approximately 3 in-game weeks.
- **SimCity 4 (Deluxe Edition):**
  - Zoning is strictly tied to a grid system. Density is explicitly controlled by the player (Low, Medium, High density zoning tools) rather than purely organic growth.
  - Desirability is highly localized; a single noisy intersection can depress land value enough to prevent high-wealth residential development in adjacent tiles.

## 6. Common Variants
1. **Density-Specific Zoning:** Players explicitly zone for Low, Medium, or High density (e.g., SimCity 4), giving more direct control over the skyline.
2. **Organic/Procedural Zoning:** Zones adapt to the shape of curved roads rather than a strict grid, creating irregular building lots (e.g., Cities: Skylines).
3. **Specialized Zoning:** Zones that dictate specific industries, such as farming, mining, or tourism, which require specific natural resources to function (e.g., Cities: Skylines Industries DLC).
4. **Mixed-Use Zoning:** Zones that allow for both commercial on the ground floor and residential above, reflecting modern urban planning (e.g., Cities: Skylines II).
5. **Auto-Zoning:** The game automatically zones areas adjacent to newly built roads based on macro-policies, reducing player micromanagement.

## 7. Compatibility Notes
- **Commonly Pairs With:**
  - `atom_road_network`: Zoning almost always requires road access for agents to reach the buildings.
  - `atom_macro_economy`: The RCI demand driving the zoning system is usually calculated by a macro-economic simulation.
  - `atom_agent_pathfinding`: Citizens must pathfind from residential zones to commercial/industrial zones.
- **Known Conflicts:**
  - `atom_gridless_placement`: Strict grid-based zoning conflicts with free-form, gridless building placement systems.
  - `atom_direct_control_combat`: RTS-style direct unit control often clashes with the indirect, macro-level control of a zoning system.

## 8. Anti-Patterns
1. **Instant Spawning:** Buildings appearing instantly when zoned removes the sense of organic growth and time investment, making the city feel artificial.
2. **Opaque Desirability:** If players cannot easily see *why* a zone is not developing (e.g., lacking a specific hidden service), it leads to frustration and perceived bugs.
3. **Over-Sensitivity to Micro-Fluctuations:** If buildings abandon and rebuild constantly due to minor, temporary dips in land value or traffic, the visual noise becomes overwhelming and the simulation feels unstable.
