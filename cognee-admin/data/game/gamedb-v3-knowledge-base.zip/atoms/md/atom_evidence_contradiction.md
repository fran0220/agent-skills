# Identity
- **Atom ID**: atom_evidence_contradiction
- **English Name**: Evidence Contradiction
- **Chinese Name**: 证据矛盾
- **Category**: D
- **Definition**: The player compares a piece of collected evidence against a specific statement or claim to reveal a logical inconsistency, advancing the narrative or investigation.

# Core Verb & State Machine
- **Core Verb**: Present (Evidence)
- **State Diagram**:
  [Idle] -> (Listen to Testimony) -> [Cross-Examination]
  [Cross-Examination] -> (Press) -> [Pressing] -> [Cross-Examination]
  [Cross-Examination] -> (Present Evidence) -> [Evaluating]
  [Evaluating] -> (Match) -> [Contradiction Revealed]
  [Evaluating] -> (Mismatch) -> [Penalty] -> [Cross-Examination]
- **States**: Idle, Cross-Examination, Pressing, Evaluating, Contradiction Revealed, Penalty
- **Transitions**:
  - Idle -> Cross-Examination: Listen to Testimony
  - Cross-Examination -> Pressing: Press
  - Pressing -> Cross-Examination: Return
  - Cross-Examination -> Evaluating: Present Evidence
  - Evaluating -> Contradiction Revealed: Match
  - Evaluating -> Penalty: Mismatch
  - Penalty -> Cross-Examination: Return

# MDA Analysis
- **Mechanics**: The system compares the ID of the presented evidence with the expected evidence ID for a specific statement. If they match, the game progresses. If not, the player's health/credibility decreases.
- **Dynamics**: Players carefully read statements, review their evidence portfolio, and look for logical gaps. They may use trial and error if stuck, leading to resource management (health).
- **Aesthetics**: The "Aha!" moment of solving a puzzle, the thrill of cornering a culprit, and the tension of risking a penalty.

# Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value | Unit |
|---|---|---|---|---|
| penalty_damage | u32 | 10-50 | 20 (Ace Attorney v1.0) | HP |
| max_health | u32 | 50-100 | 100 (Ace Attorney v1.0) | HP |
| evidence_count | u32 | 5-20 | 10 (Danganronpa v1.0) | Items |
| time_limit | f32 | 0.0-300.0 | 0.0 (Ace Attorney v1.0) | Seconds |

# Benchmark Data
- **Ace Attorney (v1.0)**: penalty_damage = 20, max_health = 100, time_limit = 0.0
- **Danganronpa (v1.0)**: penalty_damage = 10, max_health = 50, time_limit = 300.0

# Common Variants
1. **Multiple Evidence Requirement**: The player must present two or more pieces of evidence simultaneously to prove a contradiction.
2. **Point out the Area**: The player must point to a specific area on a piece of visual evidence in addition to presenting it.
3. **Time-Limited Presentation**: The player must find and present the contradiction within a strict time limit (e.g., Danganronpa's Nonstop Debate).

# Compatibility Notes
- **Compatible Atoms**: atom_evidence_collection, atom_testimony_pressing, atom_health_system
- **Incompatible Atoms**: atom_auto_battler, atom_physics_platforming

# Anti-Patterns
1. **Moon Logic**: The connection between the evidence and the statement is too obscure or relies on leaps of logic not established in the game.
2. **Overly Punishing**: The penalty for a wrong guess is too high, discouraging experimentation and leading to save-scumming.
3. **Red Herrings**: Too many pieces of useless evidence clutter the inventory, making the correct choice frustratingly difficult to find.
