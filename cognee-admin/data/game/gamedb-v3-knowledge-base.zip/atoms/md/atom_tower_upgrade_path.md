# Gameplay Atom: Tower Upgrade Path

## 1. Identity
- **Atom ID:** `atom_tower_upgrade_path`
- **English Name:** Tower Upgrade Path
- **Chinese Name:** 塔升级路线
- **Category:** G/H (Progression / Strategy)
- **Definition:** The Tower Upgrade Path is a progression mechanic where a base defensive unit (tower) can be permanently enhanced during a gameplay session through the expenditure of resources. These enhancements often branch into mutually exclusive paths, forcing players to make strategic choices about the tower's specialized role (e.g., area-of-effect damage, single-target burst, utility, or economy generation) based on the current tactical situation.

## 2. Core Verb & State Machine
- **Core Verb:** Upgrade (Select and apply an enhancement to a tower by spending resources).

**State Diagram:**
```text
[Unbuilt] --(Build)--> [Base Tower]
[Base Tower] --(Upgrade Path A)--> [Tier 1A]
[Base Tower] --(Upgrade Path B)--> [Tier 1B]
[Tier 1A] --(Upgrade Path A)--> [Tier 2A]
[Tier 1B] --(Upgrade Path B)--> [Tier 2B]
[Tier 2A] --(Sell)--> [Unbuilt]
```

**States:**
- `Unbuilt`: The tower does not exist on the map.
- `Base Tower`: The tower is built in its default state with baseline stats.
- `Tier X`: The tower has been upgraded to a specific tier on a specific path.

**Transitions:**
- `Build`: Transitions from `Unbuilt` to `Base Tower`. Requires building cost.
- `Upgrade`: Transitions from a lower tier to a higher tier. Requires upgrade cost and meeting prerequisites.
- `Sell`: Transitions from any built state to `Unbuilt`. Refunds a percentage of the total invested cost.

## 3. MDA Analysis
- **Mechanics:** The system provides a structured tree of enhancements for a tower. Each node in the tree modifies the tower's parameters (damage, range, fire rate) or adds new behaviors (camo detection, lead popping). Upgrades cost in-game currency and may be restricted by global progression or mutually exclusive branching rules.
- **Dynamics:** Players must balance immediate survival needs with long-term economic efficiency. The branching paths create emergent synergies between different towers. Players often delay upgrades to save for a more impactful tier, creating a risk-reward tension.
- **Aesthetics:** The mechanic evokes feelings of growth, investment, and strategic mastery. Players experience satisfaction when a carefully planned upgrade path perfectly counters a challenging wave of enemies.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Bloons TD 6 v38.0) | Unit |
| --- | --- | --- | --- | --- |
| `base_cost` | u32 | 100 - 1000 | 200 (Dart Monkey) | Currency |
| `upgrade_cost` | u32 | 100 - 100000 | 150 (Sharp Shots) | Currency |
| `damage_multiplier` | f32 | 1.0 - 10.0 | 1.0 | Multiplier |
| `range_bonus` | f32 | 0.0 - 50.0 | 8.0 | Distance Units |
| `attack_speed_mod` | f32 | 0.1 - 2.0 | 0.85 | Multiplier |
| `sell_return_rate` | f32 | 0.5 - 0.9 | 0.7 | Percentage |

## 5. Benchmark Data
- **Bloons TD 6 (v38.0):** Dart Monkey base cost is 200. Path 1 Tier 1 (Sharp Shots) costs 140, adds +1 pierce. Path 2 Tier 1 (Quick Shots) costs 100, increases attack speed by 15%. Sell return rate is 70% of total investment. Towers can be upgraded up to Tier 5 in one path and Tier 2 in another (5-2-0 or 0-2-5).
- **Kingdom Rush (v1.0):** Archer Tower base cost is 70. Level 2 upgrade costs 110, increases damage from 4-6 to 7-11. Level 4 presents a mutually exclusive choice between Rangers Hideout (cost 230) and Musketeer Garrison (cost 230). Sell return rate is 60%.
- **Arknights (v1.0):** Operators (towers) are upgraded outside of combat (Elite 1, Elite 2) using persistent resources, changing their base stats and unlocking new skills, which fundamentally alters their deployment strategy.

## 6. Common Variants
1. **Mutually Exclusive Branches:** Upgrading down one path permanently locks out the other paths for that specific tower instance (e.g., Kingdom Rush Level 4 upgrades).
2. **Primary/Secondary Paths:** Players can max out one path but only partially upgrade a secondary path (e.g., Bloons TD 6's 5-2-0 system).
3. **Global Upgrades:** Upgrades apply to all towers of that type globally rather than individually (e.g., Plants vs. Zombies plant food upgrades or permanent tech trees).
4. **Synergy Unlocks:** Upgrading a tower unlocks bonuses for adjacent towers of specific types.
5. **Transformative Upgrades:** The final upgrade completely changes the tower's mechanics, sometimes sacrificing its original utility for a new specialized role.

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_resource_generation` (economy towers), `atom_wave_spawning` (upgrading in response to specific wave compositions), `atom_status_effect` (upgrades that add slow, burn, or stun).
- **Incompatible Atoms:** `atom_fixed_loadout` (if towers cannot be modified mid-game), `atom_auto_battler_merge` (merging mechanics often replace traditional linear upgrade paths).

## 8. Anti-Patterns
1. **Illusion of Choice:** One upgrade path is mathematically superior in all situations, rendering the other paths obsolete and removing strategic depth.
2. **Information Obscurity:** The game fails to clearly communicate what an upgrade actually does (e.g., "Increases power" instead of "+5 Damage"), making it impossible for players to make informed decisions.
3. **Punishing Respecs:** The sell return rate is too low, severely punishing players for experimenting with different upgrade paths or adapting to unexpected threats.
