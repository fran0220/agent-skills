# Gameplay Atom: Storyteller / AI Director

## 1. Identity
The `atom_storyteller_ai` gameplay atom, known in English as the Storyteller or AI Director and in Chinese as 叙事者/AI导演, belongs to the H (Systems & AI) category. It is defined as a dynamic pacing and event generation system that monitors player performance, stress levels, and game state to procedurally spawn challenges, rewards, or narrative events. Its primary goal is to maintain an optimal flow state by adjusting difficulty and pacing on the fly, ensuring the player is neither bored nor overwhelmed. This atom is a cornerstone of games that rely on high replayability and emergent narratives, as it acts as an invisible hand guiding the player's experience.

## 2. Core Verb & State Machine
The core verb associated with this atom from the system's perspective is "Direct," while from the player's perspective, it is "Adapt." The player is constantly adapting to the situations orchestrated by the director.

The state machine for the AI Director operates continuously in the background, transitioning between different phases of pacing to create a rhythmic experience.

```text
[Idle/Monitoring] --> (Player Stress Low) --> [Build-up]
[Build-up] --> (Threat Spawned) --> [Peak Action]
[Peak Action] --> (Player Stress High / Threat Defeated) --> [Cooldown]
[Cooldown] --> (Time Passed / Stress Recovered) --> [Idle/Monitoring]
```

The system begins in the `Monitoring` state, where it passively tracks player metrics such as health, resources, and recent combat encounters. When the player's stress falls below a minimum threshold, indicating a lull in the action, the system transitions to the `Build-up` state. Here, it begins spawning minor threats or tension-building events to gradually increase the player's engagement. Once tension reaches a critical mass or a specific trigger occurs, the system enters the `Peak Action` state, unleashing a major challenge or horde to test the player's limits. After the player survives the peak or their stress exceeds the maximum threshold, the system shifts to the `Cooldown` state. This is a grace period where threats are paused, allowing the player to recover, heal, and loot. Finally, after a set duration of peace, the system returns to the `Monitoring` state to begin the cycle anew.

## 3. MDA Analysis
**Mechanics:** The underlying mechanics of the AI Director involve calculating a hidden "stress" or "tension" metric based on various player states, including health, inventory, and recent encounters. The system uses this metric to select events from a weighted pool, which may include enemy spawns, item drops, or environmental changes. The director constantly evaluates the game state against its target pacing curve and makes adjustments by injecting these events into the world.

**Dynamics:** The dynamics that emerge from these mechanics create a rhythmic cycle of tension and release for the player. Players may attempt to "game" the system by intentionally keeping their health low or hoarding resources to prevent massive enemy spawns, or they may naturally fall into the intended pacing. The constant adaptation required by the player leads to emergent gameplay scenarios that are unique to each playthrough, as the director responds differently based on the player's actions and current state.

**Aesthetics:** Aesthetically, the AI Director creates profound feelings of suspense, relief, and a sense that the game world is alive and reacting to the player's presence. It fosters a personalized narrative experience, making the player feel like they are the protagonist of a dynamically unfolding story. The peaks of action provide thrilling adrenaline rushes, while the cooldown periods offer a satisfying sense of accomplishment and respite.

## 4. Parameter Space
The AI Director relies on several tunable parameters to shape the pacing and difficulty of the game.

| Parameter Name | Type | Typical Range | Benchmark Value (Game) | Unit |
|---|---|---|---|---|
| `target_stress` | f32 | 0.0 - 100.0 | 50.0 (Left 4 Dead 2 v2.2) | Points |
| `stress_decay_rate` | f32 | 0.1 - 5.0 | 1.5 (RimWorld v1.4) | Points/sec |
| `cooldown_duration` | f32 | 10.0 - 300.0 | 60.0 (Left 4 Dead 2 v2.2) | Seconds |
| `max_active_threats` | u32 | 5 - 100 | 30 (Left 4 Dead 2 v2.2) | Count |
| `event_weight_multiplier` | f32 | 0.1 - 10.0 | 1.0 (RimWorld v1.4) | Multiplier |

## 5. Benchmark Data
Benchmark data from representative games highlights how these parameters are utilized in practice.

In Left 4 Dead 2 (v2.2), the AI Director aims for a `target_stress` of 50.0 points. The `cooldown_duration` is typically set to 60.0 seconds, though this varies based on the chosen difficulty level. The system also enforces a `max_active_threats` limit of 30 common infected at any given time to maintain performance and readability.

In RimWorld (v1.4), specifically with the Cassandra Classic storyteller, the `stress_decay_rate` (often referred to as the adaptation factor) is set to 1.5. The `event_weight_multiplier` starts at 1.0 and scales with the colony's wealth and population. The `cooldown_duration` between major threats ranges from 4.6 to 6.0 in-game days, providing a structured but challenging experience.

## 6. Common Variants
Several variations of the AI Director exist across different games, each tailoring the experience to specific design goals.

The Punisher variant continuously ramps up difficulty over time regardless of player performance, forcing the player to race against the clock, as seen in Risk of Rain. The Randomizer variant completely ignores player state and spawns events based on pure RNG, creating chaotic and unpredictable narratives, exemplified by RimWorld's Randy Random. The Rubber-Bander variant strictly pulls the player back to a baseline, spawning health when low and overwhelming enemies when doing too well, a technique often used in Mario Kart item distribution. Finally, the Narrative Weaver variant focuses less on combat stress and more on story beats, ensuring dramatic pacing in narrative-driven games.

## 7. Compatibility Notes
The AI Director is highly compatible with atoms such as `atom_procedural_spawning`, `atom_dynamic_difficulty`, and `atom_resource_management`. It relies heavily on procedural spawning to enact its decisions and dynamically adjusts difficulty based on resource management.

Conversely, it is generally incompatible with `atom_static_encounters` and `atom_fixed_timeline`. A fully scripted game with static encounters conflicts with the dynamic, responsive nature of an AI Director, as the director requires the flexibility to alter the game state on the fly.

## 8. Anti-Patterns
When implementing an AI Director, several common design mistakes should be avoided.

Over-Correction occurs when the system reacts too quickly to minor changes in player state, leading to erratic pacing. For example, spawning a boss immediately after the player heals can feel punishing and unfair. Predictable Rhythms happen when the cooldown and peak action phases are too rigidly timed, allowing players to easily predict and exploit the system, draining the tension from the experience. Finally, Ignoring Player Agency is a critical flaw where the system forces a loss or a win regardless of player skill, making the player feel like their actions and decisions do not matter in the grand scheme of the game.
