# Gameplay Atom: Loot Rarity Tier (装备稀有度)

## 1. Identity
- **Atom ID:** `atom_loot_rarity`
- **English Name:** Loot Rarity Tier
- **Chinese Name:** 装备稀有度
- **Category:** C
- **Definition:** A system that categorizes items into distinct tiers of value, power, and scarcity, typically represented by a standardized color-coding scheme, to provide players with clear, immediate feedback on the quality of their rewards and to structure long-term progression.

## 2. Core Verb & State Machine
- **Core Verb:** Evaluate / Equip / Discard
- **State Diagram:**
  [Drop Generated] -> [Rarity Rolled] -> [Item Instantiated] -> [Player Evaluates] -> [Equipped / Stored / Sold / Dismantled]
- **States:**
  - `Unrolled`: The item exists in the loot table but hasn't been assigned a rarity.
  - `Rolled`: The rarity tier has been determined by the RNG system.
  - `Dropped`: The item is visible in the game world with its rarity color indicator.
  - `Evaluated`: The player has inspected the item's stats relative to its rarity.
  - `Equipped`: The item is actively used by the player.
  - `Discarded`: The item is sold, dismantled, or left on the ground.
- **Transitions:**
  - `Unrolled` -> `Rolled`: Triggered by enemy death or chest opening.
  - `Rolled` -> `Dropped`: Triggered by item instantiation in the world.
  - `Dropped` -> `Evaluated`: Triggered by player picking up or hovering over the item.
  - `Evaluated` -> `Equipped`: Triggered by player decision to use the item.
  - `Evaluated` -> `Discarded`: Triggered by player decision that the item is not useful.

## 3. MDA Analysis
- **Mechanics:** The system uses weighted random number generation (RNG) to assign a rarity tier to an item when it drops. Higher rarity tiers have lower drop weights. Rarity determines the number of affixes, base stat multipliers, and sometimes unique mechanical behaviors.
- **Dynamics:** Players learn to quickly filter loot visually based on color. The pursuit of higher rarity items drives repetitive gameplay loops (farming/grinding). The transition from finding mostly common items to mostly rare/epic items marks progression through the game's phases.
- **Aesthetics:** 
  - *Anticipation:* The visual and audio cues of a high-rarity drop create a dopamine spike.
  - *Satisfaction:* Equipping a powerful, rare item provides a sense of achievement and power.
  - *Frustration/Desire:* Long dry spells without high-rarity drops build tension that is released upon a successful drop.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Diablo 3 v2.7) | Unit | Description |
| :--- | :--- | :--- | :--- | :--- | :--- |
| `common_weight` | `f32` | 0.5 - 0.9 | 0.70 | % | Probability of a Common (White) drop |
| `magic_weight` | `f32` | 0.1 - 0.4 | 0.20 | % | Probability of a Magic (Blue) drop |
| `rare_weight` | `f32` | 0.01 - 0.15 | 0.09 | % | Probability of a Rare (Yellow) drop |
| `legendary_weight` | `f32` | 0.001 - 0.05 | 0.01 | % | Probability of a Legendary (Orange) drop |
| `stat_multiplier_magic` | `f32` | 1.1 - 1.5 | 1.2 | x | Base stat multiplier for Magic items |
| `stat_multiplier_rare` | `f32` | 1.3 - 2.0 | 1.5 | x | Base stat multiplier for Rare items |
| `stat_multiplier_legendary` | `f32` | 1.5 - 3.0 | 2.0 | x | Base stat multiplier for Legendary items |
| `affix_count_magic` | `u32` | 1 - 2 | 1 | count | Number of random affixes on Magic items |
| `affix_count_rare` | `u32` | 3 - 6 | 4 | count | Number of random affixes on Rare items |
| `affix_count_legendary` | `u32` | 4 - 8 | 6 | count | Number of random affixes on Legendary items |

## 5. Benchmark Data
- **Diablo 3 (v2.7.4):**
  - Common: White, 0 affixes, base stats.
  - Magic: Blue, 1-3 affixes.
  - Rare: Yellow, 4-6 affixes.
  - Legendary: Orange, 6 affixes + 1 unique legendary power. Drop rate scales heavily with Torment difficulty.
- **Borderlands 3 (v1.1.5):**
  - White (Common), Green (Uncommon), Blue (Rare), Purple (Epic), Orange (Legendary).
  - Legendary items have fixed unique behaviors (e.g., shooting patterns) rather than just higher stats.
- **Destiny 2 (v7.0.0):**
  - White (Common), Green (Uncommon), Blue (Rare), Purple (Legendary), Yellow (Exotic).
  - Players are restricted to equipping only one Exotic weapon and one Exotic armor piece at a time, making the highest rarity a strategic choice rather than a pure upgrade.

## 6. Common Variants
1. **The "Exotic" Restriction:** As seen in Destiny, the highest rarity tier is limited in how many can be equipped simultaneously, forcing build choices.
2. **Set Items:** A parallel rarity tier (often Green in Diablo) where items gain massive bonuses only when equipped with other items of the same set.
3. **Corrupted/Cursed Rarity:** Items that have higher stats than normal for their tier but come with a significant negative affix (e.g., Path of Exile's Corrupted items).
4. **Upgradable Rarity:** Systems where players can spend resources to upgrade an item from a lower rarity to a higher one, keeping its base type but increasing its stats and affixes.

## 7. Compatibility Notes
- **Commonly Pairs With:**
  - `atom_random_affixes`: Rarity directly dictates the number and tier of random affixes.
  - `atom_loot_filter`: As players progress, they need systems to hide lower-rarity items.
  - `atom_crafting_materials`: Lower rarity items are often dismantled into materials used to craft or upgrade higher rarity items.
- **Known Conflicts:**
  - `atom_fixed_progression`: Games with strictly linear, fixed power upgrades (like classic Zelda) clash with randomized loot rarities.

## 8. Anti-Patterns
1. **Rarity Inflation:** Introducing too many new rarity tiers over a game's lifespan (e.g., Ancient, Primal Ancient), which devalues the original "highest" tier and confuses the visual hierarchy.
2. **Meaningless Lower Tiers:** In the late game, if 99% of drops are Common/Magic and they serve no purpose (not even for dismantling), they become visual clutter and annoy the player.
3. **Color Blindness Unfriendliness:** Relying solely on color to distinguish rarity without providing secondary visual cues (like distinct borders, icons, or text labels), making the game inaccessible to color-blind players.
