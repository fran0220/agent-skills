# Gameplay Atom: Pattern Matching

## 1. Identity
**Atom ID:** `atom_pattern_match`
**English Name:** Pattern Matching
**Chinese Name:** 图案匹配
**Category:** Category C (Cognitive / Puzzle)
**Definition:** Pattern Matching is a fundamental cognitive gameplay atom where the player is tasked with identifying, aligning, or recreating a specific spatial, visual, or logical arrangement of elements to satisfy a predefined condition. This atom challenges the player's observation, spatial reasoning, and memory, often serving as the core mechanic in puzzle games or as a supplementary mini-game in larger adventure titles.

## 2. Core Verb & State Machine
**Core Verb:** `Match` (Identify and align elements to form a target pattern)

**State Diagram:**
```text
[Idle] --> (Player Input) --> [Evaluating]
[Evaluating] --> (Match Success) --> [Resolved]
[Evaluating] --> (Match Failure) --> [Reset/Penalty]
[Reset/Penalty] --> (Cooldown/Animation) --> [Idle]
```

**States and Transitions:**
- **Idle:** The system waits for the player to manipulate the elements or submit a pattern.
- **Evaluating:** The system checks the current arrangement of elements against the target pattern.
- **Resolved:** The pattern matches the target condition, triggering a success event (e.g., unlocking a door, clearing lines).
- **Reset/Penalty:** The pattern does not match. The system may reset the puzzle, apply a penalty, or simply return to the Idle state.

## 3. MDA Analysis
**Mechanics:** The system defines a grid or space containing manipulable elements and a target state. It continuously or discretely evaluates the distance or difference between the current state and the target state. Rules dictate how elements can be moved, rotated, or altered.
**Dynamics:** Players develop heuristics to quickly identify partial matches. In time-pressured environments (like Tetris), the dynamics shift from pure logical deduction to rapid pattern recognition and reflex-based placement. In untimed environments (like The Witness), players engage in deep observation and hypothesis testing.
**Aesthetics:** The primary aesthetic is *Discovery* and *Challenge*. Successfully matching a complex pattern provides a strong sense of "Aha!" (epiphany) and cognitive satisfaction. When combined with time pressure, it induces *Submission* (flow state) and tension.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Game) | Unit |
| :--- | :--- | :--- | :--- | :--- |
| `grid_width` | u32 | 3 - 20 | 10 (Tetris v1.0) | cells |
| `grid_height` | u32 | 3 - 30 | 20 (Tetris v1.0) | cells |
| `match_threshold` | f32 | 0.5 - 1.0 | 1.0 (The Witness v1.0) | ratio |
| `time_limit` | f32 | 0.0 - 300.0 | 0.0 (The Witness v1.0) | seconds |
| `element_types` | u32 | 2 - 10 | 7 (Tetris v1.0) | count |

## 5. Benchmark Data
- **Tetris (NES version):** `grid_width` = 10, `grid_height` = 20, `element_types` = 7 (Tetrominoes), `match_threshold` = 1.0 (full line). The game relies on rapid, continuous pattern matching under increasing time pressure.
- **The Witness (v1.0):** `grid_width` = variable (often 4-8), `grid_height` = variable, `match_threshold` = 1.0 (exact path match). The game focuses on untimed, highly complex spatial and environmental pattern matching.

## 6. Common Variants
1. **Line Clearing (Tetris, Bejeweled):** Matching a specific number of elements in a line causes them to disappear, altering the state of the remaining elements.
2. **Environmental Alignment (Hellblade, The Witness):** The player must move the camera or character to align environmental objects to form a specific 2D shape from a 3D perspective.
3. **Sequence Matching (Simon Says):** The pattern is temporal rather than spatial; the player must remember and reproduce a sequence of inputs.
4. **Jigsaw/Tile Placement (Carcassonne):** Elements must be placed such that their edges match the properties of adjacent elements.

## 7. Compatibility Notes
- **Commonly Pairs With:** `atom_time_limit` (adds tension), `atom_spatial_rotation` (increases complexity of matching), `atom_resource_management` (matching yields resources).
- **Known Conflicts:** `atom_high_speed_movement`. Forcing complex cognitive pattern matching while the player is engaged in high-speed, reflex-heavy navigation often leads to cognitive overload and frustration.

## 8. Anti-Patterns
1. **Ambiguous Feedback:** Failing to clearly communicate *why* a pattern match failed. If the player doesn't understand the rules of the match, the puzzle feels arbitrary rather than logical.
2. **Color-Blind Unfriendly:** Relying solely on color to differentiate elements in a pattern without providing secondary visual cues (like shapes or patterns), making the atom inaccessible to color-blind players.
3. **Overwhelming Complexity:** Introducing too many `element_types` or a massive grid size too early in the learning curve, preventing the player from developing basic pattern recognition heuristics.
