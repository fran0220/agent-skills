# Identity
- **Atom ID**: atom_ad_reward
- **English Name**: Ad Reward
- **Chinese Name**: 广告奖励
- **Category**: C or D (Monetization/Meta)
- **Definition**: A monetization mechanic where players voluntarily watch a video advertisement in exchange for in-game rewards, such as currency, extra lives, or temporary buffs.

# Core Verb & State Machine
- **Core Verb**: Watch (Ad)
- **State Diagram**:
  [Idle] -> (Trigger Ad Offer) -> [Offer Available]
  [Offer Available] -> (Accept Offer) -> [Watching Ad]
  [Offer Available] -> (Decline Offer) -> [Idle]
  [Watching Ad] -> (Ad Completed) -> [Reward Granted] -> [Idle]
  [Watching Ad] -> (Ad Skipped/Failed) -> [Reward Denied] -> [Idle]

# MDA Analysis
- **Mechanics**: The system presents an optional video ad to the player. If the player watches the ad to completion, the system grants a predefined reward.
- **Dynamics**: Players strategically choose when to watch ads based on their current needs (e.g., needing a revive during a good run, or wanting to double offline earnings). It creates a pacing break and a value exchange.
- **Aesthetics**: Relief (getting a second chance), Satisfaction (earning premium currency for free), or mild Annoyance (if the ad is too long or unskippable, though voluntary ads mitigate this).

# Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value | Unit |
|---|---|---|---|---|
| `ad_duration` | f32 | 15.0 - 30.0 | 30.0 (Subway Surfers v3.14) | seconds |
| `reward_multiplier` | f32 | 1.5 - 3.0 | 2.0 (Archero v4.12) | multiplier |
| `cooldown_time` | f32 | 0.0 - 3600.0 | 300.0 (Survivor.io v1.15) | seconds |
| `daily_limit` | u32 | 3 - 10 | 5 (Subway Surfers v3.14) | count |

# Benchmark Data
- **Subway Surfers (v3.14)**: `ad_duration` = 30.0s, `daily_limit` = 5 (for specific high-value rewards like keys).
- **Archero (v4.12)**: `reward_multiplier` = 2.0 (for end-of-stage coin rewards).
- **Survivor.io (v1.15)**: `cooldown_time` = 300.0s (between free gem ad offers).

# Common Variants
1. **Revive Ad**: Watch an ad to continue playing after failing a level.
2. **Multiplier Ad**: Watch an ad to double or triple the rewards earned at the end of a level.
3. **Store Freebie**: Watch an ad in the store to get a small amount of premium currency or a free chest.
4. **Offline Earnings Boost**: Watch an ad to double the resources accumulated while the player was offline.

# Compatibility Notes
- **Compatible Atoms**: `atom_revive` (Revive), `atom_offline_earnings` (Offline Earnings), `atom_loot_box` (Loot Box).
- **Incompatible Atoms**: `atom_hardcore_mode` (Permadeath/Hardcore mode usually disables revives, including ad revives).

# Anti-Patterns
1. **Over-saturation**: Offering too many ad rewards can devalue the in-game currency and disrupt the core gameplay loop.
2. **Bait and Switch**: Promising a large reward but delivering a small one, or forcing an ad when the player expected a voluntary one.
3. **Broken Flow**: Failing to grant the reward after the player has watched the entire ad due to network or API issues.
