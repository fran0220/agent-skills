# Gameplay Atom: Wall Slide & Jump

## 1. Identity
- **Atom ID:** atom_wall_slide_jump
- **English Name:** Wall Slide & Jump
- **Chinese Name:** 滑墙与墙跳
- **Category:** A
- **Definition:** A movement mechanic that allows a player character to slow their descent by sliding against a vertical surface and subsequently leap off that surface to gain height or distance, often used for vertical traversal or avoiding hazards.

## 2. Core Verb & State Machine
- **Core Verb:** Slide, Jump
- **State Diagram:**
  [Airborne] --(Touch Wall & Move Towards Wall)--> [Wall Sliding]
  [Wall Sliding] --(Jump Input)--> [Wall Jumping]
  [Wall Sliding] --(Move Away From Wall)--> [Airborne]
  [Wall Sliding] --(Touch Ground)--> [Grounded]
  [Wall Jumping] --(Apex Reached/Time Elapsed)--> [Airborne]

- **States:**
  - `Airborne`: Character is falling or jumping in the air.
  - `Wall Sliding`: Character is touching a wall, facing it or moving towards it, descending at a reduced speed.
  - `Wall Jumping`: Character has jumped off the wall, moving upwards and outwards.
  - `Grounded`: Character is on the floor.

- **Transitions:**
  - `Airborne` -> `Wall Sliding`: Triggered when the character collides with a wall while in the air and the player holds the directional input towards the wall.
  - `Wall Sliding` -> `Wall Jumping`: Triggered when the player presses the jump button while in the `Wall Sliding` state.
  - `Wall Sliding` -> `Airborne`: Triggered when the player holds the directional input away from the wall, or the wall ends.
  - `Wall Sliding` -> `Grounded`: Triggered when the character reaches the bottom of the wall and touches the ground.

## 3. MDA Analysis
- **Mechanics:** The system detects collision with a vertical surface while airborne. If conditions are met (e.g., input towards the wall), vertical downward velocity is capped or reduced (friction applied). Upon jump input, a velocity vector (combining vertical and horizontal components away from the wall) is applied, often with a brief lockout of horizontal input to ensure the character moves away from the wall.
- **Dynamics:** Players use walls not just as obstacles, but as platforms. It enables vertical climbing of parallel walls (wall jumping back and forth) or scaling a single wall (if the game allows jumping and re-grabbing the same wall). It creates a rhythm of sliding and jumping.
- **Aesthetics:** Empowers the player with agility and fluidity. It turns dead-ends into pathways, fostering a sense of mastery, flow, and exploration.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Celeste v1.4) | Unit |
| :--- | :--- | :--- | :--- | :--- |
| `slide_speed_max` | f32 | 2.0 - 10.0 | 4.0 | m/s |
| `slide_acceleration` | f32 | 5.0 - 20.0 | 10.0 | m/s² |
| `jump_force_x` | f32 | 5.0 - 15.0 | 8.0 | m/s |
| `jump_force_y` | f32 | 10.0 - 25.0 | 15.0 | m/s |
| `input_lockout_time` | f32 | 0.0 - 0.3 | 0.15 | seconds |
| `coyote_time_wall` | f32 | 0.0 - 0.15 | 0.08 | seconds |

## 5. Benchmark Data
- **Celeste (v1.4.0.0):**
  - `slide_speed_max`: 4.0 m/s
  - `jump_force_x`: 8.0 m/s
  - `jump_force_y`: 15.0 m/s
  - `input_lockout_time`: 0.15 s
- **Hollow Knight (v1.5.78.11833):**
  - `slide_speed_max`: 5.5 m/s
  - `jump_force_x`: 7.0 m/s
  - `jump_force_y`: 16.0 m/s
  - `input_lockout_time`: 0.2 s
- **Mega Man X (SNES):**
  - `slide_speed_max`: 6.0 m/s
  - `jump_force_x`: 6.5 m/s
  - `jump_force_y`: 14.0 m/s
  - `input_lockout_time`: 0.0 s (allows immediate re-attachment to the same wall)

## 6. Common Variants
1. **Sticky Wall Jump:** The character sticks to the wall completely (0 slide speed) for a brief moment or indefinitely before sliding or jumping (e.g., Super Meat Boy).
2. **Single-Wall Scale:** The player can repeatedly jump off and steer back into the same wall to climb it without needing a parallel wall (e.g., Mega Man X).
3. **Kick-Off Wall Jump:** The character doesn't slide but instantly kicks off the wall upon contact and jump input (e.g., Super Mario 64).
4. **Stamina-Based Slide:** Sliding or holding onto the wall consumes a stamina meter; when depleted, the character falls (e.g., The Legend of Zelda: Breath of the Wild).

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_dash` (dashing into a wall to initiate a slide), `atom_double_jump` (using a double jump after a wall jump to gain more distance).
- **Incompatible Atoms:** `atom_heavy_fall` (ground pound mechanics often cancel or conflict with wall sliding states).

## 8. Anti-Patterns
1. **No Input Lockout:** Allowing immediate horizontal air control back towards the wall after a wall jump, making the character accidentally re-attach to the same wall and lose horizontal momentum.
2. **Overly Strict Collision:** Requiring the player to be perfectly flush with the wall to trigger the slide, leading to missed inputs on slightly uneven terrain.
3. **Missing Coyote Time:** Not allowing a wall jump for a few frames after the player has slid off the bottom of the wall, making the timing feel unfair and unresponsive.
