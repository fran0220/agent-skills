# Furniture Catalog (家具目录)

## 1. Identity
- **Atom ID:** `atom_furniture_catalog`
- **English Name:** Furniture Catalog
- **Chinese Name:** 家具目录
- **Category:** G/H (Collection/Customization)
- **Definition:** A system that records, categorizes, and displays all furniture items a player has discovered, purchased, or crafted, allowing them to track their collection progress and often re-order previously obtained items.

## 2. Core Verb & State Machine
- **Core Verb:** Browse / Collect / Order
- **State Diagram:**
  [Uncollected] --(Discover/Obtain)--> [Collected/Unlocked]
  [Collected/Unlocked] --(Select)--> [Viewing Details]
  [Viewing Details] --(Order)--> [Ordered]
  [Ordered] --(Delivery)--> [In Inventory]

- **States:**
  - `Uncollected`: Item is unknown or locked.
  - `Collected`: Item is unlocked in the catalog.
  - `Viewing Details`: Player is inspecting the item's stats, price, or variations.
  - `Ordered`: Item has been purchased from the catalog and is pending delivery.
  - `In Inventory`: Item is available for placement.

- **Transitions:**
  - `Uncollected` -> `Collected`: Triggered by obtaining the item for the first time.
  - `Collected` -> `Viewing Details`: Triggered by player selecting the item in the UI.
  - `Viewing Details` -> `Ordered`: Triggered by player confirming purchase.
  - `Ordered` -> `In Inventory`: Triggered by mail delivery or immediate transfer.

## 3. MDA Analysis
- **Mechanics:** The game maintains a persistent database of all furniture items and a boolean flag for each indicating if the player has unlocked it. It provides a UI to filter, sort, and search these items.
- **Dynamics:** Players engage in completionist behaviors, trading with others to fill gaps in their catalog, and grinding currency to order expensive items.
- **Aesthetics:** Discovery, Expression, and Submission (completionism). Players feel a sense of achievement as the catalog fills up and enjoy the freedom to express themselves by ordering specific items for decoration.

## 4. Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value (Game) | Unit |
|---|---|---|---|---|
| `total_items` | u32 | 100 - 2000 | 1700 (Animal Crossing: New Horizons v2.0) | items |
| `order_limit_per_day` | u32 | 3 - 10 | 5 (Animal Crossing: New Horizons v2.0) | items/day |
| `delivery_delay` | f32 | 0.0 - 24.0 | 24.0 (Animal Crossing: New Horizons v2.0) | hours |
| `completion_reward_threshold` | f32 | 0.5 - 1.0 | 1.0 (Stardew Valley v1.5) | ratio |

## 5. Benchmark Data
- **Animal Crossing: New Horizons (v2.0):**
  - `total_items`: 1700
  - `order_limit_per_day`: 5
  - `delivery_delay`: 24.0 hours (next day mail)
- **The Sims 4 (Base Game v1.90):**
  - `total_items`: 1000
  - `order_limit_per_day`: 999
  - `delivery_delay`: 0.0 hours (instant)

## 6. Common Variants
1. **Mail-Order Catalog:** Items take real or in-game time to arrive (e.g., Animal Crossing).
2. **Instant Buy/Build Mode:** Items are instantly available for placement upon purchase (e.g., The Sims).
3. **Crafting Recipe Book:** Instead of buying the item directly, the catalog stores the recipe to craft it (e.g., Minecraft, Terraria).
4. **Gacha/Randomized Catalog:** Items are unlocked randomly through capsules or loot boxes, and the catalog tracks the collection.

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_inventory_management`, `atom_currency_economy`, `atom_housing_customization`, `atom_crafting_system`.
- **Incompatible Atoms:** `atom_permadeath_wipe` (if catalog progress is wiped, it heavily discourages collection).

## 8. Anti-Patterns
1. **Overwhelming UI:** Presenting hundreds of items without proper filtering, sorting, or search functionalities, making it impossible to find specific items.
2. **Punishing Order Limits:** Setting the daily order limit too low compared to the total number of items, artificially time-gating creativity.
3. **Lack of Variants Tracking:** Failing to track color or pattern variations of the same furniture piece, confusing players about what they actually own.
