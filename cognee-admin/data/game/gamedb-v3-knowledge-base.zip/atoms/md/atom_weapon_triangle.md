# Weapon Triangle (武器三角)

## 1. Identity
- **Atom ID**: atom_weapon_triangle
- **English Name**: Weapon Triangle
- **Chinese Name**: 武器三角
- **Category**: A
- **Definition**: A rock-paper-scissors style combat mechanic where different weapon types have inherent advantages and disadvantages against each other, affecting hit rates, damage, or other combat parameters.

## 2. Core Verb & State Machine
- **Core Verb**: Attack / Defend
- **State Diagram**:
  - [Idle] -> (Equip Weapon) -> [Ready]
  - [Ready] -> (Engage Combat) -> [Combat Resolution]
  - [Combat Resolution] -> (Advantage/Disadvantage Applied) -> [Damage Calculation]
  - [Damage Calculation] -> [Idle]
- **States**: Idle, Ready, Combat Resolution, Damage Calculation
- **Transitions**:
  - Idle to Ready: Triggered by equipping a weapon.
  - Ready to Combat Resolution: Triggered by initiating an attack or being attacked.
  - Combat Resolution to Damage Calculation: Triggered by applying the weapon triangle modifiers.
  - Damage Calculation to Idle: Triggered by the end of the combat sequence.

## 3. MDA Analysis
- **Mechanics**: Weapons are categorized into types (e.g., Sword, Lance, Axe). A cyclical relationship is established (Sword beats Axe, Axe beats Lance, Lance beats Sword). When combat occurs, the system checks the weapon types of both combatants and applies modifiers to accuracy, damage, or evasion based on the relationship.
- **Dynamics**: Players are encouraged to position their units strategically to ensure favorable matchups. It creates a layer of tactical depth where raw stats can be overcome by exploiting weapon advantages.
- **Aesthetics**: Players feel a sense of mastery and satisfaction when they successfully predict enemy movements and counter them with the correct weapon types. It adds a puzzle-like element to combat.

## 4. Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value (Fire Emblem: Blazing Blade) | Unit |
|---|---|---|---|---|
| `advantage_damage_mod` | f32 | 1.0 - 2.0 | 1.0 (Flat +1 damage) | Points/Multiplier |
| `advantage_hit_mod` | f32 | 0.0 - 0.3 | 0.15 (+15% Hit) | Percentage |
| `disadvantage_damage_mod` | f32 | 0.5 - 1.0 | -1.0 (Flat -1 damage) | Points/Multiplier |
| `disadvantage_hit_mod` | f32 | -0.3 - 0.0 | -0.15 (-15% Hit) | Percentage |

## 5. Benchmark Data
- **Fire Emblem: The Blazing Blade (GBA)**:
  - Advantage: +1 Damage, +15% Hit Rate
  - Disadvantage: -1 Damage, -15% Hit Rate
- **Fire Emblem Engage (Switch)**:
  - Advantage: Inflicts "Break" status (cannot counterattack), no direct damage/hit modifiers from the triangle itself but prevents counterattacks.

## 6. Common Variants
1. **Magic Triangle**: Anima beats Light, Light beats Dark, Dark beats Anima.
2. **Extended Triangle**: Includes Bows, Daggers, or other weapon types into a larger web of advantages.
3. **Color-Coded Triangle**: Red beats Green, Green beats Blue, Blue beats Red (e.g., Fire Emblem Heroes).
4. **Reaver Weapons**: Weapons that reverse the standard triangle (e.g., a Sword that is strong against Lances but weak against Axes).

## 7. Compatibility Notes
- **Compatible Atoms**: `atom_grid_movement`, `atom_counterattack`, `atom_critical_hit`.
- **Incompatible Atoms**: `atom_pure_skill_combat` (where stats/matchups don't matter, only player reflexes).

## 8. Anti-Patterns
1. **Insignificant Modifiers**: If the advantage/disadvantage modifiers are too small, players will ignore the mechanic and just use their strongest units.
2. **Overly Punishing Disadvantages**: If a disadvantage means guaranteed death, it can make the game feel too rigid and limit creative strategies.
3. **Unclear Relationships**: If the triangle (or web) is too complex or not visually communicated well, players will be confused and frustrated.
