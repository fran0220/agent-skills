# Gameplay Atom: Hitscan Shooting

## 1. Identity
- **Atom ID**: `atom_hitscan`
- **English Name**: Hitscan Shooting
- **Chinese Name**: 即时命中射击
- **Category**: A (Core Mechanics)
- **Definition**: Hitscan shooting is a weapon firing mechanic where the trajectory of a projectile is calculated instantly using a raycast from the weapon's barrel or the player's camera to the target. If the ray intersects with a valid target's hitbox, the hit is registered immediately without any travel time for the projectile.

## 2. Core Verb & State Machine
- **Core Verb**: Fire / Shoot

**State Diagram**:
```text
[Idle] --(Trigger Pull)--> [Firing]
[Firing] --(Raycast Hit)--> [Damage Applied]
[Firing] --(Raycast Miss)--> [Miss Effect]
[Damage Applied] --(Cooldown/Recoil)--> [Recovery]
[Miss Effect] --(Cooldown/Recoil)--> [Recovery]
[Recovery] --(Time Elapsed)--> [Idle]
```

**States**:
- `Idle`: Weapon is ready to fire.
- `Firing`: The moment the trigger is pulled, initiating the raycast.
- `Damage Applied`: The raycast successfully intersects a target, applying damage.
- `Miss Effect`: The raycast hits the environment or nothing, triggering visual/audio effects.
- `Recovery`: The period after firing where the weapon applies recoil and waits for the fire rate cooldown.

**Transitions**:
- `Idle` -> `Firing`: Trigger pulled by player.
- `Firing` -> `Damage Applied`: Raycast intersects target hitbox.
- `Firing` -> `Miss Effect`: Raycast does not intersect target hitbox.
- `Damage Applied` -> `Recovery`: Automatic transition after hit processing.
- `Miss Effect` -> `Recovery`: Automatic transition after miss processing.
- `Recovery` -> `Idle`: Fire rate cooldown completes.

## 3. MDA Analysis
- **Mechanics**: The system casts a mathematical ray from the origin point (usually the camera center) along the forward vector. It checks for intersections with colliders in the game world. If an intersection occurs, it calculates damage based on distance (falloff) and hit location (e.g., headshot multiplier).
- **Dynamics**: Players develop tracking and flicking aiming skills. The lack of projectile travel time means players do not need to lead their targets, resulting in highly responsive and precise gunplay. Positioning and reaction time become the dominant factors in engagements.
- **Aesthetics**: Creates a feeling of immediate impact, crispness, and high lethality. It rewards precision and fast reflexes, often leading to a competitive and fast-paced player experience.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (CS:GO v1.38) | Unit |
|---|---|---|---|---|
| `base_damage` | f32 | 10.0 - 150.0 | 33.0 (AK-47) | HP |
| `fire_rate` | f32 | 1.0 - 20.0 | 10.0 (600 RPM) | Rounds/sec |
| `max_range` | f32 | 50.0 - 10000.0 | 8192.0 | Units |
| `damage_falloff` | f32 | 0.0 - 1.0 | 0.98 | Multiplier/500u |
| `headshot_multiplier` | f32 | 1.0 - 4.0 | 4.0 | Multiplier |
| `base_spread` | f32 | 0.0 - 5.0 | 0.6 | Degrees |

## 5. Benchmark Data
- **CS:GO (v1.38.7.9)**:
  - Weapon: AK-47
  - `base_damage`: 33.0
  - `fire_rate`: 10.0 rounds/sec (600 RPM)
  - `headshot_multiplier`: 4.0
  - `damage_falloff`: 0.98 per 500 units
- **Overwatch 2 (v2.4.0)**:
  - Hero: Widowmaker (Widow's Kiss - Sniper)
  - `base_damage`: 120.0 (fully charged)
  - `fire_rate`: 1.11 rounds/sec (charge time)
  - `headshot_multiplier`: 2.5
  - `damage_falloff`: 0.5 at 50+ meters
- **Call of Duty: Modern Warfare II (v1.15)**:
  - Weapon: M4
  - `base_damage`: 28.0
  - `fire_rate`: 13.5 rounds/sec (811 RPM)
  - `headshot_multiplier`: 1.4
  - `damage_falloff`: 0.7 at 30+ meters

## 6. Common Variants
1. **Perfect Accuracy Hitscan**: The ray is always cast perfectly down the center of the screen (e.g., early Doom, Quake railgun).
2. **Cone Spread Hitscan**: The ray's direction is randomized within a cone, simulating weapon inaccuracy (e.g., CS:GO rifles, Valorant).
3. **Damage Falloff Hitscan**: Damage decreases linearly or in steps based on the distance to the target (e.g., Overwatch Tracer/Reaper).
4. **Penetrating Hitscan**: The ray can pass through certain materials or multiple enemies, dealing reduced damage to subsequent targets (e.g., CS:GO wallbanging).
5. **Beam/Continuous Hitscan**: A continuous raycast applied every frame or tick, dealing damage over time rather than in discrete chunks (e.g., Overwatch Zarya).

## 7. Compatibility Notes
- **Compatible Atoms**: `atom_recoil_pattern` (adds skill ceiling to continuous firing), `atom_damage_falloff` (balances long-range effectiveness), `atom_headshot_multiplier` (rewards precision).
- **Incompatible Atoms**: `atom_projectile_physics` (mutually exclusive core mechanic for a single firing mode), `atom_wind_deflection` (hitscan ignores environmental travel factors).

## 8. Anti-Patterns
1. **Zero Feedback on Miss**: Failing to provide visual (bullet tracers, wall decals) or audio feedback when a hitscan shot misses, leaving the player confused about their accuracy.
2. **Infinite Range without Falloff**: Allowing hitscan weapons to deal full damage at infinite distances, which can break map design and make sniper rifles obsolete.
3. **Desynced Hitboxes**: When the visual representation of a character does not match the server-side hitboxes, causing perfectly aimed hitscan shots to miss (often exacerbated by network latency).
