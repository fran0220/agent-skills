# Gameplay Atom: Extraction Zone

## 1. Identity
- **Atom ID:** `atom_extraction_zone`
- **English Name:** Extraction Zone
- **Chinese Name:** 撤离区域
- **Category:** G/H (Gameplay/Hybrid)
- **Definition:** A designated area within the game world where players must remain for a specified duration to successfully exit the current session, securing their accumulated loot and progression.

## 2. Core Verb & State Machine
- **Core Verb:** Extract (Evacuate)
- **State Diagram:**
  [Inactive] --(Trigger/Time)--> [Active] --(Player Enters)--> [Extracting] --(Timer Completes)--> [Extracted]
  [Extracting] --(Player Leaves)--> [Active]
  [Extracting] --(Player Dies)--> [Failed]

- **States:**
  - `Inactive`: The extraction zone is not yet available for use.
  - `Active`: The zone is open and waiting for players.
  - `Extracting`: A player is inside the zone, and the countdown timer is running.
  - `Extracted`: The player has successfully completed the extraction.
  - `Failed`: The player failed to extract (e.g., died or time ran out).

- **Transitions:**
  - `Inactive` -> `Active`: Triggered by match time, player action, or event.
  - `Active` -> `Extracting`: Player enters the zone boundary.
  - `Extracting` -> `Active`: Player leaves the zone boundary before the timer finishes.
  - `Extracting` -> `Extracted`: The extraction timer reaches zero while the player is inside.
  - `Extracting` -> `Failed`: Player is eliminated while in the zone.

## 3. MDA Analysis
- **Mechanics:** The system defines a spatial volume and a temporal requirement. When a player's collider intersects the volume, a timer starts. If the intersection is maintained until the timer expires, the player's state is saved, and they are removed from the instance.
- **Dynamics:** Creates high-tension chokepoints. Players may camp extraction zones to ambush others (extract camping). Forces players to balance the greed of gathering more loot against the risk of failing to extract.
- **Aesthetics:** Tension, relief, anticipation, and fear. The climax of a session often occurs at the extraction zone, leading to a massive release of tension upon success.

## 4. Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value (Game) | Unit |
|---|---|---|---|---|
| `extraction_time` | f32 | 3.0 - 30.0 | 7.0 (Escape from Tarkov v0.13) | seconds |
| `zone_radius` | f32 | 5.0 - 50.0 | 15.0 (Hunt: Showdown v1.10) | meters |
| `activation_delay` | f32 | 0.0 - 120.0 | 0.0 (DMZ Season 1) | seconds |
| `max_capacity` | u32 | 1 - 10 | 4 (Escape from Tarkov v0.13) | players |
| `requires_item` | bool | true/false | false (DMZ Season 1) | boolean |

## 5. Benchmark Data
- **Escape from Tarkov (v0.13):**
  - `extraction_time`: 7.0s
  - `zone_radius`: ~10.0m (varies by extract)
  - `requires_item`: Often true (e.g., Red Rebel, Roubles)
- **Hunt: Showdown (v1.10):**
  - `extraction_time`: 30.0s
  - `zone_radius`: 15.0m
  - `requires_item`: false
- **Call of Duty: DMZ (Season 1):**
  - `extraction_time`: 35.0s (helicopter arrival) + 5.0s (liftoff)
  - `zone_radius`: 20.0m
  - `requires_item`: false

## 6. Common Variants
1. **Vehicle Extraction:** Requires calling a vehicle (e.g., helicopter) which takes time to arrive before the actual extraction timer begins.
2. **Conditional Extraction:** Requires specific items, currency, or not wearing a backpack to use.
3. **Single-Use Extraction:** Once a player or team uses the extraction, it becomes unavailable for the rest of the match.
4. **Dynamic Extraction:** The location of the extraction zone changes randomly each match or during the match.

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_loot_system`, `atom_inventory_management`, `atom_match_timer`, `atom_permadeath`.
- **Incompatible Atoms:** `atom_infinite_respawn` (Extraction implies a definitive end to a high-stakes session, which conflicts with infinite respawns).

## 8. Anti-Patterns
1. **Lack of Cover:** Placing extraction zones in completely open areas without cover, making it impossible to survive an ambush.
2. **Unclear Boundaries:** Failing to clearly communicate the physical limits of the extraction zone, causing players to accidentally step out and reset the timer.
3. **Instant Extraction:** Having zero extraction time removes the tension and counter-play opportunities at the end of a match.
