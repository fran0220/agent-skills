# Gameplay Atom: Photo Mode (拍照模式)

## 1. Identity
- **Atom ID:** `atom_photo_mode`
- **English Name:** Photo Mode
- **Chinese Name:** 拍照模式
- **Category:** E
- **Definition:** Photo Mode is a dedicated gameplay feature that pauses the active game state and grants the player free control over a virtual camera, allowing them to compose, adjust, and capture screenshots of the game world. It often includes various photographic parameters such as depth of field, field of view, exposure, and filters, transforming the player from an active participant into a virtual photographer.

## 2. Core Verb & State Machine
- **Core Verb:** Capture (Compose and take a photograph)
- **State Diagram:**
  [Playing] -> (Trigger Photo Mode) -> [Camera Setup]
  [Camera Setup] -> (Adjust Parameters) -> [Camera Setup]
  [Camera Setup] -> (Take Photo) -> [Processing/Saving]
  [Processing/Saving] -> (Complete) -> [Camera Setup]
  [Camera Setup] -> (Exit) -> [Playing]
- **States:**
  - `Playing`: The normal gameplay state.
  - `Camera Setup`: The game is paused, UI is hidden or replaced with camera controls, and the player can move the camera and adjust settings.
  - `Processing/Saving`: The system captures the frame, applies final post-processing, and saves the image to disk.
- **Transitions:**
  - `Playing` to `Camera Setup`: Triggered by pressing a specific button or menu option.
  - `Camera Setup` to `Processing/Saving`: Triggered by the "Capture" input.
  - `Processing/Saving` to `Camera Setup`: Automatic after the image is saved.
  - `Camera Setup` to `Playing`: Triggered by the "Exit" input.

## 3. MDA Analysis
- **Mechanics:** The system pauses the game simulation (time scale = 0), detaches the camera from the player character, and provides a UI to manipulate camera transform (position, rotation) and rendering parameters (FOV, DOF, color grading, time of day).
- **Dynamics:** Players spend time exploring the frozen environment from new angles, discovering details they might have missed during active gameplay. They experiment with lighting and composition to create visually striking images.
- **Aesthetics:** Expression and Discovery. Players feel a sense of creative freedom and artistic expression. They also experience a deeper appreciation for the game's visual fidelity and art direction.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Ghost of Tsushima v1.12) | Unit |
| --- | --- | --- | --- | --- |
| `field_of_view` | f32 | 10.0 - 120.0 | 50.0 | degrees |
| `roll` | f32 | -180.0 - 180.0 | 0.0 | degrees |
| `depth_of_field` | f32 | 0.0 - 100.0 | 10.0 | percentage |
| `focus_distance` | f32 | 0.1 - 1000.0 | 5.0 | meters |
| `exposure_bias` | f32 | -5.0 - 5.0 | 0.0 | EV |
| `time_of_day` | f32 | 0.0 - 24.0 | 12.0 | hours |
| `filter_intensity` | f32 | 0.0 - 1.0 | 1.0 | normalized |

## 5. Benchmark Data
- **Ghost of Tsushima (v1.12):**
  - `field_of_view`: 50.0 degrees
  - `depth_of_field`: 10.0%
  - `time_of_day`: Adjustable (default 12.0)
  - `exposure_bias`: 0.0 EV
- **Marvel's Spider-Man (v1.19):**
  - `field_of_view`: 45.0 degrees
  - `depth_of_field`: 15.0%
  - `exposure_bias`: 0.0 EV
  - `filter_intensity`: 1.0

## 6. Common Variants
1. **Orbit-Only Camera:** The camera is tethered to the player character and can only orbit around them, restricting free movement (e.g., older games or games with strict culling).
2. **Free-Roam Camera:** The camera can be moved anywhere within a certain radius of the player, allowing for environmental shots without the character.
3. **Director Mode:** Includes the ability to spawn NPCs, change character poses, or alter facial expressions (e.g., Cyberpunk 2077, Horizon Zero Dawn).
4. **Multiplayer Photo Mode:** Pauses the game only for the local player or requires all players to agree to pause, often implemented as a non-pausing free camera in live games (e.g., Final Fantasy XIV).

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_character_customization` (players love taking photos of their customized characters), `atom_dynamic_weather` (changing weather for better shots), `atom_emote_system` (posing for photos).
- **Incompatible Atoms:** `atom_strict_multiplayer_sync` (pausing the game is impossible in synchronous competitive multiplayer without affecting others).

## 8. Anti-Patterns
1. **Restrictive Camera Bounds:** Limiting the camera movement too tightly around the player character, preventing creative environmental composition.
2. **UI Clutter in Capture:** Failing to completely hide all UI elements (including crosshairs or objective markers) when the final screenshot is taken.
3. **Resetting State on Exit:** Reverting environmental changes (like time of day or weather) abruptly when exiting photo mode, causing a jarring transition back to gameplay.
