# Gameplay Atom: Projectile Shooting (弹道射击)

## 1. Identity
- **Atom ID:** `atom_projectile`
- **English Name:** Projectile Shooting
- **Chinese Name:** 弹道射击
- **Category:** A (Core Combat/Action)
- **Definition:** A core gameplay mechanic where a player entity spawns a moving object (projectile) that travels through the game world over time, affected by physics such as gravity and drag, to interact with or damage other entities upon collision.

## 2. Core Verb & State Machine
- **Core Verb:** Shoot / Fire

**State Diagram (Text):**
[Idle] --(Fire Input)--> [Spawning]
[Spawning] --(Spawn Complete)--> [Traveling]
[Traveling] --(Collision/Timeout)--> [Impact]
[Impact] --(Effect Applied)--> [Destroyed]

**States:**
- `Idle`: The weapon or character is ready to fire.
- `Spawning`: The projectile is being instantiated at the muzzle or spawn point.
- `Traveling`: The projectile is moving through the world, updating its position based on velocity, gravity, and drag.
- `Impact`: The projectile has collided with a target or surface, triggering hit effects and damage calculation.
- `Destroyed`: The projectile is removed from the game world.

**Transitions:**
- `Idle` -> `Spawning`: Triggered by player input (e.g., pressing the fire button) and passing cooldown/ammo checks.
- `Spawning` -> `Traveling`: Triggered automatically once the projectile object is fully created and initial velocity is applied.
- `Traveling` -> `Impact`: Triggered by the physics engine detecting a collision with a valid surface or entity, or reaching maximum lifespan.
- `Impact` -> `Destroyed`: Triggered after all on-hit logic (damage, visual effects, sound) is resolved.

## 3. MDA Analysis
- **Mechanics:** The system spawns an entity with an initial velocity vector. The physics engine updates its position each frame applying gravity and air resistance. Raycasting or collision volumes are used to detect hits. Damage is calculated based on distance (falloff) and hit location (e.g., headshot multipliers).
- **Dynamics:** Players must lead their targets (aim ahead of moving targets) and compensate for bullet drop over long distances. This creates a skill gap in aiming and positioning. Players may use cover to avoid incoming projectiles with travel time.
- **Aesthetics:** Creates a sense of tension, realism, and satisfaction. Landing a difficult long-range shot with travel time and drop feels highly rewarding (Challenge/Submission). The visual and audio feedback of the projectile traveling and hitting enhances immersion (Sensation).

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Apex Legends v18) | Unit |
|---|---|---|---|---|
| `initial_velocity` | f32 | 100.0 - 1500.0 | 800.0 (R-301) | m/s |
| `gravity_scale` | f32 | 0.0 - 2.0 | 1.0 | multiplier |
| `drag_coefficient` | f32 | 0.0 - 0.1 | 0.01 | N/(m/s)^2 |
| `max_lifespan` | f32 | 1.0 - 10.0 | 3.0 | seconds |
| `base_damage` | f32 | 10.0 - 150.0 | 14.0 (R-301) | HP |
| `headshot_multiplier` | f32 | 1.0 - 3.0 | 1.75 | multiplier |
| `projectile_radius` | f32 | 0.0 - 0.5 | 0.05 | meters |

## 5. Benchmark Data
- **Apex Legends (v18.0):**
  - Weapon: Kraber .50-Cal Sniper
  - `initial_velocity`: 900.0 m/s
  - `gravity_scale`: 1.0
  - `base_damage`: 140.0
  - `headshot_multiplier`: 2.0
- **Fortnite (Chapter 4 Season 4):**
  - Weapon: Twin Mag Assault Rifle
  - `initial_velocity`: 750.0 m/s
  - `gravity_scale`: 0.8 (slightly floatier bullets)
  - `base_damage`: 32.0
  - `headshot_multiplier`: 1.5

## 6. Common Variants
1. **Hitscan Hybrid:** Projectiles act as hitscan (instant travel) up to a certain distance, then convert to physical projectiles with travel time and drop beyond that range.
2. **Homing/Tracking Projectiles:** Projectiles that adjust their velocity vector each frame to steer towards a locked-on target (e.g., Smart Pistol).
3. **Bouncing Projectiles:** Projectiles that reflect off surfaces instead of destroying on impact, losing a percentage of velocity per bounce (e.g., Grenade Launchers).
4. **Piercing Projectiles:** Projectiles that pass through enemies or thin cover, applying damage to multiple targets along their path, often with reduced damage after the first penetration.

## 7. Compatibility Notes
- **Commonly Pairs With:** `atom_recoil` (Recoil Control), `atom_reload` (Ammunition Management), `atom_ads` (Aim Down Sights).
- **Conflicts:** Can conflict with `atom_melee_lockon` if the game tries to blend heavy melee auto-targeting with precision projectile aiming, leading to confusing player feedback.

## 8. Anti-Patterns
1. **Invisible Projectiles:** Having projectiles with travel time but lacking clear visual tracers or trails, making it impossible for players to learn how to lead targets or adjust for drop.
2. **Excessive Drag:** Applying too much air resistance so that projectiles slow down drastically at mid-range, making combat feel sluggish and unpredictable.
3. **Mismatched Hitboxes:** Using a collision radius for the projectile that is significantly larger or smaller than its visual representation, leading to "ghost hits" or frustrating misses.
