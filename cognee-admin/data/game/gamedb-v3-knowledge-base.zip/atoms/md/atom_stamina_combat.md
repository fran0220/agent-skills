# Identity
The atom ID for this gameplay mechanic is atom_stamina_combat. Its English name is Stamina-Gated Combat, and its Chinese name is 体力门控战斗. It belongs to Category A. Stamina-Gated Combat is a core gameplay mechanic where every significant combat action—such as attacking, dodging, blocking, or sprinting—consumes a shared, regenerating resource called stamina. This system forces players to manage their energy economy carefully, transforming combat from a test of pure reaction speed into a strategic dance of resource allocation and timing.

# Core Verb & State Machine
The core verb of this atom is to manage stamina through actions like attacking, dodging, blocking, and waiting. The state machine consists of several key states: Idle, Attacking, Dodging, Blocking, and Exhausted. In the Idle state, stamina regenerates over time. When the player transitions to Attacking or Dodging, stamina is consumed based on the specific action's cost. The Blocking state pauses stamina regeneration and consumes stamina when the player is hit by an enemy attack. If stamina reaches zero, the player enters the Exhausted state, where they cannot perform stamina-consuming actions and their movement speed is significantly reduced.

Transitions between these states are governed by player input and stamina availability. Moving from Idle to Attacking requires an attack input and a stamina value greater than zero. Similarly, transitioning to Dodging requires a dodge input and enough stamina to cover the dodge cost. Blocking requires a block input and positive stamina. The Attacking and Dodging states return to Idle once their respective animations finish, while Blocking returns to Idle when the block input is released. Any state, except Exhausted, transitions to Exhausted if stamina is fully depleted. The Exhausted state returns to Idle only after stamina regenerates above a specific threshold.

# MDA Analysis
The mechanics of this system revolve around tracking a stamina value that decreases upon performing specific actions and regenerates over time when the player is idle or walking. Each action has a specific stamina cost. If stamina is insufficient, the action cannot be performed, or performing it depletes stamina to zero, triggering an exhausted state.

The dynamics of Stamina-Gated Combat naturally lead players into a rhythm of engaging the enemy, expending stamina to deal damage or avoid attacks, and then retreating or playing defensively to allow stamina to recharge. This creates a pacing of tension and release during combat encounters, as players must constantly evaluate their remaining stamina before committing to an action.

The aesthetics of the system evoke feelings of tension, vulnerability, and deliberate pacing. Players feel the weight of their decisions, as overcommitting to an attack leaves them defenseless against counterattacks. Success in this system brings a profound sense of mastery over the game's rhythm and resource management, rewarding patience and strategic planning.

# Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value | Unit |
|---|---|---|---|---|
| max_stamina | f32 | 50.0 - 200.0 | 100.0 (Dark Souls 3 v1.15) | points |
| stamina_regen_rate | f32 | 10.0 - 50.0 | 45.0 (Dark Souls 3 v1.15) | points/sec |
| attack_cost_light | f32 | 10.0 - 30.0 | 20.0 (Dark Souls 3 v1.15) | points |
| attack_cost_heavy | f32 | 25.0 - 60.0 | 40.0 (Dark Souls 3 v1.15) | points |
| dodge_cost | f32 | 10.0 - 25.0 | 15.0 (Dark Souls 3 v1.15) | points |
| block_regen_penalty | f32 | 0.0 - 1.0 | 0.2 (Dark Souls 3 v1.15) | multiplier |
| exhaust_penalty_time | f32 | 0.5 - 2.0 | 1.0 (Elden Ring v1.10) | seconds |

# Benchmark Data
In Dark Souls 3 (v1.15), the base Knight class starts with a max_stamina of 100.0 points. The stamina_regen_rate is set to 45.0 points per second. A standard dodge roll costs 15.0 points of stamina, while a light attack with a Longsword consumes 20.0 points.

In Elden Ring (v1.10), the base Vagabond class also begins with a max_stamina of 100.0 points and a stamina_regen_rate of 45.0 points per second. However, the dodge_cost is slightly lower at 12.0 points, and a light attack with a Longsword costs 18.0 points, reflecting a slightly more forgiving stamina economy compared to its predecessor.

# Common Variants
One common variant is Negative Stamina, where actions can push stamina below zero. In this system, the player must wait for stamina to regenerate back to a positive value before they can act again, as seen in games like Valheim. Another variant is Active Reload or Regen, where players can press a button with precise timing after an attack to instantly recover a portion of the expended stamina, exemplified by Nioh's Ki Pulse mechanic.

Some games use Stamina as Health, where taking damage reduces stamina instead of health, and health is only damaged when stamina is completely depleted. Finally, Segmented Stamina divides stamina into discrete chunks rather than a continuous bar, simplifying the math and resource management for the player.

# Compatibility Notes
Stamina-Gated Combat is highly compatible with atoms such as atom_dodge_roll, atom_parry_riposte, atom_poise_armor, and atom_lock_on_targeting. These mechanics synergize well, creating a cohesive and deliberate combat experience. Conversely, it is generally incompatible with atoms like atom_infinite_combo and atom_bullet_hell_movement, which encourage relentless attacking and constant, high-speed mobility that conflict with the deliberate pacing of stamina management.

# Anti-Patterns
A common anti-pattern is Overly Punishing Exhaustion. Making the exhausted state last too long or slowing movement to a crawl can make the game feel unresponsive and frustrating rather than challenging. Another issue is Unclear Costs, where players cannot intuitively gauge how much stamina an action will cost. This prevents them from planning their attacks effectively, leading to accidental exhaustion. Finally, if stamina regenerates too slowly, combat pacing grinds to a halt, forcing players to spend most of their time waiting rather than engaging with the enemy.
