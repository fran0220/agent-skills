# Gameplay Atom: Coyote Time

## 1. Identity
- **Atom ID**: `atom_coyote_time`
- **English Name**: Coyote Time
- **Chinese Name**: 土狼时间
- **Category**: A
- **Definition**: Coyote Time is a player-friendly mechanic that allows the player to input a jump command for a brief window of time (usually a few frames) immediately after walking off a ledge, even though the character is technically no longer supported by the ground. This compensates for human reaction time and prevents frustrating "missed" jumps that feel unfair to the player.

## 2. Core Verb & State Machine
- **Primary Player Verb**: Jump

**State Diagram**:
```text
[Grounded] --(Walk off ledge)--> [Coyote Time Active]
[Coyote Time Active] --(Jump Input)--> [Jumping]
[Coyote Time Active] --(Timer Expires)--> [Falling]
[Jumping] --(Land)--> [Grounded]
[Falling] --(Land)--> [Grounded]
```

**States**:
- `Grounded`: The character is on a solid surface.
- `Coyote Time Active`: The character has just left the ground without jumping, and the coyote time window is ticking.
- `Jumping`: The character is moving upwards due to a jump action.
- `Falling`: The character is moving downwards under the influence of gravity.

**Transitions**:
- `Grounded` -> `Coyote Time Active`: Triggered when the character walks off a ledge.
- `Coyote Time Active` -> `Jumping`: Triggered when the player presses the jump button before the timer expires.
- `Coyote Time Active` -> `Falling`: Triggered when the coyote time timer reaches zero without a jump input.

## 3. MDA Analysis
- **Mechanics**: The system starts a timer when the player's collider leaves the ground collider without a jump input. If a jump input is received while the timer is greater than zero, the character executes a grounded jump.
- **Dynamics**: Players can push their jumps to the absolute edge of platforms, maximizing jump distance and feeling a sense of precision and control. It encourages risk-taking and fluid movement.
- **Aesthetics**: Creates a feeling of fairness, responsiveness, and empowerment. The game feels "tight" and forgiving rather than punishing and rigid.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Celeste v1.4) | Unit |
| --- | --- | --- | --- | --- |
| `coyote_time_duration` | f32 | 0.05 - 0.15 | 0.083 (5 frames at 60fps) | seconds |
| `allow_coyote_jump` | bool | true/false | true | boolean |
| `coyote_jump_velocity_multiplier` | f32 | 0.8 - 1.0 | 1.0 | multiplier |

## 5. Benchmark Data
- **Celeste (v1.4.0.0)**:
  - `coyote_time_duration`: 0.083 seconds (exactly 5 frames at 60 FPS).
  - Notes: Celeste's implementation is highly generous and is a core reason why the platforming feels so precise.
- **Hollow Knight (v1.5.78.11833)**:
  - `coyote_time_duration`: ~0.1 seconds (around 6 frames at 60 FPS).
  - Notes: Hollow Knight uses this to ensure combat and platforming flow smoothly together, preventing accidental falls during intense encounters.

## 6. Common Variants
1. **Diminishing Returns Coyote Time**: The later the jump is pressed within the window, the weaker the jump force applied.
2. **Visual Cue Coyote Time**: The character leaves a faint afterimage or particle effect on the ledge to visually indicate the window is active.
3. **Weapon-Specific Coyote Time**: Only certain weapons or character states allow for coyote time (e.g., lighter characters get more frames).
4. **Wall-Jump Coyote Time**: Applying the same logic to wall jumps, allowing a wall jump slightly after detaching from a wall.

## 7. Compatibility Notes
- **Commonly Pairs With**: `atom_jump_buffering` (Jump Buffering), `atom_variable_jump_height` (Variable Jump Height), `atom_dash` (Dash).
- **Known Conflicts**: Can conflict with `atom_strict_physics_simulation` if the physics engine strictly enforces rigid body states without allowing for custom state overrides.

## 8. Anti-Patterns
1. **Excessive Duration**: Setting the coyote time too high (e.g., > 0.2 seconds) makes the character look like they are floating on air, breaking immersion and making the game feel floaty.
2. **Inconsistent Application**: Applying coyote time to some ledges but not others, leading to unpredictable player experiences.
3. **Double Jump Exploit**: Failing to consume the "grounded" state properly, allowing players to coyote jump and then immediately double jump, gaining unintended height.
