# Gameplay Atom: Meta-Progression (元进度)

## 1. Identity
- **Atom ID:** atom_meta_progression
- **English Name:** Meta-Progression
- **Chinese Name:** 元进度
- **Category:** E
- **Definition:** Meta-progression refers to the persistent advancement or accumulation of resources, stats, or unlocks across multiple independent playthroughs or runs, providing long-term goals and gradually easing the difficulty or expanding the possibility space of subsequent runs.

## 2. Core Verb & State Machine
- **Core Verb:** Accumulate / Upgrade
- **State Diagram:**
  [Start Run] -> [Gather Meta-Resources] -> [Die/Complete Run] -> [Hub/Menu] -> [Spend Meta-Resources] -> [Unlock/Upgrade] -> [Start Run]
- **States:**
  - `Run_Active`: Player is in a run, collecting temporary and meta-resources.
  - `Run_Ended`: Player dies or wins, tallying collected meta-resources.
  - `Hub_Active`: Player is in the meta-progression hub.
  - `Upgrading`: Player spends resources to acquire permanent upgrades.
- **Transitions:**
  - `Run_Active` -> `Run_Ended`: Triggered by player death or run completion.
  - `Run_Ended` -> `Hub_Active`: Triggered by returning to the main menu or hub area.
  - `Hub_Active` -> `Upgrading`: Triggered by interacting with an upgrade vendor/menu.
  - `Upgrading` -> `Hub_Active`: Triggered by completing an upgrade.
  - `Hub_Active` -> `Run_Active`: Triggered by starting a new run.

## 3. MDA Analysis
- **Mechanics:** The system tracks specific currencies or achievements that persist beyond a single game session. These currencies can be spent in a hub area to permanently increase base stats (e.g., health, damage), unlock new items/weapons for future runs, or unlock new gameplay mechanics.
- **Dynamics:** Players may alter their playstyle during a run to prioritize gathering meta-resources over immediate survival (farming/grinding). The power curve of the player character gradually increases over multiple runs, allowing them to reach further into the game even if their raw skill does not improve proportionally.
- **Aesthetics:** Provides a sense of continuous growth, achievement, and investment. It mitigates the frustration of losing a run by ensuring that time spent always contributes to long-term progress (Submission/Discovery/Fellowship).

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Game/Version) | Unit |
|---|---|---|---|---|
| `base_health_upgrade_cost` | u32 | 10 - 500 | 50 (Hades v1.0) | Darkness |
| `health_increase_per_level` | f32 | 5.0 - 20.0 | 10.0 (Hades v1.0) | HP |
| `max_upgrade_levels` | u32 | 1 - 100 | 10 (Rogue Legacy v1.2) | Levels |
| `resource_retention_rate` | f32 | 0.0 - 1.0 | 1.0 (Dead Cells v3.4) | Multiplier |
| `unlock_cost_multiplier` | f32 | 1.1 - 2.0 | 1.5 (Rogue Legacy v1.2) | Multiplier |

## 5. Benchmark Data
- **Hades (v1.0):**
  - `base_health_upgrade_cost`: 50 Darkness
  - `health_increase_per_level`: 10.0 HP
  - `max_upgrade_levels`: 10
- **Dead Cells (v3.4):**
  - `resource_retention_rate`: 1.0 (Cells are kept until spent or lost on death, but permanent upgrades persist forever)
  - `unlock_cost_multiplier`: 1.0 (Fixed costs for blueprints)
- **Rogue Legacy (v1.2):**
  - `base_health_upgrade_cost`: 100 Gold
  - `health_increase_per_level`: 5.0 HP
  - `unlock_cost_multiplier`: 1.2 (Costs increase as you buy more upgrades)

## 6. Common Variants
1. **Stat-Based Meta-Progression:** Permanent increases to base stats (e.g., Rogue Legacy's manor).
2. **Unlock-Based Meta-Progression:** Adding new items, weapons, or abilities to the random pool of future runs (e.g., Dead Cells' blueprints).
3. **Narrative Meta-Progression:** Unlocking new story elements, dialogues, or lore entries across runs (e.g., Hades' relationship system).
4. **Shortcut/Checkpoint Meta-Progression:** Unlocking the ability to skip early levels or start from later points (e.g., Enter the Gungeon's elevators).

## 7. Compatibility Notes
- **Commonly Pairs With:** `atom_permadeath`, `atom_procedural_generation`, `atom_random_loot`, `atom_hub_world`.
- **Conflicts:** `atom_linear_story` (can disrupt pacing if grinding is required), `atom_pure_skill_check` (meta-progression dilutes the purity of skill-based challenges).

## 8. Anti-Patterns
1. **Excessive Grinding:** Making the cost of upgrades so high that players must repeatedly play early levels just to farm resources, leading to boredom.
2. **Trivializing Content:** Allowing players to become so powerful through meta-progression that the core gameplay loop loses all challenge and tension.
3. **Meaningless Choices:** Offering a massive skill tree where most upgrades provide negligible benefits (e.g., +0.1% damage), making the progression feel unrewarding.
