# Gameplay Atom: Chase Sequence

## 1. Identity
- **Atom ID:** `atom_chase_sequence`
- **English Name:** Chase Sequence
- **Chinese Name:** 追逐序列
- **Category:** G/H (Action/Horror)
- **Definition:** A high-stakes gameplay segment where the player is relentlessly pursued by an invincible or overwhelmingly powerful entity, forcing them to prioritize evasion, navigation, and resource management over direct combat to survive.

## 2. Core Verb & State Machine
- **Core Verb:** Flee (Escape)

**State Diagram:**
```text
[Idle/Exploration] --> (Trigger Event) --> [Pursuit Initiated]
[Pursuit Initiated] --> (Line of Sight Broken) --> [Searching]
[Searching] --> (Player Spotted) --> [Pursuit Initiated]
[Searching] --> (Timeout) --> [Idle/Exploration]
[Pursuit Initiated] --> (Player Caught) --> [Death/Failure]
[Pursuit Initiated] --> (Safe Zone Reached) --> [Escape Successful]
```

**States and Transitions:**
- **Idle/Exploration:** The player is exploring normally. The pursuer is either absent or patrolling passively.
- **Pursuit Initiated:** The pursuer has detected the player and is actively chasing them.
- **Searching:** The pursuer has lost direct line of sight and is investigating the player's last known location.
- **Death/Failure:** The pursuer catches the player, resulting in a game over or penalty.
- **Escape Successful:** The player reaches a designated safe area or completes an objective to end the chase.

## 3. MDA Analysis
- **Mechanics:** The system spawns a pursuer with a movement speed typically slightly faster or equal to the player's sprint speed. The environment is designed with obstacles, hiding spots, and branching paths. Stamina management is often enforced.
- **Dynamics:** Players must quickly read the environment, make split-second routing decisions, and manage their stamina to maintain distance. The pursuer's AI dynamically adjusts its pathing to cut off the player.
- **Aesthetics:** Induces panic, adrenaline, tension, and a profound sense of vulnerability. The relief upon successful escape provides a strong emotional catharsis.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Game) | Unit |
|---|---|---|---|---|
| `pursuer_speed` | f32 | 3.0 - 7.0 | 5.5 (Outlast v1.0) | m/s |
| `player_sprint_speed` | f32 | 4.0 - 8.0 | 6.0 (Outlast v1.0) | m/s |
| `stamina_drain_rate` | f32 | 5.0 - 20.0 | 10.0 (Amnesia: TDD v1.2) | %/s |
| `detection_radius` | f32 | 10.0 - 50.0 | 20.0 (RE2 Remake v1.0) | meters |
| `search_duration` | f32 | 10.0 - 60.0 | 30.0 (Alien: Isolation v1.0) | seconds |
| `catch_distance` | f32 | 0.5 - 2.0 | 1.2 (Outlast v1.0) | meters |

## 5. Benchmark Data
- **Outlast (v1.0):** `pursuer_speed` = 5.5 m/s, `player_sprint_speed` = 6.0 m/s, `catch_distance` = 1.2 m/s. The slight speed advantage of the player is offset by stamina limitations and environmental obstacles.
- **Resident Evil 2 Remake (v1.0):** Mr. X `pursuer_speed` = 3.5 m/s (walking), `detection_radius` = 20.0 m (hearing gunshots). The chase is slower but persistent, focusing on routing rather than pure speed.
- **Amnesia: The Dark Descent (v1.2):** `stamina_drain_rate` = 10.0 %/s (sanity drain when looking at monster), `search_duration` = 15.0 s. Emphasizes hiding and breaking line of sight over prolonged running.

## 6. Common Variants
1. **Scripted Chase:** A highly cinematic, linear chase with collapsing environments (e.g., Crash Bandicoot boulder levels, Uncharted set pieces).
2. **Stalker/Persistent Chase:** The pursuer roams the entire map dynamically and can appear at any time (e.g., Alien in Alien: Isolation, Nemesis in RE3).
3. **Hide-and-Seek:** Focuses heavily on breaking line of sight and utilizing hiding spots (lockers, under beds) rather than outrunning the enemy (e.g., Outlast, Clock Tower).
4. **Obstacle Course Chase:** The player must perform parkour or platforming moves flawlessly while being chased (e.g., Ori and the Blind Forest escape sequences).

## 7. Compatibility Notes
- **Commonly Pairs With:** `atom_stealth_hiding`, `atom_stamina_management`, `atom_environmental_puzzles` (quick interactions under pressure), `atom_qte` (struggle mechanics if caught).
- **Known Conflicts:** `atom_heavy_combat` (giving the player too much firepower ruins the vulnerability required for a chase), `atom_complex_inventory_management` (pausing or navigating menus breaks the pacing of a chase).

## 8. Anti-Patterns
1. **Unreadable Environments:** Designing the escape route with unclear signposting, leading to frustrating trial-and-error deaths where the player doesn't know where to go.
2. **Rubber-Banding AI:** Making the pursuer artificially teleport or speed up when the player plays perfectly, punishing good performance and breaking immersion.
3. **Overuse of Instant Death:** Relying solely on one-hit kills without any warning or struggle mechanic, which can lead to rapid frustration rather than tension.
