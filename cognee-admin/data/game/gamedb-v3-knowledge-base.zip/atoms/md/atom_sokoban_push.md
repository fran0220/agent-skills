# Gameplay Atom: Sokoban Push

## 1. Identity
- **Atom ID:** atom_sokoban_push
- **English Name:** Sokoban Push
- **Chinese Name:** 推箱子
- **Category:** Category C (Core Mechanics)
- **Definition:** A fundamental puzzle mechanic where a player-controlled entity can move discrete objects (usually blocks or crates) by walking into them, typically restricted to pushing one object at a time along a grid, with the constraint that objects cannot be pulled.

## 2. Core Verb & State Machine
- **Core Verb:** Push
- **State Diagram:**
  [Idle] --(Move Input)--> [Moving]
  [Moving] --(Collide with Pushable)--> [Pushing]
  [Pushing] --(Obstacle/Wall)--> [Blocked]
  [Pushing] --(Input Released/Grid Reached)--> [Idle]
- **States:**
  - `Idle`: The player and the pushable object are stationary.
  - `Moving`: The player is moving without interacting with a pushable object.
  - `Pushing`: The player is actively displacing a pushable object.
  - `Blocked`: The player is attempting to push, but the object is obstructed by a wall or another object.
- **Transitions:**
  - `Idle` -> `Moving`: Player initiates movement.
  - `Moving` -> `Pushing`: Player moves into a grid cell occupied by a pushable object.
  - `Pushing` -> `Blocked`: The target cell for the pushable object is occupied.
  - `Pushing` -> `Idle`: The push action is completed (e.g., object reaches the next grid cell).

## 3. MDA Analysis
- **Mechanics:** The system checks for collisions between the player and pushable entities. If a collision occurs in the direction of movement, it checks the adjacent space beyond the entity. If empty, both player and entity move; if occupied, movement is blocked.
- **Dynamics:** Players must plan their moves carefully to avoid pushing objects into corners or against walls where they cannot be retrieved, leading to emergent puzzle-solving strategies like creating paths or blocking hazards.
- **Aesthetics:** Evokes feelings of intellectual challenge, satisfaction upon solving spatial puzzles, and occasional frustration when a single wrong move requires a reset.

## 4. Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value (Game) | Unit |
|---|---|---|---|---|
| `push_speed` | f32 | 1.0 - 10.0 | 5.0 (Sokoban v1.0) | tiles/sec |
| `max_push_count` | u32 | 1 - 5 | 1 (Sokoban v1.0) | blocks |
| `undo_limit` | u32 | 0 - 999 | 999 (Baba Is You v1.0) | actions |
| `grid_size` | f32 | 16.0 - 64.0 | 32.0 (Sokoban v1.0) | pixels |

## 5. Benchmark Data
- **Sokoban (Original, 1982):**
  - `push_speed`: 5.0
  - `max_push_count`: 1
  - `undo_limit`: 0
- **Stephen's Sausage Roll (v1.0):**
  - `push_speed`: 3.0
  - `max_push_count`: 1
  - `undo_limit`: 999
- **Baba Is You (v1.0):**
  - `push_speed`: 10.0
  - `max_push_count`: 99
  - `undo_limit`: 999

## 6. Common Variants
1. **Multi-Push:** The ability to push multiple aligned objects simultaneously (e.g., Baba Is You).
2. **Pulling:** Adding the ability to pull objects as well as push them (e.g., some Zelda puzzles).
3. **Sticky Blocks:** Blocks that stick together when pushed adjacent to each other.
4. **Momentum Push:** Pushing an object causes it to slide until it hits an obstacle (Ice block puzzles).

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_grid_movement`, `atom_undo_system`, `atom_pressure_plate`, `atom_teleport`.
- **Incompatible Atoms:** `atom_continuous_physics` (often conflicts with strict grid-based Sokoban logic), `atom_jump` (bypasses the spatial constraints of pushing).

## 8. Anti-Patterns
1. **Hidden Unsolvable States:** Allowing the player to reach a state where the puzzle is unsolvable without providing clear feedback or an easy undo mechanism.
2. **Ambiguous Hitboxes:** In non-grid-based variants, having unclear collision boundaries that make it difficult to predict if a push will succeed.
3. **Tedious Resetting:** Forcing the player to manually walk back or reload a save instead of providing a quick restart or undo button.
