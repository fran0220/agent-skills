# Gameplay Atom: Run-Based Session

## 1. Identity
- **Atom ID:** `atom_run_based`
- **English Name:** Run-Based Session
- **Chinese Name:** 单局制结构
- **Category:** H
- **Definition:** A gameplay structure where the game is divided into distinct, self-contained attempts or "runs". Each run starts from a baseline state, progresses through a series of challenges, and ends in either victory or defeat, resetting the core state while often retaining meta-progression elements.

## 2. Core Verb & State Machine
- **Primary Player Verb:** "Attempt" / "Run"
- **State Diagram:**
  ```text
  [Hub/Menu] --> [Start Run]
  [Start Run] --> [Encounter]
  [Encounter] --> [Reward]
  [Reward] --> [Next Encounter]
  [Next Encounter] --> [Encounter]
  [Encounter] --> [Death]
  [Encounter] --> [Victory]
  [Death] --> [Run End]
  [Victory] --> [Run End]
  [Run End] --> [Hub/Menu]
  ```
- **States:** Hub/Menu, Start Run, Encounter, Reward, Next Encounter, Death, Victory, Run End.
- **Transitions:**
  - Hub/Menu to Start Run: Player initiates a new attempt.
  - Start Run to Encounter: First challenge begins.
  - Encounter to Reward: Player clears the challenge.
  - Reward to Next Encounter: Player chooses the next path.
  - Encounter to Death: Player loses all health.
  - Encounter to Victory: Player defeats the final boss.
  - Death/Victory to Run End: Tallying score and meta-currency.
  - Run End to Hub/Menu: Return to base for upgrades.

## 3. MDA Analysis
- **Mechanics:** Permadeath within a single run, procedural generation of encounters, temporary power-ups that reset upon death, and permanent meta-currency accumulation.
- **Dynamics:** Players constantly weigh risk versus reward, adapt their strategies based on random number generation (RNG) drops, and learn enemy patterns through repeated failures.
- **Aesthetics:** Challenge (overcoming difficult obstacles), Discovery (finding new synergies), and Submission (entering the flow state of the gameplay loop).

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value | Unit |
|---|---|---|---|---|
| `base_health` | u32 | 50 - 200 | 50 (Hades v1.0) | HP |
| `encounters_per_run` | u32 | 10 - 100 | 50 (Slay the Spire v2.2) | count |
| `meta_currency_rate` | f32 | 0.1 - 5.0 | 1.0 (Dead Cells v3.4) | multiplier |

## 5. Benchmark Data
- **Hades (v1.0):** `base_health` = 50, `encounters_per_run` = 69, `meta_currency_rate` = 1.0
- **Slay the Spire (v2.2):** `base_health` = 70, `encounters_per_run` = 50, `meta_currency_rate` = 0.0 (No direct meta-currency for stats, but unlock XP)
- **Dead Cells (v3.4):** `base_health` = 100, `encounters_per_run` = 30, `meta_currency_rate` = 1.5

## 6. Common Variants
1. **Pure Roguelike:** No meta-progression; every run starts completely fresh (e.g., Spelunky).
2. **Roguelite:** Heavy meta-progression where permanent upgrades make future runs easier (e.g., Rogue Legacy).
3. **Extraction:** Players can choose to extract early to keep loot, but lose everything if they die (e.g., Escape from Tarkov).

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_procedural_gen`, `atom_permadeath`, `atom_meta_progression`, `atom_drafting`.
- **Incompatible Atoms:** `atom_save_scumming`, `atom_linear_campaign`, `atom_checkpoint_saves`.

## 8. Anti-Patterns
1. **Fatigue-Inducing Runs:** Runs that take too long (e.g., over 2 hours) can cause player fatigue and make death feel overly punishing.
2. **Trivializing Meta-Progression:** If permanent upgrades are too strong, the core gameplay loop loses its challenge and becomes a pure grind.
3. **Excessive RNG Reliance:** If success depends entirely on getting the right random drops rather than player skill, players will feel a lack of agency.
