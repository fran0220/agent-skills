# Elemental Reaction (元素反应)

## 1. Identity
- **Atom ID**: atom_elemental_reaction
- **English Name**: Elemental Reaction
- **Chinese Name**: 元素反应
- **Category**: A
- **Definition**: A system where different elemental statuses applied to a target interact to produce unique, emergent effects, such as bonus damage, crowd control, or environmental changes.

## 2. Core Verb & State Machine
- **Core Verb**: Apply (Element)
- **State Diagram**:
  [Neutral] --(Apply Element A)--> [Afflicted with A]
  [Afflicted with A] --(Apply Element B)--> [Reaction Triggered] --> [Neutral / Afflicted with C]
  [Afflicted with A] --(Time Decay)--> [Neutral]
- **States**: Neutral, Afflicted (Single Element), Reacting.
- **Transitions**:
  - Neutral -> Afflicted: Triggered by receiving elemental damage/application.
  - Afflicted -> Reacting: Triggered by receiving a different, interacting element.
  - Afflicted -> Neutral: Triggered by duration expiration.

## 3. MDA Analysis
- **Mechanics**: Entities have an elemental gauge. Applying an element adds to the gauge. Applying a second element consumes the gauge to trigger a specific effect based on the combination.
- **Dynamics**: Players actively switch characters or use environmental hazards to combine elements for optimal damage or utility, leading to dynamic team compositions and rotation strategies.
- **Aesthetics**: Satisfaction from discovering combinations, visual spectacle of reactions, and the intellectual reward of mastering complex combat systems.

## 4. Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value (Genshin Impact v4.0) | Unit |
|---|---|---|---|---|
| base_reaction_multiplier | f32 | 1.0 - 3.0 | 2.0 (Melt/Vaporize strong) | multiplier |
| elemental_mastery_bonus | f32 | 0.0 - 5.0 | Formula based | % |
| gauge_units | f32 | 1.0 - 4.0 | 1.0 (Weak), 2.0 (Strong) | U |
| aura_duration | f32 | 5.0 - 15.0 | 9.5 (1U), 12.0 (2U) | seconds |

## 5. Benchmark Data
- **Genshin Impact (v4.0)**:
  - `base_reaction_multiplier`: 1.5 (Weak Melt), 2.0 (Strong Melt)
  - `gauge_units`: 1.0, 2.0, 4.0
  - `aura_duration`: 9.5s for 1U, 12.0s for 2U.
- **Divinity: Original Sin 2 (v3.6)**:
  - Surface interaction duration: 2-3 turns.
  - Damage multiplier on surfaces: 1.2 - 1.5.

## 6. Common Variants
1. **Gauge-based (Genshin Impact)**: Elements have hidden "units" that are consumed proportionally.
2. **Surface-based (Divinity: Original Sin 2)**: Elements exist in the environment and interact when overlapping.
3. **Stack-based (Honkai: Star Rail)**: Elements build up stacks to trigger a break effect rather than interacting with each other directly.
4. **Binary (Magicka)**: Elements combine in a queue to form a new spell, with opposing elements canceling each other out.

## 7. Compatibility Notes
- **Compatible Atoms**: atom_status_effect, atom_environmental_hazard, atom_combat_combo.
- **Incompatible Atoms**: atom_pure_physical_combat (conflicts with the core premise).

## 8. Anti-Patterns
1. **Overcomplication**: Having too many elements with unintuitive interactions that players cannot memorize.
2. **Imbalance**: One specific reaction being mathematically superior in all situations, invalidating the rest of the system.
3. **Lack of Feedback**: Failing to provide clear visual or audio cues when a reaction occurs, leaving players confused about their damage output.
