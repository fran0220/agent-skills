# Identity
- **Atom ID**: atom_shrinking_zone
- **English Name**: Shrinking Zone / Circle
- **Chinese Name**: 毒圈收缩
- **Category**: G/H (Gameplay Mechanics)
- **Definition**: A dynamic boundary that progressively reduces the playable area over time, forcing players into closer proximity and escalating conflict to ensure the game concludes within a predictable timeframe.

# Core Verb & State Machine
- **Core Verb**: Survive / Relocate
- **State Diagram**:
  [Waiting] -> [Warning] -> [Shrinking] -> [Paused] -> [Waiting] ... -> [Final Collapse]
- **States and Transitions**:
  - `Waiting`: The zone is stable. Players can loot and fight. Transition to `Warning` when the wait timer expires.
  - `Warning`: The next safe zone is revealed, and a countdown begins. Transition to `Shrinking` when the warning timer expires.
  - `Shrinking`: The blue zone moves towards the safe zone. Transition to `Paused` when the blue zone reaches the safe zone.
  - `Paused`: The zone is stable again (same as Waiting for the next phase).
  - `Final Collapse`: The zone shrinks to nothing, eliminating all remaining players outside the center.

# MDA Analysis
- **Mechanics**: The system periodically selects a smaller circle within the current safe zone and moves a damaging boundary from the old circle to the new one over a set duration. Players outside the safe zone take damage over time.
- **Dynamics**: Players are forced to move, creating chokepoints and ambushes. The density of players increases as the game progresses, leading to more frequent and intense firefights.
- **Aesthetics**: Tension, urgency, and relief (when reaching the safe zone). The shrinking zone creates a pacing mechanism that builds climax.

# Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value (PUBG v1.0) | Unit |
|---|---|---|---|---|
| `initial_radius` | f32 | 2000 - 5000 | 4500 | meters |
| `shrink_factor` | f32 | 0.3 - 0.7 | 0.5 | ratio |
| `wait_time` | f32 | 30 - 300 | 120 | seconds |
| `shrink_time` | f32 | 30 - 180 | 90 | seconds |
| `damage_per_tick` | f32 | 1.0 - 15.0 | 1.5 | HP/sec |

# Benchmark Data
- **PUBG (v1.0)**: Phase 1 wait time 300s, shrink time 300s, damage 0.4/s. Phase 8 wait time 60s, shrink time 60s, damage 11/s.
- **Apex Legends (Season 10)**: Round 1 wait time 180s, shrink time 150s, damage 2/tick. Round 5 wait time 90s, shrink time 90s, damage 10/tick.

# Common Variants
1. **Moving Zones**: The final zones do not just shrink but also move to a new location outside the current safe zone (e.g., Fortnite moving storms).
2. **Sector Collapse**: Instead of a circle, specific map sectors become dangerous (e.g., Super People, Ring of Elysium).
3. **Dynamic Damage**: Damage increases the further a player is from the safe zone.

# Compatibility Notes
- **Compatible Atoms**: `atom_loot_drop` (air drops inside the safe zone), `atom_vehicle_transport` (vehicles become highly valuable for relocation).
- **Incompatible Atoms**: `atom_static_base_building` (building a permanent base is counterproductive if the zone moves away).

# Anti-Patterns
1. **Too Fast Shrink**: If the zone shrinks faster than players can run, it feels unfair and frustrating.
2. **Predictable Centers**: If the final zone always ends in the exact center of the map, it removes the need for adaptation.
3. **Insufficient Warning**: Not giving players enough time to react to the new zone location.
