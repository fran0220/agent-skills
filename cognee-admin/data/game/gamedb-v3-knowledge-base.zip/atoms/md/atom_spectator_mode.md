# Gameplay Atom: Spectator Mode

## 1. Identity
- **Atom ID:** `atom_spectator_mode`
- **English Name:** Spectator Mode
- **Chinese Name:** 观战模式
- **Category:** E/F (Esports / Features)
- **Definition:** Spectator Mode is a gameplay feature that allows players or non-playing users to observe an ongoing match without directly participating or affecting the outcome. It provides various camera controls, player perspectives, and statistical overlays to enhance the viewing experience, making it a cornerstone for esports broadcasting and community engagement.

## 2. Core Verb & State Machine
- **Core Verb:** Observe (Watch, Switch Perspective, Analyze)

**State Diagram:**
```text
[Idle] --> (Join Match as Spectator) --> [Loading]
[Loading] --> (Load Complete) --> [Spectating]
[Spectating] --> (Switch to Free Camera) --> [Free Camera Mode]
[Spectating] --> (Switch to Player POV) --> [Player POV Mode]
[Spectating] --> (Switch to Directed Camera) --> [Directed Camera Mode]
[Free Camera Mode] --> (Switch to Player POV) --> [Player POV Mode]
[Player POV Mode] --> (Switch to Free Camera) --> [Free Camera Mode]
[Spectating] --> (Match Ends) --> [Post-Match Stats]
[Post-Match Stats] --> (Leave) --> [Idle]
```

**States and Transitions:**
- **Idle:** The spectator is in the lobby or main menu.
- **Loading:** The spectator is loading the match data and assets.
- **Spectating:** The default state of watching the match.
- **Free Camera Mode:** The spectator can freely move the camera around the map.
- **Player POV Mode:** The spectator views the game exactly as a specific player sees it.
- **Directed Camera Mode:** An automated or director-controlled camera that focuses on the action.
- **Post-Match Stats:** The match has concluded, and the spectator is viewing the final statistics.

## 3. MDA Analysis
- **Mechanics:** The system provides tools to render the game world from arbitrary viewpoints, access real-time data of all players (health, economy, cooldowns), and delay the broadcast to prevent cheating (stream sniping).
- **Dynamics:** Spectators can switch between macro-level views (to understand team strategies) and micro-level views (to appreciate individual mechanical skill). Broadcasters use these tools to create a narrative out of the match.
- **Aesthetics:** The player (spectator) experiences a sense of discovery, excitement, and analytical satisfaction. It transforms the game from a participatory challenge into an entertaining spectacle or an educational resource.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value | Unit |
| --- | --- | --- | --- | --- |
| `broadcast_delay` | `u32` | 0 - 300 | 180 (CS:GO) | seconds |
| `camera_move_speed` | `f32` | 1.0 - 10.0 | 5.0 (LoL) | units/sec |
| `fov_spectator` | `f32` | 60.0 - 120.0 | 90.0 (CS:GO) | degrees |
| `xray_enabled` | `bool` | true/false | true (CS:GO) | boolean |
| `auto_director_enabled` | `bool` | true/false | true (CS:GO) | boolean |

## 5. Benchmark Data
- **Counter-Strike: Global Offensive (CS:GO) [v1.38.7.9]:**
  - `broadcast_delay`: 180 seconds (for official matchmaking)
  - `xray_enabled`: true (allows seeing players through walls)
  - `auto_director_enabled`: true (automatically switches to the most action-packed perspective)
- **League of Legends (LoL) [v13.20]:**
  - `broadcast_delay`: 180 seconds
  - `camera_move_speed`: 5.0 (adjustable via settings)
  - `fog_of_war_toggle`: true (can view vision of Blue team, Red team, or both)

## 6. Common Variants
1. **Live Spectating with Delay:** Used in competitive games to prevent cheating (e.g., LoL, CS:GO).
2. **Replay/Demo Spectating:** Watching a previously recorded match with full spectator controls (e.g., StarCraft II, Dota 2).
3. **Ghost Mode:** Dead players spectating their living teammates in round-based games (e.g., Valorant, Rainbow Six Siege).
4. **VR Spectating:** Watching a match in a virtual reality environment, often as a giant looking down at the map (e.g., Dota 2 VR Hub).
5. **Interactive Spectating:** Spectators can influence the game, such as dropping items or voting on events (e.g., The Darwin Project).

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_replay_system`, `atom_fog_of_war`, `atom_ping_system`.
- **Incompatible Atoms:** `atom_pause_system` (Spectators usually cannot pause a live multiplayer game).

## 8. Anti-Patterns
1. **Zero Delay in Competitive Play:** Allowing live spectating without a delay in competitive matches, leading to "ghosting" or stream sniping.
2. **Cluttered UI:** Overwhelming the spectator with too much information on the screen.
3. **Lack of Director Tools:** Forcing human broadcasters to manually control the camera at all times without automated assistance.
