# Identity
- **Atom ID**: atom_block_placement
- **English Name**: Block Placement / Destruction
- **Chinese Name**: 方块放置/破坏
- **Category**: G (Gameplay Mechanics)
- **Definition**: The ability for players to add or remove discrete volumetric units (blocks/voxels) within a grid-based or continuous world, fundamentally altering the terrain, creating structures, or gathering resources.

# Core Verb & State Machine
- **Core Verb**: Place / Destroy
- **State Diagram**:
  [Idle] --(Target Block/Empty Space)--> [Targeting]
  [Targeting] --(Input: Place)--> [Placing]
  [Targeting] --(Input: Destroy)--> [Destroying]
  [Placing] --(Success)--> [Idle]
  [Destroying] --(Success)--> [Idle]
- **States**: Idle, Targeting, Placing, Destroying
- **Transitions**:
  - Idle -> Targeting: Player aims at a valid grid coordinate.
  - Targeting -> Placing: Player initiates placement action with a valid block in inventory.
  - Targeting -> Destroying: Player initiates destruction action on an existing block.
  - Placing -> Idle: Block is successfully added to the world.
  - Destroying -> Idle: Block is successfully removed from the world.

# MDA Analysis
- **Mechanics**: The system tracks a 3D grid of block states. Placing updates an empty cell to a specific block type, deducting from inventory. Destroying updates a filled cell to empty, potentially yielding an item. Raycasting determines the targeted cell.
- **Dynamics**: Players reshape the environment for traversal (stairs, bridges), defense (walls, bunkers), or expression (pixel art, architecture). Resource gathering drives exploration.
- **Aesthetics**: Expression (building creative structures), Discovery (mining into unknown areas), Submission (repetitive clearing/mining as a relaxing activity).

# Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value (Minecraft 1.20) | Unit |
|---|---|---|---|---|
| `placement_range` | f32 | 3.0 - 10.0 | 4.5 | meters/blocks |
| `destruction_range` | f32 | 3.0 - 10.0 | 4.5 | meters/blocks |
| `base_mining_time` | f32 | 0.1 - 10.0 | 1.5 (Stone) | seconds |
| `placement_cooldown` | f32 | 0.0 - 0.5 | 0.2 | seconds |

# Benchmark Data
- **Minecraft (1.20)**:
  - `placement_range`: 4.5 blocks (Survival)
  - `destruction_range`: 4.5 blocks (Survival)
  - `placement_cooldown`: 0.2 seconds (4 ticks)
- **Terraria (1.4.4)**:
  - `placement_range`: 5.0 tiles (base)
  - `destruction_range`: 5.0 tiles (base)
  - `placement_cooldown`: ~0.15 seconds (depends on tool speed)

# Common Variants
1. **Physics-Enabled Blocks**: Blocks fall if unsupported (e.g., Sand in Minecraft, 7 Days to Die structural integrity).
2. **Multi-Block Structures**: Placing one item occupies multiple grid cells (e.g., Beds, Doors).
3. **Blueprint Placement**: Players place a holographic outline first, then fill it with resources (e.g., The Forest, Rust).
4. **Area of Effect (AoE) Destruction**: Explosives or upgraded tools destroy multiple blocks at once.

# Compatibility Notes
- **Compatible Atoms**: `atom_inventory_management` (storing blocks), `atom_crafting` (making blocks), `atom_durability` (tools breaking during destruction).
- **Conflicts**: `atom_rigid_body_physics` (having thousands of physics-active blocks can cause severe performance issues).

# Anti-Patterns
1. **Z-Fighting/Overlap**: Allowing blocks to be placed inside entities or other blocks without proper collision checks.
2. **Tedious Mining**: Setting base mining times too high without adequate progression, leading to player fatigue.
3. **Griefing Vulnerability**: Lacking protection systems in multiplayer, allowing players to easily destroy others' creations.
