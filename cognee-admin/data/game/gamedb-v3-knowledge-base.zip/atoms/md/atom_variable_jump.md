# Gameplay Atom: Variable Jump Height

## 1. Identity
**Atom ID:** `atom_variable_jump`
**English Name:** Variable Jump Height
**Chinese Name:** 可变跳跃高度
**Category:** A (Core Movement)
**Definition:** Variable Jump Height is a fundamental platforming mechanic where the height of a character's jump is determined by how long the player holds the jump button. Releasing the button early applies a downward force or cuts the upward velocity, resulting in a shorter jump, which provides players with precise control over their aerial trajectory and landing positioning.

## 2. Core Verb & State Machine
**Core Verb:** Jump (Hold/Release)

**State Diagram:**
[Grounded] --(Press Jump)--> [Jumping_Rising]
[Jumping_Rising] --(Hold Jump)--> [Jumping_Rising] (until max height/time)
[Jumping_Rising] --(Release Jump)--> [Jumping_Falling] (early fall)
[Jumping_Rising] --(Reach Max Height)--> [Jumping_Falling]
[Jumping_Falling] --(Touch Ground)--> [Grounded]

**States and Transitions:**
- **Grounded:** The character is on the ground. Transition to `Jumping_Rising` occurs when the jump button is pressed.
- **Jumping_Rising:** The character is moving upwards. The state persists as long as the jump button is held and the maximum jump duration or height has not been reached. If the button is released early, or the maximum height is reached, the state transitions to `Jumping_Falling`.
- **Jumping_Falling:** The character is moving downwards under the influence of gravity. Transition to `Grounded` occurs when the character's collider intersects with the ground.

## 3. MDA Analysis
**Mechanics:** The system applies an initial upward velocity when the jump button is pressed. While the button is held, gravity is either reduced or an upward force is continuously applied up to a maximum duration. If the button is released before this duration, gravity returns to normal or a velocity dampening multiplier is applied, causing the character to fall sooner.
**Dynamics:** Players learn to tap the button for short hops to avoid low obstacles or enemies, and hold the button for maximum height to cross large gaps. This creates a rhythm of micro-adjustments during platforming sequences.
**Aesthetics:** The mechanic fosters a sense of agency, precision, and fluidity. Players feel in complete control of their character's weight and momentum, leading to satisfaction when executing complex aerial maneuvers.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Celeste v1.4) | Unit |
|---|---|---|---|---|
| `initial_jump_velocity` | `f32` | 100.0 - 500.0 | 105.0 | pixels/sec |
| `gravity_normal` | `f32` | 500.0 - 1500.0 | 900.0 | pixels/sec² |
| `gravity_half` | `f32` | 200.0 - 800.0 | 450.0 | pixels/sec² |
| `max_jump_hold_time` | `f32` | 0.1 - 0.5 | 0.2 | seconds |
| `early_release_multiplier` | `f32` | 0.0 - 0.5 | 0.5 | ratio |

## 5. Benchmark Data
- **Celeste (v1.4.0.0):** 
  - `initial_jump_velocity`: 105.0
  - `max_jump_hold_time`: 0.2 seconds
  - `gravity_normal`: 900.0
  - `gravity_half`: 450.0 (applied at apex)
  - `early_release_multiplier`: 0.5 (velocity is cut in half if moving up and button released)
- **Super Mario Bros. (NES Release):**
  - `initial_jump_velocity`: 4.0 (sub-pixels/frame)
  - `gravity_normal`: 0.125 to 0.7 (depends on horizontal speed)
  - `early_release_multiplier`: Gravity increases drastically when the A button is released.

## 6. Common Variants
1. **Velocity Cut:** Releasing the jump button instantly multiplies the current upward Y-velocity by a fraction (e.g., 0.5). Common in modern indie platformers.
2. **Gravity Shift:** Releasing the jump button increases the gravity scale applied to the character, pulling them down faster.
3. **Continuous Force:** Holding the jump button applies a continuous upward force fighting gravity until a timer runs out.
4. **Multi-Stage Jump:** The jump has distinct height tiers based on specific frame windows of holding the button.

## 7. Compatibility Notes
**Compatible Atoms:**
- `atom_coyote_time`: Allows jumping shortly after leaving a ledge, pairs perfectly with variable jump for forgiving platforming.
- `atom_jump_buffer`: Queues a jump input just before landing, ensuring smooth chaining of variable jumps.
- `atom_double_jump`: The second jump can also have variable height properties.

**Incompatible Atoms:**
- `atom_fixed_grid_movement`: Games that rely on strict grid-based movement (like classic Sokoban) conflict with the continuous analog nature of variable jumps.

## 8. Anti-Patterns
1. **Floaty Jumps:** Setting the normal gravity too low or the hold time too long, making the character feel weightless and unresponsive.
2. **Punishing Early Release:** Cutting the velocity to 0 instantly upon release, which feels jarring and unnatural, breaking the parabolic arc of the jump.
3. **Inconsistent Physics:** Applying variable jump logic differently based on framerate, leading to different jump heights on different hardware.
