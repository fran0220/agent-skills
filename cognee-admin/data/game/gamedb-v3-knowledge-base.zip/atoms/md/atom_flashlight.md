# Gameplay Atom: Flashlight / Light Source

## 1. Identity
The **atom_flashlight** (English: Flashlight / Light Source, Chinese: 手电筒/光源) belongs to the G/H category, primarily focusing on exploration and survival mechanics. 

A flashlight is a portable, directional or omnidirectional light source controlled by the player, used to illuminate dark environments, reveal hidden objects, or interact with light-sensitive entities. It often involves resource management, such as battery life or oil, and creates tension by limiting visibility to a specific cone or radius, forcing the player to make tactical decisions about when and where to look.

## 2. Core Verb & State Machine
The core verb for this atom is **Illuminate**, which involves toggling the light source on or off, and aiming it at specific targets.

The state diagram for the flashlight operates as follows:
[Off] --(Toggle On)--> [On]
[On] --(Toggle Off)--> [Off]
[On] --(Battery Depleted)--> [Off]
[On] --(Focus/Boost)--> [Boosted]
[Boosted] --(Release/Overheat)--> [On]

The system consists of three primary states. In the `Off` state, the flashlight is inactive, providing no illumination and consuming no power. When transitioned to the `On` state, the flashlight becomes active, providing standard illumination and consuming power at a base rate. The `Boosted` state occurs when the player focuses the beam, emitting a stronger, more intense light that consumes power at an accelerated rate or generates heat.

Transitions between these states are driven by player input and resource limits. The player can transition from `Off` to `On` by pressing the toggle button. Conversely, transitioning from `On` to `Off` happens either when the player presses the toggle button again or when the battery reaches zero. The player can enter the `Boosted` state from `On` by holding a focus or aim button. Releasing this button, or reaching a stamina or heat limit, returns the flashlight to the `On` state.

## 3. MDA Analysis
**Mechanics:** The system casts a light volume, typically a cone or sphere, originating from the player's position or camera. It continuously checks for collisions with the environment to render dynamic lighting and shadows. Furthermore, it utilizes raycasting or trigger volumes to detect interactions with specific entities, such as burning away darkness shields on enemies or revealing hidden messages. The system also tracks a battery or fuel resource that depletes over time when the light is active and may recharge when inactive.

**Dynamics:** Players are forced to balance the critical need to see their surroundings with the necessity of conserving their limited battery resource. This leads to emergent behaviors such as quickly toggling the light on and off to check for threats (flicking) or saving the boost mode for strategic moments during combat. The limited cone of vision inherent in directional flashlights forces players to constantly move their camera to scan the environment, increasing their vulnerability to attacks from unseen angles.

**Aesthetics:** The implementation of a flashlight mechanic primarily evokes feelings of tension, vulnerability, and claustrophobia. The stark visual contrast between the illuminated, safe area and the surrounding, oppressive darkness heightens fear and anticipation. This sensory deprivation makes the player feel isolated and exposed in a hostile environment, amplifying the horror or survival experience.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Game) | Unit |
|---|---|---|---|---|
| `max_battery` | f32 | 10.0 - 300.0 | 100.0 (Alan Wake v1.0) | seconds |
| `drain_rate_normal` | f32 | 0.1 - 5.0 | 1.0 (Alan Wake v1.0) | units/sec |
| `drain_rate_boost` | f32 | 2.0 - 15.0 | 5.0 (Alan Wake v1.0) | units/sec |
| `recharge_rate` | f32 | 0.0 - 10.0 | 2.5 (Alan Wake v1.0) | units/sec |
| `cone_angle_normal` | f32 | 30.0 - 90.0 | 60.0 (Amnesia: The Dark Descent v1.2) | degrees |
| `cone_angle_boost` | f32 | 15.0 - 45.0 | 25.0 (Alan Wake v1.0) | degrees |
| `intensity_normal` | f32 | 1.0 - 5.0 | 2.0 (Amnesia: The Dark Descent v1.2) | lumens/multiplier |
| `intensity_boost` | f32 | 3.0 - 10.0 | 6.0 (Alan Wake v1.0) | lumens/multiplier |
| `range_normal` | f32 | 10.0 - 50.0 | 20.0 (Amnesia: The Dark Descent v1.2) | meters |

## 5. Benchmark Data
In **Alan Wake (v1.0)**, the flashlight serves as both a navigational tool and a weapon. The `max_battery` is set to 100.0 units. The `drain_rate_normal` is 1.0 unit per second, while the `drain_rate_boost` significantly increases to 5.0 units per second to strip enemy shields. When turned off, the battery recovers with a `recharge_rate` of 2.5 units per second. The `cone_angle_normal` provides a wide 55.0-degree view, which narrows to a `cone_angle_boost` of 25.0 degrees for focused attacks.

In **Amnesia: The Dark Descent (v1.2)**, the player uses a lantern instead of a directional flashlight. The `max_battery` (representing oil duration) is much longer at 300.0 seconds. The `drain_rate_normal` is a steady 1.0 unit per second. Because it is a lantern, the `cone_angle_normal` is effectively 360.0 degrees, providing omnidirectional light. The `range_normal` is limited to 15.0 meters, and the `intensity_normal` is set to 1.5, creating a soft glow rather than a piercing beam.

## 6. Common Variants
The **Battery Drainer** variant requires the player to constantly scavenge for battery pickups to keep the flashlight functioning, as seen in games like Outlast. This creates high resource anxiety and forces exploration in dangerous areas.

The **Combat Tool** variant integrates the flashlight directly into the combat loop. The light physically damages or weakens enemies, requiring a boost mode that drains power rapidly, a mechanic famously utilized in Alan Wake.

The **Dynamo or Kinetic** variant requires the player to manually crank or shake the flashlight to generate power. This action creates noise that can attract enemies and occupies the player's hands, preventing them from using weapons simultaneously, as demonstrated in Metro 2033.

The **Omnidirectional Lantern** variant illuminates a sphere around the player rather than a directional cone. This sacrifices long-range visibility for better peripheral awareness, commonly used in historical or fantasy settings like Amnesia.

The **UV or Specialty Light** variant is used to reveal hidden clues, blood trails, or specific enemy types that are invisible to normal light. This encourages players to switch between different light modes to fully understand their environment, as seen in Dying Light.

## 7. Compatibility Notes
The flashlight atom is highly compatible with several other systems. It pairs naturally with `atom_stealth`, where using the light breaks the player's concealment and alerts enemies. It also integrates well with `atom_inventory` for managing batteries or fuel, and `atom_sanity`, where standing in illuminated areas restores the player's mental state. Furthermore, it interacts directly with `atom_enemy_ai`, as enemies can be programmed to investigate the light source or flee from it.

However, there are notable conflicts. It is generally incompatible with `atom_auto_aim`, as the core tension of a directional flashlight relies on the player manually aiming the beam to spot threats. Additionally, if the game heavily features an `atom_day_night_cycle` where the majority of gameplay occurs during bright daylight, the flashlight mechanic becomes redundant and loses its impact.

## 8. Anti-Patterns
A common design mistake is providing an **Infinite Battery with No Drawbacks**. This removes the resource management aspect entirely, turning the flashlight into a permanent screen filter rather than a tactical tool that requires thoughtful use.

Another issue is implementing an **Overly Narrow Cone**. A cone angle that is too small forces the player to constantly sweep the camera back and forth just to navigate basic environments, which can cause motion sickness and severe frustration.

Finally, creating **Instant Total Darkness** when the battery dies is a significant anti-pattern. Plunging the player into absolute pitch blackness with zero ambient light can halt gameplay entirely, leading to soft-locks if the player cannot see well enough to find replacement batteries or navigate to a light source.
