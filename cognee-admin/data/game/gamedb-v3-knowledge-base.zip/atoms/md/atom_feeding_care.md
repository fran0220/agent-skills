# Gameplay Atom: Feeding / Care Cycle

## 1. Identity
- **Atom ID:** `atom_feeding_care`
- **English Name:** Feeding / Care Cycle
- **Chinese Name:** 喂养/照顾循环
- **Category:** H (Simulation / Nurturing)
- **Definition:** The Feeding / Care Cycle is a core gameplay loop where the player must periodically attend to the needs of a virtual entity (such as a pet, plant, or character) by providing resources like food, water, or affection to maintain its health, happiness, and overall well-being, preventing negative states like starvation, illness, or neglect.

## 2. Core Verb & State Machine
- **Core Verb:** Feed / Care / Nurture

**State Diagram:**
```text
[ Idle / Satisfied ] ---> (Time Passes) ---> [ Hungry / Needy ]
[ Hungry / Needy ] ---> (Player Feeds/Cares) ---> [ Idle / Satisfied ]
[ Hungry / Needy ] ---> (Time Passes / Ignored) ---> [ Starving / Sick ]
[ Starving / Sick ] ---> (Player Heals/Feeds) ---> [ Hungry / Needy ]
[ Starving / Sick ] ---> (Time Passes / Ignored) ---> [ Dead / Run Away ]
```

**States:**
- `Satisfied`: The entity has all its needs met and may provide passive benefits or progress towards growth.
- `Needy`: The entity requires attention (e.g., food, play). It may alert the player.
- `Sick`: The entity has been neglected for too long and requires special intervention (e.g., medicine).
- `Dead`: The entity has perished or left due to extreme neglect.

**Transitions:**
- `Satisfied` -> `Needy`: Triggered by time decay of the hunger/happiness meter.
- `Needy` -> `Satisfied`: Triggered by the player providing the required resource.
- `Needy` -> `Sick`: Triggered by the hunger/happiness meter reaching zero or a critical threshold.
- `Sick` -> `Needy`: Triggered by the player providing medicine or special care.
- `Sick` -> `Dead`: Triggered by prolonged time in the `Sick` state without intervention.

## 3. MDA Analysis
- **Mechanics:** The system tracks one or more internal variables (e.g., hunger, hygiene, happiness) that decay over real or in-game time. The player uses specific actions (feeding, cleaning, petting) to replenish these variables.
- **Dynamics:** Players develop routines and habits, checking in on the game periodically to maintain the entity's state. This creates a rhythm of engagement and encourages short, frequent play sessions.
- **Aesthetics:** The player experiences a sense of responsibility, attachment, and empathy towards the virtual entity. Successfully maintaining the entity provides a feeling of accomplishment and nurturing satisfaction.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Game + Version) | Unit |
|---|---|---|---|---|
| `max_hunger` | `f32` | 100.0 - 1000.0 | 100.0 (Tamagotchi Classic) | Points |
| `hunger_decay_rate` | `f32` | 0.1 - 5.0 | 1.0 (Tamagotchi Classic) | Points/Hour |
| `feed_amount` | `f32` | 10.0 - 50.0 | 25.0 (Tamagotchi Classic) | Points/Action |
| `sick_threshold` | `f32` | 0.0 - 20.0 | 0.0 (Tamagotchi Classic) | Points |
| `death_timer` | `f32` | 12.0 - 72.0 | 24.0 (Tamagotchi Classic) | Hours |

## 5. Benchmark Data
- **Tamagotchi (Classic 1997 Release):**
  - `max_hunger`: 4 hearts (represented internally as 100%)
  - `hunger_decay_rate`: Loses 1 heart every 3 hours.
  - `feed_amount`: 1 heart per meal.
  - `death_timer`: Dies if left empty for 24 hours.
- **Neko Atsume (v1.14.0):**
  - `food_capacity`: 1 bowl (lasts for a specific duration depending on food type).
  - `consumption_rate`: Thrifty Bitz lasts 8 hours, Frisky Bitz lasts 6 hours.
  - `attraction_rate`: Higher quality food attracts rare cats faster.

## 6. Common Variants
1. **Real-Time vs. In-Game Time:** Some games (like Tamagotchi) use real-world time, requiring players to check in constantly. Others (like Stardew Valley) use in-game time, where needs only decay while the player is actively playing.
2. **Multi-Need Systems:** Instead of just hunger, entities might have complex needs like hygiene, social interaction, and sleep (e.g., The Sims).
3. **Passive vs. Active Consumption:** In Neko Atsume, food is placed passively and consumed over time by visiting cats, whereas in Tamagotchi, feeding is an active, targeted action.
4. **Consequence Severity:** Some games feature permadeath (Tamagotchi), while others simply pause progress or have the entity temporarily leave (Neko Atsume).

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_resource_management` (spending resources to buy food), `atom_collection` (collecting different pets to care for), `atom_progression_tree` (pets evolving based on care quality).
- **Incompatible Atoms:** `atom_fast_paced_combat` (constant interruptions for care can disrupt flow), `atom_permadeath_roguelike` (long-term attachment clashes with rapid reset cycles).

## 8. Anti-Patterns
1. **Overly Punishing Decay:** Making the decay rate too fast, forcing the player to check in at unreasonable hours (e.g., waking up at 3 AM to feed a virtual pet), leading to burnout and churn.
2. **Lack of Meaningful Feedback:** Failing to visually or audibly communicate the entity's state, making it difficult for the player to know when care is needed.
3. **Tedious Repetition:** Making the care action take too long or require too many clicks without any variation or reward, turning a nurturing activity into a chore.
