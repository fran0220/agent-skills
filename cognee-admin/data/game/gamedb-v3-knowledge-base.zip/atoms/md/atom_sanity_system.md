# Identity
- **Atom ID**: atom_sanity_system
- **English Name**: Sanity System
- **Chinese Name**: 理智系统
- **Category**: E
- **Definition**: A secondary health-like resource that depletes under stressful or terrifying conditions, causing negative gameplay effects, hallucinations, or death when it reaches zero.

# Core Verb & State Machine
- **Core Verb**: Manage sanity (avoiding darkness/monsters, seeking light/comfort).
- **State Diagram**:
  - `Normal` -> `Stressed` (Sanity < 75%)
  - `Stressed` -> `Afflicted` (Sanity < 50%)
  - `Afflicted` -> `Insane` (Sanity < 25%)
  - `Insane` -> `Dead/Broken` (Sanity = 0)
  - `Insane` -> `Afflicted` (Sanity restored > 25%)
  - `Afflicted` -> `Stressed` (Sanity restored > 50%)
  - `Stressed` -> `Normal` (Sanity restored > 75%)

# MDA Analysis
- **Mechanics**: The system tracks a numerical value representing the character's mental health. It decreases when exposed to darkness, monsters, or specific events, and increases when resting, staying in light, or consuming specific items.
- **Dynamics**: Players must balance physical health and mental health, often taking risks to preserve sanity or sacrificing sanity for material gain. It creates a tension between exploration and safety.
- **Aesthetics**: Induces feelings of dread, paranoia, tension, and vulnerability in the player.

# Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value | Unit |
|---|---|---|---|---|
| `max_sanity` | f32 | 100.0 - 200.0 | 200.0 (Don't Starve v1.0) | points |
| `drain_rate_darkness` | f32 | 0.1 - 5.0 | 1.0 (Amnesia v1.0) | points/sec |
| `drain_rate_monster` | f32 | 1.0 - 20.0 | 10.0 (Darkest Dungeon v1.0) | points/encounter |
| `restore_rate_light` | f32 | 0.1 - 5.0 | 0.5 (Don't Starve v1.0) | points/sec |
| `hallucination_threshold` | f32 | 0.0 - 50.0 | 30.0 (Don't Starve v1.0) | points |

# Benchmark Data
- **Don't Starve (v1.0)**: `max_sanity` = 200.0, `restore_rate_light` = 0.5, `hallucination_threshold` = 30.0
- **Amnesia: The Dark Descent (v1.0)**: `max_sanity` = 100.0, `drain_rate_darkness` = 1.0
- **Darkest Dungeon (v1.0)**: `max_sanity` = 200.0, `drain_rate_monster` = 10.0 (Stress)

# Common Variants
1. **Stress System (Darkest Dungeon)**: Sanity is inverted as "Stress" which builds up from 0 to 200. Reaching 100 causes an affliction or virtue, reaching 200 causes a heart attack.
2. **Insight System (Bloodborne)**: Gaining insight (sanity loss equivalent) reveals hidden horrors in the world and reduces frenzy resistance.
3. **Phobia System**: Specific triggers cause rapid sanity drain rather than a constant environmental drain.

# Compatibility Notes
- **Compatible Atoms**: `atom_health_system`, `atom_light_mechanic`, `atom_stealth_system`, `atom_consumable_items`.
- **Incompatible Atoms**: `atom_auto_regen_health` (can undermine the tension of sanity management).

# Anti-Patterns
1. **Unavoidable Drain**: Making sanity drain too fast with no reliable way to restore it, leading to frustrating death spirals.
2. **Annoying Hallucinations**: Visual or auditory hallucinations that obscure the screen too much or become repetitive rather than scary.
3. **Irrelevant Sanity**: Providing too many sanity-restoring items, making the system a trivial nuisance rather than a core mechanic.
