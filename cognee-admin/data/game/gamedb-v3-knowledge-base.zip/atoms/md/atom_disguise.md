# Disguise System (伪装系统)

## 1. Identity
**Atom ID:** atom_disguise
**English Name:** Disguise System
**Chinese Name:** 伪装系统
**Category:** A+B (Stealth & Social Engineering)
**Definition:** The Disguise System is a core gameplay mechanic that allows the player character to assume the visual identity of an NPC or a specific faction member. By donning specific clothing, uniforms, or using advanced technology, the player can bypass security checkpoints, avoid immediate hostile detection, and access restricted areas. This system fundamentally alters the rules of engagement, shifting the focus from physical concealment to social stealth and behavioral conformity.

## 2. Core Verb & State Machine
**Primary Player Verb:** Impersonate (伪装)

**State Diagram:**
[Unconcealed] --(Equip Disguise)--> [Disguised]
[Disguised] --(Enter Restricted Area)--> [Trespassing (Disguised)]
[Disguised] --(Perform Suspicious Action)--> [Suspicious]
[Suspicious] --(Observed by Enforcer)--> [Compromised]
[Compromised] --(Break Line of Sight & Change Disguise)--> [Disguised]
[Compromised] --(Combat Initiated)--> [Hunted]

**States:**
- **Unconcealed:** The player is in their default attire, subject to standard detection rules.
- **Disguised:** The player is wearing a disguise, granting access to specific areas and reducing detection speed from standard NPCs.
- **Trespassing (Disguised):** The player is in an area where their current disguise is not permitted, but they may not be immediately recognized as a threat unless scrutinized.
- **Suspicious:** The player is performing actions that do not align with their disguise (e.g., a chef carrying a sniper rifle), causing NPCs to investigate.
- **Compromised:** The disguise is blown. Enemies recognize the player as a threat and will initiate combat or raise an alarm.
- **Hunted:** Active combat or search phase where the current disguise is permanently burned for the involved faction.

**Transitions:**
- **Equip Disguise:** Player interacts with a clothing item or incapacitated NPC.
- **Enter Restricted Area:** Player crosses a spatial boundary with specific access permissions.
- **Perform Suspicious Action:** Player executes a verb tagged as "illegal" or "suspicious" for the current disguise.
- **Observed by Enforcer:** An NPC with the "Enforcer" tag (someone who knows everyone in their unit) maintains line of sight on the player for a specific duration.
- **Break Line of Sight & Change Disguise:** Player escapes visual contact and equips a new, uncompromised disguise.

## 3. MDA Analysis
**Mechanics:** The system evaluates the player's current outfit against the access privileges of the current zone and the perception capabilities of nearby NPCs. It calculates a "suspicion meter" based on distance, line of sight, NPC type (standard vs. enforcer), and player actions.
**Dynamics:** Players are encouraged to explore the environment to find optimal disguises, often requiring them to isolate and incapacitate specific NPCs. This creates a puzzle-like approach to navigation, where players must constantly evaluate their surroundings, avoid enforcers, and manage their behavior to maintain the illusion.
**Aesthetics:** The system evokes feelings of tension, thrill, and intellectual satisfaction. Players experience the "hiding in plain sight" fantasy, enjoying the suspense of walking past heavily armed guards while disguised as a harmless janitor.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Hitman 3 v3.170) | Unit |
| :--- | :--- | :--- | :--- | :--- |
| `detection_time_base` | f32 | 1.0 - 5.0 | 2.5 | seconds |
| `enforcer_fov` | f32 | 60.0 - 120.0 | 90.0 | degrees |
| `suspicion_decay_rate` | f32 | 0.1 - 1.0 | 0.5 | meter/second |
| `disguise_equip_time` | f32 | 0.5 - 3.0 | 1.5 | seconds |
| `movement_penalty` | f32 | 0.0 - 0.5 | 0.0 | multiplier |
| `is_compromised` | bool | true/false | false | boolean |

## 5. Benchmark Data
- **Hitman 3 (v3.170):**
  - `detection_time_base`: 2.5 seconds (varies by difficulty).
  - `enforcer_fov`: 90.0 degrees.
  - `disguise_equip_time`: 1.5 seconds.
- **Assassin's Creed Valhalla (v1.7.0):**
  - `detection_time_base`: 3.0 seconds (Cloak active).
  - `movement_penalty`: 0.3 (Slower walking speed when blending).
  - `suspicion_decay_rate`: 0.8 meter/second.

## 6. Common Variants
1. **Social Blending:** Instead of changing clothes, the player mimics NPC animations (e.g., sitting on a bench, sweeping the floor) to become invisible to guards (Assassin's Creed series).
2. **Holographic/Tech Disguise:** The player uses a gadget to project a holographic image of an enemy, which may consume energy or have a strict time limit (Team Fortress 2 Spy).
3. **Faction Armor:** Wearing specific faction armor makes that faction friendly but makes rival factions instantly hostile (Fallout: New Vegas).
4. **Procedural Suspicion:** The disguise is imperfect, and suspicion constantly builds up while in the line of sight of any enemy, requiring the player to keep moving (Deathloop).

## 7. Compatibility Notes
**Compatible Atoms:**
- `atom_stealth_takedown`: Essential for acquiring disguises from NPCs without raising alarms.
- `atom_distraction`: Useful for luring enforcers away from patrol routes to safely pass while disguised.
- `atom_restricted_zones`: Provides the spatial framework that gives disguises their value.

**Incompatible Atoms:**
- `atom_auto_aggro`: Systems where enemies instantly attack on sight regardless of context completely negate the purpose of a disguise system.
- `atom_unrestricted_movement`: If the player can freely access all areas without penalty, disguises lose their mechanical utility.

## 8. Anti-Patterns
1. **The Omniscient Guard:** NPCs instantly recognize the player through a disguise from across the map without any logical reason or build-up of suspicion, leading to frustration.
2. **Useless Wardrobe:** Providing numerous disguises that offer no distinct gameplay advantages or access privileges, turning the system into a purely cosmetic feature.
3. **Inconsistent Rules:** Actions that are considered "suspicious" are not clearly communicated to the player, resulting in unpredictable and unfair compromises of the disguise.
