# Identity
- **Atom ID**: atom_pet_evolution
- **English Name**: Pet Growth / Evolution
- **Chinese Name**: 宠物成长/进化
- **Category**: G
- **Definition**: A system where a companion entity (pet) progresses through distinct life stages or power levels based on time, care, or experience, unlocking new abilities or changing forms.

# Core Verb & State Machine
- **Core Verb**: Nurture / Train
- **State Diagram**:
  Egg -> Baby -> Child -> Adult -> (Optional) Evolution / Mega Evolution
- **States**:
  - `Egg`: Incubation phase, requires time or steps.
  - `Baby`: High dependency, requires frequent feeding/care.
  - `Child`: Developing phase, can participate in basic activities.
  - `Adult`: Fully developed, capable of all activities.
  - `Evolved`: Enhanced form with specialized abilities.
- **Transitions**:
  - `Egg` -> `Baby`: Hatching (Trigger: Time elapsed or steps taken)
  - `Baby` -> `Child`: Growth (Trigger: Care threshold met, time elapsed)
  - `Child` -> `Adult`: Maturation (Trigger: Experience points, specific items)
  - `Adult` -> `Evolved`: Evolution (Trigger: Evolution stone, level threshold, specific conditions)

# MDA Analysis
- **Mechanics**: Players invest resources (time, food, experience) into a pet entity. The system tracks these inputs and triggers state changes (growth/evolution) when thresholds are met.
- **Dynamics**: Players optimize their resource allocation to achieve desired evolutionary paths. They may trade off short-term gains for long-term pet development.
- **Aesthetics**: Nurturing, Discovery, Fellowship, Expression. Players feel a bond with their pet and a sense of accomplishment when it evolves.

# Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value (Pokemon Red) | Unit |
|---|---|---|---|---|
| `hatch_steps` | u32 | 1000 - 10000 | 5120 | steps |
| `exp_to_level` | u32 | 10 - 1000000 | 1000000 | exp |
| `evolution_level` | u32 | 10 - 50 | 16 | level |
| `hunger_decay_rate` | f32 | 0.1 - 10.0 | 1.0 (Tamagotchi) | points/hour |
| `happiness_threshold` | u32 | 0 - 255 | 220 | points |

# Benchmark Data
- **Pokemon Red/Blue (v1.0)**:
  - `evolution_level` for Bulbasaur -> Ivysaur: 16
  - `exp_to_level` (Medium Slow group to level 100): 1,059,860
- **Tamagotchi (Original 1996)**:
  - `hunger_decay_rate`: 1 heart per hour
  - `growth_time_baby_to_child`: 1 hour

# Common Variants
1. **Branching Evolution**: The pet can evolve into different forms based on stats or items (e.g., Eevee in Pokemon).
2. **Rebirth/Reincarnation**: The pet reaches a maximum age/level and resets to an egg with bonus base stats (e.g., Digimon World).
3. **Fusion Evolution**: Combining two or more pets to create a stronger one (e.g., Persona fusion, though slightly different, applies to monster catching).
4. **Temporary Evolution**: The pet evolves only during combat and reverts afterward (e.g., Mega Evolution in Pokemon).

# Compatibility Notes
- **Commonly Pairs With**: `atom_combat_turn_based`, `atom_resource_management`, `atom_exploration`.
- **Conflicts**: `atom_permadeath` (can cause extreme frustration if a long-nurtured pet dies permanently, though some games like Tamagotchi use it as a core loop).

# Anti-Patterns
1. **Opaque Evolution Conditions**: Making the requirements for a specific evolution so obscure that players must use a guide.
2. **Tedious Maintenance**: Requiring too frequent care (e.g., feeding every 5 minutes) which turns gameplay into a chore.
3. **Power Creep Invalidation**: Early game pets becoming completely useless in the late game, invalidating the player's emotional investment.
