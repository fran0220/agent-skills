# Atom: Grid Inventory (Tetris)

## 1. Identity
- **Atom ID**: atom_inventory_grid
- **English Name**: Grid Inventory (Tetris)
- **Chinese Name**: 网格背包(俄罗斯方块式)
- **Category**: C
- **Definition**: A spatial inventory system where items occupy a specific number of grid cells in various shapes (often Tetris-like), requiring players to manage space efficiently by rotating and arranging items within a limited grid.

## 2. Core Verb & State Machine
- **Core Verb**: Arrange / Manage Space
- **State Diagram**:
  [Empty] -> (Pick up item) -> [Holding Item]
  [Holding Item] -> (Rotate) -> [Holding Item (Rotated)]
  [Holding Item] -> (Place in valid grid) -> [Item Placed]
  [Item Placed] -> (Remove) -> [Holding Item]
  [Holding Item] -> (Drop/Discard) -> [Empty]
- **States**: Empty, Holding Item, Item Placed
- **Transitions**:
  - Empty -> Holding Item: Player selects an item from the world or another container.
  - Holding Item -> Holding Item (Rotated): Player presses the rotate key.
  - Holding Item -> Item Placed: Player clicks on a valid, unobstructed set of grid cells.
  - Item Placed -> Holding Item: Player clicks on an already placed item.
  - Holding Item -> Empty: Player discards the item or places it in another container.

## 3. MDA Analysis
- **Mechanics**: The inventory is a 2D grid of cells (e.g., 10x40). Items have specific dimensions (e.g., 1x1, 2x2, 1x3) and shapes. The system checks for overlaps and out-of-bounds placement.
- **Dynamics**: Players spend time organizing their inventory to maximize space, prioritizing high-value or essential items, and making trade-offs between keeping an item and freeing up space.
- **Aesthetics**: Satisfaction from a perfectly organized inventory (the "Tetris effect"), tension when space is limited and tough choices must be made, and a sense of ownership over the collected items.

## 4. Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value (Game/Version) | Unit |
|---|---|---|---|---|
| grid_width | u32 | 5 - 20 | 10 (Escape from Tarkov v0.13) | cells |
| grid_height | u32 | 5 - 100 | 45 (Escape from Tarkov v0.13) | cells |
| item_width | u32 | 1 - 5 | 2 (Resident Evil 4 Remake) | cells |
| item_height | u32 | 1 - 5 | 3 (Resident Evil 4 Remake) | cells |
| can_rotate | bool | true/false | true (Resident Evil 4 Remake) | boolean |
| auto_sort | bool | true/false | true (Resident Evil 4 Remake) | boolean |

## 5. Benchmark Data
- **Escape from Tarkov (v0.13)**: Standard stash size is 10x28 (280 cells), expandable to 10x68 (680 cells). Items range from 1x1 (bullets) to 2x5 (large weapons). Rotation is allowed.
- **Resident Evil 4 Remake (v1.0)**: Attache case starts at 7x10 (70 cells), expandable to 9x13 (117 cells). Weapons take up significant space (e.g., Shotgun is 2x8). Rotation is allowed. Auto-sort feature is available.
- **Diablo II: Resurrected (v1.0)**: Inventory is 10x4 (40 cells). Items range from 1x1 (gems) to 2x4 (polearms). Rotation is NOT allowed.

## 6. Common Variants
- **Weight-Limited Grid**: In addition to spatial constraints, items have weight, and the total weight cannot exceed a limit (e.g., Escape from Tarkov).
- **Non-Rotatable Grid**: Items have fixed orientations and cannot be rotated to fit (e.g., Diablo II).
- **Multi-Container Grid**: Players have multiple separate grids (e.g., pockets, backpack, tactical rig) instead of one large grid (e.g., Escape from Tarkov).
- **Auto-Sorting Grid**: A button automatically rearranges items to maximize contiguous free space (e.g., Resident Evil 4 Remake).

## 7. Compatibility Notes
- **Compatible Atoms**: atom_item_weight, atom_equipment_slots, atom_loot_generation
- **Incompatible Atoms**: atom_infinite_inventory, atom_slot_based_inventory

## 8. Anti-Patterns
- **Overly Complex Shapes**: Using non-rectangular shapes (e.g., L-shapes or T-shapes) can make inventory management frustrating rather than satisfying.
- **Insufficient Starting Space**: Giving the player too little space early on can halt gameplay flow and force tedious micro-management before they are invested.
- **Lack of Sorting Tools**: In very large grids, not providing an auto-sort or filter function can lead to extreme player fatigue.
