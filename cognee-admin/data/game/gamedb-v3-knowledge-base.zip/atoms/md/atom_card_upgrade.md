# Gameplay Atom: Card Upgrade (atom_card_upgrade)

## 1. Identity
**Atom ID:** atom_card_upgrade
**English Name:** Card Upgrade
**Chinese Name:** 卡牌升级
**Category:** C (Progression/Enhancement)
**Definition:** The Card Upgrade atom represents a mechanic where a player can permanently or temporarily enhance the properties, effects, or cost of a specific card in their deck. This process typically requires a resource (such as gold, experience, or a specific location like a campfire) and results in a strictly better or functionally altered version of the original card, thereby increasing the overall power level and efficiency of the player's deck.

## 2. Core Verb & State Machine
**Core Verb:** Upgrade (Enhance, Forge, Smith)

**State Diagram:**
[Unupgraded Card] --(Trigger Upgrade Event)--> [Pending Upgrade Selection]
[Pending Upgrade Selection] --(Select Card & Pay Cost)--> [Upgraded Card]
[Upgraded Card] --(Optional: Further Upgrade if supported)--> [Multi-Upgraded Card]

**States and Transitions:**
- **State: Unupgraded Card:** The base state of a card when acquired.
- **State: Pending Upgrade Selection:** The state when the player is at an upgrade node (e.g., Campfire) or using an upgrade resource, choosing which card to enhance.
- **State: Upgraded Card:** The enhanced state of the card, usually denoted by a "+" or a visual change.
- **Transition 1:** Unupgraded Card -> Pending Upgrade Selection (Trigger: Player enters an upgrade interface).
- **Transition 2:** Pending Upgrade Selection -> Upgraded Card (Trigger: Player confirms the selection and pays any associated costs).

## 3. MDA Analysis
**Mechanics:** The system allows the player to select a card from their current deck and replace it with a predefined upgraded version. The upgrade may increase damage, increase block, reduce energy cost, add new keywords (e.g., Retain, Innate), or remove negative traits (e.g., Exhaust). The system tracks the upgrade status of each card instance.
**Dynamics:** Players must evaluate the opportunity cost of upgrading versus other actions (e.g., resting for health, removing a card). This creates a dynamic where players prioritize upgrading key scaling cards or defensive tools early in a run to snowball their advantage. It also encourages deck thinning to draw the upgraded cards more frequently.
**Aesthetics:** The player experiences a sense of progression, empowerment, and strategic satisfaction. Successfully upgrading a pivotal card provides a feeling of optimization and mastery over the game's challenges.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Slay the Spire v2.3) | Unit |
| :--- | :--- | :--- | :--- | :--- |
| `upgrade_cost_reduction` | Integer | 0 to 1 | 1 (e.g., Bloodletting) | Energy |
| `damage_increase_flat` | Integer | 2 to 5 | 3 (e.g., Strike) | HP |
| `block_increase_flat` | Integer | 2 to 5 | 3 (e.g., Defend) | HP |
| `magic_number_increase` | Integer | 1 to 3 | 1 (e.g., Spot Weakness) | Stacks/Turns |
| `max_upgrades_per_card` | Integer | 1 to infinite | 1 (Standard) | Count |

## 5. Benchmark Data
- **Slay the Spire (v2.3):**
  - Most cards can only be upgraded once (denoted by "+").
  - Upgrading a basic Strike increases damage from 6 to 9.
  - Upgrading a basic Defend increases block from 5 to 8.
  - Searing Blow is a unique exception, allowing infinite upgrades (damage scales quadratically).
- **Monster Train (v1.2):**
  - Cards can typically be upgraded twice using spell/unit upgrades at merchant nodes.
  - Upgrades are modular (e.g., +10 Magic Power, Cost -1, Gain Consume) rather than predefined fixed versions of the card.
  - Cost: Varies by upgrade type (e.g., 20 to 50 gold).

## 6. Common Variants
1. **Modular Upgrades:** Instead of a fixed "Card+", players slot specific gems or runes into a card to customize its enhancement (e.g., Monster Train).
2. **Temporary Upgrades:** Cards are upgraded only for the duration of the current combat (e.g., Armaments in Slay the Spire).
3. **Branching Upgrades:** Players choose between two different upgrade paths for a single card, altering its function significantly (e.g., Griftlands).
4. **Infinite Scaling Upgrades:** A specific card can be upgraded indefinitely, becoming a central win condition (e.g., Searing Blow in Slay the Spire).
5. **Conditional Upgrades:** Cards upgrade automatically when a specific condition is met during combat or a run (e.g., completing a quest).

## 7. Compatibility Notes
- **Compatible Atoms:**
  - `atom_deck_building`: Core synergy; upgrading improves the deck's average card quality.
  - `atom_card_removal`: Highly synergistic; removing bad cards increases the draw rate of upgraded cards.
  - `atom_resource_management`: Upgrades often cost resources (gold, campfires), tying into the economy.
- **Incompatible/Conflict Atoms:**
  - `atom_fixed_deck`: If the deck cannot be altered in any way, permanent upgrades are impossible.
  - `atom_pure_rng_output`: If card effects are entirely random, the value of an upgrade is obscured or nullified.

## 8. Anti-Patterns
1. **Insignificant Upgrades:** Making the upgrade effect too small (e.g., +1 damage on a 20-damage card), making the mechanic feel unrewarding and not worth the opportunity cost.
2. **Mandatory Upgrades:** Designing encounters such that specific card upgrades are strictly required to progress, removing player agency and strategic choice.
3. **Overly Complex Modular Upgrades:** Providing too many granular upgrade options that overwhelm the player and slow down the pacing of the game without adding meaningful depth.
