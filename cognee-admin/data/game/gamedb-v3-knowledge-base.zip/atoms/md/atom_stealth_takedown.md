# atom_stealth_takedown (Stealth Takedown / 潜行处决)

## 1. Identity
- **Atom ID**: atom_stealth_takedown
- **English Name**: Stealth Takedown
- **Chinese Name**: 潜行处决
- **Category**: A
- **Definition**: A gameplay mechanic where a player character instantly incapacitates or eliminates an unaware enemy from close range, typically rewarding stealthy approaches and positioning.

## 2. Core Verb & State Machine
- **Core Verb**: Takedown (Execute)
- **State Diagram**:
  [Idle] -> (Enemy Unaware & In Range) -> [Prompt Available]
  [Prompt Available] -> (Player Input) -> [Execution Animation]
  [Execution Animation] -> (Animation Complete) -> [Enemy Incapacitated]
  [Prompt Available] -> (Enemy Becomes Aware / Out of Range) -> [Idle]

## 3. MDA Analysis
- **Mechanics**: The system checks the distance between the player and the enemy, the enemy's awareness state (e.g., field of vision, alert level), and the player's relative position (e.g., behind, above). If conditions are met, a prompt is displayed. Upon input, an uninterruptible or semi-interruptible animation plays, resulting in the enemy's death or unconsciousness.
- **Dynamics**: Players are incentivized to navigate the environment carefully, utilizing cover, shadows, and verticality to isolate enemies. It creates a rhythm of observation, approach, and execution.
- **Aesthetics**: Evokes feelings of empowerment, tension, and satisfaction. The player feels like a silent predator, rewarded for patience and tactical planning.

## 4. Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value (Game) | Unit |
|---|---|---|---|---|
| `takedown_range` | f32 | 1.0 - 3.0 | 1.5 (Assassin's Creed Mirage) | meters |
| `angle_tolerance` | f32 | 45.0 - 180.0 | 90.0 (Hitman 3) | degrees |
| `animation_duration` | f32 | 1.0 - 4.0 | 2.5 (MGSV: TPP) | seconds |
| `noise_radius` | f32 | 0.0 - 10.0 | 2.0 (Hitman 3) | meters |
| `requires_weapon` | bool | true/false | true (Assassin's Creed Mirage) | boolean |

## 5. Benchmark Data
- **Assassin's Creed Mirage (v1.0.4)**: `takedown_range` = 1.5m, `angle_tolerance` = 120.0 degrees, `requires_weapon` = true (Hidden Blade).
- **Hitman 3 (v3.170)**: `takedown_range` = 1.2m, `angle_tolerance` = 90.0 degrees, `noise_radius` = 2.0m (Subdue).
- **Metal Gear Solid V: The Phantom Pain (v1.15)**: `takedown_range` = 2.0m, `animation_duration` = 2.5s (CQC Chokehold).

## 6. Common Variants
1. **Lethal vs. Non-Lethal**: Takedowns that kill the enemy versus those that merely knock them out (e.g., Hitman's subdue vs. neck snap).
2. **Aerial Takedown**: Executed from above the enemy, often with a larger trigger range (e.g., Batman: Arkham series, Assassin's Creed).
3. **Cover Takedown**: Executed while the player is in cover and the enemy walks past (e.g., Splinter Cell, Deus Ex).
4. **Chain Takedown**: Allows the player to immediately target another nearby enemy after a successful takedown (e.g., Far Cry series).

## 7. Compatibility Notes
- **Compatible Atoms**: `atom_crouch`, `atom_cover_system`, `atom_enemy_vision_cone`, `atom_distraction_throw`.
- **Incompatible Atoms**: `atom_loud_footsteps` (conflicts with the stealth requirement), `atom_auto_fire` (breaks stealth state).

## 8. Anti-Patterns
1. **Overly Generous Range**: Making the takedown range too large can make the game feel unrealistic and remove the challenge of closing the distance.
2. **Uninterruptible Long Animations in Open Areas**: Locking the player in a long animation where they can be easily spotted and shot by other enemies without any way to cancel.
3. **Inconsistent Awareness Checks**: Enemies detecting the player mid-takedown due to slight camera angle changes, leading to frustrating failures.
