# Gameplay Atom: Tower Placement

## 1. Identity
- **Atom ID:** `atom_tower_placement`
- **English Name:** Tower Placement
- **Chinese Name:** 塔防放置
- **Category:** G/H (Gameplay/Heuristics)
- **Definition:** The core action of selecting a defensive structure (tower) and positioning it on a valid grid or node within the game world to automatically engage incoming enemy units. This atom forms the foundational strategic layer of tower defense games, dictating resource allocation, spatial control, and defensive synergy.

## 2. Core Verb & State Machine
- **Core Verb:** Place (Tower)

**State Diagram:**
[Idle] --> (Select Tower) --> [Previewing]
[Previewing] --> (Cancel) --> [Idle]
[Previewing] --> (Confirm Valid Position) --> [Placing]
[Placing] --> (Construction Complete) --> [Active]
[Active] --> (Sell/Destroy) --> [Idle]

**States and Transitions:**
- **Idle:** The default state where the player is observing the battlefield.
- **Previewing:** The player has selected a tower type and is moving the cursor/finger to find a valid placement spot. The UI typically shows the tower's range and whether the current spot is valid (green) or invalid (red).
- **Placing:** The player has confirmed the placement. Resources are deducted, and the tower begins its construction phase (if applicable).
- **Active:** The tower is fully built and operational, engaging enemies within its range.
- **Transitions:**
  - *Select Tower:* Player chooses a tower from the UI.
  - *Cancel:* Player deselects the tower before placing.
  - *Confirm Valid Position:* Player clicks/taps on a valid grid/node.
  - *Construction Complete:* The build timer finishes.
  - *Sell/Destroy:* Player removes the tower to regain resources or clear space.

## 3. MDA Analysis
- **Mechanics:** The system defines valid placement areas (grids, paths, or specific nodes), calculates resource costs, checks for collision with other objects, and instantiates the tower entity upon confirmation. It also manages the tower's footprint and attack range visualization during the preview state.
- **Dynamics:** Players must balance their limited resources against the spatial constraints of the map. They create choke points, maximize overlapping fields of fire, and adapt their placement strategy based on enemy pathing and wave composition. The spatial puzzle of fitting different tower footprints optimally emerges.
- **Aesthetics:** The player experiences a sense of strategic mastery, anticipation, and satisfaction as their carefully planned defenses successfully repel waves of enemies. There is also a feeling of tension when resources are tight and optimal placement is crucial for survival.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Game) | Unit |
|---|---|---|---|---|
| `cost` | `u32` | 50 - 500 | 100 (Bloons TD 6 v38.0) | Gold/Money |
| `footprint_radius` | `f32` | 1.0 - 3.0 | 1.0 (Kingdom Rush v1.0) | Grid Cells/Meters |
| `attack_range` | `f32` | 3.0 - 15.0 | 5.0 (Kingdom Rush v1.0) | Grid Cells/Meters |
| `build_time` | `f32` | 0.0 - 10.0 | 0.0 (Bloons TD 6 v38.0) | Seconds |
| `refund_rate` | `f32` | 0.5 - 1.0 | 0.7 (Bloons TD 6 v38.0) | Multiplier |

## 5. Benchmark Data
- **Bloons TD 6 (v38.0):**
  - Dart Monkey: `cost` = 200, `footprint_radius` = 1.0 (approx), `attack_range` = 32.0 (in-game units), `build_time` = 0.0s, `refund_rate` = 0.7.
- **Kingdom Rush (v1.0):**
  - Archer Tower: `cost` = 70, `footprint_radius` = 1.0 (fixed node), `attack_range` = 5.0 (approx grid units), `build_time` = 0.0s, `refund_rate` = 0.6.

## 6. Common Variants
1. **Node-Based Placement:** Towers can only be placed on pre-defined, fixed spots on the map (e.g., Kingdom Rush). Limits freedom but tightens level design.
2. **Grid-Based Free Placement:** Towers can be placed anywhere on a grid as long as it doesn't block the enemy path completely (e.g., Desktop Tower Defense). Allows mazing.
3. **Path-Adjacent Placement:** Towers must be placed immediately next to the enemy path (e.g., Anomaly: Warzone Earth).
4. **Tetromino Footprints:** Towers have complex shapes (like Tetris blocks) that must be fitted together (e.g., some puzzle-hybrid TDs).

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_enemy_pathing` (Enemy Pathing), `atom_resource_generation` (Resource Generation), `atom_tower_upgrade` (Tower Upgrade), `atom_damage_calculation` (Damage Calculation).
- **Incompatible Atoms:** `atom_free_movement` (Free Movement - usually conflicts with static tower defense unless it's a hybrid action-TD), `atom_physics_ragdoll` (often too performance-heavy for games with hundreds of entities).

## 8. Anti-Patterns
1. **Pixel-Hunting Placement:** Requiring overly precise placement without snapping to a grid or nodes, causing frustration when a tower *almost* fits but doesn't.
2. **Unclear Range Visualization:** Failing to accurately show the tower's attack range during the preview phase, leading to sub-optimal placements and player regret.
3. **Irreversible Mistakes:** Not providing a sell or undo option, punishing players too harshly for accidental misclicks during placement.
