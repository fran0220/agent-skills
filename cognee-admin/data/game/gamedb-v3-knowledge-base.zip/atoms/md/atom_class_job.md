# Identity
- **Atom ID:** atom_class_job
- **English Name:** Class / Job System
- **Chinese Name:** 职业系统
- **Category:** E
- **Definition:** A system that categorizes player characters into distinct archetypes, each with unique abilities, stat growths, equipment proficiencies, and roles within a group. It provides a structured path for character development and specialization.

# Core Verb & State Machine
- **Core Verb:** Change Class / Specialize
- **State Diagram:**
  [Novice] --> [Base Class]
  [Base Class] --> [Advanced Class A]
  [Base Class] --> [Advanced Class B]
  [Advanced Class A] --> [Master Class]
- **States:** Unclassed, Base Class, Advanced Class, Master Class
- **Transitions:**
  - Unclassed -> Base Class: Triggered by reaching a specific level or completing a tutorial quest.
  - Base Class -> Advanced Class: Triggered by reaching a level cap and using a specific item or completing a trial.
  - Advanced Class -> Master Class: Triggered by mastering the advanced class and completing an endgame quest.

# MDA Analysis
- **Mechanics:** Defines stat modifiers, available skill trees, equippable gear types, and role-specific mechanics (e.g., aggro generation for tanks).
- **Dynamics:** Encourages players to form balanced parties (tank, healer, DPS), experiment with different class combinations, and optimize gear for specific roles.
- **Aesthetics:** Provides a sense of identity, fantasy fulfillment (e.g., being a powerful wizard or a stealthy rogue), and progression as the character masters their chosen path.

# Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value (Game) | Unit |
|---|---|---|---|---|
| Base HP Multiplier | f32 | 0.8 - 1.5 | 1.2 (WoW v10.0) | Multiplier |
| Base MP Multiplier | f32 | 0.0 - 2.0 | 1.5 (FFXIV v6.0) | Multiplier |
| Stat Growth Rate | f32 | 0.5 - 2.0 | 1.1 (Fire Emblem: Three Houses) | Multiplier |
| Max Level | u32 | 20 - 100 | 90 (FFXIV v6.0) | Levels |
| Skill Points per Level | u32 | 1 - 5 | 1 (WoW v10.0) | Points |

# Benchmark Data
- **World of Warcraft (v10.0):**
  - Base HP Multiplier (Warrior): 1.2
  - Max Level: 70
  - Skill Points per Level: 1
- **Final Fantasy XIV (v6.0):**
  - Base MP Multiplier (Black Mage): 1.5
  - Max Level: 90
- **Fire Emblem: Three Houses (v1.2.0):**
  - Stat Growth Rate (Swordmaster Speed): 1.2
  - Max Level: 99

# Common Variants
1. **Rigid Classes:** Characters are locked into a single class for the entire game (e.g., classic D&D).
2. **Job System:** Characters can freely switch between unlocked classes outside of combat, retaining some abilities (e.g., Final Fantasy V, FFXIV).
3. **Class Trees:** Characters start as a base class and branch into specialized advanced classes (e.g., Fire Emblem, Ragnarok Online).
4. **Sub-classes:** Characters have a primary class and a secondary class, blending their abilities (e.g., Titan Quest, Grim Dawn).

# Compatibility Notes
- **Compatible Atoms:** atom_xp_level, atom_skill_tree, atom_equipment, atom_party_formation
- **Incompatible Atoms:** atom_classless_system

# Anti-Patterns
1. **Illusion of Choice:** Offering multiple classes that ultimately play exactly the same or have identical optimal strategies.
2. **Useless Classes:** Designing a class that is mathematically inferior in all situations, making it a "trap" choice for players.
3. **Over-specialization:** Making a class so niche that it is only useful in a tiny fraction of the game's content, leaving the player frustrated elsewhere.
