# atom_new_game_plus (New Game Plus / 二周目)

## 1. Identity
- **Atom ID:** atom_new_game_plus
- **English Name:** New Game Plus
- **Chinese Name:** 二周目
- **Category:** F (Meta-Progression / Replayability)
- **Definition:** New Game Plus (NG+) is an unlockable game mode available after the player has completed the main campaign at least once. It allows the player to start a new playthrough while retaining certain aspects of their progression from the previous playthrough, such as character levels, equipment, skills, or currency. To maintain a sense of challenge, the game typically scales up the difficulty of enemies, introduces new content, or alters enemy placements. This mechanic significantly extends the game's lifespan and provides a satisfying power fantasy combined with renewed challenges.

## 2. Core Verb & State Machine
- **Core Verb:** Restart (with retained progression)

**State Diagram:**
[First Playthrough] -> (Complete Game) -> [Endgame State] -> (Select NG+) -> [NG+ Playthrough] -> (Complete Game) -> [NG++ Playthrough]

**States:**
- `FirstPlaythrough`: The initial state where the player starts from scratch.
- `Endgame`: The state reached after defeating the final boss or completing the main story.
- `NGPlus`: The state of playing the game again with carried-over progression and increased difficulty.
- `NGPlusPlus`: Subsequent iterations of NG+ with further scaling.

**Transitions:**
- `FirstPlaythrough` -> `Endgame`: Triggered by completing the main story objectives.
- `Endgame` -> `NGPlus`: Triggered by the player selecting the "New Game Plus" option from the menu or a specific in-game interaction.
- `NGPlus` -> `Endgame`: Triggered by completing the main story in NG+.
- `Endgame` -> `NGPlusPlus`: Triggered by selecting NG+ again after completing a previous NG+ cycle.

## 3. MDA Analysis
- **Mechanics:** The system saves specific player data (inventory, stats, unlocked skills) at the end of a playthrough and loads it into a new game state. Simultaneously, it applies a scaling multiplier to enemy health, damage, and sometimes AI behavior. It may also unlock new items, alternative story paths, or hidden bosses that were inaccessible in the first playthrough.
- **Dynamics:** Players experience a shifted power dynamic. Early game areas that were initially challenging become trivialized by late-game gear, creating a strong power fantasy. However, as the NG+ scaling catches up, the challenge returns, often requiring players to optimize their builds and utilize advanced mechanics they might have ignored previously. Players also engage in "completionist" behaviors, hunting for missed items or alternative endings.
- **Aesthetics:** The primary aesthetics are **Challenge** (overcoming harder obstacles), **Expression** (experimenting with complete builds from the start), and **Discovery** (finding new content exclusive to NG+). It evokes feelings of mastery, nostalgia (revisiting early areas), and satisfaction from seeing the tangible results of previous efforts.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Dark Souls Remastered v1.03) | Unit |
|---|---|---|---|---|
| `enemy_health_multiplier` | f32 | 1.1 - 3.0 | 1.41 | Multiplier |
| `enemy_damage_multiplier` | f32 | 1.1 - 3.0 | 1.41 | Multiplier |
| `soul_drop_multiplier` | f32 | 1.5 - 5.0 | 3.0 | Multiplier |
| `max_ng_cycles` | u32 | 1 - 99 | 7 | Cycles |
| `retain_inventory` | bool | true/false | true | Boolean |
| `retain_key_items` | bool | true/false | false | Boolean |
| `retain_levels` | bool | true/false | true | Boolean |

## 5. Benchmark Data
- **Dark Souls Remastered (v1.03):**
  - `enemy_health_multiplier`: 1.41 (NG+1), scales up to ~2.5 by NG+6.
  - `enemy_damage_multiplier`: 1.41 (NG+1), scales up to ~2.5 by NG+6.
  - `soul_drop_multiplier`: 3.0 (NG+1), scales up to ~5.0 by NG+6.
  - `max_ng_cycles`: 7 (Difficulty stops scaling after NG+6, but cycles can continue).
- **Chrono Trigger (SNES v1.0):**
  - `enemy_health_multiplier`: 1.0 (No scaling, enemies remain the same).
  - `enemy_damage_multiplier`: 1.0.
  - `retain_inventory`: true.
  - `retain_levels`: true.
  - *Note:* The focus is on accessing different endings rather than increased difficulty.
- **Nier: Automata (v1.06):**
  - *Note:* NG+ is integrated into the narrative structure (Route B, Route C). It changes the playable character and perspective rather than just scaling numbers.

## 6. Common Variants
1. **Stat-Scaling NG+:** The most common variant (e.g., Dark Souls). Enemies get flat percentage boosts to health and damage.
2. **Narrative NG+:** The subsequent playthrough reveals new story elements, different perspectives, or true endings (e.g., Nier: Automata, Chrono Trigger).
3. **Remixed NG+:** Enemy placements are changed, new enemy types appear in early areas, and boss attack patterns are altered (e.g., Dark Souls II).
4. **Customizable NG+:** Players can choose exactly what carries over and what modifiers are applied to the new world (e.g., Hades' Pact of Punishment, though technically a roguelite loop, it shares NG+ DNA).
5. **Victory Lap:** No difficulty scaling. The player simply replays the game with all their endgame gear to easily crush early enemies (e.g., Resident Evil series with infinite ammo weapons).

## 7. Compatibility Notes
- **Compatible Atoms:**
  - `atom_multiple_endings`: NG+ is the perfect vehicle for allowing players to see different narrative outcomes without starting from scratch.
  - `atom_skill_tree`: Allows players to max out skill trees that are impossible to complete in a single playthrough.
  - `atom_weapon_upgrades`: Provides the resources and time needed to reach the highest upgrade tiers.
- **Incompatible Atoms:**
  - `atom_permadeath`: True permadeath conflicts with the concept of carrying over progression across completed runs, unless structured as a roguelite meta-progression.
  - `atom_strict_level_scaling`: If enemies always scale perfectly to the player's level, the power fantasy of bringing endgame gear to the early game is lost.

## 8. Anti-Patterns
1. **Bullet Sponge Scaling:** Simply increasing enemy health by 500% without adjusting their mechanics or the player's damage output makes combat tedious rather than challenging.
2. **Meaningless Progression:** If the player has already unlocked everything and reached the level cap in the first playthrough, NG+ offers no mechanical incentive to continue playing.
3. **Forced Key Item Loss:** Stripping the player of movement abilities or crucial tools they earned, forcing them to re-do tedious fetch quests, can cause frustration and abandonment of the NG+ run.
