# Gameplay Atom: Style Meter / Rank

## 1. Identity
- **Atom ID:** atom_style_meter
- **English Name:** Style Meter / Rank
- **Chinese Name:** 风格评分
- **Category:** A
- **Definition:** A dynamic scoring system that evaluates the player's performance in real-time based on variety, efficiency, and avoidance of damage, translating these metrics into a visible rank or grade that decays over time if not maintained.

## 2. Core Verb & State Machine
- **Core Verb:** Perform (varied attacks while avoiding damage)
- **State Diagram:**
  [Idle] --(Attack hits)--> [Active/Building]
  [Active/Building] --(Attack hits, varied)--> [Rank Up]
  [Active/Building] --(Time passes without hits)--> [Decaying]
  [Decaying] --(Attack hits)--> [Active/Building]
  [Decaying] --(Time passes)--> [Rank Down]
  [Active/Building] --(Player takes damage)--> [Rank Drop/Reset]
  [Rank Up] --> [Active/Building]
  [Rank Down] --> [Active/Building]
  [Rank Drop/Reset] --> [Idle]

- **States:**
  - `Idle`: No style points accumulated.
  - `Active/Building`: Style points are increasing due to successful, varied attacks.
  - `Decaying`: Style points are decreasing due to inactivity.
  - `Rank Up`: Transition state when crossing a positive threshold.
  - `Rank Down`: Transition state when crossing a negative threshold.
  - `Rank Drop/Reset`: State when player takes damage, causing a massive loss of points or complete reset.

- **Transitions:**
  - `Idle` -> `Active/Building`: Triggered by landing an attack.
  - `Active/Building` -> `Rank Up`: Triggered by accumulating enough points for the next tier.
  - `Active/Building` -> `Decaying`: Triggered by a timer expiring without landing new attacks.
  - `Decaying` -> `Active/Building`: Triggered by landing an attack before dropping a rank.
  - `Decaying` -> `Rank Down`: Triggered by points dropping below the current tier's threshold.
  - `Active/Building` -> `Rank Drop/Reset`: Triggered by the player taking damage.

## 3. MDA Analysis
- **Mechanics:** The system tracks a hidden numerical value (style points). Different attacks add different amounts of points. Using the same attack repeatedly yields diminishing returns (staling). Taking damage subtracts a large chunk of points or resets the meter. Points decay over time. Crossing specific thresholds changes the visible letter grade (e.g., D, C, B, A, S, SS, SSS).
- **Dynamics:** Players are incentivized to constantly switch up their attacks, use different weapons, and play aggressively to keep the meter from decaying, while simultaneously playing defensively to avoid taking damage and losing their rank.
- **Aesthetics:** Creates a feeling of mastery, flow, and performance. The player feels like a "badass" when maintaining a high rank, accompanied by dynamic music changes and announcer callouts.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Game) | Unit |
|---|---|---|---|---|
| `base_decay_rate` | f32 | 1.0 - 10.0 | 5.0 (DMC5 v1.0) | points/sec |
| `decay_delay` | f32 | 1.0 - 5.0 | 2.5 (Bayonetta v1.0) | seconds |
| `damage_penalty` | f32 | 0.5 - 1.0 | 0.75 (DMC5 v1.0) | multiplier |
| `stale_move_penalty` | f32 | 0.1 - 0.9 | 0.5 (DMC5 v1.0) | multiplier |
| `max_rank_threshold` | u32 | 5000 - 20000 | 10000 (DMC5 v1.0) | points |

## 5. Benchmark Data
- **Devil May Cry 5 (v1.0):**
  - `base_decay_rate`: 5.0 points/sec (scales up at higher ranks)
  - `decay_delay`: 3.0 seconds
  - `damage_penalty`: Drops 2 full ranks (approx 0.5 multiplier of total points)
  - `stale_move_penalty`: 0.5 multiplier after 3 repeated uses
- **Bayonetta (v1.0):**
  - `base_decay_rate`: 0.0 (Combo points don't decay smoothly, the combo just breaks)
  - `decay_delay`: 2.5 seconds (Time before combo drops)
  - `damage_penalty`: Combo breaks entirely (multiplier reset)
  - `stale_move_penalty`: Diminishing point returns for repeated weaves.

## 6. Common Variants
1. **Combo Counter:** Simpler version that only tracks consecutive hits without a decay timer, resetting only on damage or long pauses (e.g., Batman Arkham series).
2. **Tension Gauge:** Meter builds up to allow special moves, but doesn't explicitly grade the player with letters (e.g., Guilty Gear).
3. **Groove Meter:** Focuses on rhythm and timing rather than attack variety (e.g., Hi-Fi Rush).
4. **Carnage/Gore Meter:** Builds up by performing specific brutal executions rather than just varied attacks (e.g., DOOM).

## 7. Compatibility Notes
- **Commonly pairs with:** `atom_combo_system`, `atom_dodge_offset`, `atom_taunt`, `atom_dynamic_music`.
- **Conflicts:** `atom_stealth_kill` (stealth usually discourages prolonged, flashy combat), `atom_resource_starvation` (style meters encourage using all tools, which is hard if resources are scarce).

## 8. Anti-Patterns
1. **Overly Punishing Decay:** If the meter decays too fast, players feel frustrated and stressed rather than motivated to perform.
2. **Lack of Clarity:** If players don't understand *why* their rank isn't going up (e.g., hidden staling mechanics are too aggressive), they will feel cheated.
3. **Optimal but Boring Strategies:** If one specific rotation of 3 moves is mathematically optimal for building style, players will optimize the fun out of the game and ignore the rest of the moveset.
