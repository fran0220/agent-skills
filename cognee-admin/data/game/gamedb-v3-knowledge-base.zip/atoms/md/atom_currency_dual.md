# Identity
- **Atom ID**: atom_currency_dual
- **English Name**: Dual Currency System
- **Chinese Name**: 双货币系统
- **Category**: C
- **Definition**: A game economy structure utilizing two distinct currencies—typically a "soft" currency earned through regular gameplay and a "hard" currency purchased with real money or earned in limited quantities—to balance player progression, monetization, and engagement.

# Core Verb & State Machine
- **Core Verb**: Spend / Earn
- **State Diagram**:
  [Idle] --(Play)--> [Earning Soft Currency]
  [Idle] --(Pay/Achieve)--> [Earning Hard Currency]
  [Earning Soft Currency] --(Accumulate)--> [Soft Wealth]
  [Earning Hard Currency] --(Accumulate)--> [Hard Wealth]
  [Soft Wealth] --(Spend)--> [Basic Upgrades/Items]
  [Hard Wealth] --(Spend)--> [Premium Items/Time Skips/Gacha]
  [Hard Wealth] --(Convert)--> [Soft Wealth]
- **States**: Idle, Earning Soft Currency, Earning Hard Currency, Soft Wealth, Hard Wealth, Basic Upgrades/Items, Premium Items/Time Skips/Gacha
- **Transitions**:
  - Idle -> Earning Soft Currency (Trigger: Play game loop)
  - Idle -> Earning Hard Currency (Trigger: Real money purchase or complete rare achievement)
  - Earning Soft Currency -> Soft Wealth (Trigger: Collect rewards)
  - Earning Hard Currency -> Hard Wealth (Trigger: Collect rewards)
  - Soft Wealth -> Basic Upgrades/Items (Trigger: Purchase basic item)
  - Hard Wealth -> Premium Items/Time Skips/Gacha (Trigger: Purchase premium item)
  - Hard Wealth -> Soft Wealth (Trigger: Currency conversion)

# MDA Analysis
- **Mechanics**: The system tracks two separate integer values for the player. Soft currency is awarded frequently for core loop actions. Hard currency is awarded rarely or purchased via microtransactions. Sinks (places to spend) are divided: basic progression requires soft currency, while premium content, cosmetics, or time-savers require hard currency. Hard currency can often be converted to soft currency, but not vice versa.
- **Dynamics**: Players optimize their time to maximize soft currency earning. When faced with a progression wall, players must decide whether to grind for soft currency or spend hard currency to bypass the wait. The scarcity of hard currency makes players hoard it for high-value purchases (like Gacha pulls).
- **Aesthetics**: Players feel a sense of steady progression through soft currency accumulation. Hard currency provides moments of high excitement (e.g., finally saving enough for a 10-pull) or relief (bypassing a tedious grind). It also creates a sense of value and exclusivity for premium items.

# Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value | Unit |
|---|---|---|---|---|
| soft_currency_earn_rate | f32 | 10.0 - 1000.0 | 100.0 (Genshin Impact v4.0) | units/hour |
| hard_currency_earn_rate | f32 | 0.0 - 50.0 | 10.0 (Genshin Impact v4.0) | units/week |
| hard_to_soft_exchange_rate | f32 | 10.0 - 1000.0 | 100.0 (Clash Royale v5.0) | soft/hard |
| premium_item_cost | u32 | 100 - 3000 | 160 (Genshin Impact v4.0) | hard currency |
| basic_item_cost | u32 | 100 - 100000 | 1000 (Clash Royale v5.0) | soft currency |

# Benchmark Data
- **Genshin Impact (v4.0)**:
  - soft_currency_earn_rate: 10000.0
  - hard_currency_earn_rate: 60.0
  - premium_item_cost: 160
- **Clash Royale (v5.0)**:
  - hard_to_soft_exchange_rate: 16.6
  - basic_item_cost: 1000
  - premium_item_cost: 500

# Common Variants
1. **Triple Currency System**: Adds a third "social" or "event" currency to drive specific behaviors (e.g., friend points).
2. **Energy as Currency**: Soft currency is split into an accumulative currency (Gold) and a regenerative currency (Energy/Stamina) that limits playtime.
3. **Premium-Only Economy**: Very rare, where only hard currency exists, but the game provides a slow drip of it for free players.
4. **Segmented Soft Currencies**: Multiple soft currencies tied to specific game modes (e.g., PvP tokens, Guild coins).

# Compatibility Notes
- **Compatible Atoms**: atom_gacha_system, atom_energy_stamina, atom_battle_pass, atom_daily_quests.
- **Conflicts**: atom_pure_sandbox, atom_single_purchase.

# Anti-Patterns
1. **Hyperinflation**: Soft currency earn rate outpaces sinks, making it worthless and removing the incentive to play the core loop.
2. **Hard Currency Starvation**: Providing zero hard currency to free players, causing them to churn before they convert to paying users.
3. **Pay-to-Win Imbalance**: Allowing hard currency to directly purchase overwhelming competitive advantages in PvP, alienating the free-to-play user base.
