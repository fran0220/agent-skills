# Identity
- **Atom ID**: atom_insurance
- **English Name**: Insurance System
- **Chinese Name**: 保险系统
- **Category**: C
- **Definition**: A system that allows players to pay a premium before a high-risk activity to guarantee the return of specific items or a portion of their value if they fail or die during the activity.

# Core Verb & State Machine
- **Core Verb**: Insure
- **State Diagram**:
  [Uninsured] --(Pay Premium)--> [Insured]
  [Insured] --(Survive/Success)--> [Uninsured] (Insurance expires)
  [Insured] --(Die/Fail)--> [Pending Return]
  [Pending Return] --(Wait Time)--> [Returned]
  [Returned] --(Claim)--> [Uninsured]
  [Returned] --(Expire)--> [Lost]
- **States**: Uninsured, Insured, Pending Return, Returned, Lost
- **Transitions**:
  - Uninsured -> Insured: Triggered by paying premium
  - Insured -> Uninsured: Triggered by successful extraction/survival
  - Insured -> Pending Return: Triggered by death/failure
  - Pending Return -> Returned: Triggered by time elapsed
  - Returned -> Uninsured: Triggered by player claiming items
  - Returned -> Lost: Triggered by claim time expiration

# MDA Analysis
- **Mechanics**: Players select items to insure and pay a fee based on the item's value and the chosen insurer's rates. If the player dies and the items are not extracted by other players, the items are returned after a delay.
- **Dynamics**: Encourages players to bring higher-tier gear into raids by mitigating the risk of total loss. Creates a secondary economy and strategic choices regarding which items are worth insuring.
- **Aesthetics**: Provides a sense of security and relief (mitigating gear fear), anticipation (waiting for returns), and sometimes frustration (if items are looted by others and not returned).

# Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value | Unit |
|---|---|---|---|---|
| premium_rate | f32 | 0.05 - 0.30 | 0.10 (Escape from Tarkov 0.13) | multiplier |
| return_time_min | u32 | 12 - 24 | 12 (Escape from Tarkov 0.13) | hours |
| return_time_max | u32 | 24 - 36 | 24 (Escape from Tarkov 0.13) | hours |
| claim_duration | u32 | 24 - 72 | 72 (Escape from Tarkov 0.13) | hours |
| return_chance | f32 | 0.0 - 1.0 | 1.0 (Escape from Tarkov 0.13) | probability |

# Benchmark Data
- **Escape from Tarkov (0.13)**:
  - Prapor: premium_rate = 0.10, return_time_min = 24, return_time_max = 36, claim_duration = 96
  - Therapist: premium_rate = 0.15, return_time_min = 12, return_time_max = 24, claim_duration = 144

# Common Variants
1. **Partial Value Return**: Instead of returning the exact item, the system returns a percentage of the item's monetary value (e.g., Hunt: Showdown).
2. **Durability Loss**: Returned items suffer a permanent reduction in maximum durability.
3. **Loot Priority**: Insured items are locked and cannot be looted by other players, guaranteeing return.

# Compatibility Notes
- **Compatible Atoms**: atom_inventory_loss, atom_durability, atom_economy, atom_extraction
- **Incompatible Atoms**: atom_permadeath, atom_soulbound

# Anti-Patterns
1. **Over-Insurance**: Making insurance too cheap, completely removing the tension and risk of loss.
2. **Instant Return**: Returning items immediately upon death, which disrupts the economic loop and inventory management.
3. **Unclear Conditions**: Not clearly communicating to the player that items looted by others will not be returned.
