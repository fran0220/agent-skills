# 1. Identity

The **atom_random_affix** gameplay atom, commonly known in English as **Random Affix** or **Roll**, and in Chinese as **随机词缀**, is a fundamental component of many action role-playing games (ARPGs) and loot-driven titles. It falls under the **C** category of gameplay atoms. 

At its core, this atom defines a system where items, equipment, or even entities are generated with a randomized set of modifiers, known as affixes. These affixes are drawn from predefined pools of possible stats, creating significant variance in the power, utility, and overall value of the generated items. This variance is a primary driver of player engagement, as it encourages continuous farming, evaluation, and optimization of equipment to overcome increasingly difficult challenges.

# 2. Core Verb & State Machine

The primary player verb associated with this atom is **Roll** or **Evaluate**. Players are constantly rolling for new items and evaluating the affixes they receive to determine if the item is an upgrade or useful for their specific build.

The state machine for an item with random affixes typically follows this flow:
- `[Unidentified]` -> (Identify) -> `[Identified]`
- `[Identified]` -> (Equip) -> `[Equipped]`
- `[Identified]` -> (Reroll/Modify) -> `[Modified]`
- `[Identified]` -> (Discard/Salvage) -> `[Destroyed]`

Initially, an item may drop in an `[Unidentified]` state, hiding its specific affixes from the player. The player must perform an action to identify the item, transitioning it to the `[Identified]` state. Once identified, the player evaluates the item. If it is desirable, they may transition it to the `[Equipped]` state by wearing it. If the item has potential but needs adjustment, the player might use crafting systems to transition it to a `[Modified]` state, rerolling specific affixes or upgrading its tiers. Finally, if the item is deemed useless, it is transitioned to the `[Destroyed]` state through discarding, selling, or salvaging for base materials.

# 3. MDA Analysis

**Mechanics**: The underlying mechanics of the random affix system involve the game engine assigning random properties to an item upon its generation or identification. These properties are typically divided into prefixes and suffixes, each with specific pools of possible stats (e.g., +Attack Damage, +Maximum Health, +Critical Hit Chance). Furthermore, these stats are often divided into tiers, which dictate the range of possible values the stat can roll. The selection process is frequently weighted, meaning more powerful or desirable affixes have a lower probability of appearing compared to common ones.

**Dynamics**: The mechanics of random affixes create emergent behaviors where players repeatedly engage in specific in-game activities (such as defeating bosses or clearing dungeons) that yield high quantities of items. This pursuit is often referred to as "min-maxing" or chasing the "god roll"—an item with the perfect combination of high-tier affixes. Players develop complex heuristics and utilize external tools to quickly evaluate the worth of an item, making calculated trade-offs between different stats to optimize their character's performance.

**Aesthetics**: The aesthetic experience of the random affix system is deeply rooted in psychology, resembling a slot machine effect. There is a strong sense of **Anticipation** before an item is identified or a boss is defeated. This can culminate in immense **Excitement** and satisfaction when a perfect or near-perfect item is obtained. Conversely, it can lead to **Frustration** when hours of farming yield only poor rolls. Over time, players also experience a sense of **Mastery** as they learn to navigate and understand the complex affix pools, recognizing the subtle differences that make an item valuable.

# 4. Parameter Space

The implementation of a random affix system requires tuning several key parameters to ensure a balanced and engaging experience.

| Parameter Name | Type | Typical Range | Benchmark Value | Unit |
|---|---|---|---|---|
| Affix Count | u32 | 1-6 | 4 (Diablo 3 Rare) | Count |
| Weight | u32 | 1-1000 | 100 | Weight |
| Value Range | f32 | 0.01-1000.0 | 5.0-10.0 (Crit Chance) | % or Flat |
| Tier Count | u32 | 1-10 | 6 (Path of Exile) | Tiers |

# 5. Benchmark Data

To provide concrete examples, we can look at benchmark data from several representative games that heavily utilize the random affix atom.

In **Diablo 3 (v2.7.4)**, Rare (yellow) items typically roll with 4 to 6 random affixes. For example, the Critical Hit Chance affix on gloves can roll a value between 8.0% and 10.0%. The variance is relatively tight, ensuring that even a low roll is somewhat useful, but the pursuit of the perfect 10.0% keeps players engaged.

**Path of Exile (v3.20)** features one of the most complex random affix systems in gaming. Rare items can have up to 3 Prefixes and 3 Suffixes. The affixes are divided into numerous tiers. For instance, a maximum Life roll on a body armour can go up to +109 (Tier 1), while lower tiers offer significantly less. The weighting system in Path of Exile makes finding high-tier, desirable affixes extremely rare.

In **Genshin Impact (v3.5)**, the artifact system relies heavily on random affixes. Artifacts drop with a main stat and 3 to 4 substats. As the artifact is leveled up (every 4 levels), it either gains a new substat or upgrades an existing one. The upgrade value is randomly selected from a set of 4 possible tiers. For example, a Critical Rate upgrade might add 2.7%, 3.1%, 3.5%, or 3.9%. This creates a multi-layered RNG system where players must first find an artifact with good initial substats and then hope the upgrades roll into the desired stats at high values.

# 6. Common Variants

The random affix system has several common variations across different games:

**Fixed Pools with Random Values**: In this variant, the item always drops with the same set of stats, but the specific values of those stats vary. This is common in games like the Borderlands series, where a specific legendary weapon will always have certain behaviors, but its damage, fire rate, and reload speed will fluctuate within a range.

**Progressive Unlocking**: Affixes are not all available immediately but are revealed or added as the item levels up or is upgraded by the player. The Genshin Impact artifact system is a prime example of this, where the full potential of the item is unknown until resources are invested into it.

**Craftable Affixes**: To mitigate the extreme RNG of pure random drops, many games introduce crafting systems that allow players to manipulate affixes. Players might be able to lock certain desirable affixes and reroll the rest, or deterministically add a specific affix to an item with an open slot. The crafting bench in Path of Exile serves this purpose.

**Corrupted/Cursed Affixes**: This variant introduces a risk-reward element. Items can roll with exceptionally powerful positive effects, but these are paired with significant drawbacks or curses. Players must build around these drawbacks to harness the item's full power.

# 7. Compatibility Notes

The random affix atom rarely exists in isolation and is highly compatible with several other systems. It pairs naturally with `atom_loot_drop`, as the excitement of loot drops is amplified by the variance of random affixes. It is also deeply intertwined with `atom_crafting`, providing the base items that players will modify and improve. Furthermore, it necessitates robust `atom_inventory_management`, as players will accumulate vast amounts of items that need to be sorted, evaluated, and stored.

Conversely, this atom is generally incompatible with `atom_fixed_progression` systems, where player power is strictly tied to predetermined milestones or linear upgrades, as the variance introduced by random affixes would disrupt the intended progression curve.

# 8. Anti-Patterns

When designing a random affix system, developers must be wary of several common anti-patterns that can negatively impact the player experience.

**Over-diluted Pools**: Adding too many niche or useless affixes (e.g., "Light Radius" or "+1 to a skill no one uses") to the generation pool makes finding a genuinely good item statistically improbable. This leads to player burnout, as the reward loop feels unachievable.

**Unclear Ranges**: Failing to show the player the possible minimum and maximum values for a specific roll makes it incredibly difficult for them to evaluate if an item is good or bad. Modern ARPGs often include a UI toggle to display these ranges, empowering players to make informed decisions.

**Excessive Variance**: When the difference between a low roll and a high roll is too massive, low rolls feel completely worthless rather than just suboptimal. This can make the majority of loot drops feel like trash, reducing the overall excitement of finding items. The variance should be tuned so that even average rolls provide a tangible benefit, while perfect rolls offer a satisfying optimization.
