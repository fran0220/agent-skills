# Gameplay Atom: Lock-On Targeting (锁定目标)

## 1. Identity
- **Atom ID:** atom_lock_on
- **English Name:** Lock-On Targeting
- **Chinese Name:** 锁定目标
- **Category:** A (Core Combat/Camera)
- **Definition:** Lock-On Targeting is a camera and character control mechanic that forces the player's view and attacks to automatically orient toward a specific, selected enemy or point of interest, ensuring that combat actions remain focused on the target regardless of the player's movement.

## 2. Core Verb & State Machine
**Core Verb:** Lock (锁定)

**State Diagram:**
[Idle] --(Press Lock Button)--> [Searching Target]
[Searching Target] --(Target Found in Range/Angle)--> [Locked On]
[Searching Target] --(No Target Found)--> [Camera Reset/Idle]
[Locked On] --(Press Lock Button)--> [Idle]
[Locked On] --(Target Dies/Out of Range/Obscured)--> [Idle]
[Locked On] --(Flick Right Stick)--> [Switch Target]

**States and Transitions:**
- **Idle:** The default state where the camera is freely controlled by the player.
- **Searching Target:** A transient state triggered when the player initiates the lock-on command. The system evaluates potential targets based on distance, angle, and line of sight.
- **Locked On:** The active state where the camera tracks the target, and the player character's orientation is tethered to the target.
- **Switch Target:** A transient state where the lock-on focus shifts from the current target to another valid target in the specified direction.

## 3. MDA Analysis
**Mechanics:**
The system continuously calculates the distance and angle between the player character and potential targets. When activated, it selects the most optimal target (usually the closest or most central to the screen) and overrides the manual camera controls to keep the target in the center or at a specific offset on the screen. The player's movement inputs are often remapped relative to the target (e.g., strafing instead of turning).

**Dynamics:**
Players use lock-on to manage complex combat scenarios, allowing them to focus on dodging, blocking, and attacking without the cognitive load of manual camera management. It encourages a duel-like engagement, circling the enemy and reading their telegraphs. However, in multi-enemy situations, it can lead to tunnel vision, making the player vulnerable to attacks from off-screen enemies.

**Aesthetics:**
The lock-on mechanic creates a feeling of intense focus and intimacy in combat. It transforms a chaotic brawl into a structured, tactical duel. The player feels a sense of control and precision, as their attacks are guaranteed to aim at the intended target, enhancing the visceral impact of the combat experience.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value | Unit | Description |
|---|---|---|---|---|---|
| `max_lock_distance` | f32 | 10.0 - 50.0 | 25.0 (Dark Souls III v1.15) | meters | Maximum distance to initiate or maintain lock-on. |
| `lock_angle_fov` | f32 | 30.0 - 120.0 | 90.0 (Zelda: Breath of the Wild v1.6.0) | degrees | The field of view angle within which targets can be locked. |
| `break_distance_margin` | f32 | 1.0 - 10.0 | 5.0 (Elden Ring v1.10) | meters | Extra distance beyond `max_lock_distance` before lock breaks. |
| `target_switch_cooldown` | f32 | 0.1 - 0.5 | 0.2 (Sekiro v1.06) | seconds | Minimum time between switching targets. |
| `soft_lock_weight_distance` | f32 | 0.0 - 1.0 | 0.6 (Bloodborne v1.09) | ratio | Weight given to distance when scoring potential targets. |
| `soft_lock_weight_angle` | f32 | 0.0 - 1.0 | 0.4 (Bloodborne v1.09) | ratio | Weight given to screen center proximity when scoring targets. |

## 5. Benchmark Data
- **Dark Souls III (v1.15):**
  - `max_lock_distance`: 25.0 meters
  - `break_distance_margin`: 3.0 meters
  - `lock_angle_fov`: 75.0 degrees
- **The Legend of Zelda: Breath of the Wild (v1.6.0):**
  - `max_lock_distance`: 20.0 meters
  - `break_distance_margin`: 5.0 meters
  - `lock_angle_fov`: 90.0 degrees
- **Elden Ring (v1.10):**
  - `max_lock_distance`: 30.0 meters
  - `break_distance_margin`: 5.0 meters
  - `lock_angle_fov`: 80.0 degrees

## 6. Common Variants
1. **Soft Lock-On:** The game automatically assists aiming towards nearby targets without a hard camera lock or UI indicator (e.g., Assassin's Creed series).
2. **Part-Specific Lock-On:** Allows the player to lock onto specific body parts of a large enemy, such as a dragon's head or legs (e.g., Monster Hunter series, The Surge).
3. **Toggle vs. Hold:** Some games require holding a button to maintain the lock (Zelda's Z-targeting), while others use a toggle (Dark Souls).
4. **Magnetic Lock:** The camera doesn't strictly lock, but the character's attacks magnetically snap to the nearest enemy within a cone (e.g., Batman: Arkham series).

## 7. Compatibility Notes
**Compatible Atoms:**
- `atom_dodge_roll`: Dodging while locked on usually results in directional strafing or rolling relative to the target.
- `atom_parry`: Lock-on ensures the player is facing the correct direction to execute a parry.
- `atom_block`: Shield blocking is highly synergistic, keeping the shield oriented towards the threat.

**Incompatible/Conflicting Atoms:**
- `atom_free_aim_ranged`: Manual aiming with bows or firearms conflicts with the hard camera control of lock-on.
- `atom_sprint`: Sprinting away from a locked target can cause awkward camera snapping or force the player to break the lock first.

## 8. Anti-Patterns
1. **Aggressive Camera Snapping:** Instantly snapping the camera to a target without interpolation can cause motion sickness and disorient the player.
2. **Poor Target Prioritization:** Locking onto a distant, passive enemy instead of the immediate threat right in front of the player due to flawed scoring algorithms.
3. **Unbreakable Lock in Crowds:** Failing to automatically break the lock when the target is obscured by geometry or other enemies, leading to the camera getting stuck behind walls or clipping through the environment.
