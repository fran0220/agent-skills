# Gameplay Atom: Inner Voice / Thought Cabinet

## 1. Identity
**Atom ID:** `atom_inner_voice`
**English Name:** Inner Voice / Thought Cabinet
**Chinese Name:** 内心声音/思维柜
**Category:** F (Narrative & Cognitive Systems)

**Definition:** The Inner Voice / Thought Cabinet atom represents a cognitive inventory system where abstract concepts, internal monologues, or psychological traits are treated as equippable or developable entities. Instead of physical items, players collect, internalize, and equip thoughts, which then provide passive bonuses, alter dialogue options, or unlock new narrative pathways. This system externalizes the protagonist's internal psychological state, turning character development into a narrative puzzle.

## 2. Core Verb & State Machine
**Core Verb:** Internalize (to process a thought over time and integrate it into the character's psyche).

**State Diagram:**
```text
[Undiscovered] --(Trigger Event)--> [Discovered]
[Discovered] --(Opt-in)--> [Internalizing]
[Internalizing] --(Time/Progress)--> [Internalized]
[Internalized] --(Forget)--> [Forgotten]
[Forgotten] --(Re-discover)--> [Discovered]
```

**States and Transitions:**
- **Undiscovered:** The thought is hidden from the player.
- **Discovered:** The thought is revealed in the inventory but not yet active. Transition from Undiscovered occurs via specific dialogue choices or world interactions.
- **Internalizing:** The thought is currently being processed. Transition from Discovered occurs when the player actively chooses to equip it in an empty slot. During this state, it may apply temporary debuffs or buffs.
- **Internalized:** The thought is fully processed and permanently active (unless forgotten). Transition from Internalizing occurs after a set amount of in-game time or specific triggers.
- **Forgotten:** The thought is removed from the active slots, freeing up space. Transition from Internalized occurs when the player spends a specific resource (e.g., skill points) to forget it.

## 3. MDA Analysis
**Mechanics:** The system provides a limited number of "thought slots." Players discover thoughts through exploration and dialogue. Equipping a thought initiates a timer (in-game hours or real-time). Once the timer completes, the thought grants permanent stat changes, new dialogue options, or alters the game world's rules. Forgetting a thought costs a meta-currency (like skill points).

**Dynamics:** Players must balance the short-term penalties of internalizing a thought against its unknown long-term benefits. The limited slots force players to curate their character's mental landscape, leading to highly specialized and psychologically distinct builds. The cost of forgetting creates a strong commitment to chosen thoughts.

**Aesthetics:** The system evokes a sense of deep psychological role-playing. Players feel intimately connected to the protagonist's mental struggles and growth. It transforms abstract personality traits into tangible gameplay elements, fostering a sense of discovery and narrative agency.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Disco Elysium v1.0) | Unit |
| :--- | :--- | :--- | :--- | :--- |
| `max_slots` | `u32` | 3 - 12 | 12 | slots |
| `initial_slots` | `u32` | 1 - 5 | 3 | slots |
| `internalization_time` | `f32` | 0.5 - 24.0 | 4.0 | in-game hours |
| `forget_cost` | `u32` | 1 - 5 | 1 | skill points |
| `unlock_slot_cost` | `u32` | 1 - 5 | 1 | skill points |

## 5. Benchmark Data
- **Disco Elysium (v1.0):** `max_slots` = 12, `initial_slots` = 3, `forget_cost` = 1 skill point, `unlock_slot_cost` = 1 skill point. Internalization times vary wildly per thought, typically ranging from 30 in-game minutes to 9 in-game hours.
- **Citizen Sleeper (v1.0.4):** While not a direct 1:1, the "Drives" system acts similarly. `max_slots` = 5 (typically), `internalization_time` = 1-3 cycles (turns).

## 6. Common Variants
1. **The Trait Draft:** Instead of discovering thoughts in the world, players draft them during level-ups or specific milestones (e.g., Fallout's Perks, but framed as psychological traits).
2. **The Contagious Idea:** Thoughts are forced upon the player by interacting with specific NPCs or environments, requiring the player to actively spend resources to cure or suppress them (e.g., Darkest Dungeon's Quirks).
3. **The Stance System:** Thoughts are instantly equippable and swappable without an internalization timer, acting more like combat stances or active buffs (e.g., Ghost of Tsushima's stances, but applied to narrative).
4. **The Memory Palace:** Thoughts are spatialized in a 3D environment or grid, where placing certain thoughts next to each other creates synergistic effects.

## 7. Compatibility Notes
**Compatible Atoms:**
- `atom_dialogue_tree`: Thoughts frequently unlock new branches or alter the success rates of dialogue checks.
- `atom_skill_check`: Internalized thoughts often provide passive modifiers to skill checks.
- `atom_time_progression`: The internalization process relies heavily on a robust in-game time system.

**Incompatible Atoms:**
- `atom_fast_paced_combat`: Deep cognitive inventory management disrupts the flow of high-speed action games.
- `atom_amnesia_reset`: Roguelikes that wipe all progress frequently struggle to make long-term thought internalization meaningful unless thoughts persist across runs.

## 8. Anti-Patterns
1. **The Meaningless Choice:** Providing thoughts that only offer minor statistical buffs without any narrative flavor or dialogue impact, reducing the system to a generic passive skill tree.
2. **The Hidden Trap:** Making the temporary debuff during the "Internalizing" phase so severe that it soft-locks the player or makes the game unplayable, discouraging experimentation.
3. **The Cluttered Mind:** Giving the player too many slots and too many thoughts too quickly, leading to decision paralysis and diluting the impact of individual choices.
