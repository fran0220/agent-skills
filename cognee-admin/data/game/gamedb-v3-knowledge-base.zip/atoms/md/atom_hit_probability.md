# Gameplay Atom: Hit Probability

## 1. Identity
- **Atom ID:** `atom_hit_probability`
- **English Name:** Hit Probability
- **Chinese Name:** 命中概率
- **Category:** A
- **Definition:** Hit Probability is a core gameplay mechanic that determines the likelihood of an action (typically an attack) successfully connecting with its target. It introduces uncertainty and risk management into combat systems, forcing players to weigh the potential outcomes of their decisions based on statistical chances rather than guaranteed results.

## 2. Core Verb & State Machine
- **Core Verb:** Attack / Execute Action

**State Diagram:**
```text
[Idle] --> (Initiate Attack) --> [Calculating Hit]
[Calculating Hit] --> (Roll <= Hit Chance) --> [Hit Success]
[Calculating Hit] --> (Roll > Hit Chance) --> [Hit Miss]
[Hit Success] --> (Apply Effects) --> [Idle]
[Hit Miss] --> (Apply Miss Effects) --> [Idle]
```

**States:**
- `Idle`: Waiting for player or AI input.
- `Calculating Hit`: The system evaluates the attacker's accuracy against the defender's evasion.
- `Hit Success`: The attack connects.
- `Hit Miss`: The attack fails to connect.

**Transitions:**
- `Idle` -> `Calculating Hit`: Triggered by the player or AI initiating an attack.
- `Calculating Hit` -> `Hit Success`: Triggered when the random number generation (RNG) roll is less than or equal to the calculated hit chance.
- `Calculating Hit` -> `Hit Miss`: Triggered when the RNG roll is greater than the calculated hit chance.
- `Hit Success` / `Hit Miss` -> `Idle`: Triggered after the respective outcomes and animations are resolved.

## 3. MDA Analysis
- **Mechanics:** The system calculates a percentage chance for an attack to hit based on various factors such as base accuracy, weapon stats, distance, cover, and target evasion. A random number is then generated to determine the outcome.
- **Dynamics:** Players engage in risk assessment and mitigation. They will attempt to maximize their hit chances by flanking, destroying cover, or using buffs, while minimizing the enemy's chances through positioning and debuffs. Emergent behaviors include "save scumming" or overly cautious play when probabilities are not heavily in the player's favor.
- **Aesthetics:** Creates tension, excitement, and sometimes frustration. A successful low-probability hit can evoke immense satisfaction and relief, while missing a high-probability shot can lead to feelings of unfairness or despair. It heavily contributes to the dramatic narrative of a battle.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Game) | Unit |
| :--- | :--- | :--- | :--- | :--- |
| `base_accuracy` | `f32` | 0.0 - 1.0 | 0.65 (XCOM: Enemy Unknown v1.0) | Percentage (Decimal) |
| `weapon_bonus` | `f32` | -0.5 - 0.5 | 0.10 (Fire Emblem: Three Houses v1.2.0) | Percentage (Decimal) |
| `target_evasion` | `f32` | 0.0 - 1.0 | 0.20 (XCOM 2 v1.0) | Percentage (Decimal) |
| `cover_penalty` | `f32` | 0.0 - 0.5 | 0.40 (XCOM: Enemy Unknown v1.0 - Full Cover) | Percentage (Decimal) |
| `distance_modifier` | `f32` | -0.5 - 0.5 | -0.15 (XCOM 2 v1.0 - Long Range) | Percentage (Decimal) |

## 5. Benchmark Data
- **XCOM: Enemy Unknown (v1.0):**
  - Base Rookie Accuracy: 65%
  - Half Cover Defense Bonus: 20%
  - Full Cover Defense Bonus: 40%
  - Elevation Bonus: 20%
- **Fire Emblem: Three Houses (v1.2.0):**
  - True Hit System: Uses a 2RN (Two Random Numbers) system where two numbers from 0-99 are averaged and compared to the displayed hit rate. This makes high displayed hit rates more likely to hit and low displayed hit rates less likely to hit than the raw percentage suggests.
  - Base Hit = Weapon Hit + (Dexterity * 1) + modifiers.
- **XCOM 2 (v1.0):**
  - Base Rookie Accuracy: 65%
  - Low Cover: 20%
  - High Cover: 40%
  - Hidden modifiers: On lower difficulties, the game secretly buffs player hit chances after consecutive misses to reduce frustration.

## 6. Common Variants
1. **True Hit (2RN):** Averages two random numbers to determine the outcome, skewing results towards the extremes (high chances hit more often, low chances miss more often). Used heavily in the *Fire Emblem* series.
2. **Pseudo-Random Distribution (PRD):** The probability of a hit increases with each consecutive miss, ensuring that the actual hit rate approaches the theoretical hit rate over a smaller sample size and reducing streaks of good or bad luck. Common in MOBAs like *Dota 2*.
3. **Grazing/Partial Hits:** Instead of a binary hit/miss, attacks can "graze" for reduced damage if the roll is close to the required threshold. Seen in games like *XCOM 2* (with certain mods or mechanics) and *Pillars of Eternity*.
4. **Deterministic Hit:** Removes RNG entirely; attacks always hit, but damage or effects are scaled based on the "accuracy" vs "evasion" stats.
5. **Advantage/Disadvantage:** Rolling two dice and taking the higher (advantage) or lower (disadvantage) result, significantly altering the probability curve. Popularized by *Dungeons & Dragons 5th Edition* and adapted into games like *Baldur's Gate 3*.

## 7. Compatibility Notes
- **Commonly Pairs With:** `atom_critical_hit` (Critical hits often require a successful hit first), `atom_cover_system` (Cover directly modifies hit probability), `atom_line_of_sight` (LOS is usually a prerequisite for calculating hit probability).
- **Known Conflicts:** `atom_action_points` (If actions are highly limited, frequent misses can feel overly punishing, requiring careful balance).

## 8. Anti-Patterns
1. **The 99% Miss Frustration:** Displaying a 99% hit chance that misses can feel incredibly unfair to players due to human cognitive biases regarding probability. *Solution: Implement hidden modifiers or PRD to fudge the numbers slightly in the player's favor at extreme ends.*
2. **Opaque Calculations:** Hiding the factors that contribute to the hit chance, leaving players unable to make informed tactical decisions. *Solution: Provide a detailed breakdown of the hit calculation in the UI.*
3. **Over-reliance on RNG:** Making hit chances consistently hover around 50%, turning tactical combat into a coin-flipping contest rather than a test of skill and positioning. *Solution: Ensure players have adequate tools to manipulate the odds significantly.*
