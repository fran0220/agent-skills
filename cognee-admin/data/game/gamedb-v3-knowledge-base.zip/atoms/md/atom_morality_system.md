# Morality System (道德系统)

## 1. Identity
- **Atom ID**: atom_morality_system
- **English Name**: Morality System
- **Chinese Name**: 道德系统
- **Category**: E/F (Emergent/Fictional)
- **Definition**: A gameplay system that tracks and evaluates player choices and actions along a moral spectrum (typically good vs. evil, or law vs. chaos), dynamically altering the game world, NPC reactions, narrative outcomes, and available abilities based on the accumulated moral alignment.

## 2. Core Verb & State Machine
- **Core Verb**: Choose / Act (Make moral decisions)
- **State Diagram**:
  [Neutral] <--> [Good/Paragon] <--> [Max Good]
     ^
     |
     v
  [Evil/Renegade] <--> [Max Evil]

- **States**:
  - `Neutral`: The starting state where the player has no strong moral alignment.
  - `Good`: The player has accumulated positive moral points.
  - `Max Good`: The player has reached the maximum positive moral threshold.
  - `Evil`: The player has accumulated negative moral points.
  - `Max Evil`: The player has reached the maximum negative moral threshold.

- **Transitions**:
  - `Neutral` -> `Good`: Triggered by performing a good action or making a good choice.
  - `Neutral` -> `Evil`: Triggered by performing an evil action or making an evil choice.
  - `Good` -> `Max Good`: Triggered by accumulating enough good points to reach the threshold.
  - `Evil` -> `Max Evil`: Triggered by accumulating enough evil points to reach the threshold.
  - `Good` -> `Neutral`: Triggered by performing evil actions that offset the good points.
  - `Evil` -> `Neutral`: Triggered by performing good actions that offset the evil points.

## 3. MDA Analysis
- **Mechanics**: The system assigns numerical values to specific player actions and dialogue choices. These values are aggregated into a global "morality score" or separate "good" and "evil" meters. Thresholds on these meters unlock specific game states, such as new dialogue options, different NPC behaviors, or unique abilities.
- **Dynamics**: Players often min-max their morality to unlock specific rewards, leading to a polarized playstyle where they consistently choose one extreme over the other, rather than making nuanced decisions. The world reacts dynamically, with factions becoming hostile or friendly based on the player's alignment.
- **Aesthetics**: The system evokes feelings of consequence, agency, and role-playing immersion. Players feel the weight of their decisions as they see the tangible impact on the game world and characters, fostering a sense of identity and personal narrative.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Game) | Unit |
|---|---|---|---|---|
| `morality_score` | f32 | -100.0 to 100.0 | 0.0 (Mass Effect 2) | Points |
| `good_threshold` | f32 | 50.0 to 100.0 | 75.0 (Fable) | Points |
| `evil_threshold` | f32 | -100.0 to -50.0 | -75.0 (Fable) | Points |
| `action_weight` | f32 | 1.0 to 20.0 | 5.0 (InFamous) | Points/Action |
| `decay_rate` | f32 | 0.0 to 5.0 | 0.0 (Mass Effect 2) | Points/Day |

## 5. Benchmark Data
- **Mass Effect 2 (v1.02)**: Uses separate Paragon (Good) and Renegade (Evil) meters rather than a single slider. Paragon actions add to the Paragon meter, Renegade actions add to the Renegade meter. The maximum value for each is typically around 1000 points, but it's often calculated as a percentage of available points in the current playthrough.
- **InFamous (v1.0)**: Uses a single Karma meter ranging from -3 (Infamous) to +3 (Hero). Actions grant specific Karma points (e.g., healing a civilian grants +1, executing a civilian grants -1). Thresholds unlock specific powers.
- **Fable (v1.0)**: Uses a continuous alignment slider from -1000 (100% Evil) to +1000 (100% Good). Appearance changes dynamically based on the score (e.g., growing horns or a halo).

## 6. Common Variants
- **Dual Meter System**: Tracks good and evil separately, allowing a player to be both highly good and highly evil simultaneously (e.g., Mass Effect).
- **Single Slider System**: A zero-sum game where good actions directly subtract from evil actions and vice versa (e.g., Fallout 3).
- **Faction Reputation**: Morality is localized to specific groups rather than a universal standard (e.g., Fallout: New Vegas).
- **Hidden Morality**: The game tracks morality but hides the exact score from the player, revealing it only through narrative consequences (e.g., Metro 2033).
- **Action-Specific Morality**: Morality is tied to specific gameplay actions (like stealth vs. lethal combat) rather than dialogue choices (e.g., Dishonored).

## 7. Compatibility Notes
- **Compatible Atoms**: `atom_dialogue_tree` (Dialogue Tree), `atom_faction_reputation` (Faction Reputation), `atom_skill_tree` (Skill Tree).
- **Incompatible Atoms**: `atom_linear_narrative` (Strict Linear Narrative), as morality systems require branching outcomes.

## 8. Anti-Patterns
- **The "Binary Choice" Problem**: Forcing players into extreme good or extreme evil paths to unlock the best rewards, discouraging nuanced or neutral role-playing.
- **Inconsistent Morality**: Assigning moral values to actions that contradict the player's understanding of the game world's ethics (e.g., looting a generic container is considered "stealing" and evil).
- **Lack of Meaningful Consequences**: The morality score changes, but the game world and narrative remain largely unaffected, making the system feel superficial.
