# Identity
- **Atom ID**: atom_limited_resources
- **English Name**: Limited Resources
- **Chinese Name**: 有限资源
- **Category**: C
- **Definition**: A gameplay mechanic where players are provided with a strictly constrained amount of essential items (such as ammunition, health packs, or crafting materials), forcing them to make strategic decisions about when and how to use them to survive or progress.

# Core Verb & State Machine
- **Core Verb**: Manage / Conserve
- **State Diagram**:
  [Abundant] -> (Consume) -> [Scarce] -> (Deplete) -> [Empty]
  [Empty] -> (Scavenge/Loot) -> [Scarce]
  [Scarce] -> (Scavenge/Loot) -> [Abundant]
- **States**: Abundant, Scarce, Empty
- **Transitions**:
  - Abundant to Scarce: Triggered by consuming resources.
  - Scarce to Empty: Triggered by depleting the last of the resources.
  - Empty to Scarce: Triggered by finding or looting new resources.
  - Scarce to Abundant: Triggered by hoarding or finding a large cache of resources.

# MDA Analysis
- **Mechanics**: The game system strictly limits the spawn rate and maximum carrying capacity of essential items. It tracks the player's inventory and adjusts difficulty or item drops based on current resource levels.
- **Dynamics**: Players naturally adopt a conservative playstyle, avoiding unnecessary combat, exploring thoroughly for hidden items, and constantly evaluating the cost-benefit of engaging enemies versus fleeing.
- **Aesthetics**: Induces feelings of tension, vulnerability, and survival dread, followed by immense relief and satisfaction when finding a safe room or a crucial supply cache.

# Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value | Unit |
|---|---|---|---|---|
| max_ammo_capacity | u32 | 10 - 100 | 30 (Resident Evil 2 Remake) | bullets |
| health_item_spawn_rate | f32 | 0.01 - 0.1 | 0.05 (Silent Hill 2) | items/room |
| enemy_drop_chance | f32 | 0.0 - 0.5 | 0.1 (Resident Evil 4) | probability |
| inventory_slots | u32 | 4 - 20 | 8 (Resident Evil 7) | slots |

# Benchmark Data
- **Resident Evil 2 Remake (v1.0)**: max_ammo_capacity = 30, inventory_slots = 8
- **Silent Hill 2 (v1.0)**: health_item_spawn_rate = 0.05
- **Resident Evil 4 (v1.0)**: enemy_drop_chance = 0.1

# Common Variants
1. **Dynamic Scarcity**: The game director AI adjusts resource drops based on the player's current inventory (e.g., Resident Evil 4).
2. **Degrading Resources**: Items lose effectiveness or break over time, adding another layer of scarcity (e.g., weapon durability in Breath of the Wild).
3. **Shared Resource Pool**: Multiple actions draw from the same limited resource (e.g., stamina for attacking, dodging, and running).
4. **Weight-Based Limits**: Instead of slot limits, players are constrained by the total weight of items they can carry.

# Compatibility Notes
- **Compatible Atoms**: atom_inventory_management, atom_survival_horror, atom_crafting_system, atom_stealth.
- **Incompatible Atoms**: atom_infinite_ammo, atom_auto_heal, atom_power_fantasy.

# Anti-Patterns
1. **Soft-Locking**: Providing so few resources that a player can become permanently stuck at a boss fight with no way to win or backtrack.
2. **Hoarder's Regret**: Making resources so scarce that players never use their powerful items, finishing the game with an inventory full of unused ultimate weapons.
3. **Unpredictable Spawns**: Relying entirely on RNG for essential drops, leading to wildly inconsistent difficulty spikes.
