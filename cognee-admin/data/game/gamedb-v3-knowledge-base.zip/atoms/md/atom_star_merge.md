# Atom: Star-Up / Merge Units (升星/合成单位)

## 1. Identity
- **Atom ID**: `atom_star_merge`
- **English Name**: Star-Up / Merge Units
- **Chinese Name**: 升星/合成单位
- **Category**: C/D (Progression/Economy)
- **Definition**: A progression mechanic where multiple identical units of a lower tier (usually 3) are combined to create a single, more powerful unit of a higher tier, often resulting in exponential stat growth and freeing up board space.

## 2. Core Verb & State Machine
- **Core Verb**: Merge / Combine
- **State Diagram**:
  [Unowned] -> (Purchase) -> [Owned (1-Star)]
  [Owned (1-Star)] -> (Acquire 2 more) -> [Owned (2-Star)]
  [Owned (2-Star)] -> (Acquire 2 more 2-Star) -> [Owned (3-Star)]
- **States**:
  - `Unowned`: Unit is in the shop or pool.
  - `Owned_Star1`: Player owns a base copy of the unit.
  - `Owned_Star2`: Player owns an upgraded copy (merged from 3 Star1s).
  - `Owned_Star3`: Player owns a fully upgraded copy (merged from 3 Star2s).
- **Transitions**:
  - `Unowned` -> `Owned_Star1`: Triggered by `Buy`.
  - `Owned_Star1` -> `Owned_Star2`: Triggered by `Merge_Level1` (requires 3x Star1).
  - `Owned_Star2` -> `Owned_Star3`: Triggered by `Merge_Level2` (requires 3x Star2).

## 3. MDA Analysis
- **Mechanics**: The system tracks the number of identical units a player owns. When the threshold (usually 3) is reached, it automatically removes the lower-tier units and replaces them with a higher-tier unit. Stats are multiplied by a specific factor (e.g., 1.8x).
- **Dynamics**: Players must balance their economy and bench space while searching for duplicates. It creates a "push your luck" dynamic where holding pairs of units consumes resources (gold/space) but offers a high potential reward.
- **Aesthetics**: The feeling of anticipation when searching for the final copy, followed by the immense satisfaction and visual/audio payoff when the merge occurs. It provides a strong sense of progression and power fantasy.

## 4. Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value (TFT Set 10) | Unit |
|---|---|---|---|---|
| `merge_requirement` | u32 | 2 - 5 | 3 | units |
| `stat_multiplier` | f32 | 1.5 - 2.5 | 1.8 | multiplier |
| `max_star_level` | u32 | 2 - 4 | 3 | levels |
| `sell_value_penalty` | f32 | 0.0 - 0.5 | 0.0 (for 1-cost) | multiplier |

## 5. Benchmark Data
- **Teamfight Tactics (TFT) Set 10**:
  - `merge_requirement`: 3
  - `stat_multiplier`: 1.8 (HP and AD typically scale by 1.8x per star level)
  - `max_star_level`: 3
- **Dota Underlords (v1.0)**:
  - `merge_requirement`: 3
  - `stat_multiplier`: 2.0 (HP and Damage often double)
  - `max_star_level`: 3

## 6. Common Variants
1. **Two-to-Merge**: Some games or specific units (like Druids in Auto Chess) only require 2 copies to merge.
2. **Item Merging**: The same mechanic applied to items instead of units (e.g., combining two basic items into a completed item).
3. **Infinite Merging**: Games like *Merge Dragons* where there is no strict max level, and merging 5 gives a bonus over merging 3.
4. **Gacha Duplicates**: Using duplicates to unlock "constellations" or "potentials" rather than transforming the base unit on a board.

## 7. Compatibility Notes
- **Compatible Atoms**: `atom_shop_reroll` (Rerolling shop to find copies), `atom_limited_pool` (Shared pool makes finding copies harder), `atom_bench_space` (Limited space creates tension).
- **Incompatible Atoms**: `atom_permadeath` (Losing a 3-star unit instantly would be too punishing), `atom_infinite_scaling` (Can conflict if base stats scale infinitely outside of star levels).

## 8. Anti-Patterns
1. **Bench Lock**: Making the merge requirement too high (e.g., 5) without providing enough bench space, leading to frustrating gridlock.
2. **Linear Scaling**: If a 2-star unit is exactly twice as strong as a 1-star but costs 3 times as much, players will avoid merging. The stat multiplier must outpace the cost or provide space efficiency.
3. **Hidden Pool Sizes**: Not communicating to the player that the pool of units is limited, causing them to roll for a 3-star unit that is mathematically impossible to hit.
