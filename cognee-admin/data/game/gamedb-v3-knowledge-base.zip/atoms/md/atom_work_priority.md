# Gameplay Atom: Work Priority Queue

## 1. Identity
- **Atom ID:** atom_work_priority
- **English Name:** Work Priority Queue
- **Chinese Name:** 工作优先级
- **Category:** G/H (Simulation/Management)
- **Definition:** A system where autonomous agents or units are assigned tasks based on a prioritized queue or matrix. Players do not directly control every action but instead set rules, priorities, and schedules, allowing the AI to evaluate available tasks and execute the most critical or highly prioritized one based on the current state and agent capabilities.

## 2. Core Verb & State Machine
- **Core Verb:** Prioritize (Assigning priority levels to different task types for different agents).
- **State Diagram:**
  [Idle] --> (Task Available & Priority > 0) --> [Evaluating]
  [Evaluating] --> (Highest Priority Task Found) --> [Pathing]
  [Pathing] --> (Reached Target) --> [Working]
  [Working] --> (Task Complete) --> [Idle]
  [Working] --> (Interrupted/Needs Met) --> [Idle]
- **States:**
  - `Idle`: Agent has no current task and is waiting for a valid task.
  - `Evaluating`: Agent is scanning the global or local task list to find the best match based on priority settings and distance.
  - `Pathing`: Agent is moving towards the location of the selected task.
  - `Working`: Agent is actively performing the task.
- **Transitions:**
  - `Idle` -> `Evaluating`: Triggered by a periodic tick or when a new task is added.
  - `Evaluating` -> `Pathing`: Triggered when a task is successfully claimed.
  - `Pathing` -> `Working`: Triggered when the agent reaches the task location.
  - `Working` -> `Idle`: Triggered when the task is completed or the agent is interrupted (e.g., attacked, starving).

## 3. MDA Analysis
- **Mechanics:** Players configure a matrix of agents and task types, assigning numerical priorities (e.g., 1-4, where 1 is highest) or toggling tasks on/off. The game engine periodically evaluates all pending tasks against available agents' priorities, skills, and distances to assign work.
- **Dynamics:** Emergent behaviors arise as the colony grows. A poorly configured priority queue can lead to critical tasks (like harvesting food or treating wounds) being ignored in favor of low-priority tasks (like cleaning). Players must constantly adjust priorities to respond to crises or changing goals.
- **Aesthetics:** Creates a feeling of indirect control, management, and orchestration. Players feel satisfaction when a well-oiled machine of agents efficiently handles complex logistical chains, and panic/challenge when the system breaks down during emergencies.

## 4. Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value (RimWorld 1.4) | Unit |
|---|---|---|---|---|
| `priority_levels` | u32 | 1 - 9 | 4 | levels |
| `evaluation_interval` | f32 | 0.1 - 5.0 | 0.5 | seconds |
| `distance_weight` | f32 | 0.0 - 10.0 | 1.0 | multiplier |
| `skill_weight` | f32 | 0.0 - 5.0 | 0.0 | multiplier |
| `task_timeout` | f32 | 10.0 - 300.0 | 60.0 | seconds |

## 5. Benchmark Data
- **RimWorld (Version 1.4):**
  - `priority_levels`: 4 (1 is highest, 4 is lowest, 0 is disabled).
  - `evaluation_interval`: 0.5 seconds.
  - `distance_weight`: 1.0 (Used as a tie-breaker for tasks of the same priority type).
- **Dwarf Fortress (Version 50.xx):**
  - `priority_levels`: 7 (1 to 7).
  - `evaluation_interval`: 0.1 seconds (Continuous/Event-driven).
  - `distance_weight`: 5.0 (High impact on task selection to minimize walking).

## 6. Common Variants
1. **Strict Left-to-Right Priority:** Agents evaluate tasks strictly from left to right on the UI, only considering the assigned number as a secondary factor.
2. **Skill-Weighted Priority:** Agents automatically prefer tasks they are highly skilled at, even if the player-assigned priority is slightly lower.
3. **Need-Driven Priority:** Agents will abandon player-assigned tasks if their personal needs (hunger, sleep) fall below a critical threshold, overriding the work queue.
4. **Zone-Restricted Priority:** Tasks are only evaluated if they fall within an agent's assigned allowed area, acting as a hard filter before priority is considered.

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_pathfinding` (essential for reaching tasks), `atom_agent_needs` (interacts with work schedules), `atom_skill_progression` (determines task efficiency).
- **Incompatible Atoms:** `atom_direct_control` (RTS-style direct unit micro-management conflicts with autonomous priority queues).

## 8. Anti-Patterns
1. **Priority Inversion:** When a high-priority task is blocked by a missing resource, and the agent idles instead of falling back to a lower-priority task.
2. **Distance Ignorance:** Agents walking across the entire map to do a high-priority task that takes 1 second, ignoring a slightly lower-priority task right next to them.
3. **Task Thrashing:** Agents constantly switching between two tasks of equal priority because the evaluation interval is too short and distance weights fluctuate.
