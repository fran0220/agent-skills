# Action Points (atom_action_points)

## 1. Identity
- **Atom ID**: atom_action_points
- **English Name**: Action Points
- **Chinese Name**: 行动点数
- **Category**: A
- **Definition**: A resource management system where players are allocated a specific number of points per turn, which are consumed to perform various actions such as moving, attacking, or using items.

## 2. Core Verb & State Machine
- **Core Verb**: Spend
- **State Diagram**:
  [Start Turn] -> (Replenish AP) -> [Idle]
  [Idle] -> (Choose Action) -> [Action Selected]
  [Action Selected] -> (Execute Action & Deduct AP) -> [Action Resolving]
  [Action Resolving] -> (Check Remaining AP) -> [Idle] (if AP > 0) OR [End Turn] (if AP == 0)
- **States**: Start Turn, Idle, Action Selected, Action Resolving, End Turn
- **Transitions**:
  - Start Turn -> Idle: Replenish AP
  - Idle -> Action Selected: Choose Action
  - Action Selected -> Action Resolving: Execute Action & Deduct AP
  - Action Resolving -> Idle: Check Remaining AP (AP > 0)
  - Action Resolving -> End Turn: Check Remaining AP (AP == 0)

## 3. MDA Analysis
- **Mechanics**: The system allocates a finite number of Action Points (AP) to a unit at the start of their turn. Every action has an AP cost. The unit can perform actions as long as they have sufficient AP.
- **Dynamics**: Players must optimize their AP usage, balancing between movement, offense, and defense. It creates a puzzle-like tactical layer where sequencing matters.
- **Aesthetics**: Players feel a sense of agency and tactical depth. It evokes feelings of calculation, tension (when AP is low), and satisfaction (when executing a perfect sequence of actions).

## 4. Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value (Game/Version) | Unit |
|---|---|---|---|---|
| max_ap | u32 | 2 - 10 | 2 (XCOM: Enemy Unknown v1.0) | Points |
| base_ap_regen | u32 | 2 - 10 | 2 (XCOM: Enemy Unknown v1.0) | Points/Turn |
| move_cost | u32 | 1 - 4 | 1 (XCOM: Enemy Unknown v1.0) | Points |
| attack_cost | u32 | 1 - 6 | 1 (XCOM: Enemy Unknown v1.0) | Points |
| overwatch_cost | u32 | 1 - 4 | 1 (XCOM: Enemy Unknown v1.0) | Points |

## 5. Benchmark Data
- **XCOM: Enemy Unknown (v1.0)**:
  - max_ap: 2
  - base_ap_regen: 2
  - move_cost: 1
  - attack_cost: 1 (often ends turn regardless of remaining AP)
- **Divinity: Original Sin 2 (v3.6.69.4648)**:
  - max_ap: 6
  - base_ap_regen: 4
  - move_cost: 1 per X meters
  - attack_cost: 2

## 6. Common Variants
1. **Time Units (TU)**: A more granular version of AP where units have a large pool (e.g., 50-100) and actions cost specific amounts (e.g., original X-COM: UFO Defense).
2. **Action/Bonus Action**: A simplified system where units get one main action and one minor/bonus action per turn (e.g., Dungeons & Dragons 5e, Baldur's Gate 3).
3. **Fatigue/Stamina**: AP that regenerates over time in real-time or active-time battle systems, rather than strictly per turn.
4. **Shared AP Pool**: A single pool of AP shared among all units in a squad, allowing players to heavily invest in one unit's actions at the expense of others (e.g., Valkyria Chronicles).

## 7. Compatibility Notes
- **Commonly Pairs With**: atom_grid_movement, atom_turn_order, atom_cooldowns, atom_status_effects.
- **Known Conflicts**: Real-time action combat systems (unless implemented as a stamina bar).

## 8. Anti-Patterns
1. **AP Hoarding**: Allowing players to save too much AP between turns, leading to alpha-strike strategies that trivialize encounters.
2. **Overly Granular Costs**: Making AP costs too complex (e.g., 13 AP for an attack out of 100), which slows down gameplay as players struggle to calculate optimal turns.
3. **Action Starvation**: Giving units too few AP relative to action costs, resulting in turns where players feel they accomplished nothing.
