# Gameplay Atom: Double Jump (二段跳)

## 1. Identity
**Atom ID:** `atom_double_jump`
**English Name:** Double Jump
**Chinese Name:** 二段跳
**Category:** A (Core Movement)
**Definition:** The Double Jump is a fundamental platforming and action game mechanic that allows a character to execute a second jump while already airborne from an initial jump or fall. This mechanic significantly expands the player's vertical and horizontal reach, provides a margin of error for platforming challenges, and introduces new dimensions to aerial combat and evasion. By granting players a mid-air trajectory correction, it transforms the rigid physics of a standard jump into a flexible, expressive movement tool.

## 2. Core Verb & State Machine
**Core Verb:** Jump (Mid-air)

**State Diagram:**
```text
[Grounded] --(Jump Input)--> [First Jump Ascent]
[First Jump Ascent] --(Apex Reached)--> [Falling]
[Falling] --(Jump Input)--> [Double Jump Ascent]
[First Jump Ascent] --(Jump Input)--> [Double Jump Ascent]
[Double Jump Ascent] --(Apex Reached)--> [Falling (No Jumps Left)]
[Falling (No Jumps Left)] --(Land on Ground)--> [Grounded]
```

**States:**
- `Grounded`: The character is on a solid surface, jump counter is reset.
- `First Jump Ascent`: The character is moving upwards after the initial jump.
- `Falling`: The character is moving downwards due to gravity.
- `Double Jump Ascent`: The character is moving upwards after executing the mid-air jump.
- `Falling (No Jumps Left)`: The character is falling and cannot jump again until landing.

**Transitions:**
- `Grounded` -> `First Jump Ascent`: Triggered by the jump button press while on the ground.
- `First Jump Ascent` -> `Falling`: Triggered when vertical velocity reaches zero or the jump button is released (variable jump height).
- `Falling` / `First Jump Ascent` -> `Double Jump Ascent`: Triggered by the jump button press while airborne, provided the double jump has not been used.
- `Double Jump Ascent` -> `Falling (No Jumps Left)`: Triggered when vertical velocity reaches zero.
- `Falling (No Jumps Left)` -> `Grounded`: Triggered upon collision with a walkable surface.

## 3. MDA Analysis
**Mechanics:** The system tracks the player's grounded state and maintains a counter for available jumps. When the player inputs a jump command while airborne and the counter is greater than zero, the system resets the player's vertical velocity to a specific upward value (the double jump force), decrements the jump counter, and often plays a distinct animation and particle effect to provide feedback.

**Dynamics:** Players utilize the double jump not just for reaching higher platforms, but for extending horizontal distance, correcting overshoots, baiting enemy attacks, and delaying their landing. It allows for non-committal initial jumps, where the player can scout ahead and use the second jump to retreat if danger is spotted. In combat, it enables prolonged aerial combos and evasion of ground-based area-of-effect attacks.

**Aesthetics:** The double jump evokes feelings of freedom, agility, and mastery over gravity. It empowers the player, reducing the frustration of precise platforming by offering a built-in safety net. The visual and auditory feedback of kicking off thin air adds a satisfying, magical, or superhuman flair to the character's movement, enhancing the overall kinetic joy of navigating the game world.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (Hollow Knight v1.5) | Unit |
| :--- | :--- | :--- | :--- | :--- |
| `double_jump_velocity` | `f32` | 10.0 - 25.0 | 16.5 | Units/sec |
| `gravity_multiplier` | `f32` | 0.5 - 2.0 | 1.0 | Multiplier |
| `horizontal_boost` | `f32` | 0.0 - 10.0 | 0.0 | Units/sec |
| `input_buffer_time` | `f32` | 0.05 - 0.2 | 0.1 | Seconds |
| `coyote_time_override` | `bool` | true/false | false | Boolean |
| `max_jumps` | `u32` | 2 - 3 | 2 | Count |

## 5. Benchmark Data
- **Hollow Knight (v1.5.78.11833):** The "Monarch Wings" ability grants the double jump. The `double_jump_velocity` is slightly lower than the initial full jump velocity, ensuring it feels like a secondary boost rather than a primary leap. It completely overrides current downward velocity, providing a crisp, immediate upward snap.
- **Devil May Cry 5 (v1.05):** The "Air Hike" ability. The `double_jump_velocity` is high, designed to keep the player in the air for extended combo sequences. It includes a slight `horizontal_boost` if a directional input is held, aiding in repositioning during aerial raves.
- **Celeste (v1.4.0.0):** While technically a mid-air dash rather than a traditional double jump, it serves a similar purpose. The parameter space here focuses heavily on `input_buffer_time` (generous, around 0.15s) to ensure the action feels responsive even in high-stress, frame-perfect platforming sequences.

## 6. Common Variants
1. **The Hover Jump:** Instead of an instant burst of upward velocity, the second jump provides a sustained, slow ascent or horizontal hover (e.g., Princess Peach in Super Mario Bros. 2).
2. **The Directional Dash:** The second jump is replaced by a rapid horizontal or omnidirectional dash (e.g., Celeste, Hollow Knight's Mothwing Cloak).
3. **The Attack Jump:** The double jump has a hitbox and damages enemies upon activation (e.g., Sonic's double jump with certain shields).
4. **The Resource-Consuming Jump:** The double jump consumes stamina or mana, limiting its use in rapid succession or forcing strategic choices (e.g., some RPGs or Metroidvanias).
5. **The Multi-Jump:** Expanding the concept to triple or infinite jumps, often with diminishing returns on height (e.g., Kirby, Super Smash Bros. characters).

## 7. Compatibility Notes
**Compatible Atoms:**
- `atom_dash`: Combines for massive horizontal recovery or complex platforming sequences.
- `atom_wall_jump`: Essential pairing in Metroidvanias; double jumping off a wall jump or vice versa.
- `atom_ground_pound`: Using the double jump to position perfectly before slamming down.
- `atom_glide`: Double jumping to gain altitude before initiating a glide.

**Incompatible/Conflicting Atoms:**
- `atom_realistic_physics`: Games aiming for strict realism cannot logically support a mid-air jump without a physical prop (like a jetpack).
- `atom_heavy_fall`: If a character is in a specific "heavy" state, allowing a double jump might break the intended vulnerability of that state.

## 8. Anti-Patterns
1. **Velocity Addition instead of Override:** If the double jump simply adds upward velocity to the current falling velocity, a player falling very fast might double jump and still move downwards, feeling unresponsive and frustrating. The vertical velocity must be reset/overridden.
2. **Lack of Visual/Audio Feedback:** Because the jump happens in mid-air without a surface reference, failing to provide a distinct particle effect (like a ring of air) or sound effect makes the action feel weightless and confusing.
3. **Ignoring Horizontal Momentum:** If the double jump abruptly halts horizontal momentum, it breaks the flow of platforming. The double jump should generally preserve or slightly enhance the current horizontal trajectory.
