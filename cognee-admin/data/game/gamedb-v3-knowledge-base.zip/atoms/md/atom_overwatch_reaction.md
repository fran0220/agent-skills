# Gameplay Atom: Overwatch / Reaction Fire

## 1. Identity
- **Atom ID:** `atom_overwatch_reaction`
- **English Name:** Overwatch / Reaction Fire
- **Chinese Name:** 监视/反应射击
- **Category:** A
- **Definition:** A tactical mechanic where a unit forfeits its immediate offensive action during its turn to enter a readied state, automatically triggering an attack against any enemy unit that moves within its line of sight or attack range during the enemy's turn.

## 2. Core Verb & State Machine
- **Core Verb:** `overwatch` (Set unit to watch a specific area or general line of sight)

**State Diagram:**
```text
[Idle] --(Action: Overwatch)--> [Overwatching]
[Overwatching] --(Enemy Moves in LOS)--> [Triggered]
[Triggered] --(Attack Resolves)--> [Cooldown/Idle]
[Overwatching] --(Turn Ends/Interrupted)--> [Idle]
```

**States:**
- `Idle`: The unit is waiting for commands.
- `Overwatching`: The unit is actively monitoring for enemy movement.
- `Triggered`: An enemy has moved, and the unit is executing the reaction fire.
- `Cooldown/Idle`: The unit has completed the reaction fire and returns to idle or is out of action points.

**Transitions:**
- `Idle` -> `Overwatching`: Player selects the overwatch action, consuming action points.
- `Overwatching` -> `Triggered`: Enemy unit enters or moves within the overwatch zone/LOS.
- `Triggered` -> `Cooldown/Idle`: The reaction attack is completed.
- `Overwatching` -> `Idle`: The round ends, or the unit takes damage/status effect that cancels overwatch.

## 3. MDA Analysis
- **Mechanics:** The system monitors enemy movement events. If an enemy moves within the line of sight and range of an overwatching unit, an attack is automatically rolled and executed, often with an aim penalty.
- **Dynamics:** Players use overwatch to control space, set up ambushes, and punish aggressive enemy positioning. It creates a "zone of control" that forces the opponent to reconsider their movement paths or use abilities to break the overwatch.
- **Aesthetics:** Creates tension and anticipation. Players feel a sense of tactical superiority when a trap is sprung successfully, or anxiety when moving their own units into unknown territory where enemies might be overwatching.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (XCOM 2 v1.0) | Unit |
|---|---|---|---|---|
| `aim_penalty_multiplier` | f32 | 0.5 - 1.0 | 0.7 | multiplier |
| `dash_penalty_multiplier` | f32 | 0.4 - 0.8 | 0.6 | multiplier |
| `trigger_radius` | f32 | 5.0 - 30.0 | 27.0 | tiles/meters |
| `action_point_cost` | u32 | 1 - 2 | 1 | AP |
| `max_triggers_per_turn` | u32 | 1 - 5 | 1 | count |

## 5. Benchmark Data
- **XCOM 2 (v1.0):**
  - `aim_penalty_multiplier`: 0.7 (Standard overwatch shot has a 30% aim penalty)
  - `dash_penalty_multiplier`: 0.6 (If the target is dashing, the penalty is higher)
  - `max_triggers_per_turn`: 1 (Usually, a unit can only fire once per overwatch)
- **Gears Tactics (v1.0):**
  - `aim_penalty_multiplier`: 1.0 (No inherent aim penalty, but cone of fire restricts area)
  - `max_triggers_per_turn`: 3 (Depends on remaining action points; can fire multiple times)
  - `trigger_radius`: Variable based on weapon range and player-defined cone.

## 6. Common Variants
1. **Cone Overwatch:** Instead of a 360-degree line of sight, the player defines a specific cone or direction for the unit to watch (e.g., Gears Tactics).
2. **Suppressive Fire:** Overwatch that also applies a debuff (like reduced movement or aim) to the target, even if the shot misses.
3. **Melee Overwatch (Zone of Control):** Automatically triggers a melee attack if an enemy attempts to move out of an adjacent tile (e.g., Dungeons & Dragons Attacks of Opportunity).
4. **Conditional Overwatch:** Only triggers on specific enemy types or specific actions (e.g., only triggers when an enemy attacks, rather than moves).

## 7. Compatibility Notes
- **Compatible Atoms:** `atom_cover_system` (Overwatch interacts heavily with cover, often ignoring cover bonuses if the target is caught moving in the open), `atom_action_points` (Consumes AP to activate).
- **Incompatible Atoms:** `atom_real_time_evasion` (Reaction fire is typically a staple of turn-based or pause-and-play systems, conflicting with pure real-time twitch evasion).

## 8. Anti-Patterns
1. **Overwatch Creep:** If overwatch has no downside or cooldown, players will move one tile and put everyone on overwatch, slowing the game to a crawl. (Solution: Timers or objective pressure).
2. **Unclear Triggers:** Failing to clearly communicate to the player which tiles are under enemy overwatch, leading to frustrating "gotcha" moments.
3. **Infinite Reaction Loops:** Two units triggering overwatch on each other simultaneously, causing an infinite loop of attacks.
