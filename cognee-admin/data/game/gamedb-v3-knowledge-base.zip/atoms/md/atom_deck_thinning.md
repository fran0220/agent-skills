# Deck Thinning (卡组精简)

## 1. Identity
- **Atom ID**: atom_deck_thinning
- **English Name**: Deck Thinning
- **Chinese Name**: 卡组精简
- **Category**: C
- **Definition**: The process of permanently removing suboptimal or basic cards from a player's deck during a run or game session, thereby increasing the probability of drawing high-value or synergistic cards in subsequent turns.

## 2. Core Verb & State Machine
- **Core Verb**: Exhaust / Trash / Remove
- **State Diagram**:
  [Deck] -> (Draw) -> [Hand]
  [Hand] -> (Play/Discard) -> [Discard Pile]
  [Hand/Deck/Discard] -> (Remove Action) -> [Exhaust/Trash Pile]
- **States**:
  - `In_Deck`: Card is in the draw pile.
  - `In_Hand`: Card is currently held by the player.
  - `In_Discard`: Card has been played or discarded and will be reshuffled.
  - `Removed`: Card is permanently removed from the current game or run.
- **Transitions**:
  - `In_Deck` -> `In_Hand`: Triggered by drawing a card.
  - `In_Hand` -> `In_Discard`: Triggered by playing or discarding at end of turn.
  - `In_Discard` -> `In_Deck`: Triggered by reshuffling when deck is empty.
  - `In_Hand`/`In_Deck`/`In_Discard` -> `Removed`: Triggered by a removal effect (e.g., playing a card that trashes another card, or paying at a shop).

## 3. MDA Analysis
- **Mechanics**: The system provides specific actions, events, or resources that allow players to select a card from their deck/hand/discard and move it to an out-of-play zone.
- **Dynamics**: Players must balance the short-term cost of removal (spending gold, using an action, or taking damage) against the long-term benefit of a more consistent and powerful deck. This creates a pacing dynamic where early thinning is highly valuable but often costly.
- **Aesthetics**: Players feel a sense of optimization, control, and satisfaction as their deck becomes a finely tuned engine. It rewards strategic foresight and planning.

## 4. Parameter Space
| Parameter Name | Type | Typical Range | Benchmark Value | Unit |
|---|---|---|---|---|
| `removal_cost_base` | u32 | 50 - 100 | 75 (Slay the Spire v2.2) | Gold |
| `removal_cost_increment` | u32 | 0 - 50 | 25 (Slay the Spire v2.2) | Gold |
| `max_removals_per_shop` | u32 | 1 - 3 | 1 (Slay the Spire v2.2) | Count |
| `trash_action_cost` | u32 | 0 - 2 | 1 (Dominion 2nd Ed) | Action |

## 5. Benchmark Data
- **Slay the Spire (v2.2)**:
  - `removal_cost_base`: 75 Gold
  - `removal_cost_increment`: 25 Gold
  - `max_removals_per_shop`: 1
- **Dominion (2nd Edition)**:
  - Chapel card allows trashing up to 4 cards for 1 Action.
  - `trash_action_cost`: 1 Action
  - `cards_trashed_per_effect`: 4

## 6. Common Variants
1. **Paid Removal**: Paying a currency at a specific node/shop to remove a card (e.g., Slay the Spire shops).
2. **In-Combat Exhaust**: Cards that remove themselves or other cards when played during a battle, returning after the battle (e.g., Exhaust mechanic in Slay the Spire).
3. **Action-Based Trashing**: Playing a specific card from hand to remove other cards from hand (e.g., Chapel in Dominion).
4. **Event-Based Removal**: Random events that offer card removal, often with a trade-off like taking damage or gaining a curse.

## 7. Compatibility Notes
- **Compatible Atoms**: `atom_card_draw` (Card Draw), `atom_infinite_combo` (Infinite Combos), `atom_deck_shuffling` (Deck Shuffling). Thinning makes combos and draw engines much more reliable.
- **Incompatible/Conflicting Atoms**: `atom_deck_bloat` (Deck Bloat/Curses) - these directly oppose thinning, though they often exist in the same game to create tension. `atom_fatigue` (Fatigue/Deck Out damage) - thinning too much can accelerate fatigue if the game penalizes empty decks.

## 8. Anti-Patterns
1. **Too Cheap Removal**: If removing cards is too easy or cheap, players will always reduce their deck to a minimal degenerate combo, reducing variety.
2. **No Removal Options**: In games with starting "junk" cards, lacking removal makes the late game overly reliant on RNG, frustrating players.
3. **Over-Penalizing Thinning**: Adding severe punishments for small decks (like taking massive damage when reshuffling) can make thinning a trap rather than a viable strategy.
