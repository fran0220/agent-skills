# Gameplay Atom: Glide / Float

## 1. Identity
- **Atom ID:** `atom_glide_float`
- **English Name:** Glide / Float
- **Chinese Name:** 滑翔/漂浮
- **Category:** A+B
- **Definition:** The Glide / Float atom allows a character to significantly reduce their downward vertical velocity while moving through the air, often converting vertical descent into horizontal movement. This mechanic provides players with extended airtime, enabling them to cross large gaps, bypass ground-based obstacles, and explore vertical environments with greater freedom and safety.

## 2. Core Verb & State Machine
- **Core Verb:** Glide
- **State Diagram:**
  ```text
  [Grounded] --> (Jump/Fall) --> [Airborne]
  [Airborne] --> (Deploy Glider) --> [Gliding]
  [Gliding] --> (Release Glider/Stamina Depleted) --> [Airborne]
  [Gliding] --> (Touch Ground) --> [Grounded]
  [Airborne] --> (Touch Ground) --> [Grounded]
  ```
- **States:**
  - `Grounded`: The character is on a solid surface.
  - `Airborne`: The character is in the air, subject to normal gravity.
  - `Gliding`: The character is in the air with reduced gravity/fall speed, often with modified horizontal control.
- **Transitions:**
  - `Grounded` to `Airborne`: Triggered by jumping or walking off an edge.
  - `Airborne` to `Gliding`: Triggered by player input (e.g., pressing the jump button again while in the air) to deploy the glider.
  - `Gliding` to `Airborne`: Triggered by player input to cancel the glide, or automatically if a resource like stamina is fully depleted.
  - `Gliding` to `Grounded`: Triggered by colliding with a walkable surface.
  - `Airborne` to `Grounded`: Triggered by colliding with a walkable surface.

## 3. MDA Analysis
- **Mechanics:** The system applies a counter-force to gravity or caps the maximum downward velocity when the glide state is active. It may also alter horizontal acceleration and maximum horizontal speed. Often, gliding consumes a resource (like stamina) over time.
- **Dynamics:** Players use gliding to traverse long distances that are otherwise impassable. They seek out high vantage points to maximize glide distance. Resource management becomes crucial, as running out of stamina mid-glide leads to a normal, potentially fatal, fall. Players may also use updrafts to regain height.
- **Aesthetics:** Gliding evokes feelings of freedom, exploration, and tranquility. It provides a break from intense ground combat or platforming, allowing players to survey the landscape from above. The gradual descent creates a sense of peaceful floating, contrasted by the tension of managing stamina.

## 4. Parameter Space

| Parameter Name | Type | Typical Range | Benchmark Value (BotW v1.5.0) | Unit |
| :--- | :--- | :--- | :--- | :--- |
| `glide_fall_speed` | `f32` | 2.0 - 10.0 | 5.0 | m/s |
| `horizontal_speed` | `f32` | 5.0 - 20.0 | 12.0 | m/s |
| `stamina_drain_rate` | `f32` | 0.0 - 50.0 | 10.0 | pts/s |
| `deploy_delay` | `f32` | 0.0 - 0.5 | 0.1 | s |
| `updraft_lift` | `f32` | 10.0 - 30.0 | 15.0 | m/s |

## 5. Benchmark Data
- **The Legend of Zelda: Breath of the Wild (v1.5.0):**
  - `glide_fall_speed`: ~5.0 m/s
  - `horizontal_speed`: ~12.0 m/s
  - `stamina_drain_rate`: ~10.0 stamina points per second.
  - *Notes:* Gliding is a core traversal mechanic, heavily tied to the stamina wheel and environmental updrafts.
- **Ori and the Will of the Wisps (v1.0):**
  - `glide_fall_speed`: ~3.5 m/s
  - `horizontal_speed`: ~8.0 m/s
  - `stamina_drain_rate`: 0.0 (Unlimited glide duration).
  - *Notes:* Kuro's Feather allows for indefinite gliding, focusing more on navigating environmental hazards and updrafts rather than resource management.

## 6. Common Variants
1. **Stamina-Gated Gliding:** The glide duration is strictly limited by a stamina bar (e.g., *Breath of the Wild*, *Genshin Impact*).
2. **Infinite Gliding:** The player can glide indefinitely as long as they have vertical height (e.g., *Ori and the Will of the Wisps*, *Batman: Arkham City*).
3. **Momentum-Based Gliding:** The glide speed and lift depend heavily on the player's initial velocity and dive mechanics (e.g., *Batman: Arkham Knight*, *Super Mario World* cape).
4. **Hovering:** A variant where the player maintains a fixed vertical height for a short duration rather than slowly descending (e.g., Princess Peach in *Super Mario Bros. 2*).

## 7. Compatibility Notes
- **Compatible Atoms:**
  - `atom_updraft`: Updrafts naturally synergize with gliding, allowing players to gain height and extend their flight.
  - `atom_double_jump`: Often used in sequence; a double jump provides extra height before deploying the glider.
  - `atom_dash`: Mid-air dashes can be used before or after gliding to adjust positioning.
- **Incompatible Atoms:**
  - `atom_ground_pound`: Typically, initiating a ground pound immediately cancels the glide state, making them mutually exclusive in execution.
  - `atom_heavy_carry`: Carrying heavy objects usually disables the ability to deploy a glider.

## 8. Anti-Patterns
1. **Overpowered Gliding:** Making the glide speed too fast or the fall speed too slow without any resource cost can trivialize level design and platforming challenges, allowing players to skip intended content.
2. **Unresponsive Deployment:** Having a long animation or delay before the glider deploys can lead to frustrating deaths when players try to save themselves from a fall at the last second.
3. **Lack of Feedback:** Failing to provide clear visual or auditory cues when stamina is running low during a glide, resulting in unexpected and punishing falls.
